<?php
/**
 * Membership access control for Scent Freedom Club.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Membership
 */
class Oilmazing_SFC_Membership {

	const OPTION_KEY = 'oilmazing_sfc_membership_settings';

	const META_MANUAL_ACCESS = 'oilmazing_sfc_membership_active';

	const META_CLUB_PLAN_ID = 'oilmazing_sfc_club_plan_id';

	const META_CLUB_STARTED = 'oilmazing_sfc_club_membership_started';

	const META_CLUB_PENDING = 'oilmazing_sfc_membership_pending';

	const META_CLUB_EXPIRES = 'oilmazing_sfc_club_membership_expires';

	const META_CHECKOUT_RETURN = 'oilmazing_sfc_checkout_return_url';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_filter( 'rest_pre_dispatch', array( __CLASS__, 'guard_rest_routes' ), 10, 3 );

		if ( class_exists( 'WC_Subscriptions' ) ) {
			add_action( 'woocommerce_subscription_status_active', array( __CLASS__, 'on_subscription_active' ), 10, 1 );
			add_action( 'woocommerce_subscription_status_trialing', array( __CLASS__, 'on_subscription_active' ), 10, 1 );
		}

		add_action( 'woocommerce_payment_complete', array( __CLASS__, 'maybe_activate_club_after_order' ), 20, 1 );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'maybe_activate_club_after_order' ), 20, 1 );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'maybe_activate_club_after_order' ), 20, 1 );
		add_action( 'woocommerce_thankyou', array( __CLASS__, 'maybe_redirect_after_checkout' ), 5, 1 );
		add_action( 'template_redirect', array( __CLASS__, 'guard_dashboard_page_access' ), 9 );
		add_action( 'arm_after_add_new_user', array( __CLASS__, 'on_armember_user_update' ), 20, 2 );
		add_action( 'arm_after_user_plan_change', array( __CLASS__, 'on_armember_user_update' ), 20, 2 );
	}

	/**
	 * Settings with defaults.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_settings() {
		$defaults = array(
			'require_membership'  => 'yes',
			'product_ids'         => array(),
			'membership_page_url' => '',
			'club_plans'          => self::default_club_plans(),
			'benefits'            => array(
				__( 'Personal scent calendar planning', 'oilmazing-sfc' ),
				__( 'Exclusive member deals and flash offers', 'oilmazing-sfc' ),
				__( 'Member perks, coupons, and loyalty rewards', 'oilmazing-sfc' ),
				__( 'Community hub and member messaging', 'oilmazing-sfc' ),
				__( 'Refer-a-friend rewards', 'oilmazing-sfc' ),
			),
		);

		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		return wp_parse_args( $stored, $defaults );
	}

	/**
	 * Settings with defaults applied and club plan fallback.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_resolved_settings() {
		$settings = self::get_settings();

		if ( empty( $settings['club_plans'] ) || ! is_array( $settings['club_plans'] ) ) {
			$settings['club_plans'] = self::default_club_plans();
		} else {
			foreach ( $settings['club_plans'] as $index => $plan ) {
				if ( ! is_array( $plan ) ) {
					continue;
				}

				if ( 'sfc-monthly' === sanitize_key( (string) ( $plan['id'] ?? '' ) ) && (float) ( $plan['price'] ?? 0 ) <= 0 ) {
					$settings['club_plans'][ $index ]['price'] = '29.99';
				}
			}
		}

		return $settings;
	}

	/**
	 * Whether membership is required for club features.
	 *
	 * @return bool
	 */
	public static function membership_required() {
		$settings = self::get_settings();

		return 'yes' === $settings['require_membership'];
	}

	/**
	 * Check if user has active paid membership.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	public static function has_active_membership( $user_id = 0 ) {
		$user_id = $user_id ? (int) $user_id : get_current_user_id();

		if ( $user_id <= 0 ) {
			return false;
		}

		if ( ! self::membership_required() ) {
			return true;
		}

		if ( user_can( $user_id, 'manage_options' ) || user_can( $user_id, 'manage_woocommerce' ) ) {
			return true;
		}

		if ( 'yes' === get_user_meta( $user_id, self::META_MANUAL_ACCESS, true ) ) {
			return true;
		}

		if ( self::has_club_membership( $user_id ) ) {
			return true;
		}

		$status = self::get_membership_status( $user_id );

		return ! empty( $status['active'] );
	}

	/**
	 * Resolve membership status for a user.
	 *
	 * @param int $user_id User ID.
	 * @return array<string, mixed>
	 */
	public static function get_membership_status( $user_id = 0 ) {
		$user_id = $user_id ? (int) $user_id : get_current_user_id();

		$payload = array(
			'active'          => false,
			'status'          => 'none',
			'label'           => __( 'No active membership', 'oilmazing-sfc' ),
			'plan'            => '',
			'renewal_date'    => '',
			'manage_url'      => self::get_account_subscriptions_url(),
			'can_purchase'    => true,
		);

		if ( $user_id <= 0 ) {
			return $payload;
		}

		self::sync_membership_from_subscriptions( $user_id );

		$pending_plan = (string) get_user_meta( $user_id, self::META_CLUB_PENDING, true );
		if ( '' !== $pending_plan && ! self::user_has_active_membership_subscription( $user_id ) ) {
			$plan = self::get_club_plan_by_id( $pending_plan );

			return array(
				'active'       => false,
				'status'       => 'pending',
				'label'        => __( 'Membership payment pending', 'oilmazing-sfc' ),
				'plan'         => $plan ? (string) $plan['name'] : '',
				'renewal_date' => '',
				'manage_url'   => '',
				'can_purchase' => false,
			);
		}

		if ( self::has_club_membership( $user_id ) ) {
			$plan_id = (string) get_user_meta( $user_id, self::META_CLUB_PLAN_ID, true );
			$plan    = self::get_club_plan_by_id( $plan_id );
			$started = (string) get_user_meta( $user_id, self::META_CLUB_STARTED, true );
			$expires = (string) get_user_meta( $user_id, self::META_CLUB_EXPIRES, true );
			$renewal = '';

			if ( '' !== $expires ) {
				$renewal = gmdate( 'M j, Y', strtotime( $expires . ' UTC' ) );
			} elseif ( $plan && ! empty( $plan['interval'] ) && 'lifetime' !== $plan['interval'] && $started ) {
				$timestamp = strtotime( $started . ' UTC' );
				if ( $timestamp ) {
					$modifier = 'year' === $plan['interval'] ? '+1 year' : '+1 month';
					$renewal  = gmdate( 'M j, Y', strtotime( $modifier, $timestamp ) );
				}
			}

			return array(
				'active'       => true,
				'status'       => 'club',
				'label'        => __( 'Active Scent Freedom Club membership', 'oilmazing-sfc' ),
				'plan'         => $plan ? (string) $plan['name'] : __( 'Scent Freedom Club', 'oilmazing-sfc' ),
				'renewal_date' => $renewal,
				'manage_url'   => '',
				'can_purchase' => false,
			);
		}

		if ( function_exists( 'wcs_get_users_subscriptions' ) ) {
			$subscriptions = wcs_get_users_subscriptions( $user_id );

			foreach ( (array) $subscriptions as $subscription ) {
				if ( ! is_object( $subscription ) || ! method_exists( $subscription, 'get_status' ) ) {
					continue;
				}

				$sub_status = $subscription->get_status();
				$plan_name  = self::get_subscription_plan_name( $subscription );

				if ( in_array( $sub_status, array( 'active', 'trialing' ), true ) ) {
					$renewal = method_exists( $subscription, 'get_date' )
						? $subscription->get_date( 'next_payment' )
						: '';

					return array(
						'active'       => true,
						'status'       => $sub_status,
						'label'        => 'trialing' === $sub_status
							? __( 'Trial membership active', 'oilmazing-sfc' )
							: __( 'Active membership', 'oilmazing-sfc' ),
						'plan'         => $plan_name,
						'renewal_date' => $renewal ? gmdate( 'M j, Y', strtotime( $renewal ) ) : '',
						'manage_url'   => self::get_account_subscriptions_url(),
						'can_purchase' => false,
					);
				}

				if ( 'on-hold' === $sub_status ) {
					return array(
						'active'       => false,
						'status'       => 'on-hold',
						'label'        => __( 'Membership on hold — update payment to restore access', 'oilmazing-sfc' ),
						'plan'         => $plan_name,
						'renewal_date' => '',
						'manage_url'   => self::get_account_subscriptions_url(),
						'can_purchase' => false,
					);
				}

				if ( in_array( $sub_status, array( 'pending', 'pending-cancel' ), true ) ) {
					return array(
						'active'       => false,
						'status'       => $sub_status,
						'label'        => __( 'Membership pending activation', 'oilmazing-sfc' ),
						'plan'         => $plan_name,
						'renewal_date' => '',
						'manage_url'   => self::get_account_subscriptions_url(),
						'can_purchase' => false,
					);
				}
			}
		}

		if ( self::has_armember_membership( $user_id ) ) {
			return array(
				'active'       => true,
				'status'       => 'armember',
				'label'        => __( 'Active membership', 'oilmazing-sfc' ),
				'plan'         => __( 'Scent Freedom Club', 'oilmazing-sfc' ),
				'renewal_date' => '',
				'manage_url'   => self::get_account_subscriptions_url(),
				'can_purchase' => false,
			);
		}

		return $payload;
	}

	/**
	 * Subscription summary for the member billing tab and REST /user payload.
	 *
	 * @param int $user_id User ID.
	 * @return array<string, mixed>
	 */
	public static function get_subscription_summary( $user_id = 0 ) {
		$user_id = $user_id ? (int) $user_id : get_current_user_id();
		$status  = self::get_membership_status( $user_id );
		$plan_id = (string) get_user_meta( $user_id, self::META_CLUB_PLAN_ID, true );
		$plan    = self::get_club_plan_by_id( $plan_id );

		if ( ! $plan && ! empty( $status['plan'] ) ) {
			foreach ( self::get_enabled_club_plans() as $candidate ) {
				if ( ! empty( $candidate['name'] ) && (string) $candidate['name'] === (string) $status['plan'] ) {
					$plan = $candidate;
					break;
				}
			}
		}

		if ( ! $plan && ! empty( $status['active'] ) ) {
			$enabled = self::get_enabled_club_plans();
			$plan    = ! empty( $enabled[0] ) ? $enabled[0] : null;
		}

		if ( ! $plan && self::has_active_membership( $user_id ) && empty( $status['active'] ) ) {
			$enabled = self::get_enabled_club_plans();
			$plan    = ! empty( $enabled[0] ) ? $enabled[0] : null;
			if ( $plan ) {
				$status['active'] = true;
				$status['status'] = 'active';
				$status['label']  = user_can( $user_id, 'manage_options' )
					? __( 'Administrator access', 'oilmazing-sfc' )
					: __( 'Active membership', 'oilmazing-sfc' );
				$status['plan']   = (string) $plan['name'];
			}
		}

		$price    = $plan ? max( 0, (float) ( $plan['price'] ?? 0 ) ) : 0;
		$interval = $plan ? sanitize_key( (string) ( $plan['interval'] ?? 'month' ) ) : 'month';
		$symbol   = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '$';

		$frequency_map = array(
			'month'    => __( 'Every 30 Days', 'oilmazing-sfc' ),
			'year'     => __( 'Every 12 Months', 'oilmazing-sfc' ),
			'lifetime' => __( 'Lifetime access', 'oilmazing-sfc' ),
		);

		$interval_suffix = array(
			'month'    => '/mo',
			'year'     => '/yr',
			'lifetime' => '',
		);

		return array(
			'plan'             => (string) ( $status['plan'] ?: ( $plan['name'] ?? '' ) ),
			'description'      => $plan ? (string) ( $plan['description'] ?? '' ) : '',
			'price'            => $price,
			'price_html'       => $price > 0 ? $symbol . number_format_i18n( $price, 2 ) : '',
			'interval_suffix'  => $interval_suffix[ $interval ] ?? '/mo',
			'status'           => ! empty( $status['active'] ) ? 'active' : (string) ( $status['status'] ?? 'none' ),
			'status_label'     => (string) ( $status['label'] ?? __( 'No active membership', 'oilmazing-sfc' ) ),
			'billing'          => (string) ( $status['renewal_date'] ?? '' ),
			'frequency'        => $frequency_map[ $interval ] ?? __( 'Every 30 Days', 'oilmazing-sfc' ),
			'manage_url'       => (string) ( $status['manage_url'] ?? '' ),
		);
	}

	/**
	 * Get sellable membership plans.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_plans() {
		$club_plans = self::get_club_plans_for_display();

		if ( ! empty( $club_plans ) ) {
			return apply_filters( 'oilmazing_sfc_membership_plans', $club_plans );
		}

		$woocommerce_plans = self::get_woocommerce_plans_for_display();
		if ( ! empty( $woocommerce_plans ) ) {
			return apply_filters( 'oilmazing_sfc_membership_plans', $woocommerce_plans );
		}

		return apply_filters( 'oilmazing_sfc_membership_plans', array() );
	}

	/**
	 * Built-in Scent Freedom Club plans (no WooCommerce required).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_club_plans_for_display() {
		$plans = array();

		foreach ( self::get_enabled_club_plans() as $plan ) {
			$plans[] = self::format_club_plan( $plan );
		}

		return $plans;
	}

	/**
	 * Legacy WooCommerce subscription plans (optional fallback).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function get_woocommerce_plans_for_display() {
		$settings = self::get_settings();
		$ids      = array_filter( array_map( 'absint', (array) $settings['product_ids'] ) );

		if ( empty( $ids ) ) {
			return array();
		}

		$plans = array();

		foreach ( self::get_membership_products() as $product ) {
			if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
				continue;
			}

			$formatted                 = self::format_plan_product( $product );
			$formatted['is_club_plan'] = false;
			$plans[]                   = $formatted;
		}

		return $plans;
	}

	/**
	 * Explain why no plans are available on the membership gate.
	 *
	 * @return array{reason:string,message:string}
	 */
	public static function get_plans_empty_info() {
		if ( ! empty( self::get_enabled_club_plans() ) && empty( self::get_club_plans_for_display() ) ) {
			return array(
				'reason'  => 'club_plans_disabled',
				'message' => __( 'Membership plans are turned off in admin. Please contact support.', 'oilmazing-sfc' ),
			);
		}

		if ( empty( self::get_enabled_club_plans() ) ) {
			return array(
				'reason'  => 'no_club_plans',
				'message' => __( 'No Scent Freedom Club plans are available yet. Please contact support.', 'oilmazing-sfc' ),
			);
		}

		return array(
			'reason'  => 'not_purchasable',
			'message' => __( 'Membership plans are temporarily unavailable. Please contact support.', 'oilmazing-sfc' ),
		);
	}

	/**
	 * Render membership purchase gate.
	 *
	 * @param array<string, string> $args Args.
	 * @return string
	 */
	public static function render_gate( $args = array() ) {
		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			return '';
		}

		if ( self::has_active_membership( $user_id ) ) {
			wp_safe_redirect( self::get_dashboard_url( $args['redirect'] ?? '' ) );
			exit;
		}

		self::enqueue_assets(
			array(
				'status' => self::get_membership_status( $user_id ),
				'plans'  => self::get_plans(),
			)
		);

		return oilmazing_sfc_render_template(
			'membership-gate.php',
			array(
				'status'      => self::get_membership_status( $user_id ),
				'plans'       => self::get_plans(),
				'benefits'    => self::get_settings()['benefits'],
				'user'        => wp_get_current_user(),
				'plans_empty' => self::get_plans_empty_info(),
			)
		);
	}

	/**
	 * Register REST routes.
	 */
	public static function register_routes() {
		if ( ! defined( 'OILMAZING_SFC_REST_NAMESPACE' ) ) {
			return;
		}

		register_rest_route(
			OILMAZING_SFC_REST_NAMESPACE,
			'/membership',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'rest_get_membership' ),
					'permission_callback' => 'is_user_logged_in',
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'rest_subscribe' ),
					'permission_callback' => 'is_user_logged_in',
				),
			)
		);
	}

	/**
	 * GET /membership
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_get_membership() {
		$user_id = get_current_user_id();

		return rest_ensure_response(
			array(
				'success'    => true,
				'active'     => self::has_active_membership( $user_id ),
				'membership' => self::get_membership_status( $user_id ),
				'plans'      => self::get_plans(),
				'benefits'   => self::get_settings()['benefits'],
			)
		);
	}

	/**
	 * POST /membership — add selected plan to cart.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_subscribe( WP_REST_Request $request ) {
		$user_id  = get_current_user_id();
		$plan_id  = sanitize_key( (string) $request->get_param( 'plan_id' ) );
		$body     = $request->get_json_params();
		$plan_key = $plan_id;

		if ( '' === $plan_key && is_array( $body ) && ! empty( $body['plan_id'] ) ) {
			$plan_key = sanitize_key( (string) $body['plan_id'] );
		}

		if ( '' !== $plan_key ) {
			return self::subscribe_club_plan( $user_id, $plan_key );
		}

		$product_id = absint( $request->get_param( 'product_id' ) );
		if ( is_array( $body ) && ! $product_id && ! empty( $body['product_id'] ) ) {
			$product_id = absint( $body['product_id'] );
		}

		if ( ! $product_id ) {
			return new WP_Error(
				'oilmazing_sfc_invalid_plan',
				__( 'Please choose a valid membership plan.', 'oilmazing-sfc' ),
				array( 'status' => 400 )
			);
		}

		return self::start_woocommerce_checkout( $user_id, '', $product_id );
	}

	/**
	 * Add a WooCommerce membership product to cart and return checkout URL.
	 *
	 * @param int    $user_id User ID.
	 * @param string $plan_id Club plan slug for pending activation.
	 * @param int    $product_id WooCommerce product ID.
	 * @return WP_REST_Response|WP_Error
	 */
	private static function start_woocommerce_checkout( $user_id, $plan_id, $product_id ) {
		$user_id    = (int) $user_id;
		$product_id = absint( $product_id );
		$plan_id    = sanitize_key( (string) $plan_id );

		if ( ! class_exists( 'WooCommerce' ) ) {
			return new WP_Error(
				'oilmazing_sfc_wc_missing',
				__( 'WooCommerce checkout is not available for this plan.', 'oilmazing-sfc' ),
				array( 'status' => 500 )
			);
		}

		if ( ! self::is_membership_product( $product_id ) ) {
			return new WP_Error(
				'oilmazing_sfc_invalid_plan',
				__( 'Please choose a valid membership plan.', 'oilmazing-sfc' ),
				array( 'status' => 400 )
			);
		}

		if ( null === WC()->cart ) {
			wc_load_cart();
		}

		if ( '' !== $plan_id ) {
			update_user_meta( $user_id, self::META_CLUB_PENDING, $plan_id );
			delete_user_meta( $user_id, self::META_MANUAL_ACCESS );
			delete_user_meta( $user_id, self::META_CLUB_PLAN_ID );
		}

		update_user_meta( $user_id, self::META_CHECKOUT_RETURN, esc_url_raw( self::get_dashboard_url() ) );

		WC()->cart->empty_cart();

		$added = WC()->cart->add_to_cart( $product_id, 1 );
		if ( ! $added ) {
			return new WP_Error(
				'oilmazing_sfc_subscribe_failed',
				__( 'Could not start checkout for this membership plan.', 'oilmazing-sfc' ),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response(
			array(
				'success'      => true,
				'message'      => __( 'Continue to payment to activate your Scent Freedom Club membership.', 'oilmazing-sfc' ),
				'checkout_url' => wc_get_checkout_url(),
				'pending'      => '' !== $plan_id,
			)
		);
	}

	/**
	 * Join a built-in Scent Freedom Club plan.
	 *
	 * @param int    $user_id User ID.
	 * @param string $plan_id Plan slug.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function subscribe_club_plan( $user_id, $plan_id ) {
		$user_id = (int) $user_id;
		$plan    = self::get_club_plan_by_id( $plan_id );

		if ( ! $plan || 'yes' !== ( $plan['enabled'] ?? 'yes' ) ) {
			return new WP_Error(
				'oilmazing_sfc_invalid_plan',
				__( 'Please choose a valid membership plan.', 'oilmazing-sfc' ),
				array( 'status' => 400 )
			);
		}

		$price        = (float) ( $plan['price'] ?? 0 );
		$checkout_url = ! empty( $plan['checkout_url'] ) ? esc_url_raw( $plan['checkout_url'] ) : '';

		if ( $price > 0 && '' === $checkout_url ) {
			$product_id = self::resolve_club_plan_product_id( $plan );
			if ( $product_id > 0 ) {
				return self::start_woocommerce_checkout( $user_id, $plan_id, $product_id );
			}

			return new WP_Error(
				'oilmazing_sfc_payment_unconfigured',
				__( 'This membership plan is not ready for checkout yet. Add a payment URL or WooCommerce product in Club Membership settings.', 'oilmazing-sfc' ),
				array( 'status' => 503 )
			);
		}

		if ( $price > 0 && '' !== $checkout_url ) {
			update_user_meta( $user_id, self::META_CLUB_PENDING, $plan_id );
			delete_user_meta( $user_id, self::META_MANUAL_ACCESS );
			delete_user_meta( $user_id, self::META_CLUB_PLAN_ID );
			update_user_meta( $user_id, self::META_CHECKOUT_RETURN, esc_url_raw( self::get_dashboard_url() ) );

			return rest_ensure_response(
				array(
					'success'      => true,
					'message'      => __( 'Continue to payment to activate your Scent Freedom Club membership.', 'oilmazing-sfc' ),
					'checkout_url' => $checkout_url,
					'pending'      => true,
				)
			);
		}

		self::activate_club_membership( $user_id, $plan_id );

		return rest_ensure_response(
			array(
				'success'       => true,
				'message'       => __( 'Welcome to Scent Freedom Club! Your membership is now active.', 'oilmazing-sfc' ),
				'dashboard_url' => self::get_dashboard_url(),
				'active'        => true,
			)
		);
	}

	/**
	 * Activate a built-in club membership for a user.
	 *
	 * @param int    $user_id User ID.
	 * @param string $plan_id Plan slug.
	 */
	public static function activate_club_membership( $user_id, $plan_id ) {
		$user_id = (int) $user_id;
		$plan_id = sanitize_key( $plan_id );

		if ( $user_id <= 0 || '' === $plan_id ) {
			return;
		}

		$now  = current_time( 'mysql', true );
		$plan = self::get_club_plan_by_id( $plan_id );

		update_user_meta( $user_id, self::META_CLUB_PLAN_ID, $plan_id );
		update_user_meta( $user_id, self::META_MANUAL_ACCESS, 'yes' );
		update_user_meta( $user_id, self::META_CLUB_STARTED, $now );
		update_user_meta( $user_id, 'oilmazing_sfc_tier', __( 'Gold Member', 'oilmazing-sfc' ) );
		delete_user_meta( $user_id, self::META_CLUB_PENDING );

		$interval = $plan ? sanitize_key( (string) ( $plan['interval'] ?? 'month' ) ) : 'month';
		if ( 'lifetime' === $interval ) {
			delete_user_meta( $user_id, self::META_CLUB_EXPIRES );
		} else {
			$modifier = 'year' === $interval ? '+1 year' : '+1 month';
			$expires  = gmdate( 'Y-m-d H:i:s', strtotime( $modifier, strtotime( $now . ' UTC' ) ) );
			update_user_meta( $user_id, self::META_CLUB_EXPIRES, $expires );
		}
	}

	/**
	 * @param int $user_id User ID.
	 * @return bool
	 */
	public static function has_club_membership( $user_id ) {
		$user_id = (int) $user_id;

		if ( $user_id <= 0
			|| 'yes' !== get_user_meta( $user_id, self::META_MANUAL_ACCESS, true )
			|| '' === (string) get_user_meta( $user_id, self::META_CLUB_PLAN_ID, true ) ) {
			return false;
		}

		$expires = (string) get_user_meta( $user_id, self::META_CLUB_EXPIRES, true );
		if ( '' !== $expires && strtotime( $expires . ' UTC' ) < time() ) {
			return false;
		}

		return true;
	}

	/**
	 * Default built-in club plans.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function default_club_plans() {
		return array(
			array(
				'id'           => 'sfc-monthly',
				'name'         => __( 'Scent Freedom Club Monthly', 'oilmazing-sfc' ),
				'description'  => __( 'Full access to deals, perks, calendar planning, community, and member messaging.', 'oilmazing-sfc' ),
				'price'        => '29.99',
				'interval'     => 'month',
				'featured'     => 'yes',
				'enabled'      => 'yes',
				'checkout_url' => '',
				'product_id'   => 0,
			),
		);
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_enabled_club_plans() {
		$settings = self::get_resolved_settings();
		$plans    = isset( $settings['club_plans'] ) && is_array( $settings['club_plans'] ) ? $settings['club_plans'] : self::default_club_plans();
		$enabled  = array();

		foreach ( $plans as $plan ) {
			if ( ! is_array( $plan ) ) {
				continue;
			}

			if ( isset( $plan['enabled'] ) && 'yes' !== $plan['enabled'] ) {
				continue;
			}

			if ( empty( $plan['name'] ) ) {
				continue;
			}

			$enabled[] = $plan;
		}

		return $enabled;
	}

	/**
	 * @param string $plan_id Plan slug.
	 * @return array<string, mixed>|null
	 */
	public static function get_club_plan_by_id( $plan_id ) {
		$plan_id = sanitize_key( (string) $plan_id );
		if ( '' === $plan_id ) {
			return null;
		}

		foreach ( self::get_enabled_club_plans() as $plan ) {
			if ( sanitize_key( (string) ( $plan['id'] ?? '' ) ) === $plan_id ) {
				return $plan;
			}
		}

		$settings = self::get_resolved_settings();
		$plans    = isset( $settings['club_plans'] ) && is_array( $settings['club_plans'] ) ? $settings['club_plans'] : array();

		foreach ( $plans as $plan ) {
			if ( is_array( $plan ) && sanitize_key( (string) ( $plan['id'] ?? '' ) ) === $plan_id ) {
				return $plan;
			}
		}

		return null;
	}

	/**
	 * @param array<string, mixed> $plan Plan settings.
	 * @return array<string, mixed>
	 */
	private static function format_club_plan( $plan ) {
		$price    = max( 0, (float) ( $plan['price'] ?? 0 ) );
		$interval = sanitize_key( (string) ( $plan['interval'] ?? 'month' ) );
		$symbol   = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '$';

		if ( $price <= 0 ) {
			$price_html = __( 'Free', 'oilmazing-sfc' );
		} else {
			$price_html = $symbol . number_format_i18n( $price, 2 );
		}

		$interval_labels = array(
			'month'    => __( 'month', 'oilmazing-sfc' ),
			'year'     => __( 'year', 'oilmazing-sfc' ),
			'lifetime' => __( 'lifetime', 'oilmazing-sfc' ),
		);

		return array(
			'id'           => sanitize_key( (string) ( $plan['id'] ?? 'sfc-plan' ) ),
			'name'         => (string) $plan['name'],
			'description'  => (string) ( $plan['description'] ?? '' ),
			'price_html'   => $price_html,
			'price'        => $price,
			'interval'     => $interval_labels[ $interval ] ?? $interval,
			'permalink'    => '',
			'featured'     => 'yes' === ( $plan['featured'] ?? '' ),
			'is_club_plan' => true,
		);
	}

	/**
	 * Block premium REST routes until membership is active.
	 *
	 * @param mixed           $result  Response.
	 * @param WP_REST_Server  $server  Server.
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public static function guard_rest_routes( $result, $server, $request ) {
		unset( $server );

		if ( ! defined( 'OILMAZING_SFC_REST_NAMESPACE' ) ) {
			return $result;
		}

		if ( ! $request instanceof WP_REST_Request ) {
			return $result;
		}

		$route = (string) $request->get_route();
		if ( false === strpos( $route, '/' . OILMAZING_SFC_REST_NAMESPACE . '/' ) ) {
			return $result;
		}

		$allowed = array(
			'/health',
			'/auth/login',
			'/auth/register',
			'/membership',
		);

		foreach ( $allowed as $path ) {
			if ( false !== strpos( $route, $path ) ) {
				return $result;
			}
		}

		if ( ! is_user_logged_in() || self::has_active_membership() ) {
			return $result;
		}

		return new WP_Error(
			'oilmazing_sfc_membership_required',
			__( 'An active Scent Freedom Club membership is required to access this feature.', 'oilmazing-sfc' ),
			array(
				'status'     => 403,
				'membership' => self::get_membership_status(),
				'plans'      => self::get_plans(),
			)
		);
	}

	/**
	 * Activate pending club membership after a WooCommerce order is paid.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function maybe_activate_club_after_order( $order_id ) {
		$order_id = absint( $order_id );
		if ( $order_id <= 0 || ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$user_id = (int) $order->get_user_id();
		if ( $user_id <= 0 ) {
			return;
		}

		if ( ! in_array( $order->get_status(), array( 'processing', 'completed', 'on-hold' ), true ) ) {
			return;
		}

		if ( ! self::order_contains_membership_product( $order ) ) {
			return;
		}

		$pending_plan = sanitize_key( (string) get_user_meta( $user_id, self::META_CLUB_PENDING, true ) );
		$plan_id      = '' !== $pending_plan ? $pending_plan : 'sfc-monthly';

		self::activate_club_membership( $user_id, $plan_id );
	}

	/**
	 * Resolve a WooCommerce product for a built-in club plan.
	 *
	 * @param array<string, mixed> $plan Club plan settings.
	 * @return int
	 */
	private static function resolve_club_plan_product_id( $plan ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return 0;
		}

		$configured_id = absint( $plan['product_id'] ?? 0 );
		if ( $configured_id > 0 ) {
			$product = wc_get_product( $configured_id );
			if ( self::is_sellable_membership_product( $product ) ) {
				$uses_wcs_product = $product instanceof WC_Product
					&& $product->is_type( array( 'subscription', 'subscription_variation', 'variable-subscription' ) );

				if ( ! $uses_wcs_product || class_exists( 'WC_Subscriptions' ) ) {
					return $configured_id;
				}
			}
		}

		$products     = self::prefer_simple_membership_products(
			self::expand_purchasable_products( self::get_membership_products() )
		);
		$target_price = max( 0, (float) ( $plan['price'] ?? 0 ) );

		if ( empty( $products ) ) {
			return self::ensure_club_checkout_product( $plan );
		}

		if ( $target_price > 0 ) {
			foreach ( $products as $product ) {
				if ( ! $product instanceof WC_Product ) {
					continue;
				}

				if ( abs( (float) $product->get_price() - $target_price ) < 0.02 ) {
					return (int) $product->get_id();
				}
			}
		}

		$first = reset( $products );

		if ( $first instanceof WC_Product ) {
			return (int) $first->get_id();
		}

		return self::ensure_club_checkout_product( $plan );
	}

	/**
	 * Redirect to club dashboard after membership checkout.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function maybe_redirect_after_checkout( $order_id ) {
		$order_id = absint( $order_id );
		if ( $order_id <= 0 || ! is_user_logged_in() || ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order || (int) $order->get_user_id() !== get_current_user_id() ) {
			return;
		}

		if ( ! self::order_contains_membership_product( $order ) ) {
			return;
		}

		self::maybe_activate_club_after_order( $order_id );
		self::sync_membership_from_subscriptions( (int) $order->get_user_id() );

		if ( ! self::has_active_membership( (int) $order->get_user_id() ) ) {
			return;
		}

		$user_id = get_current_user_id();
		$target  = (string) get_user_meta( $user_id, self::META_CHECKOUT_RETURN, true );
		delete_user_meta( $user_id, self::META_CHECKOUT_RETURN );

		if ( '' === $target ) {
			$target = self::get_dashboard_url();
		}

		if ( $target ) {
			wp_safe_redirect( $target );
			exit;
		}
	}

	/**
	 * Send logged-in non-members to the subscribe screen before the member dashboard.
	 */
	public static function guard_dashboard_page_access() {
		if ( ! is_user_logged_in() || self::has_active_membership() || ! self::membership_required() ) {
			return;
		}

		$page_id = self::find_dashboard_page_id();
		if ( $page_id <= 0 || ! is_page( $page_id ) ) {
			return;
		}

		$subscribe_url = self::get_subscribe_url();
		$dashboard_url = self::get_dashboard_url();

		if ( untrailingslashit( $subscribe_url ) === untrailingslashit( $dashboard_url ) ) {
			return;
		}

		wp_safe_redirect( $subscribe_url );
		exit;
	}

	/**
	 * Sync tier meta when a subscription becomes active.
	 *
	 * @param WC_Subscription $subscription Subscription.
	 */
	public static function on_subscription_active( $subscription ) {
		if ( ! is_object( $subscription ) || ! method_exists( $subscription, 'get_user_id' ) ) {
			return;
		}

		$user_id = (int) $subscription->get_user_id();
		if ( $user_id <= 0 || ! self::subscription_contains_membership_product( $subscription ) ) {
			return;
		}

		$pending_plan = sanitize_key( (string) get_user_meta( $user_id, self::META_CLUB_PENDING, true ) );
		$plan_id      = '' !== $pending_plan ? $pending_plan : 'sfc-monthly';

		if ( ! self::has_club_membership( $user_id ) || '' !== $pending_plan ) {
			self::activate_club_membership( $user_id, $plan_id );
			return;
		}

		update_user_meta( $user_id, 'oilmazing_sfc_tier', 'Gold Member' );
	}

	/**
	 * ARMember plan change hook.
	 *
	 * @param mixed $user_id User ID.
	 * @param mixed $plan_id Plan ID.
	 */
	public static function on_armember_user_update( $user_id, $plan_id = 0 ) {
		unset( $plan_id );
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return;
		}

		if ( self::has_armember_membership( $user_id ) ) {
			update_user_meta( $user_id, 'oilmazing_sfc_tier', 'Gold Member' );
		}
	}

	/**
	 * Enqueue membership gate assets.
	 *
	 * @param array<string, mixed> $context Context.
	 */
	public static function enqueue_assets( $context = array() ) {
		wp_enqueue_style(
			'oilmazing-sfc-auth-fonts',
			'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap',
			array(),
			null
		);

		wp_enqueue_style(
			'font-awesome-6',
			'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
			array(),
			'6.4.0'
		);

		wp_enqueue_style(
			'oilmazing-sfc-membership-gate',
			OILMAZING_SFC_AUTH_URL . 'assets/css/membership-gate.css',
			array( 'oilmazing-sfc-auth-fonts' ),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_enqueue_script(
			'oilmazing-sfc-membership-gate',
			OILMAZING_SFC_AUTH_URL . 'assets/js/membership-gate.js',
			array(),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		wp_localize_script(
			'oilmazing-sfc-membership-gate',
			'oilmazingSfcMembership',
			array(
				'restUrl' => esc_url_raw( rest_url( OILMAZING_SFC_REST_NAMESPACE . '/' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'context' => $context,
				'i18n'    => array(
					'loading'  => __( 'Activating membership...', 'oilmazing-sfc' ),
					'error'    => __( 'Could not join the club. Please try again.', 'oilmazing-sfc' ),
					'selected' => __( 'Selected plan', 'oilmazing-sfc' ),
					'join'     => __( 'Join Scent Freedom Club', 'oilmazing-sfc' ),
				),
			)
		);
	}

	/**
	 * @param WC_Subscription $subscription Subscription.
	 * @return string
	 */
	private static function get_subscription_plan_name( $subscription ) {
		if ( ! method_exists( $subscription, 'get_items' ) ) {
			return '';
		}

		foreach ( $subscription->get_items() as $item ) {
			if ( is_object( $item ) && method_exists( $item, 'get_name' ) ) {
				return (string) $item->get_name();
			}
		}

		return '';
	}

	/**
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private static function has_armember_membership( $user_id ) {
		if ( ! defined( 'ARM_VERSION' ) && ! defined( 'MEMBERSHIPLITE_VERSION' ) ) {
			return false;
		}

		if ( function_exists( 'arm_is_member' ) && arm_is_member( $user_id ) ) {
			return true;
		}

		$plans = get_user_meta( $user_id, 'arm_user_plan_ids', true );
		if ( empty( $plans ) ) {
			return false;
		}

		if ( function_exists( 'arm_user_has_plan' ) ) {
			foreach ( (array) $plans as $plan_id ) {
				if ( arm_user_has_plan( $user_id, $plan_id ) ) {
					return true;
				}
			}
			return false;
		}

		return true;
	}

	/**
	 * @return array<int, WC_Product>
	 */
	private static function get_membership_products() {
		return self::expand_purchasable_products( self::collect_membership_product_candidates() );
	}

	/**
	 * Gather membership product candidates before purchasability filtering.
	 *
	 * @return array<int, WC_Product>
	 */
	private static function collect_membership_product_candidates() {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return array();
		}

		$candidates = array();
		$seen       = array();

		$add_product = static function ( $product ) use ( &$candidates, &$seen ) {
			if ( ! $product instanceof WC_Product ) {
				return;
			}

			$id = (int) $product->get_id();
			if ( $id <= 0 || isset( $seen[ $id ] ) ) {
				return;
			}

			$seen[ $id ]       = true;
			$candidates[ $id ] = $product;
		};

		$settings = self::get_settings();
		$ids      = array_filter( array_map( 'absint', (array) $settings['product_ids'] ) );
		$ids      = array_values( array_filter( $ids ) );

		if ( empty( $ids ) ) {
			$ids = array_filter( array_map( 'absint', (array) apply_filters( 'oilmazing_sfc_membership_product_ids', array() ) ) );
		}

		foreach ( $ids as $id ) {
			$add_product( wc_get_product( $id ) );
		}

		$club_plans = isset( $settings['club_plans'] ) && is_array( $settings['club_plans'] ) ? $settings['club_plans'] : array();
		foreach ( $club_plans as $plan ) {
			if ( ! is_array( $plan ) || empty( $plan['product_id'] ) ) {
				continue;
			}

			$add_product( wc_get_product( absint( $plan['product_id'] ) ) );
		}

		if ( ! empty( $candidates ) ) {
			return array_values( $candidates );
		}

		if ( ! function_exists( 'wc_get_products' ) ) {
			return array();
		}

		$query_sets = array(
			array(
				'status' => array( 'publish' ),
				'limit'  => 12,
				'type'   => array( 'simple' ),
				'tag'    => array( 'scent-freedom-club', 'sfc-membership', 'membership' ),
			),
			array(
				'status'   => array( 'publish' ),
				'limit'    => 12,
				'type'     => array( 'simple' ),
				'category' => array( 'scent-freedom-club', 'sfc-membership', 'membership' ),
			),
			array(
				'status' => array( 'publish' ),
				'limit'  => 12,
				'type'   => array( 'simple' ),
				's'      => 'scent freedom club',
			),
		);

		foreach ( $query_sets as $query ) {
			$products = wc_get_products( $query );
			foreach ( (array) $products as $product ) {
				$add_product( $product );
			}

			if ( ! empty( $candidates ) ) {
				break;
			}
		}

		return array_values( $candidates );
	}

	/**
	 * Expand variable subscriptions into purchasable child plans.
	 *
	 * @param array<int, WC_Product> $products Product candidates.
	 * @return array<int, WC_Product>
	 */
	private static function expand_purchasable_products( $products ) {
		$plans = array();
		$seen  = array();

		foreach ( (array) $products as $product ) {
			if ( ! $product instanceof WC_Product ) {
				continue;
			}

			if ( $product->is_type( 'variable-subscription' ) ) {
				foreach ( (array) $product->get_children() as $child_id ) {
					$child = wc_get_product( (int) $child_id );
					if ( ! self::is_sellable_membership_product( $child ) ) {
						continue;
					}

					$child_id = (int) $child->get_id();
					if ( isset( $seen[ $child_id ] ) ) {
						continue;
					}

					$seen[ $child_id ] = true;
					$plans[]           = $child;
				}
				continue;
			}

			if ( ! self::is_sellable_membership_product( $product ) ) {
				continue;
			}

			$product_id = (int) $product->get_id();
			if ( isset( $seen[ $product_id ] ) ) {
				continue;
			}

			$seen[ $product_id ] = true;
			$plans[]             = $product;
		}

		return $plans;
	}

	/**
	 * @param WC_Product|null $product Product.
	 * @return bool
	 */
	private static function is_sellable_membership_product( $product ) {
		if ( ! $product instanceof WC_Product ) {
			return false;
		}

		if ( ! in_array( $product->get_status(), array( 'publish', 'private' ), true ) ) {
			return false;
		}

		if ( ! $product->is_purchasable() ) {
			return false;
		}

		return $product->is_type( array( 'subscription', 'subscription_variation', 'variable-subscription', 'simple' ) );
	}

	/**
	 * @param WC_Product $product Product.
	 * @return array<string, mixed>
	 */
	private static function format_plan_product( $product ) {
		$parent_id  = (int) $product->get_parent_id();
		$parent     = $parent_id > 0 ? wc_get_product( $parent_id ) : null;
		$label_id   = $parent_id > 0 ? $parent_id : (int) $product->get_id();
		$price_html = $product->get_price_html();
		$interval   = '';
		$name       = $product->get_name();

		if ( $parent instanceof WC_Product && $product->is_type( 'subscription_variation' ) ) {
			$name = $parent->get_name();
			if ( function_exists( 'wc_get_formatted_variation' ) ) {
				$variation_label = wc_get_formatted_variation( $product, true, false );
				if ( $variation_label ) {
					$name .= ' — ' . wp_strip_all_tags( $variation_label );
				}
			}
		}

		if ( function_exists( 'wcs_get_subscription_period_strings' ) && $product->is_type( array( 'subscription', 'subscription_variation', 'variable-subscription' ) ) ) {
			$period = method_exists( $product, 'get_subscription_period' ) ? $product->get_subscription_period() : 'month';
			$interval = wcs_get_subscription_period_strings( 1, $period );
		}

		$description_source = $product;
		if ( $parent instanceof WC_Product ) {
			$description_source = $parent;
		}

		return array(
			'id'          => $product->get_id(),
			'name'        => $name,
			'description' => wp_strip_all_tags( $description_source->get_short_description() ? $description_source->get_short_description() : $description_source->get_description() ),
			'price_html'  => $price_html,
			'price'       => (float) wc_get_price_to_display( $product ),
			'interval'    => $interval,
			'permalink'   => $product->get_permalink(),
			'featured'    => has_term( 'featured', 'product_tag', $label_id ),
		);
	}

	/**
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	private static function is_membership_product( $product_id ) {
		$product_id = (string) $product_id;
		if ( ! is_numeric( $product_id ) ) {
			return null !== self::get_club_plan_by_id( $product_id );
		}

		$product_id = absint( $product_id );
		if ( $product_id <= 0 ) {
			return false;
		}

		foreach ( self::get_plans() as $plan ) {
			if ( (string) $plan['id'] === (string) $product_id ) {
				return true;
			}
		}

		foreach ( self::get_resolved_settings()['club_plans'] as $plan ) {
			if ( is_array( $plan ) && absint( $plan['product_id'] ?? 0 ) === $product_id ) {
				return true;
			}
		}

		foreach ( self::expand_purchasable_products( self::get_membership_products() ) as $product ) {
			if ( $product instanceof WC_Product && (int) $product->get_id() === $product_id ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Resolve the membership subscribe / gate URL for logged-in non-members.
	 *
	 * @return string
	 */
	public static function get_subscribe_url() {
		if ( function_exists( 'wc_get_page_permalink' ) && function_exists( 'wc_get_endpoint_url' ) ) {
			$account_url = wc_get_page_permalink( 'myaccount' );

			if ( $account_url && class_exists( 'Oilmazing_SFC_My_Account' ) ) {
				return wc_get_endpoint_url( Oilmazing_SFC_My_Account::ENDPOINT, '', $account_url );
			}
		}

		return self::get_dashboard_url();
	}

	/**
	 * Resolve the member dashboard URL after join or checkout.
	 *
	 * @param string $requested Optional explicit redirect.
	 * @return string
	 */
	public static function get_dashboard_url( $requested = '' ) {
		$url = is_string( $requested ) ? trim( $requested ) : '';

		if ( $url && wp_validate_redirect( $url, false ) ) {
			return wp_validate_redirect( $url, home_url( '/' ) );
		}

		$settings = self::get_settings();
		if ( ! empty( $settings['membership_page_url'] ) ) {
			return esc_url_raw( $settings['membership_page_url'] );
		}

		$page_id = self::find_dashboard_page_id();
		if ( $page_id > 0 ) {
			return (string) get_permalink( $page_id );
		}

		return home_url( '/' );
	}

	/**
	 * Find a published page that renders the club dashboard shortcode.
	 *
	 * @return int
	 */
	private static function find_dashboard_page_id() {
		static $cached = null;

		if ( null !== $cached ) {
			return (int) $cached;
		}

		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		foreach ( (array) $pages as $page_id ) {
			$page_id = (int) $page_id;
			if ( $page_id <= 0 ) {
				continue;
			}

			$content = (string) get_post_field( 'post_content', $page_id );
			if ( has_shortcode( $content, 'oilmazing_sfc_dashboard' ) || has_shortcode( $content, 'scent_freedom_club' ) ) {
				$cached = $page_id;
				return (int) $cached;
			}

			$elementor = get_post_meta( $page_id, '_elementor_data', true );
			if ( is_string( $elementor ) && ( false !== strpos( $elementor, 'oilmazing_sfc_dashboard' ) || false !== strpos( $elementor, 'scent_freedom_club' ) ) ) {
				$cached = $page_id;
				return (int) $cached;
			}
		}

		$cached = 0;

		return 0;
	}

	/**
	 * Activate club meta when a WooCommerce subscription is already active.
	 *
	 * @param int $user_id User ID.
	 */
	private static function sync_membership_from_subscriptions( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 || ! function_exists( 'wcs_get_users_subscriptions' ) ) {
			return;
		}

		foreach ( wcs_get_users_subscriptions( $user_id ) as $subscription ) {
			if ( ! is_object( $subscription ) || ! method_exists( $subscription, 'get_status' ) ) {
				continue;
			}

			if ( ! in_array( $subscription->get_status(), array( 'active', 'trialing' ), true ) ) {
				continue;
			}

			if ( ! self::subscription_contains_membership_product( $subscription ) ) {
				continue;
			}

			$pending = sanitize_key( (string) get_user_meta( $user_id, self::META_CLUB_PENDING, true ) );
			$plan_id = '' !== $pending ? $pending : 'sfc-monthly';

			if ( ! self::has_club_membership( $user_id ) || '' !== $pending ) {
				self::activate_club_membership( $user_id, $plan_id );
			}

			return;
		}
	}

	/**
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private static function user_has_active_membership_subscription( $user_id ) {
		if ( ! function_exists( 'wcs_get_users_subscriptions' ) ) {
			return false;
		}

		foreach ( wcs_get_users_subscriptions( (int) $user_id ) as $subscription ) {
			if ( ! is_object( $subscription ) || ! method_exists( $subscription, 'get_status' ) ) {
				continue;
			}

			if ( ! in_array( $subscription->get_status(), array( 'active', 'trialing' ), true ) ) {
				continue;
			}

			if ( self::subscription_contains_membership_product( $subscription ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param WC_Subscription $subscription Subscription.
	 * @return bool
	 */
	private static function subscription_contains_membership_product( $subscription ) {
		if ( ! is_object( $subscription ) || ! method_exists( $subscription, 'get_items' ) ) {
			return false;
		}

		foreach ( $subscription->get_items() as $item ) {
			$product_id   = (int) $item->get_product_id();
			$variation_id = (int) $item->get_variation_id();
			$line_id      = $variation_id > 0 ? $variation_id : $product_id;

			if ( self::is_membership_product( $line_id ) || self::is_membership_product( $product_id ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param WC_Order $order Order.
	 * @return bool
	 */
	private static function order_contains_membership_product( $order ) {
		if ( ! is_object( $order ) || ! method_exists( $order, 'get_items' ) ) {
			return false;
		}

		foreach ( $order->get_items() as $item ) {
			$product_id   = (int) $item->get_product_id();
			$variation_id = (int) $item->get_variation_id();
			$line_id      = $variation_id > 0 ? $variation_id : $product_id;

			if ( self::is_membership_product( $line_id ) || self::is_membership_product( $product_id ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Create a hidden WooCommerce simple product for a club plan when none exists.
	 *
	 * @param array<string, mixed> $plan Club plan settings.
	 * @return int
	 */
	private static function ensure_club_checkout_product( $plan ) {
		if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_product' ) ) {
			return 0;
		}

		$plan_id = sanitize_key( (string) ( $plan['id'] ?? 'sfc-monthly' ) );
		$cached  = absint( get_option( 'oilmazing_sfc_plan_product_' . $plan_id, 0 ) );
		if ( $cached > 0 ) {
			$cached_product = wc_get_product( $cached );
			if ( $cached_product instanceof WC_Product_Simple && self::is_sellable_membership_product( $cached_product ) ) {
				return $cached;
			}
		}

		$price   = max( 0, (float) ( $plan['price'] ?? 29.99 ) );
		$name    = (string) ( $plan['name'] ?? __( 'Scent Freedom Club Monthly', 'oilmazing-sfc' ) );
		$product = new WC_Product_Simple();
		$product->set_name( $name );
		$product->set_status( 'publish' );
		$product->set_catalog_visibility( 'hidden' );
		$product->set_sold_individually( true );
		$product->set_description( (string) ( $plan['description'] ?? '' ) );
		$product->set_regular_price( (string) $price );

		$product_id = (int) $product->save();
		if ( $product_id <= 0 ) {
			return 0;
		}

		wp_set_object_terms( $product_id, 'scent-freedom-club', 'product_tag', true );
		update_option( 'oilmazing_sfc_plan_product_' . $plan_id, $product_id );
		self::persist_plan_product_id( $plan_id, $product_id );

		return $product_id;
	}

	/**
	 * Prefer one-time WooCommerce products over subscription products.
	 *
	 * @param array<int, WC_Product> $products Product candidates.
	 * @return array<int, WC_Product>
	 */
	private static function prefer_simple_membership_products( $products ) {
		$simple = array();
		$other  = array();

		foreach ( (array) $products as $product ) {
			if ( ! $product instanceof WC_Product ) {
				continue;
			}

			if ( $product->is_type( 'simple' ) ) {
				$simple[] = $product;
				continue;
			}

			$other[] = $product;
		}

		return ! empty( $simple ) ? $simple : $other;
	}

	/**
	 * Save a WooCommerce product ID on a built-in club plan.
	 *
	 * @param string $plan_id Plan slug.
	 * @param int    $product_id Product ID.
	 */
	private static function persist_plan_product_id( $plan_id, $product_id ) {
		$plan_id    = sanitize_key( $plan_id );
		$product_id = absint( $product_id );
		if ( '' === $plan_id || $product_id <= 0 ) {
			return;
		}

		$settings = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		if ( empty( $settings['club_plans'] ) || ! is_array( $settings['club_plans'] ) ) {
			return;
		}

		$changed = false;
		foreach ( $settings['club_plans'] as $index => $plan ) {
			if ( ! is_array( $plan ) ) {
				continue;
			}

			if ( sanitize_key( (string) ( $plan['id'] ?? '' ) ) !== $plan_id ) {
				continue;
			}

			$settings['club_plans'][ $index ]['product_id'] = $product_id;
			$changed = true;
			break;
		}

		if ( $changed ) {
			update_option( self::OPTION_KEY, $settings );
		}
	}

	/**
	 * @return string
	 */
	private static function get_account_subscriptions_url() {
		if ( function_exists( 'wc_get_account_endpoint_url' ) && function_exists( 'wc_get_page_permalink' ) ) {
			return wc_get_account_endpoint_url( 'subscriptions', '', wc_get_page_permalink( 'myaccount' ) );
		}

		return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/' );
	}
}
