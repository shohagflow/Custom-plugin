<?php
/**
 * Shortcode overrides and auth screen wiring.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Auth_Bootstrap
 */
class Oilmazing_SFC_Auth_Bootstrap {

	/**
	 * Register hooks.
	 */
	public static function init() {
		Oilmazing_SFC_Auth::init();
		Oilmazing_SFC_Membership::init();
		Oilmazing_SFC_Affiliate_Integration::init();
		Oilmazing_SFC_Admin_Notices::init();

		if ( is_admin() ) {
			Oilmazing_SFC_Membership_Admin::init();
			Oilmazing_SFC_Support_Admin::init();
			Oilmazing_SFC_Customer_Mail_Admin::init();
			Oilmazing_SFC_Quantity_Discount_Admin::init();
			Oilmazing_SFC_WebP_Admin::init();
			add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_menu_assets' ), 100 );
		}

		Oilmazing_SFC_Elementor_Compat::init();
		Oilmazing_SFC_Assets_Guard::init();
		Oilmazing_SFC_Compat_Patches::init();
		Oilmazing_SFC_Presence::init();
		Oilmazing_SFC_QR_Module::init();
		Oilmazing_SFC_Quantity_Discount::init();
		Oilmazing_SFC_WebP_Converter::init();
		Oilmazing_SFC_Cart_Summary_UI::init();
		Oilmazing_SFC_My_Account::init();

		add_action( 'init', array( __CLASS__, 'register_shortcodes' ), 20 );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_enqueue_dashboard_menu_assets' ), 1002 );
	}

	/**
	 * Replace default dashboard shortcodes with auth-aware versions.
	 */
	public static function register_shortcodes() {
		remove_shortcode( 'oilmazing_sfc_dashboard' );
		remove_shortcode( 'scent_freedom_club' );

		add_shortcode( 'oilmazing_sfc_dashboard', array( __CLASS__, 'render_dashboard' ) );
		add_shortcode( 'scent_freedom_club', array( __CLASS__, 'render_dashboard' ) );
		add_shortcode( 'oilmazing_sfc_auth', array( __CLASS__, 'render_auth' ) );
	}

	/**
	 * Render dashboard or auth screen.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function render_dashboard( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'require_login' => 'yes',
			),
			$atts,
			'oilmazing_sfc_dashboard'
		);

		if ( 'yes' === $atts['require_login'] && ! is_user_logged_in() ) {
			return Oilmazing_SFC_Auth::render_screen(
				array(
					'default_tab' => self::get_default_auth_tab(),
					'redirect'    => (string) get_permalink(),
					'context'     => 'dashboard',
				)
			);
		}

		if ( is_user_logged_in() && ! Oilmazing_SFC_Membership::has_active_membership() ) {
			return Oilmazing_SFC_Membership::render_gate(
				array(
					'redirect' => (string) get_permalink(),
				)
			);
		}

		Oilmazing_SFC_Assets::mark_dashboard_active();
		Oilmazing_SFC_Assets::enqueue_dashboard();
		self::enqueue_dashboard_menu_assets();

		return oilmazing_sfc_render_template( 'dashboard.php' );
	}

	/**
	 * Standalone auth shortcode.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function render_auth( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'default_tab' => self::get_default_auth_tab(),
				'redirect'    => '',
			),
			$atts,
			'oilmazing_sfc_auth'
		);

		if ( is_user_logged_in() ) {
			if ( ! Oilmazing_SFC_Membership::has_active_membership() ) {
				return Oilmazing_SFC_Membership::render_gate(
					array(
						'redirect' => $atts['redirect'],
					)
				);
			}

			$redirect = Oilmazing_SFC_Auth::resolve_redirect_url( $atts['redirect'] );
			return sprintf(
				'<div class="oilmazing-sfc-wc-account oilmazing-sfc-auth oilmazing-sfc-auth--signed-in"><p>%s</p><p><a class="oilmazing-sfc-wc-account__button" href="%s">%s</a></p></div>',
				esc_html__( 'You are already signed in.', 'oilmazing-sfc' ),
				esc_url( $redirect ),
				esc_html__( 'Go to dashboard', 'oilmazing-sfc' )
			);
		}

		return Oilmazing_SFC_Auth::render_screen(
			array(
				'default_tab' => in_array( $atts['default_tab'], array( 'login', 'register' ), true ) ? $atts['default_tab'] : 'login',
				'redirect'    => $atts['redirect'],
				'context'     => 'auth',
			)
		);
	}

	/**
	 * Add body class on auth screens.
	 *
	 * @param array<int,string> $classes Body classes.
	 * @return array<int,string>
	 */
	public static function body_class( $classes ) {
		if ( ! is_singular() ) {
			return $classes;
		}

		$post = get_queried_object();
		if ( ! $post instanceof WP_Post ) {
			return $classes;
		}

		$has_club_shortcode = has_shortcode( $post->post_content, 'oilmazing_sfc_auth' )
			|| has_shortcode( $post->post_content, 'oilmazing_sfc_dashboard' )
			|| has_shortcode( $post->post_content, 'scent_freedom_club' );

		if ( ! $has_club_shortcode && class_exists( 'Oilmazing_SFC_Elementor_Compat' ) ) {
			$has_club_shortcode = Oilmazing_SFC_Elementor_Compat::is_club_frontend_page();
		}

		if ( ! $has_club_shortcode ) {
			return $classes;
		}

		$classes[] = 'oilmazing-sfc-club-page';

		if ( ! is_user_logged_in() ) {
			$classes[] = 'oilmazing-sfc-auth-page';
			return $classes;
		}

		if ( ! Oilmazing_SFC_Membership::has_active_membership() ) {
			$classes[] = 'oilmazing-sfc-membership-page';
			return $classes;
		}

		$classes[] = 'oilmazing-sfc-dashboard-page';
		$classes[] = 'oilmazing-sfc-canvas-dashboard';

		return $classes;
	}

	/**
	 * Enqueue modern admin navigation styles.
	 *
	 * @param string $hook_suffix Admin page hook.
	 */
	public static function enqueue_admin_menu_assets( $hook_suffix = '' ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		$is_sfc_screen = ( function_exists( 'oilmazing_sfc_is_admin_screen' ) && oilmazing_sfc_is_admin_screen() )
			|| 'oilmazing-sfc-membership' === $page
			|| ( false !== strpos( (string) $hook_suffix, 'oilmazing-sfc' ) );

		if ( ! $is_sfc_screen ) {
			return;
		}

		if ( ! wp_style_is( 'oilmazing-sfc-admin', 'enqueued' ) && ! wp_style_is( 'oilmazing-sfc-admin', 'done' ) && function_exists( 'oilmazing_sfc_url' ) ) {
			$version = defined( 'OILMAZING_SFC_VERSION' ) ? OILMAZING_SFC_VERSION : OILMAZING_SFC_AUTH_VERSION;
			wp_enqueue_style(
				'oilmazing-sfc-admin',
				oilmazing_sfc_url( 'assets/css/admin.css' ),
				array(),
				$version
			);
		}

		wp_enqueue_style(
			'oilmazing-sfc-admin-menu',
			OILMAZING_SFC_AUTH_URL . 'assets/css/admin-menu.css',
			array( 'oilmazing-sfc-admin' ),
			OILMAZING_SFC_AUTH_VERSION
		);
	}

	/**
	 * Enqueue dashboard menu styles/scripts during wp_enqueue_scripts (not only in shortcode render).
	 */
	public static function maybe_enqueue_dashboard_menu_assets() {
		if ( ! class_exists( 'Oilmazing_SFC_Assets_Guard' ) || ! Oilmazing_SFC_Assets_Guard::should_load_dashboard_assets() ) {
			return;
		}

		$is_club_page = class_exists( 'Oilmazing_SFC_Elementor_Compat' ) && Oilmazing_SFC_Elementor_Compat::is_club_frontend_page();
		$is_dashboard_page = class_exists( 'Oilmazing_SFC_Assets' ) && is_singular();

		if ( ! $is_club_page && ! $is_dashboard_page ) {
			return;
		}

		if ( ! $is_club_page && $is_dashboard_page ) {
			$post = get_queried_object();
			if ( ! $post instanceof WP_Post ) {
				return;
			}

			$has_shortcode = has_shortcode( $post->post_content, 'oilmazing_sfc_dashboard' )
				|| has_shortcode( $post->post_content, 'scent_freedom_club' );

			if ( ! $has_shortcode ) {
				$elementor_data = get_post_meta( $post->ID, '_elementor_data', true );
				$has_shortcode  = is_string( $elementor_data )
					&& ( false !== strpos( $elementor_data, 'oilmazing_sfc_dashboard' )
						|| false !== strpos( $elementor_data, 'scent_freedom_club' ) );
			}

			if ( ! $has_shortcode ) {
				return;
			}
		}

		self::enqueue_dashboard_menu_assets();
	}

	/**
	 * Enqueue modern dashboard navigation styles.
	 */
	public static function enqueue_dashboard_menu_assets() {
		static $enqueued = false;

		if ( $enqueued ) {
			return;
		}

		$enqueued = true;

		wp_enqueue_style(
			'oilmazing-sfc-dashboard-menu',
			OILMAZING_SFC_AUTH_URL . 'assets/css/dashboard-menu.css',
			array( 'oilmazing-sfc-theme-isolation' ),
			OILMAZING_SFC_AUTH_VERSION
		);

		if ( wp_script_is( 'oilmazing-sfc-api-client', 'registered' ) ) {
			wp_add_inline_script(
				'oilmazing-sfc-api-client',
				"(function(){if(typeof applyUserToUI!=='function'){return;}var original=applyUserToUI;function restoreHeaderTierBadges(tier){document.querySelectorAll('.oilmazing-sfc-user-menu .user-tier-badge, .oilmazing-sfc-user-menu__dropdown-header .user-tier-badge').forEach(function(el){if(!el.querySelector('.user-tier-badge__text')){el.innerHTML='<i class=\"fa-solid fa-crown\" aria-hidden=\"true\"></i><span class=\"user-tier-badge__text\"></span>';}var textEl=el.querySelector('.user-tier-badge__text');if(textEl){textEl.textContent=tier;}});}function syncHeaderAvatar(wrap,user){if(!wrap){return;}var fallback=wrap.querySelector('.user-avatar-fallback');var img=wrap.querySelector('.user-avatar');var showImage=!!(user&&user.avatar_url);if(showImage){if(!img){img=document.createElement('img');img.className='oilmazing-sfc-user-menu__avatar-img user-avatar';wrap.insertBefore(img,fallback||wrap.firstChild);}var bust='_v='+Date.now();img.src=user.avatar_url.indexOf('?')>-1?user.avatar_url+'&'+bust:user.avatar_url+'?'+bust;img.alt=(user.display_name||user.name||'Member');img.classList.remove('oilmazing-sfc-is-hidden');if(fallback){fallback.classList.add('oilmazing-sfc-is-hidden');}}else{if(img){img.classList.add('oilmazing-sfc-is-hidden');img.removeAttribute('src');}if(fallback){fallback.classList.remove('oilmazing-sfc-is-hidden');}}}applyUserToUI=function(user,subscription){original(user,subscription);var tier=(user&&user.tier)||(document.getElementById('oilmazing-sfc-root')||{}).dataset?.userTier||'Gold Member';restoreHeaderTierBadges(tier);document.querySelectorAll('.oilmazing-sfc-user-menu__avatar, .oilmazing-sfc-user-menu__dropdown-avatar').forEach(function(wrap){syncHeaderAvatar(wrap,user);});};})();",
				'after'
			);
		}
	}

	/**
	 * Resolve default auth tab from query string.
	 *
	 * @return string
	 */
	private static function get_default_auth_tab() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only tab switch.
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';

		return 'register' === $action ? 'register' : 'login';
	}
}
