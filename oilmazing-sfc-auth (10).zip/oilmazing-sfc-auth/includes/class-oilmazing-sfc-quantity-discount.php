<?php
/**
 * Cart subtotal percentage discount when minimum items are in the cart.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Quantity_Discount
 */
class Oilmazing_SFC_Quantity_Discount {

	const OPTION_ENABLED = 'oilmazing_sfc_quantity_discount_enabled';

	const OPTION_PERCENT = 'oilmazing_sfc_quantity_discount_percent';

	/**
	 * Register hooks.
	 */
	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		add_action( 'woocommerce_cart_calculate_fees', array( __CLASS__, 'apply_cart_fee' ), 25 );
	}

	/**
	 * @return bool
	 */
	public static function is_enabled() {
		return 'yes' === get_option( self::OPTION_ENABLED, 'yes' );
	}

	/**
	 * @return float
	 */
	public static function get_percent() {
		$percent = (float) get_option( self::OPTION_PERCENT, 10 );

		return max( 0.0, min( 100.0, $percent ) );
	}

	/**
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_yes_no( $value ) {
		return ( 'yes' === $value || true === $value || '1' === (string) $value ) ? 'yes' : 'no';
	}

	/**
	 * @param mixed $value Raw value.
	 * @return float
	 */
	public static function sanitize_percent( $value ) {
		return max( 0.0, min( 100.0, (float) $value ) );
	}

	/**
	 * Minimum total cart quantity before discount applies.
	 *
	 * @return int
	 */
	public static function get_minimum_items() {
		return 2;
	}

	/**
	 * Apply discount as a negative fee on the cart subtotal.
	 *
	 * @param WC_Cart $cart Cart object.
	 */
	public static function apply_cart_fee( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}

		if ( ! self::is_enabled() || self::get_percent() <= 0 || ! $cart instanceof WC_Cart ) {
			return;
		}

		if ( (int) $cart->get_cart_contents_count() < self::get_minimum_items() ) {
			return;
		}

		if ( self::has_oilmazing_bundle_items( $cart ) ) {
			return;
		}

		$savings = self::calculate_savings( $cart );
		if ( $savings <= 0 ) {
			return;
		}

		$label = __( 'Discount', 'oilmazing-sfc' );

		$cart->add_fee( $label, -1 * $savings, false );
	}

	/**
	 * Discount amount = cart subtotal × configured percent.
	 *
	 * @param WC_Cart $cart Cart object.
	 * @return float
	 */
	public static function calculate_savings( $cart ) {
		if ( ! self::is_enabled() || self::get_percent() <= 0 || ! $cart instanceof WC_Cart ) {
			return 0.0;
		}

		if ( (int) $cart->get_cart_contents_count() < self::get_minimum_items() ) {
			return 0.0;
		}

		if ( self::has_oilmazing_bundle_items( $cart ) ) {
			return 0.0;
		}

		$subtotal = self::get_cart_subtotal( $cart );
		if ( $subtotal <= 0 ) {
			return 0.0;
		}

		return max( 0.0, $subtotal * ( self::get_percent() / 100 ) );
	}

	/**
	 * @param WC_Cart $cart Cart object.
	 * @return float
	 */
	private static function get_cart_subtotal( $cart ) {
		$subtotal = 0.0;

		foreach ( $cart->get_cart() as $cart_item ) {
			if ( isset( $cart_item['line_subtotal'] ) && (float) $cart_item['line_subtotal'] > 0 ) {
				$subtotal += (float) $cart_item['line_subtotal'];
				continue;
			}

			if ( empty( $cart_item['data'] ) || ! is_a( $cart_item['data'], 'WC_Product' ) ) {
				continue;
			}

			$subtotal += (float) $cart_item['data']->get_price() * max( 0, (int) $cart_item['quantity'] );
		}

		return max( 0.0, $subtotal );
	}

	/**
	 * Bundle products use fixed Oilmazing Bundle System pricing, not percentage discounts.
	 *
	 * @param WC_Cart $cart Cart object.
	 * @return bool
	 */
	private static function has_oilmazing_bundle_items( $cart ) {
		if ( ! class_exists( 'Oilmazing_Bundle_Cart' ) || ! $cart instanceof WC_Cart ) {
			return false;
		}

		if ( ! empty( Oilmazing_Bundle_Cart::get_eligible_cart_items( $cart ) ) ) {
			return true;
		}

		foreach ( $cart->get_cart() as $cart_item ) {
			if ( ! empty( $cart_item['oilmazing_bundle_display_unit_price'] ) ) {
				return true;
			}
		}

		$bundle_summary = Oilmazing_Bundle_Cart::get_checkout_summary( $cart );

		return ! empty( $bundle_summary['has_bundle'] ) && (float) $bundle_summary['savings'] > 0;
	}
}
