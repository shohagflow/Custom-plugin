<?php
/**
 * Frontend lead capture popup after AffiliatePress referral visits.
 *
 * Uses the Lead Popup plugin form UI, while saving leads into QR Customer Leads.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_QR_Lead_Popup
 */
class Oilmazing_SFC_QR_Lead_Popup {

	const COOKIE_PENDING = 'oilmazing_sfc_qr_lead_pending';

	const COOKIE_DONE_PREFIX = 'oilmazing_sfc_qr_lead_done_';

	const QUERY_FLAG = 'oilmazing_sfc_qr';

	/**
	 * Affiliate queued for popup on the current request.
	 *
	 * @var int
	 */
	private static $pending_affiliate_id = 0;

	/**
	 * Whether popup markup was already printed.
	 *
	 * @var bool
	 */
	private static $popup_rendered = false;

	/**
	 * Register hooks.
	 */
	public static function init() {
		if ( ! Oilmazing_SFC_QR_Affiliate_Bridge::is_available() ) {
			return;
		}

		add_action( 'affiliatepress_after_visit_insert', array( __CLASS__, 'handle_referral_visit' ), 20, 2 );
		add_action( 'wp', array( __CLASS__, 'maybe_queue_lead_popup_from_referral' ), 15 );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_queue_lead_popup_from_referral' ), 5 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 99 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'suppress_lead_popup_plugin_assets' ), 1000 );
		add_action( 'wp_body_open', array( __CLASS__, 'render_popup_markup' ), 1 );
		add_action( 'wp_footer', array( __CLASS__, 'render_popup_markup' ), 1 );
		add_action( 'wp_ajax_oilmazing_sfc_qr_submit_lead', array( __CLASS__, 'ajax_submit_lead' ) );
		add_action( 'wp_ajax_nopriv_oilmazing_sfc_qr_submit_lead', array( __CLASS__, 'ajax_submit_lead' ) );
		add_filter( 'lead_popup_should_show', array( __CLASS__, 'suppress_sitewide_lead_popup' ) );
	}

	/**
	 * Hide the sitewide Lead Popup while a QR lead form is queued.
	 *
	 * @param bool $should_show Whether Lead Popup should show.
	 * @return bool
	 */
	public static function suppress_sitewide_lead_popup( $should_show ) {
		if ( self::get_pending_affiliate_id() > 0 || self::request_has_qr_flag() ) {
			return false;
		}

		return $should_show;
	}

	/**
	 * Append QR funnel flag to an AffiliatePress referral URL.
	 *
	 * @param string $referral_url Referral URL.
	 * @return string
	 */
	public static function append_qr_flag_to_url( $referral_url ) {
		$referral_url = esc_url_raw( (string) $referral_url );
		if ( '' === $referral_url ) {
			return '';
		}

		return add_query_arg( self::QUERY_FLAG, '1', $referral_url );
	}

	/**
	 * Queue lead popup after AffiliatePress registers a referral visit.
	 *
	 * @param int                  $visit_id Visit ID.
	 * @param array<string, mixed> $args     Visit args.
	 */
	public static function handle_referral_visit( $visit_id, $args ) {
		unset( $visit_id );

		$affiliate_id = isset( $args['ap_affiliates_id'] ) ? absint( $args['ap_affiliates_id'] ) : 0;
		if ( $affiliate_id <= 0 ) {
			return;
		}

		self::queue_lead_popup_if_eligible( $affiliate_id );
	}

	/**
	 * Queue popup when a QR referral link is opened, even if AffiliatePress skips visit insert.
	 */
	public static function maybe_queue_lead_popup_from_referral() {
		if ( is_admin() ) {
			return;
		}

		// Support both the current QR flag and older direct referral URLs that were already printed in QR codes.
		if ( ! self::request_has_qr_flag() && ! self::request_has_referral_context() ) {
			return;
		}

		$affiliate_id = self::resolve_referral_affiliate_id();
		if ( $affiliate_id <= 0 ) {
			return;
		}

		self::queue_lead_popup_if_eligible( $affiliate_id );
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 */
	private static function queue_lead_popup_if_eligible( $affiliate_id ) {
		$affiliate_id = absint( $affiliate_id );
		if ( $affiliate_id <= 0 ) {
			return;
		}

		if ( ! Oilmazing_SFC_QR_Repository::get_active_code_by_affiliate_id( $affiliate_id ) ) {
			return;
		}

		if ( is_user_logged_in() ) {
			$affiliate_user_id = Oilmazing_SFC_QR_Affiliate_Bridge::get_user_id_for_affiliate( $affiliate_id );
			if ( $affiliate_user_id > 0 && get_current_user_id() === $affiliate_user_id ) {
				return;
			}
		}

		if ( self::has_completed_lead_cookie( $affiliate_id ) ) {
			return;
		}

		self::$pending_affiliate_id = $affiliate_id;
		self::set_pending_cookie( $affiliate_id );
	}

	/**
	 * @return bool
	 */
	private static function request_has_qr_flag() {
		if ( empty( $_REQUEST[ self::QUERY_FLAG ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return false;
		}

		$flag = sanitize_text_field( wp_unslash( $_REQUEST[ self::QUERY_FLAG ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		return in_array( strtolower( $flag ), array( '1', 'true', 'yes' ), true );
	}

	/**
	 * Detect a referral request even when the QR flag is missing.
	 *
	 * @return bool
	 */
	private static function request_has_referral_context() {
		global $AffiliatePress, $wp, $wp_query;

		if ( ! isset( $AffiliatePress ) || ! method_exists( $AffiliatePress, 'affiliatepress_get_settings' ) ) {
			return false;
		}

		$referral_var = (string) $AffiliatePress->affiliatepress_get_settings( 'affiliate_url_parameter', 'affiliate_settings' );
		if ( '' === $referral_var ) {
			return false;
		}

		if ( ! empty( $_REQUEST[ $referral_var ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return true;
		}

		if ( isset( $wp_query ) && '' !== (string) $wp_query->get( $referral_var ) ) {
			return true;
		}

		if ( isset( $wp ) ) {
			$enable_fancy = (string) $AffiliatePress->affiliatepress_get_settings( 'enable_fancy_affiliate_url', 'affiliate_settings' );
			$request_path = (string) $wp->request;

			if ( '' !== $request_path && 'true' === $enable_fancy && false !== strpos( $request_path, $referral_var . '/' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Resolve affiliate ID from the current referral request or cookie.
	 *
	 * @return int
	 */
	private static function resolve_referral_affiliate_id() {
		global $AffiliatePress, $wp, $wp_query, $affiliatepress_affiliates;

		if ( ! isset( $AffiliatePress ) || ! method_exists( $AffiliatePress, 'affiliatepress_get_settings' ) ) {
			return 0;
		}

		$referral_var = (string) $AffiliatePress->affiliatepress_get_settings( 'affiliate_url_parameter', 'affiliate_settings' );
		$affiliate_id = 0;

		if ( '' !== $referral_var ) {
			$ref_value = isset( $_REQUEST[ $referral_var ] ) ? sanitize_text_field( wp_unslash( $_REQUEST[ $referral_var ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			if ( '' === $ref_value && isset( $wp_query ) ) {
				$ref_value = (string) $wp_query->get( $referral_var );
			}

			if ( '' === $ref_value && isset( $wp ) ) {
				$enable_fancy = (string) $AffiliatePress->affiliatepress_get_settings( 'enable_fancy_affiliate_url', 'affiliate_settings' );
				$request_path = (string) $wp->request;
				if ( '' !== $request_path && 'true' === $enable_fancy && false !== strpos( $request_path, $referral_var . '/' ) ) {
					$parts = explode( $referral_var . '/', 'abc/' . $request_path, 2 );
					if ( ! empty( $parts[1] ) ) {
						$ref_value = (string) $parts[1];
					}
				}
			}

			if ( '' !== $ref_value && method_exists( $AffiliatePress, 'affiliatepress_decode_affiliate_id' ) ) {
				$affiliate_id = absint( $AffiliatePress->affiliatepress_decode_affiliate_id( $ref_value ) );
			}
		}

		if ( $affiliate_id <= 0 && ! empty( $_COOKIE['affiliatepress_ref_cookie'] ) ) {
			$affiliate_id = absint( wp_unslash( $_COOKIE['affiliatepress_ref_cookie'] ) );
		}

		if ( $affiliate_id <= 0 ) {
			return 0;
		}

		if ( isset( $affiliatepress_affiliates ) && is_object( $affiliatepress_affiliates ) && method_exists( $affiliatepress_affiliates, 'affiliatepress_is_valid_affiliate' ) ) {
			if ( ! $affiliatepress_affiliates->affiliatepress_is_valid_affiliate( $affiliate_id ) ) {
				return 0;
			}
		}

		return $affiliate_id;
	}

	/**
	 * Prevent the sitewide Lead Popup plugin from hijacking QR form submits.
	 */
	public static function suppress_lead_popup_plugin_assets() {
		if ( is_admin() || ! self::get_pending_affiliate_id() ) {
			return;
		}

		wp_dequeue_script( 'lead-popup' );
		wp_deregister_script( 'lead-popup' );
		wp_dequeue_style( 'lead-popup' );
		wp_deregister_style( 'lead-popup' );
	}

	/**
	 * Enqueue popup assets when a pending lead capture is queued.
	 */
	public static function enqueue_assets() {
		if ( is_admin() || ! self::get_pending_affiliate_id() ) {
			return;
		}

		$settings = self::get_lead_popup_settings();

		wp_enqueue_style(
			'oilmazing-sfc-qr-lead-popup',
			OILMAZING_SFC_AUTH_URL . 'assets/css/qr/lead-popup.css',
			array(),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_enqueue_script(
			'oilmazing-sfc-qr-lead-popup',
			OILMAZING_SFC_AUTH_URL . 'assets/js/qr/qr-lead-popup.js',
			array(),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		wp_localize_script(
			'oilmazing-sfc-qr-lead-popup',
			'oilmazingSfcQrLead',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'oilmazing_sfc_qr_lead' ),
				'shopUrl'   => self::get_shop_url(),
				'affiliate' => self::get_pending_affiliate_id(),
				'i18n'      => array(
					'firstNameRequired' => __( 'Please enter your first name.', 'oilmazing-sfc' ),
					'emailRequired'     => __( 'Please enter your email address.', 'oilmazing-sfc' ),
					'emailInvalid'      => __( 'Please enter a valid email address.', 'oilmazing-sfc' ),
					'phoneRequired'     => __( 'Please enter your phone number.', 'oilmazing-sfc' ),
					'submitting'        => __( 'Submitting…', 'oilmazing-sfc' ),
					'submit'            => (string) $settings['button_text'],
					'success'           => __( 'Thanks! Redirecting you to the shop…', 'oilmazing-sfc' ),
					'error'             => __( 'Something went wrong. Please try again.', 'oilmazing-sfc' ),
				),
			)
		);

		$bg_url = ! empty( $settings['background_image_id'] )
			? wp_get_attachment_image_url( (int) $settings['background_image_id'], 'large' )
			: '';

		if ( ! $bg_url && defined( 'LEAD_POPUP_URL' ) ) {
			$bg_url = self::get_lead_popup_asset_url( 'assets/images/popup-bg.png' );
		}

		if ( ! $bg_url ) {
			$bg_url = self::get_default_background_url();
		}

		$inline_css = sprintf(
			':root { --lp-btn-start: %1$s; --lp-btn-end: %2$s; --lp-bg-image: url(%3$s); }',
			esc_attr( $settings['button_color_start'] ),
			esc_attr( $settings['button_color_end'] ),
			esc_url( $bg_url )
		);
		wp_add_inline_style( 'oilmazing-sfc-qr-lead-popup', $inline_css );
	}

	/**
	 * Render the Lead Popup form UI for QR scans.
	 */
	public static function render_popup_markup() {
		if ( is_admin() || self::$popup_rendered || ! self::get_pending_affiliate_id() ) {
			return;
		}

		self::$popup_rendered = true;

		$settings = self::get_lead_popup_settings();
		$logo_url = ! empty( $settings['logo_id'] )
			? wp_get_attachment_image_url( (int) $settings['logo_id'], 'full' )
			: self::get_logo_url();
		?>
		<div class="lead-popup oilmazing-sfc-qr-lead" data-qr-lead-popup>
			<div class="lead-popup__overlay" data-qr-lead-close></div>
			<div class="lead-popup__dialog" role="dialog" aria-modal="true" aria-labelledby="oilmazing-sfc-qr-lead-heading">
				<button type="button" class="lead-popup__close" data-qr-lead-close aria-label="<?php esc_attr_e( 'Close', 'oilmazing-sfc' ); ?>"></button>

				<?php if ( $logo_url ) : ?>
					<div class="lead-popup__brand">
						<img class="lead-popup__logo" src="<?php echo esc_url( $logo_url ); ?>" alt="<?php esc_attr_e( 'Oilmazing', 'oilmazing-sfc' ); ?>" width="280" height="80" loading="eager" decoding="async" />
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $settings['heading'] ) ) : ?>
					<h2 id="oilmazing-sfc-qr-lead-heading" class="lead-popup__heading"><?php echo esc_html( $settings['heading'] ); ?></h2>
				<?php endif; ?>

				<?php if ( ! empty( $settings['description'] ) ) : ?>
					<p class="lead-popup__description"><?php echo esc_html( $settings['description'] ); ?></p>
				<?php endif; ?>

				<form class="lead-popup__form" data-qr-lead-form novalidate>
					<div class="lead-popup__field">
						<span class="lead-popup__icon" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v1.2c0 .7.5 1.2 1.2 1.2h16.8c.7 0 1.2-.5 1.2-1.2v-1.2c0-3.2-6.4-4.8-9.6-4.8z"/></svg>
						</span>
						<label class="screen-reader-text" for="oilmazing-sfc-qr-lead-first-name"><?php echo esc_html( $settings['first_name_label'] ); ?></label>
						<input type="text" id="oilmazing-sfc-qr-lead-first-name" name="first_name" class="lead-popup__input" placeholder="<?php echo esc_attr( $settings['first_name_label'] ); ?>" required autocomplete="given-name" />
					</div>

					<div class="lead-popup__field">
						<span class="lead-popup__icon" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4-8 5L4 8V6l8 5 8-5v2z"/></svg>
						</span>
						<label class="screen-reader-text" for="oilmazing-sfc-qr-lead-email"><?php echo esc_html( $settings['email_label'] ); ?></label>
						<input type="email" id="oilmazing-sfc-qr-lead-email" name="email" class="lead-popup__input" placeholder="<?php echo esc_attr( $settings['email_label'] ); ?>" required autocomplete="email" />
					</div>

					<div class="lead-popup__field">
						<span class="lead-popup__icon" aria-hidden="true">
							<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M6.6 10.8c1.5 3.1 3.9 5.5 7 7l2.3-2.3c.3-.3.8-.4 1.2-.2 1.3.5 2.7.8 4.1.8.7 0 1.2.5 1.2 1.2V20c0 .7-.5 1.2-1.2 1.2C10.1 21.2 2.8 13.9 2.8 4.4 2.8 3.7 3.3 3.2 4 3.2h3.5c.7 0 1.2.5 1.2 1.2 0 1.4.3 2.8.8 4.1.1.4 0 .9-.3 1.2L6.6 10.8z"/></svg>
						</span>
						<label class="screen-reader-text" for="oilmazing-sfc-qr-lead-phone"><?php echo esc_html( $settings['phone_label'] ); ?></label>
						<input type="tel" id="oilmazing-sfc-qr-lead-phone" name="phone" class="lead-popup__input" placeholder="<?php echo esc_attr( $settings['phone_label'] ); ?>" required autocomplete="tel" />
					</div>

					<p class="lead-popup__error" data-qr-lead-error hidden></p>

					<button type="submit" class="lead-popup__submit" data-qr-lead-submit>
						<?php echo esc_html( $settings['button_text'] ); ?>
					</button>
				</form>

				<p class="lead-popup__success" data-qr-lead-success hidden></p>
			</div>
		</div>
		<script>
		document.documentElement.classList.add('lead-popup-open');
		</script>
		<?php
	}

	/**
	 * AJAX lead submission.
	 */
	public static function ajax_submit_lead() {
		check_ajax_referer( 'oilmazing_sfc_qr_lead', 'nonce' );

		$affiliate_id = isset( $_POST['affiliate_id'] ) ? absint( wp_unslash( $_POST['affiliate_id'] ) ) : 0;
		$first_name   = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
		$email        = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$phone        = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';

		if ( '' === $first_name ) {
			wp_send_json_error( array( 'message' => __( 'Please enter your first name.', 'oilmazing-sfc' ) ), 400 );
		}

		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'oilmazing-sfc' ) ), 400 );
		}

		if ( '' === $phone ) {
			wp_send_json_error( array( 'message' => __( 'Please enter your phone number.', 'oilmazing-sfc' ) ), 400 );
		}

		if ( $affiliate_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'This referral offer is no longer available.', 'oilmazing-sfc' ) ), 400 );
		}

		$code = Oilmazing_SFC_QR_Repository::get_active_code_by_affiliate_id( $affiliate_id );
		if ( ! $code ) {
			wp_send_json_error( array( 'message' => __( 'This referral offer is no longer available.', 'oilmazing-sfc' ) ), 400 );
		}

		$result = Oilmazing_SFC_QR_Repository::store_lead(
			$affiliate_id,
			$email,
			(string) ( $code['referral_url'] ?? '' ),
			array(
				'first_name' => $first_name,
				'phone'      => $phone,
			)
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 500 );
		}

		self::clear_pending_cookie();
		self::set_completed_cookie( $affiliate_id );

		wp_send_json_success(
			array(
				'message'  => __( 'Thanks! Redirecting you to the shop…', 'oilmazing-sfc' ),
				'shop_url' => self::get_shop_url(),
			)
		);
	}

	/**
	 * Settings from Lead Popup plugin when available.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_lead_popup_settings() {
		$defaults = array(
			'logo_id'             => 0,
			'heading'             => 'Welcome to Oilmazing. Own Your Aura.',
			'description'         => '',
			'first_name_label'    => 'First Name',
			'email_label'         => 'Email Address',
			'phone_label'         => 'Phone Number',
			'button_text'         => 'CLAIM MY VIBRATION',
			'background_image_id' => 0,
			'button_color_start'  => '#c49a3c',
			'button_color_end'    => '#e8c878',
		);

		$saved = get_option( 'oilmazing_sfc_qr_lead_popup_settings', array() );
		if ( is_array( $saved ) && ! empty( $saved ) ) {
			return wp_parse_args( $saved, $defaults );
		}

		if ( class_exists( 'Lead_Popup_Admin' ) && method_exists( 'Lead_Popup_Admin', 'get_settings' ) ) {
			return wp_parse_args( Lead_Popup_Admin::get_settings(), $defaults );
		}

		return $defaults;
	}

	/**
	 * @return string
	 */
	private static function get_default_background_url() {
		return OILMAZING_SFC_AUTH_URL . 'assets/images/qr-lead-popup-bg.png';
	}

	/**
	 * @param string $relative Relative asset path.
	 * @return string
	 */
	private static function get_lead_popup_asset_url( $relative ) {
		if ( defined( 'LEAD_POPUP_URL' ) ) {
			return LEAD_POPUP_URL . ltrim( $relative, '/' );
		}

		return plugins_url( 'lead-popup/' . ltrim( $relative, '/' ) );
	}

	/**
	 * @return string
	 */
	private static function get_lead_popup_version() {
		return defined( 'LEAD_POPUP_VERSION' ) ? LEAD_POPUP_VERSION : OILMAZING_SFC_AUTH_VERSION;
	}

	/**
	 * @return string
	 */
	public static function get_logo_url() {
		$relative = 'assets/Logo-2-vector-1024x294.webp';

		if ( function_exists( 'oilmazing_sfc_url' ) ) {
			return oilmazing_sfc_url( $relative );
		}

		if ( defined( 'OILMAZING_SFC_PLUGIN_URL' ) ) {
			return OILMAZING_SFC_PLUGIN_URL . $relative;
		}

		return plugins_url( 'oilmazing-scent-freedom-club/' . $relative );
	}

	/**
	 * @return string
	 */
	public static function get_shop_url() {
		if ( function_exists( 'wc_get_page_permalink' ) ) {
			$shop_url = wc_get_page_permalink( 'shop' );
			if ( $shop_url ) {
				return $shop_url;
			}
		}

		return home_url( '/shop/' );
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 */
	private static function set_pending_cookie( $affiliate_id ) {
		$expires = time() + HOUR_IN_SECONDS;
		setcookie( self::COOKIE_PENDING, (string) absint( $affiliate_id ), $expires, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
		$_COOKIE[ self::COOKIE_PENDING ] = (string) absint( $affiliate_id );
	}

	/**
	 * Clear pending popup cookie.
	 */
	private static function clear_pending_cookie() {
		setcookie( self::COOKIE_PENDING, '', time() - HOUR_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
		unset( $_COOKIE[ self::COOKIE_PENDING ] );
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 */
	private static function set_completed_cookie( $affiliate_id ) {
		$name    = self::COOKIE_DONE_PREFIX . absint( $affiliate_id );
		$expires = time() + ( 30 * DAY_IN_SECONDS );
		setcookie( $name, '1', $expires, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
		$_COOKIE[ $name ] = '1';
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 * @return bool
	 */
	private static function has_completed_lead_cookie( $affiliate_id ) {
		$name = self::COOKIE_DONE_PREFIX . absint( $affiliate_id );
		return isset( $_COOKIE[ $name ] ) && '1' === (string) wp_unslash( $_COOKIE[ $name ] );
	}

	/**
	 * @return int
	 */
	private static function get_pending_affiliate_id() {
		if ( self::$pending_affiliate_id > 0 ) {
			$affiliate_id = self::$pending_affiliate_id;
		} elseif ( empty( $_COOKIE[ self::COOKIE_PENDING ] ) ) {
			return 0;
		} else {
			$affiliate_id = absint( wp_unslash( $_COOKIE[ self::COOKIE_PENDING ] ) );
		}

		if ( $affiliate_id <= 0 ) {
			return 0;
		}

		if ( self::has_completed_lead_cookie( $affiliate_id ) ) {
			return 0;
		}

		return Oilmazing_SFC_QR_Repository::get_active_code_by_affiliate_id( $affiliate_id ) ? $affiliate_id : 0;
	}
}
