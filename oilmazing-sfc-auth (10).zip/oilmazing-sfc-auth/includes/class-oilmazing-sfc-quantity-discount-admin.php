<?php
/**
 * Admin settings for cart quantity discount.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Quantity_Discount_Admin
 */
class Oilmazing_SFC_Quantity_Discount_Admin {

	const PAGE_SLUG = 'oilmazing-sfc-cart-discount';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 20 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Register submenu under Scent Freedom Club.
	 */
	public static function register_menu() {
		$parent = class_exists( 'Oilmazing_SFC_Admin' ) ? Oilmazing_SFC_Admin::PAGE_SLUG : 'oilmazing-sfc';

		$hook = add_submenu_page(
			$parent,
			__( 'Cart Quantity Discount', 'oilmazing-sfc' ),
			__( 'Cart Discount', 'oilmazing-sfc' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);

		if ( $hook ) {
			add_action( "load-{$hook}", array( __CLASS__, 'enqueue_assets' ) );
			add_action( "admin_enqueue_scripts-{$hook}", array( __CLASS__, 'enqueue_assets' ) );
		}
	}

	/**
	 * Register settings.
	 */
	public static function register_settings() {
		register_setting(
			'oilmazing_sfc_cart_discount_settings',
			Oilmazing_SFC_Quantity_Discount::OPTION_ENABLED,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'Oilmazing_SFC_Quantity_Discount', 'sanitize_yes_no' ),
				'default'           => 'yes',
			)
		);

		register_setting(
			'oilmazing_sfc_cart_discount_settings',
			Oilmazing_SFC_Quantity_Discount::OPTION_PERCENT,
			array(
				'type'              => 'number',
				'sanitize_callback' => array( 'Oilmazing_SFC_Quantity_Discount', 'sanitize_percent' ),
				'default'           => 10,
			)
		);
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook_suffix Hook suffix.
	 */
	public static function enqueue_assets( $hook_suffix = '' ) {
		unset( $hook_suffix );

		if ( function_exists( 'oilmazing_sfc_enqueue_admin_assets' ) ) {
			oilmazing_sfc_enqueue_admin_assets();
		}

		if ( class_exists( 'Oilmazing_SFC_Auth_Bootstrap' ) ) {
			Oilmazing_SFC_Auth_Bootstrap::enqueue_admin_menu_assets( self::PAGE_SLUG );
		}
	}

	/**
	 * Render admin page.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'oilmazing-sfc' ) );
		}

		if ( function_exists( 'oilmazing_sfc_load_template' ) ) {
			oilmazing_sfc_load_template(
				'admin/cart-discount.php',
				array(
					'enabled' => Oilmazing_SFC_Quantity_Discount::is_enabled(),
					'percent' => Oilmazing_SFC_Quantity_Discount::get_percent(),
				)
			);
			return;
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'Cart Quantity Discount', 'oilmazing-sfc' ) . '</h1></div>';
	}
}
