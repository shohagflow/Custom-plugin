(function () {
    'use strict';

    function applySubscriptionToUI(subscription) {
        if (!subscription) {
            return;
        }

        const isActive = subscription.status === 'active'
            || subscription.status === 'club'
            || subscription.status === 'trialing';

        const statusEl = document.getElementById('subscription-status-badge');
        if (statusEl) {
            statusEl.textContent = subscription.status_label || (isActive ? 'Active' : 'Inactive');
            statusEl.className = 'px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider '
                + (isActive ? 'bg-emerald-600 text-white' : 'bg-zinc-200 text-zinc-700');
        }

        const planEl = document.getElementById('subscription-plan-name');
        if (planEl && subscription.plan) {
            planEl.textContent = subscription.plan;
        }

        const descEl = document.getElementById('subscription-plan-desc');
        if (descEl) {
            descEl.textContent = subscription.description || '';
            descEl.classList.toggle('hidden', !subscription.description);
        }

        const priceEl = document.getElementById('subscription-plan-price');
        if (priceEl && subscription.price_html) {
            const suffix = subscription.interval_suffix || '/mo';
            priceEl.innerHTML = `${subscription.price_html}<span class="text-xs text-zinc-400 font-normal">${suffix}</span>`;
        }

        const billingEl = document.getElementById('subscription-next-billing');
        if (billingEl) {
            billingEl.textContent = subscription.billing
                ? `Next billing date: ${subscription.billing}`
                : (isActive ? 'Billing date unavailable' : '');
        }

        const freqEl = document.getElementById('subscription-frequency');
        if (freqEl && subscription.frequency) {
            freqEl.textContent = subscription.frequency;
        }

        const manageBtn = document.getElementById('subscription-manage-btn');
        if (manageBtn && subscription.manage_url) {
            manageBtn.onclick = function () {
                window.location.href = subscription.manage_url;
            };
        }
    }

    function wrapApplyUserToUI() {
        const original = window.applyUserToUI;
        if (typeof original !== 'function' || original.__oilmazingBillingPatched) {
            return;
        }

        window.applyUserToUI = function patchedApplyUserToUI(user, subscription) {
            original(user, subscription);
            applySubscriptionToUI(subscription);
        };
        window.applyUserToUI.__oilmazingBillingPatched = true;
    }

    wrapApplyUserToUI();
    document.addEventListener('DOMContentLoaded', wrapApplyUserToUI);
})();
