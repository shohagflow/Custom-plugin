( function ( $ ) {
	'use strict';

	var config = window.oilmazingSfcCartSummaryUi || {};

	function decodeText( value ) {
		if ( typeof value !== 'string' ) {
			return value;
		}

		var textarea = document.createElement( 'textarea' );
		textarea.innerHTML = value;
		return textarea.value;
	}

	function renderDiscountRowHtml( summary ) {
		if ( ! summary.has_discount ) {
			return '<p class="oilmazing-sfc-cart-discount-row" hidden></p>';
		}

		var label = ( config.i18n && config.i18n.discount ) ? config.i18n.discount : 'Discount';
		var html = '<p class="oilmazing-sfc-cart-discount-row">';
		html += '<span class="oilmazing-sfc-cart-discount-row__label">' + label;
		html += '</span>';
		html += '<span class="oilmazing-sfc-cart-discount-row__amount">' + decodeText( summary.discount ) + '</span>';
		html += '</p>';

		return html;
	}

	function renderSubtotalLineHtml( summary, includeAmountClass ) {
		var amountClass = includeAmountClass ? ' oilmazing-sfc-cart-subtotal-amount amount' : ' oilmazing-sfc-cart-subtotal-amount';
		var html = '<span class="oilmazing-sfc-cart-subtotal-line">';
		html += '<span class="' + amountClass.trim() + '">' + decodeText( summary.subtotal ) + '</span>';

		if ( summary.has_discount && ! summary.uses_bundle_pricing ) {
			if ( summary.discount ) {
				html += '<span class="oilmazing-sfc-cart-discount-tag oilmazing-sfc-cart-discount-tag--amount">' + decodeText( summary.discount ) + '</span>';
			}
		}

		html += '</span>';
		return html;
	}

	function getDiscountedDisplayAmount( summary ) {
		if ( summary.uses_bundle_pricing ) {
			return summary.subtotal;
		}

		if ( summary.has_discount ) {
			return summary.total;
		}

		return summary.subtotal;
	}

	function renderElementorSubtotalHtml( summary ) {
		var subtotalLabel = ( config.i18n && config.i18n.subtotal ) ? config.i18n.subtotal : 'Subtotal';
		var html = '<div class="elementor-menu-cart__subtotal oilmazing-sfc-cart-subtotal-wrap">';
		html += '<strong>' + subtotalLabel + ':</strong> ';
		html += '<span class="oilmazing-sfc-cart-subtotal-amount">' + decodeText( getDiscountedDisplayAmount( summary ) ) + '</span>';
		html += renderDiscountRowHtml( summary );
		html += '</div>';
		return html;
	}

	function renderWcMiniCartTotalHtml( summary ) {
		var subtotalLabel = ( config.i18n && config.i18n.subtotal ) ? config.i18n.subtotal : 'Subtotal';
		var html = '<p class="woocommerce-mini-cart__total total oilmazing-sfc-cart-subtotal-wrap">';
		html += '<strong>' + subtotalLabel + ':</strong> ';
		html += renderSubtotalLineHtml( summary, true );
		html += '</p>';
		return html;
	}

	function getViwcaioDisplayAmount( summary, mode ) {
		if ( mode === 'total' ) {
			return summary.total;
		}

		return getDiscountedDisplayAmount( summary );
	}

	function renderViwcaioCartTotal1Html( summary, mode ) {
		var amount = getViwcaioDisplayAmount( summary, mode );
		var html = '<div class="vi-wcaio-sidebar-cart-footer-cart_total1 vi-wcaio-sidebar-cart-footer-cart_total1-' + mode + ' oilmazing-sfc-cart-subtotal-wrap">';
		html += '<span class="oilmazing-sfc-cart-subtotal-amount">' + decodeText( amount ) + '</span>';
		html += '</div>';
		return html;
	}

	function getViwcaioFooterMode( $totalWrap ) {
		if ( $totalWrap && $totalWrap.length ) {
			if ( $totalWrap.find( '.vi-wcaio-sidebar-cart-footer-cart_total1-total:not(.vi-wcaio-disabled)' ).length ) {
				return 'total';
			}
			if ( $totalWrap.find( '.vi-wcaio-sidebar-cart-footer-total:not(.vi-wcaio-disabled)' ).length ) {
				return 'total';
			}
			if ( $totalWrap.find( '.vi-wcaio-sidebar-cart-footer-subtotal:not(.vi-wcaio-disabled)' ).length ) {
				return 'subtotal';
			}
			if ( $totalWrap.find( '.vi-wcaio-sidebar-cart-footer-cart_total1-total' ).length ) {
				return 'total';
			}
		}

		return config.viwcaioFooterMode || 'subtotal';
	}

	function ensureViwcaioDiscountSlot( $totalWrap, summary ) {
		var $footer = $totalWrap.closest( '.vi-wcaio-sidebar-cart-footer-products, .vi-wcaio-sidebar-cart-footer-wrap' );

		$footer.find( '.oilmazing-sfc-viwcaio-discount-slot' ).remove();
		$footer.find( '.oilmazing-sfc-cart-discount-row' ).remove();

		if ( ! summary.has_discount ) {
			return;
		}

		var $slot = $( '<div class="oilmazing-sfc-viwcaio-discount-slot"></div>' );
		$slot.html( renderDiscountRowHtml( summary ) );
		$totalWrap.after( $slot );
	}

	function applyViwcaioCart( summary ) {
		if ( ! $( '.vi-wcaio-sidebar-cart-wrap' ).length || summary.is_empty ) {
			return;
		}

		$( '.vi-wcaio-sidebar-cart-footer-cart_total-wrap' ).each( function () {
			var $wrap = $( this );
			var mode = getViwcaioFooterMode( $wrap );
			var $amount = $wrap.find( '.vi-wcaio-sidebar-cart-footer-cart_total:not(.vi-wcaio-disabled) .vi-wcaio-sidebar-cart-footer-cart_total1' ).first();

			if ( ! $amount.length ) {
				$amount = $wrap.find( '.vi-wcaio-sidebar-cart-footer-cart_total1:not(.vi-wcaio-disabled)' ).first();
			}

			if ( ! $amount.length ) {
				$amount = $wrap.find( '.vi-wcaio-sidebar-cart-footer-cart_total1' ).first();
			}

			if ( $amount.length ) {
				$amount.replaceWith( renderViwcaioCartTotal1Html( summary, mode ) );
			}

			ensureViwcaioDiscountSlot( $wrap, summary );
		} );

		if ( summary.has_discount && summary.total ) {
			$( '.vi-wcaio-menu-cart-text-wrap .woocommerce-Price-amount' ).last().each( function () {
				var $menuWrap = $( this ).closest( '.vi-wcaio-menu-cart-text-wrap' );
				if ( $menuWrap.length && $menuWrap.text().indexOf( decodeText( summary.total ) ) === -1 ) {
					$( this ).replaceWith( '<span class="woocommerce-Price-amount amount">' + decodeText( summary.total ) + '</span>' );
				}
			} );
		}
	}

	function renderAddonsCountHtml( summary ) {
		var html = '<dd class="addons-cart__summary-count">' + summary.count;
		if ( summary.has_discount && summary.discount ) {
			html += '<span class="oilmazing-sfc-cart-discount-tag oilmazing-sfc-cart-discount-tag--count">' + decodeText( summary.discount ) + '</span>';
		}
		html += '</dd>';
		return html;
	}

	function renderAddonsSubtotalHtml( summary ) {
		return '<dd class="addons-cart__summary-subtotal">' + renderSubtotalLineHtml( summary, false ) + '</dd>';
	}

	function ensureDiscountRow( $container, summary ) {
		var $row = $container.find( '> .oilmazing-sfc-cart-discount-row' ).first();

		if ( ! $row.length ) {
			$row = $container.find( '.oilmazing-sfc-cart-discount-row' ).first();
		}

		if ( ! $row.length ) {
			$row = $( renderDiscountRowHtml( summary ) );
			$container.append( $row );
		} else {
			$row.replaceWith( renderDiscountRowHtml( summary ) );
		}

		if ( ! summary.has_discount ) {
			$row.attr( 'hidden', 'hidden' ).hide();
		} else {
			$row.removeAttr( 'hidden' ).show();
		}
	}

	function applyAddonsCart( $cart, summary ) {
		if ( ! $cart || ! $cart.length || summary.is_empty ) {
			return;
		}

		if ( summary.count ) {
			$cart.find( '.addons-cart__summary-count' ).replaceWith( renderAddonsCountHtml( summary ) );
		}

		if ( summary.subtotal ) {
			$cart.find( '.addons-cart__summary-subtotal' ).replaceWith( renderAddonsSubtotalHtml( summary ) );
		}

		if ( summary.total ) {
			$cart.find( '.addons-cart__summary-total' ).text( decodeText( summary.total ) );
		}

		var $discountRow = $cart.find( '.addons-cart__summary-row--discount' );
		if ( $discountRow.length ) {
			if ( ! summary.has_discount ) {
				$discountRow.hide();
			} else {
				$discountRow.show();
				$discountRow.find( 'dt' ).html(
					( config.i18n && config.i18n.discount ? config.i18n.discount : 'Discount' )
				);
				$discountRow.find( '.addons-cart__summary-discount' ).text( decodeText( summary.discount ) );
			}
		}
	}

	function applyElementorCart( summary ) {
		$( '.elementor-menu-cart__main' ).each( function () {
			var $main = $( this );

			$main.find( '.oilmazing-sfc-cart-discount-row' ).not( '.elementor-menu-cart__subtotal .oilmazing-sfc-cart-discount-row' ).remove();
		} );

		$( '.elementor-menu-cart__subtotal' ).each( function () {
			$( this ).replaceWith( renderElementorSubtotalHtml( summary ) );
		} );

		if ( summary.has_discount && summary.total ) {
			$( '.elementor-menu-cart__toggle_button span.elementor-button-text' ).text( decodeText( summary.total ) );
		}
	}

	function applyWooMiniCart( summary ) {
		$( 'p.woocommerce-mini-cart__total' ).each( function () {
			var $total = $( this );

			if ( $total.closest( '.elementor-menu-cart__main' ).length ) {
				return;
			}

			$total.replaceWith( renderWcMiniCartTotalHtml( summary ) );

			var $parent = $total.closest( '.widget_shopping_cart_content, .elementor-menu-cart__main, .woocommerce-mini-cart' );
			if ( $parent.length ) {
				var $buttons = $parent.find( '.woocommerce-mini-cart__buttons, .elementor-menu-cart__footer-buttons' ).first();
				var $discount = $parent.find( '.oilmazing-sfc-cart-discount-row' ).first();

				if ( summary.has_discount ) {
					if ( ! $discount.length && $buttons.length ) {
						$buttons.before( renderDiscountRowHtml( summary ) );
					} else if ( $discount.length ) {
						$discount.replaceWith( renderDiscountRowHtml( summary ) );
					}
				} else if ( $discount.length ) {
					$discount.remove();
				}
			}
		} );
	}

	function stripLegacyPercentTags() {
		$( '.oilmazing-sfc-cart-discount-tag--percent' ).remove();
		$( '.oilmazing-sfc-cart-discount-row__label, .addons-cart__summary-row--discount dt' ).each( function () {
			var $label = $( this );
			var text = $label.text().replace( /\s*-\s*\d+(?:\.\d+)?%\s*/g, ' ' ).replace( /\s+/g, ' ' ).trim();

			if ( text ) {
				$label.text( text );
			}
		} );
	}

	function applySummary( summary ) {
		stripLegacyPercentTags();

		if ( ! summary || summary.is_empty ) {
			$( '.oilmazing-sfc-cart-discount-row' ).attr( 'hidden', 'hidden' ).hide();
			return;
		}

		$( '.addons-cart' ).each( function () {
			applyAddonsCart( $( this ), summary );
		} );

		applyElementorCart( summary );
		applyWooMiniCart( summary );
		applyViwcaioCart( summary );

		stripLegacyPercentTags();

		$( '.oilmazing-sfc-cart-discount-row' )
			.not( '.vi-wcaio-sidebar-cart-wrap .oilmazing-sfc-cart-discount-row' )
			.not( '.elementor-menu-cart__subtotal .oilmazing-sfc-cart-discount-row' )
			.each( function () {
			if ( ! summary.has_discount ) {
				$( this ).attr( 'hidden', 'hidden' ).hide();
			}
		} );
	}

	function fetchSummary() {
		if ( ! config.ajaxUrl ) {
			return $.Deferred().resolve().promise();
		}

		return $.post( config.ajaxUrl, {
			action: 'oilmazing_sfc_cart_summary_ui',
			nonce: config.nonce,
		} ).done( function ( response ) {
			if ( ! response || ! response.success || ! response.data ) {
				return;
			}

			config.summary = response.data;
			applySummary( response.data );
		} );
	}

	function refreshAll( fetchRemote ) {
		if ( fetchRemote ) {
			return fetchSummary();
		}

		if ( config.summary ) {
			applySummary( config.summary );
		}

		return $.Deferred().resolve().promise();
	}

	$( document.body ).on(
		'added_to_cart removed_from_cart updated_wc_div wc_fragments_refreshed updated_cart_totals',
		function () {
			window.setTimeout( function () {
				refreshAll( true );
			}, 60 );
		}
	);

	$( document ).on( 'viwcaio_after_update_cart viwcaio_sidebar_cart_init', function () {
		if ( config.summary ) {
			applyViwcaioCart( config.summary );
		}

		window.setTimeout( function () {
			refreshAll( true );
		}, 80 );
	} );

	$( document ).ajaxComplete( function ( event, xhr, settings ) {
		var data = settings && settings.data ? settings.data : '';

		if ( typeof data !== 'string' ) {
			return;
		}

		if (
			data.indexOf( 'action=addons_cart_action' ) !== -1 ||
			data.indexOf( 'action=elementor_menu_cart_fragments' ) !== -1 ||
			data.indexOf( 'wc-ajax=get_refreshed_fragments' ) !== -1 ||
			data.indexOf( 'viwcaio_get_cart_fragments' ) !== -1 ||
			data.indexOf( 'viwcaio_change_quantity' ) !== -1 ||
			data.indexOf( 'viwcaio_remove_item' ) !== -1 ||
			data.indexOf( 'viwcaio_apply_coupon' ) !== -1
		) {
			window.setTimeout( function () {
				refreshAll( true );
			}, 80 );
		}
	} );

	$( function () {
		refreshAll( false );
	} );

	$( window ).on( 'elementor/frontend/init', function () {
		if ( typeof elementorFrontend === 'undefined' ) {
			return;
		}

		elementorFrontend.hooks.addAction( 'frontend/element_ready/addons-cart.default', function () {
			refreshAll( true );
		} );

		elementorFrontend.hooks.addAction( 'frontend/element_ready/woocommerce-menu-cart.default', function () {
			refreshAll( true );
		} );
	} );
}( jQuery ) );
