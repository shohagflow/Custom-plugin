(function ($) {
    'use strict';

    const templateList = $('#cv-builder-template-list');
    const addButton = $('#cv-builder-add-template');

    function openMediaLibrary(callback, title) {
        const frame = wp.media({
            title: title || 'Select or Upload Image',
            button: { text: 'Use this image' },
            multiple: false,
            library: {
                type: 'image'
            }
        });

        // Enable upload tab
        frame.on('open', function() {
            // Switch to upload tab if needed
            const uploader = frame.state().get('library');
            if (uploader) {
                frame.state('library').set('uploader', wp.media.view.Uploader);
            }
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            if (attachment && callback) {
                callback(attachment.url);
            }
        });

        frame.open();
    }

    function createTemplateRow(data = {}) {
        const value = data.image || '';
        const name = data.label || '';
        const border = data.border || '';
        const type = data.is_premium ? 'premium' : 'free';
        const price = data.price || '';

        const row = $('<div/>', { class: 'cv-template-row' });
        const thumbWrapper = $('<div/>', { class: 'cv-template-thumb-wrapper' }).appendTo(row);
        $('<img/>', {
            class: 'cv-template-thumb' + (value ? '' : ' hidden'),
            src: value ? value : '',
            alt: ''
        }).appendTo(thumbWrapper);

        const fields = $('<div/>', { class: 'cv-template-fields' }).appendTo(row);

        // Resume Image Upload Field
        const resumeField = $('<div/>', { class: 'cv-image-upload-field cv-resume-upload-field' });
        if (value) {
            resumeField.append(
                $('<div/>', { class: 'cv-image-preview' }).append(
                    $('<img/>', { src: value, alt: 'Resume Preview', class: 'cv-image-preview-img' }),
                    $('<button/>', { type: 'button', class: 'cv-image-remove', 'data-target': 'resume', text: '×' })
                )
            );
        } else {
            resumeField.append(
                $('<div/>', { class: 'cv-image-placeholder' }).append(
                    $('<span/>', { class: 'cv-image-placeholder-text', text: 'No image uploaded' })
                )
            );
        }

        // Border Image Upload Field
        const borderField = $('<div/>', { class: 'cv-image-upload-field cv-border-upload-field' });
        if (border) {
            borderField.append(
                $('<div/>', { class: 'cv-image-preview' }).append(
                    $('<img/>', { src: border, alt: 'Border Preview', class: 'cv-image-preview-img' }),
                    $('<button/>', { type: 'button', class: 'cv-image-remove', 'data-target': 'border', text: '×' })
                )
            );
        } else {
            borderField.append(
                $('<div/>', { class: 'cv-image-placeholder' }).append(
                    $('<span/>', { class: 'cv-image-placeholder-text', text: 'No border uploaded' })
                )
            );
        }

        fields.append(
            $('<p/>').append(
                $('<label/>').append(
                    $('<span/>', { text: 'Template Name' }),
                    $('<br>'),
                    $('<input/>', {
                        type: 'text',
                        name: 'cv_builder_template_names[]',
                        class: 'regular-text',
                        value: name,
                        placeholder: 'e.g. Classic Blue'
                    })
                )
            ),
            $('<p/>').append(
                $('<label/>').append(
                    $('<span/>', { text: 'Resume Image' }),
                    $('<br>'),
                    $('<input/>', {
                        type: 'hidden',
                        name: 'cv_builder_templates[]',
                        class: 'cv-template-input',
                        value: value
                    }),
                    resumeField
                )
            ),
            $('<p/>').append(
                $('<label/>').append(
                    $('<span/>', { text: 'Resume Border Image' }),
                    $('<br>'),
                    $('<input/>', {
                        type: 'hidden',
                        name: 'cv_builder_template_borders[]',
                        class: 'cv-template-border-input',
                        value: border
                    }),
                    borderField
                )
            ),
            $('<p/>').append(
                $('<label/>').append(
                    $('<span/>', { text: 'Access' }),
                    $('<br>'),
                    $('<select/>', { name: 'cv_builder_template_types[]' }).append(
                        $('<option/>', { value: 'free', text: 'Free', selected: type === 'free' }),
                        $('<option/>', { value: 'premium', text: 'Premium', selected: type === 'premium' })
                    )
                )
            ),
            $('<p/>').append(
                $('<label/>').append(
                    $('<span/>', { text: 'Price (if premium)' }),
                    $('<br>'),
                    $('<input/>', {
                        type: 'text',
                        name: 'cv_builder_template_prices[]',
                        class: 'regular-text',
                        value: price,
                        placeholder: 'e.g. 9.99'
                    })
                )
            )
        );

        const actions = $('<div/>', { class: 'cv-template-actions' }).appendTo(fields);
        $('<button/>', { type: 'button', class: 'button cv-template-upload', text: 'Select Resume Image', 'data-target': 'resume' }).appendTo(actions);
        $('<button/>', { type: 'button', class: 'button cv-template-border-upload', text: 'Select Border Image', 'data-target': 'border' }).appendTo(actions);
        $('<button/>', { type: 'button', class: 'button cv-template-clear', text: 'Clear Resume' }).appendTo(actions);
        $('<button/>', { type: 'button', class: 'button cv-template-border-clear', text: 'Clear Border' }).appendTo(actions);
        $('<button/>', { type: 'button', class: 'button cv-template-remove', text: 'Remove' }).appendTo(actions);

        return row;
    }

    function refreshEmptyState() {
        if (!templateList.children('.cv-template-row').length) {
            templateList.append(createTemplateRow(''));
        }
    }

    $(document).ready(function () {
        refreshEmptyState();

        addButton.on('click', function (e) {
            e.preventDefault();
            templateList.append(createTemplateRow(''));
        });

        templateList.on('click', '.cv-template-upload', function (e) {
            e.preventDefault();
            const row = $(this).closest('.cv-template-row');
            openMediaLibrary(function (url) {
                row.find('.cv-template-input').val(url);
                row.find('.cv-template-thumb').attr('src', url).removeClass('hidden');
                
                // Update resume image preview
                const resumeField = row.find('.cv-resume-upload-field');
                resumeField.html(
                    '<div class="cv-image-preview">' +
                    '<img src="' + url + '" alt="Resume Preview" class="cv-image-preview-img" />' +
                    '<button type="button" class="cv-image-remove" data-target="resume">×</button>' +
                    '</div>'
                );
            }, 'Select or Upload Resume Image');
        });

        templateList.on('click', '.cv-template-border-upload', function (e) {
            e.preventDefault();
            const row = $(this).closest('.cv-template-row');
            openMediaLibrary(function (url) {
                row.find('.cv-template-border-input').val(url);
                
                // Update border image preview
                const borderField = row.find('.cv-border-upload-field');
                borderField.html(
                    '<div class="cv-image-preview">' +
                    '<img src="' + url + '" alt="Border Preview" class="cv-image-preview-img" />' +
                    '<button type="button" class="cv-image-remove" data-target="border">×</button>' +
                    '</div>'
                );
            }, 'Select or Upload Border Image');
        });

        templateList.on('click', '.cv-template-clear', function (e) {
            e.preventDefault();
            const row = $(this).closest('.cv-template-row');
            row.find('.cv-template-input').val('');
            row.find('.cv-template-thumb').attr('src', '').addClass('hidden');
            
            // Reset resume image preview
            const resumeField = row.find('.cv-resume-upload-field');
            resumeField.html(
                '<div class="cv-image-placeholder">' +
                '<span class="cv-image-placeholder-text">No image uploaded</span>' +
                '</div>'
            );
        });

        templateList.on('click', '.cv-template-border-clear', function (e) {
            e.preventDefault();
            const row = $(this).closest('.cv-template-row');
            row.find('.cv-template-border-input').val('');
            
            // Reset border image preview
            const borderField = row.find('.cv-border-upload-field');
            borderField.html(
                '<div class="cv-image-placeholder">' +
                '<span class="cv-image-placeholder-text">No border uploaded</span>' +
                '</div>'
            );
        });

        // Handle remove button from preview
        templateList.on('click', '.cv-image-remove', function (e) {
            e.preventDefault();
            const target = $(this).data('target');
            const row = $(this).closest('.cv-template-row');
            
            if (target === 'resume') {
                row.find('.cv-template-input').val('');
                row.find('.cv-template-thumb').attr('src', '').addClass('hidden');
                const resumeField = row.find('.cv-resume-upload-field');
                resumeField.html(
                    '<div class="cv-image-placeholder">' +
                    '<span class="cv-image-placeholder-text">No image uploaded</span>' +
                    '</div>'
                );
            } else if (target === 'border') {
                row.find('.cv-template-border-input').val('');
                const borderField = row.find('.cv-border-upload-field');
                borderField.html(
                    '<div class="cv-image-placeholder">' +
                    '<span class="cv-image-placeholder-text">No border uploaded</span>' +
                    '</div>'
                );
            }
        });

        templateList.on('click', '.cv-template-remove', function (e) {
            e.preventDefault();
            $(this).closest('.cv-template-row').remove();
            refreshEmptyState();
        });

        // Save Shortcode button handler
        $(document).on('click', '#cv-builder-save-shortcode-btn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const $button = $(this);
            const $input = $('#cv-builder-shortcode');
            const shortcode = $input.val();
            
            // Disable button and show loading
            $button.prop('disabled', true).text('Saving...');
            
            // Get nonce from localized script
            let nonce = '';
            if (typeof cvBuilderAdmin !== 'undefined' && cvBuilderAdmin.shortcodeNonce) {
                nonce = cvBuilderAdmin.shortcodeNonce;
            }
            
            if (!nonce) {
                alert('Error: Security token not found. Please refresh the page and try again.');
                $button.prop('disabled', false).text('Save Shortcode');
                return false;
            }
            
            // Use current page URL
            const formAction = window.location.href.split('?')[0] + '?page=cv-builder-templates';
            
            // Create a form to submit
            const $form = $('<form>', {
                method: 'POST',
                action: formAction,
                style: 'display: none;'
            });
            
            $form.append($('<input>', { type: 'hidden', name: 'cv_builder_shortcode_nonce', value: nonce }));
            $form.append($('<input>', { type: 'hidden', name: 'cv_builder_shortcode', value: shortcode }));
            $form.append($('<input>', { type: 'hidden', name: 'action', value: 'save_cv_builder_shortcode' }));
            
            // Submit the form
            $('body').append($form);
            $form[0].submit();
            
            return false;
        });
        
        // Save Shortcut form handler - validate before submit
        $(document).on('submit', '#cv-builder-shortcut-form', function(e) {
            const $input = $('#shortcut-input');
            const shortcut = $input.val().trim();
            
            // Validate empty input
            if (!shortcut) {
                e.preventDefault();
                alert('Please enter something.');
                return false;
            }
            
            // Button will show loading state
            const $button = $('#cv-builder-save-shortcut-btn');
            $button.prop('disabled', true).text('Saving...');
            
            // Form will submit normally and page will reload
            return true;
        });
    });
})(jQuery);

