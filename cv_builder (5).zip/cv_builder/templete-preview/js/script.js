// Tab functionality
document.addEventListener('DOMContentLoaded', function () {
    const tabs = document.querySelectorAll('.tabs-item, .tabs-item-02');
    const tabContents = document.querySelectorAll('.tab-content');

    const settings = window.cvBuilderSettings || {};
    const defaultSettings = {
        cardBackground: '#FFFAF0',
        framePicker: '#ff0000',
        fontPicker: '#ff0000',
        templateImage: 'images/10.png',
        ganeshaIcon: '../assets/images/icon3.png'
    };

    let templates = (settings && Array.isArray(settings.templates)) ? settings.templates : [];
    if (!templates.length) {
        try {
            const storedTemplates = sessionStorage.getItem('cvBuilderTemplates');
            if (storedTemplates) {
                templates = JSON.parse(storedTemplates);
            }
        } catch (error) {
            console.warn('Template Preview: Unable to read templates from sessionStorage.', error);
        }
    }

    if (templates.length) {
        defaultSettings.templateImage = templates[0].image;
    }

    const storedFormData = sessionStorage.getItem('cvBuilderFormData');

    if (storedFormData) {
        try {
            const formData = JSON.parse(storedFormData);
            populatePreviewFromFormData(formData);
        } catch (error) {
            console.error('Template Preview: Failed to parse stored CV data.', error);
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', function () {
            const targetTab = this.getAttribute('data-tab');

            // Remove active class from all tabs
            tabs.forEach(t => {
                t.classList.remove('active');
                t.classList.add('tabs-item-02');
                t.classList.remove('tabs-item');
            });

            // Add active class to clicked tab
            this.classList.add('active');
            this.classList.add('tabs-item');
            this.classList.remove('tabs-item-02');

            // Hide all tab contents
            tabContents.forEach(content => {
                content.classList.remove('active');
            });

            // Show selected tab content
            const targetContent = document.getElementById(targetTab + '-content');
            if (targetContent) {
                targetContent.classList.add('active');
            }
        });
    });

    // Sub-tabs functionality
    const subTabs = document.querySelectorAll('.sub-tabs-item, .sub-tabs-item-02');
    const subTabContents = document.querySelectorAll('.sub-tab-content');

    subTabs.forEach(subTab => {
        subTab.addEventListener('click', function () {
            const targetSubTab = this.getAttribute('data-sub-tab');

            // Remove active class from all sub-tabs
            subTabs.forEach(st => {
                st.classList.remove('active');
                st.classList.add('sub-tabs-item-02');
                st.classList.remove('sub-tabs-item');
            });

            // Add active class to clicked sub-tab
            this.classList.add('active');
            this.classList.add('sub-tabs-item');
            this.classList.remove('sub-tabs-item-02');

            // Hide all sub-tab contents
            subTabContents.forEach(content => {
                content.classList.remove('active');
            });

            // Show selected sub-tab content
            const targetSubContent = document.getElementById(targetSubTab + '-content');
            if (targetSubContent) {
                targetSubContent.classList.add('active');
            }
        });
    });

    // Color circle click functionality - change card-02-content background
    const colorCircles = document.querySelectorAll('.color-circle');
    const card02Content = document.querySelector('.card-02-content');
    const detailTextElements = document.querySelectorAll('.personal-info-list .info-key, .personal-info-list .info-value, .family-info-list .info-key, .family-info-list .info-value, .contact-info-list .info-key, .contact-info-list .info-value');
    const frameColorPicker = document.querySelector('.frame-color-picker');
    const fontColorPicker = document.querySelector('.font-color-picker');
    const fontItems = document.querySelectorAll('.font-item');
    const previewTextElements = document.querySelectorAll('.card-02-content, .card-02-content h1, .card-02-content h2, .card-02-content h3, .card-02-content p, .card-02-content .info-key, .card-02-content .info-value, .card-02-content .shree-ganesh-text, .card-02-content span, .card-02-content div');
    const ganeshaIconWrapper = document.querySelector('.ganesha-icon');
    const iconOptions = document.querySelectorAll('.icon-option');
    const downloadPreviewBtn = document.getElementById('download-pdf-preview');

    function resolveBackgroundImage(element) {
        if (!element) {
            return null;
        }
        const style = window.getComputedStyle(element);
        const bgImage = style.backgroundImage;
        if (bgImage && bgImage !== 'none') {
            const match = bgImage.match(/url\(["']?(.*?)["']?\)/);
            if (match && match[1]) {
                try {
                    const absolute = new URL(match[1], window.location.href).href;
                    return 'url("' + absolute + '")';
                } catch (error) {
                    console.warn('CV Builder: Failed to resolve background image URL.', error);
                }
            }
        }
        return null;
    }

    function loadScriptOnce(src) {
        return new Promise((resolve, reject) => {
            if (document.querySelector('script[src="' + src + '"]')) {
                resolve();
                return;
            }

            const script = document.createElement('script');
            script.src = src;
            script.async = true;
            script.onload = () => resolve();
            script.onerror = () => reject(new Error('Failed to load ' + src));
            document.head.appendChild(script);
        });
    }

    function injectWatermarkOverlay(targetElement, text) {
        if (!targetElement || !text) {
            return null;
        }

        const computed = window.getComputedStyle(targetElement);
        if (computed.position === 'static') {
            targetElement.style.position = 'relative';
        }

        const rect = targetElement.getBoundingClientRect();
        const overlay = document.createElement('div');
        overlay.className = 'pdf-watermark-overlay';
        overlay.style.position = 'absolute';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.pointerEvents = 'none';
        overlay.style.zIndex = '250';
        overlay.style.overflow = 'hidden';

        const fontSize = 15;
        const stepX = Math.max(200, Math.floor(fontSize * 10));
        const stepY = Math.max(160, Math.floor(fontSize * 8));
        const watermarkLabel = text;
        const width = overlay.scrollWidth || overlay.offsetWidth || 1000;
        const height = overlay.scrollHeight || overlay.offsetHeight || 1400;

        for (let y = -stepY; y <= height + stepY; y += stepY) {
            const offsetX = (((y + stepY) / stepY) % 2 !== 0) ? stepX / 2 : 0;
            for (let x = -stepX; x <= width + stepX; x += stepX) {
                const label = document.createElement('div');
                label.textContent = watermarkLabel;
                label.style.position = 'absolute';
                label.style.left = x + offsetX + 'px';
                label.style.top = y + 'px';
                label.style.fontSize = fontSize + 'px';
                label.style.fontWeight = '600';
                label.style.fontStyle = 'italic';
                label.style.fontFamily = '"Helvetica Neue", Arial, sans-serif';
                label.style.letterSpacing = '6px';
                label.style.color = '#c9c9c9';
                label.style.textTransform = 'uppercase';
                label.style.textShadow = 'none';
                label.style.transform = 'translate(-50%, -50%) rotate(-24deg)';
                label.style.transformOrigin = '50% 50%';
                label.style.whiteSpace = 'nowrap';
                label.style.pointerEvents = 'none';
                overlay.appendChild(label);
            }
        }

        targetElement.appendChild(overlay);
        return overlay;
    }

    colorCircles.forEach(circle => {
        circle.addEventListener('click', function () {
            // Get the background color directly from inline style attribute for fastest performance
            const styleAttr = this.getAttribute('style');
            let color = '';

            if (styleAttr && styleAttr.includes('background-color:')) {
                // Extract color from inline style
                const match = styleAttr.match(/background-color:\s*([^;]+)/);
                if (match) {
                    color = match[1].trim();
                }
            }

            // Fallback to computed style if needed
            if (!color) {
                color = window.getComputedStyle(this).backgroundColor;
            }

            // Apply color immediately for instant response
            if (color) {
                const parentSubContent = this.closest('.sub-tab-content');

                if (parentSubContent && parentSubContent.id === 'font-sub-content') {
                    // Change info text colors only when selecting from font sub tab
                    detailTextElements.forEach(textEl => {
                        textEl.style.color = color;
                    });
                } else if (card02Content) {
                    // Default behavior for frame/tab color selection
                    card02Content.style.backgroundColor = color;
                }
            }
        });
    });

    if (frameColorPicker) {
        frameColorPicker.addEventListener('input', function () {
            const color = this.value;
            if (card02Content) {
                card02Content.style.backgroundColor = color;
            }
        });
    }

    if (fontColorPicker) {
        fontColorPicker.addEventListener('input', function () {
            const color = this.value;
            detailTextElements.forEach(textEl => {
                textEl.style.color = color;
            });
        });
    }

    if (fontItems.length && previewTextElements.length) {
        fontItems.forEach(item => {
            item.addEventListener('click', function () {
                const fontFamily = this.dataset.font;
                if (fontFamily) {
                    previewTextElements.forEach(element => {
                        element.style.fontFamily = fontFamily;
                    });

                    fontItems.forEach(fontItem => fontItem.classList.remove('active'));
                    this.classList.add('active');
                }
            });
        });
    }

    const templateGrid = document.getElementById('template-card-grid');
    const card02Img = document.querySelector('.card-02-content img');
    const mobileBackgroundStyle = document.createElement('style');
    const resetButton = document.querySelector('.reset-button');
    let templateCards = [];

    function setGaneshaIcon(src) {
        if (!ganeshaIconWrapper) {
            return;
        }

        ganeshaIconWrapper.innerHTML = '';

        const fallback = ganeshaIconWrapper.dataset.defaultIcon || defaultSettings.ganeshaIcon;
        const finalSrc = src || fallback;

        if (!finalSrc) {
            return;
        }

        const img = document.createElement('img');
        img.src = finalSrc;
        img.alt = 'Religious Symbol';
        ganeshaIconWrapper.appendChild(img);

        const resolvedSrc = new URL(finalSrc, window.location.href).href;
        iconOptions.forEach(option => {
            const optionSrc = option.dataset.icon ? new URL(option.dataset.icon, window.location.href).href : '';
            if (optionSrc === resolvedSrc) {
                option.classList.add('active');
            } else {
                option.classList.remove('active');
            }
        });
    }

    function storeGaneshaIcon(src) {
        try {
            if (src) {
                sessionStorage.setItem('cvBuilderSelectedIcon', src);
            } else {
                sessionStorage.removeItem('cvBuilderSelectedIcon');
            }
        } catch (error) {
            console.error('Template Preview: Failed to store icon selection.', error);
        }

        try {
            const stored = sessionStorage.getItem('cvBuilderFormData');
            const data = stored ? JSON.parse(stored) : {};

            if (src) {
                data.ganesha_icon = src;
            } else {
                delete data.ganesha_icon;
            }

            sessionStorage.setItem('cvBuilderFormData', JSON.stringify(data));
        } catch (error) {
            console.error('Template Preview: Failed to update stored form data for icon.', error);
        }
    }

    function normalizeUrl(url) {
        if (!url) {
            return '';
        }
        try {
            return new URL(url, window.location.href).href;
        } catch (error) {
            return url;
        }
    }

    function setActiveTemplate(imagePath) {
        if (!templateCards.length) {
            return;
        }
        const normalized = normalizeUrl(imagePath);
        templateCards.forEach(card => {
            if (normalizeUrl(card.dataset.templateImage) === normalized) {
                card.classList.add('active');
                
                // Apply border image if available, hide resume image
                const borderImage = card.dataset.templateBorder;
                if (card02Content && borderImage) {
                    // Hide resume image and show only border image
                    if (card02Img) {
                        card02Img.style.display = 'none';
                    }
                    // Remove any mobile background style that might override
                    if (mobileBackgroundStyle.parentNode) {
                        mobileBackgroundStyle.parentNode.removeChild(mobileBackgroundStyle);
                    }
                    // Set border image as background
                    card02Content.style.backgroundImage = 'url("' + borderImage + '")';
                    card02Content.style.backgroundSize = 'cover';
                    card02Content.style.backgroundPosition = 'center';
                    card02Content.style.backgroundRepeat = 'no-repeat';
                    card02Content.removeAttribute('data-template-bg');
                } else if (card02Content && !borderImage) {
                    // If no border, show resume image
                    if (card02Img) {
                        card02Img.src = imagePath;
                        card02Img.style.display = 'block';
                    }
                    card02Content.style.backgroundImage = 'none';
                }
            } else {
                card.classList.remove('active');
            }
        });
    }

    function renderTemplateCards() {
        if (!templateGrid) {
            return;
        }

        templateGrid.innerHTML = '';

        if (!templates.length) {
            const message = document.createElement('p');
            message.className = 'template-empty-message';
            message.textContent = 'No templates available. Please upload templates from the admin panel.';
            templateGrid.appendChild(message);
            templateCards = templateGrid.querySelectorAll('.template-card');
            return;
        }

        templates.forEach((template, index) => {
            const card = document.createElement('button');
            card.type = 'button';
            card.className = 'template-card';
            card.dataset.templateImage = template.image;
            card.dataset.templateBorder = template.border || '';
            
            // Add premium class and base radius if premium
            if (template.is_premium) {
                card.classList.add('template-card-premium');
                card.style.borderRadius = '12px';
            }

            const thumb = document.createElement('span');
            thumb.className = 'template-card-thumb';
            thumb.style.backgroundImage = 'url("' + (template.thumb || template.image) + '")';
            card.appendChild(thumb);

            // Add premium badge with price if premium
            if (template.is_premium && template.price) {
                const premiumBadge = document.createElement('span');
                premiumBadge.className = 'template-card-premium-badge';
                premiumBadge.textContent = '₹' + template.price;
                card.appendChild(premiumBadge);
            }

            const label = document.createElement('span');
            label.className = 'template-card-label';
            label.textContent = template.label || ('Template ' + (index + 1));
            card.appendChild(label);

            card.addEventListener('click', function () {
                const imagePath = this.dataset.templateImage;
                const borderImage = this.dataset.templateBorder;
                
                // Show ONLY border image in card-02-content if available
                if (card02Content && borderImage) {
                    // Hide the resume image and show only border image
                    if (card02Img) {
                        card02Img.style.display = 'none';
                    }
                    // Remove any mobile background style that might override
                    if (mobileBackgroundStyle.parentNode) {
                        mobileBackgroundStyle.parentNode.removeChild(mobileBackgroundStyle);
                    }
                    // Set border image as background
                    card02Content.style.backgroundImage = 'url("' + borderImage + '")';
                    card02Content.style.backgroundSize = 'cover';
                    card02Content.style.backgroundPosition = 'center';
                    card02Content.style.backgroundRepeat = 'no-repeat';
                    card02Content.removeAttribute('data-template-bg');
                } else if (card02Content && !borderImage) {
                    // If no border image, show resume image as fallback
                    if (card02Img) {
                        card02Img.src = imagePath;
                        card02Img.style.display = 'block';
                    }
                    card02Content.style.backgroundImage = 'none';
                    // Apply resume image background for viewport
                    applyBackgroundForViewport(imagePath);
                }
                
                sessionStorage.setItem('cvBuilderSelectedTemplate', imagePath);
                sessionStorage.setItem('cvBuilderSelectedBorder', borderImage || '');
                setActiveTemplate(imagePath);
            });

            templateGrid.appendChild(card);
        });

        templateCards = templateGrid.querySelectorAll('.template-card');
        const savedTemplate = sessionStorage.getItem('cvBuilderSelectedTemplate') || defaultSettings.templateImage;
        const savedBorder = sessionStorage.getItem('cvBuilderSelectedBorder') || '';
        setActiveTemplate(savedTemplate);
        
        // Restore border image if saved, hide resume image
        if (card02Content && savedBorder) {
            if (card02Img) {
                card02Img.style.display = 'none';
            }
            // Remove any mobile background style that might override
            if (mobileBackgroundStyle.parentNode) {
                mobileBackgroundStyle.parentNode.removeChild(mobileBackgroundStyle);
            }
            card02Content.style.backgroundImage = 'url("' + savedBorder + '")';
            card02Content.style.backgroundSize = 'cover';
            card02Content.style.backgroundPosition = 'center';
            card02Content.style.backgroundRepeat = 'no-repeat';
            card02Content.removeAttribute('data-template-bg');
        } else if (card02Img && !savedBorder) {
            // If no border saved, show resume image
            card02Img.style.display = 'block';
        }
    }

    renderTemplateCards();

    function applyBackgroundForViewport(imagePath) {
        if (!card02Content) {
            return;
        }

        const isMobile = window.matchMedia('(max-width: 640px)').matches;

        if (isMobile) {
            if (!mobileBackgroundStyle.parentNode) {
                mobileBackgroundStyle.setAttribute('data-template-style', 'true');
                document.head.appendChild(mobileBackgroundStyle);
            }
            mobileBackgroundStyle.textContent = '.card-02-content { background-image: url("' + imagePath + '"); background-size: cover; background-position: center; }';
            card02Content.setAttribute('data-template-bg', imagePath);
        } else {
            if (mobileBackgroundStyle.parentNode) {
                mobileBackgroundStyle.parentNode.removeChild(mobileBackgroundStyle);
            }
            card02Content.style.backgroundImage = 'none';
            card02Content.removeAttribute('data-template-bg');
        }

        setActiveTemplate(imagePath);
    }

    function loadStoredTemplateBackground() {
        const stored = sessionStorage.getItem('cvBuilderSelectedTemplate');
        if (stored) {
            applyBackgroundForViewport(stored);
            setActiveTemplate(stored);
        } else if (card02Content && card02Content.getAttribute('data-template-bg')) {
            applyBackgroundForViewport(card02Content.getAttribute('data-template-bg'));
            setActiveTemplate(card02Content.getAttribute('data-template-bg'));
        } else if (card02Img && card02Img.src) {
            applyBackgroundForViewport(card02Img.src);
            setActiveTemplate(card02Img.src);
        }

        const storedIcon = sessionStorage.getItem('cvBuilderSelectedIcon');
        if (storedIcon) {
            setGaneshaIcon(storedIcon);
        } else {
            const storedData = sessionStorage.getItem('cvBuilderFormData');
            if (storedData) {
                try {
                    const parsed = JSON.parse(storedData);
                    setGaneshaIcon(parsed && parsed.ganesha_icon ? parsed.ganesha_icon : defaultSettings.ganeshaIcon);
                } catch (error) {
                    console.error('Template Preview: Failed to restore ganesha icon.', error);
                    setGaneshaIcon(defaultSettings.ganeshaIcon);
                }
            } else {
                setGaneshaIcon(defaultSettings.ganeshaIcon);
            }
        }
    }

    if (templates.length === 0) {
        setActiveTemplate(defaultSettings.templateImage);
    }

    loadStoredTemplateBackground();

    if (iconOptions.length) {
        iconOptions.forEach(option => {
            option.addEventListener('click', function () {
                const iconPath = this.dataset.icon;
                setGaneshaIcon(iconPath);
                storeGaneshaIcon(iconPath);
            });
        });
    }

    window.addEventListener('resize', function () {
        loadStoredTemplateBackground();
    });

    if (downloadPreviewBtn) {
        downloadPreviewBtn.addEventListener('click', function () {
            const card = document.querySelector('.card-02');
            if (!card) {
                alert('Preview card not found.');
                return;
            }

            // Get current border image from active template or sessionStorage
            const savedBorder = sessionStorage.getItem('cvBuilderSelectedBorder') || '';
            const activeCard = document.querySelector('.template-card.active');
            const currentBorderImage = activeCard ? activeCard.dataset.templateBorder : savedBorder;
            const currentTemplateImage = activeCard ? activeCard.dataset.templateImage : (sessionStorage.getItem('cvBuilderSelectedTemplate') || '');
            
            // Check if current template is premium
            let isPremiumTemplate = false;
            if (activeCard) {
                // Check if card has premium class
                isPremiumTemplate = activeCard.classList.contains('template-card-premium');
            } else if (currentTemplateImage && templates.length) {
                // Fallback: check templates array for premium status
                const currentTemplate = templates.find(t => t.image === currentTemplateImage || t.thumb === currentTemplateImage);
                if (currentTemplate && currentTemplate.is_premium) {
                    isPremiumTemplate = true;
                }
            }
            
            // Ensure border image is set in card-02-content before cloning
            const card02Content = document.querySelector('.card-02-content');
            if (card02Content && currentBorderImage) {
                card02Content.style.backgroundImage = 'url("' + currentBorderImage + '")';
                card02Content.style.backgroundSize = 'cover';
                card02Content.style.backgroundPosition = 'center';
                card02Content.style.backgroundRepeat = 'no-repeat';
                
                // Hide resume image
                const resumeImg = card02Content.querySelector('img');
                if (resumeImg) {
                    resumeImg.style.display = 'none';
                }
            }

            // Only add watermark if template is NOT premium
            const watermarkText = (!isPremiumTemplate && settings.watermarkText && settings.watermarkText.trim()) ? settings.watermarkText.trim() : '';
            const loaders = [
                loadScriptOnce('https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js'),
                loadScriptOnce('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js')
            ];

            Promise.all(loaders)
                .then(() => {
                    const cardClone = card.cloneNode(true);
                    const computed = window.getComputedStyle(card);

                    cardClone.style.boxShadow = 'none';
                    cardClone.style.width = computed.width;
                    cardClone.style.backgroundColor = computed.backgroundColor;
                    if (window.getComputedStyle(cardClone).position === 'static') {
                        cardClone.style.position = 'relative';
                    }
                    const cardBgImage = resolveBackgroundImage(card);
                    if (cardBgImage) {
                        cardClone.style.backgroundImage = cardBgImage;
                        cardClone.style.backgroundSize = computed.backgroundSize;
                        cardClone.style.backgroundPosition = computed.backgroundPosition;
                        cardClone.style.backgroundRepeat = computed.backgroundRepeat;
                    }
                    cardClone.style.padding = computed.padding;
                    cardClone.style.margin = '0';

                    // Get the original card-02-content element to check for border image
                    const originalContent = document.querySelector('.card-02-content');
                    const contentClone = cardClone.querySelector('.card-02-content');
                    if (contentClone && originalContent) {
                        const originalComputed = window.getComputedStyle(originalContent);
                        const contentComputed = window.getComputedStyle(contentClone);
                        
                        // Preserve all color and style changes
                        contentClone.style.backgroundColor = originalComputed.backgroundColor;
                        contentClone.style.color = originalComputed.color;
                        
                        // Get the actual background image (border image) from ORIGINAL element
                        const contentBgImage = resolveBackgroundImage(originalContent);
                        const originalBgImage = originalComputed.backgroundImage;
                        
                        // Check if border image exists (background image is not 'none')
                        if (contentBgImage || (originalBgImage && originalBgImage !== 'none' && !originalBgImage.includes('data:'))) {
                            // Border image is present - use it
                            if (contentBgImage) {
                                contentClone.style.backgroundImage = contentBgImage;
                            } else {
                                contentClone.style.backgroundImage = originalBgImage;
                            }
                            contentClone.style.backgroundSize = originalComputed.backgroundSize || 'cover';
                            contentClone.style.backgroundPosition = originalComputed.backgroundPosition || 'center';
                            contentClone.style.backgroundRepeat = originalComputed.backgroundRepeat || 'no-repeat';
                            
                            // Remove resume image completely if border image is present
                            const image = contentClone.querySelector('img');
                            if (image) {
                                image.remove(); // Remove entirely from DOM
                            }
                        } else {
                            // No border image - show resume image
                            const image = contentClone.querySelector('img');
                            if (image) {
                                const originalImage = originalContent.querySelector('img');
                                if (originalImage) {
                                    const imageComputed = window.getComputedStyle(originalImage);
                                    image.style.display = imageComputed.display === 'none' ? 'none' : 'block';
                                    image.style.visibility = imageComputed.visibility || 'visible';
                                    image.style.opacity = imageComputed.opacity || '1';
                                    image.style.position = imageComputed.position || 'absolute';
                                    image.style.top = imageComputed.top || '0';
                                    image.style.left = imageComputed.left || '0';
                                    image.style.width = imageComputed.width || '100%';
                                    image.style.height = imageComputed.height || '100%';
                                    image.style.objectFit = imageComputed.objectFit || 'cover';
                                    image.style.zIndex = imageComputed.zIndex || '0';
                                }
                            }
                            contentClone.style.backgroundImage = 'none';
                        }
                        
                        // Preserve all text colors and font styles
                        const textElements = contentClone.querySelectorAll('h1, h2, h3, p, span, div, .info-key, .info-value');
                        textElements.forEach(el => {
                            const elComputed = window.getComputedStyle(el);
                            el.style.color = elComputed.color;
                            el.style.fontFamily = elComputed.fontFamily;
                            el.style.fontSize = elComputed.fontSize;
                            el.style.fontWeight = elComputed.fontWeight;
                        });
                        
                        contentClone.style.position = 'relative';
                        contentClone.style.height = contentComputed.height;
                    }

                    injectWatermarkOverlay(cardClone, watermarkText);

                    const actionsClone = cardClone.querySelector('.card-02-actions');
                    if (actionsClone) {
                        actionsClone.remove();
                    }

                    const previewTitle = cardClone.querySelector('.card-02-title');
                    if (previewTitle) {
                        previewTitle.remove();
                    }

                    const previewNotice = cardClone.querySelector('.preview-box');
                    if (previewNotice) {
                        previewNotice.remove();
                    }

                    const tempWrapper = document.createElement('div');
                    tempWrapper.style.position = 'fixed';
                    tempWrapper.style.top = '-10000px';
                    tempWrapper.style.left = '0';
                    tempWrapper.style.width = computed.width;
                    tempWrapper.appendChild(cardClone);
                    document.body.appendChild(tempWrapper);

                    // Wait for all images to load before capturing
                    const allImages = cardClone.querySelectorAll('img');
                    const imagePromises = Array.from(allImages).map(img => {
                        if (img.complete) {
                            return Promise.resolve();
                        }
                        return new Promise((resolve, reject) => {
                            img.onload = resolve;
                            img.onerror = resolve; // Continue even if image fails
                            setTimeout(resolve, 2000); // Timeout after 2 seconds
                        });
                    });

                    // Also wait for background images to load
                    const waitForBackgroundImages = () => {
                        return new Promise((resolve) => {
                            setTimeout(() => {
                                // Give time for background images to load
                                resolve();
                            }, 500);
                        });
                    };

                    Promise.all([...imagePromises, waitForBackgroundImages()])
                        .then(() => {
                            const options = {
                                scale: Math.max(2, window.devicePixelRatio || 2),
                                backgroundColor: '#ffffff',
                                useCORS: true,
                                allowTaint: true,
                                logging: false,
                                windowWidth: tempWrapper.scrollWidth,
                                windowHeight: tempWrapper.scrollHeight,
                                onclone: (clonedDoc) => {
                                    // Ensure all styles are preserved in the cloned document
                                    const clonedContent = clonedDoc.querySelector('.card-02-content');
                                    if (clonedContent) {
                                        const originalContent = document.querySelector('.card-02-content');
                                        if (originalContent) {
                                            const computed = window.getComputedStyle(originalContent);
                                            const bgImage = resolveBackgroundImage(originalContent);
                                            
                                            // Set border image if present
                                            if (bgImage || (computed.backgroundImage && computed.backgroundImage !== 'none')) {
                                                clonedContent.style.backgroundImage = bgImage || computed.backgroundImage;
                                                clonedContent.style.backgroundSize = computed.backgroundSize || 'cover';
                                                clonedContent.style.backgroundPosition = computed.backgroundPosition || 'center';
                                                clonedContent.style.backgroundRepeat = computed.backgroundRepeat || 'no-repeat';
                                                
                                                // Remove/hide resume image in cloned document
                                                const clonedImage = clonedContent.querySelector('img');
                                                if (clonedImage) {
                                                    clonedImage.remove(); // Remove entirely instead of hiding
                                                }
                                            } else {
                                                clonedContent.style.backgroundImage = 'none';
                                            }
                                            
                                            clonedContent.style.backgroundColor = computed.backgroundColor;
                                            clonedContent.style.color = computed.color;
                                            
                                            // Preserve all text colors
                                            const textElements = clonedContent.querySelectorAll('h1, h2, h3, p, span, div, .info-key, .info-value');
                                            textElements.forEach(el => {
                                                const elComputed = window.getComputedStyle(el);
                                                el.style.color = elComputed.color;
                                                el.style.fontFamily = elComputed.fontFamily;
                                            });
                                        }
                                    }
                                }
                            };

                            return window.html2canvas(cardClone, options);
                        })
                        .then(canvas => {
                            if (watermarkText) {
                                const ctx = canvas.getContext('2d');
                                if (ctx && typeof ctx.save === 'function') {
                                    ctx.save();
                                    const fontSize = 15;
                                    const step = Math.max(200, Math.floor(fontSize * 10));
                                    const text = watermarkText;

                                    ctx.font = '600 italic ' + fontSize + 'px "Helvetica Neue", Arial, sans-serif';
                                    ctx.fillStyle = '#c9c9c9';
                                    ctx.strokeStyle = 'rgba(0, 0, 0, 0.55)';
                                    ctx.lineWidth = Math.max(1.5, Math.floor(fontSize * 0.03));
                                    ctx.textAlign = 'center';
                                    ctx.textBaseline = 'middle';
                                    ctx.translate(canvas.width / 2, canvas.height / 2);
                                    ctx.rotate(-Math.PI / 5);

                                    for (let y = -step; y <= canvas.height + step; y += step) {
                                        const offset = (((y + step) / step) % 2 !== 0) ? step / 2 : 0;
                                        for (let x = -step; x <= canvas.width + step; x += step) {
                                            const posX = x + offset;
                                            ctx.strokeText(text, posX, y);
                                            ctx.fillText(text, posX, y);
                                        }
                                    }

                                    ctx.restore();
                                }
                            }

                            document.body.removeChild(tempWrapper);

                            const imgData = canvas.toDataURL('image/png');
                            const { jsPDF } = window.jspdf;
                            const orientation = canvas.width >= canvas.height ? 'l' : 'p';
                            const pdf = new jsPDF({
                                orientation,
                                unit: 'px',
                                format: [canvas.width, canvas.height]
                            });
                            pdf.internal.scaleFactor = 1;
                            pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
                            pdf.save('cv.pdf');
                        })
                        .catch(error => {
                            console.error('CV Builder: Failed to capture preview for PDF.', error);
                            alert('Unable to generate PDF preview. Please try again.');
                            document.body.removeChild(tempWrapper);
                        });
                })
                .catch(error => {
                    console.error('CV Builder: Failed to load PDF libraries.', error);
                    alert('Unable to load PDF libraries. Please check your internet connection.');
                });
        });
    }

    function resetCustomization() {
        if (card02Content) {
            card02Content.style.backgroundColor = defaultSettings.cardBackground;
            card02Content.style.backgroundImage = 'none';
            card02Content.setAttribute('data-template-bg', defaultSettings.templateImage);
        }

        if (mobileBackgroundStyle.parentNode) {
            mobileBackgroundStyle.parentNode.removeChild(mobileBackgroundStyle);
        }

        if (card02Img) {
            card02Img.src = defaultSettings.templateImage;
            card02Img.style.display = 'block';
        }

        const detailTextElements = document.querySelectorAll('.personal-info-list .info-key, .personal-info-list .info-value, .family-info-list .info-key, .family-info-list .info-value, .contact-info-list .info-key, .contact-info-list .info-value');
        detailTextElements.forEach(el => {
            el.style.color = '';
        });

        const previewTextElements = document.querySelectorAll('.card-02-content, .card-02-content h1, .card-02-content h2, .card-02-content h3, .card-02-content p, .card-02-content .info-key, .card-02-content .info-value, .card-02-content .shree-ganesh-text, .card-02-content span, .card-02-content div');
        previewTextElements.forEach(el => {
            el.style.fontFamily = '';
        });

        const frameColorPicker = document.querySelector('.frame-color-picker');
        if (frameColorPicker) {
            frameColorPicker.value = defaultSettings.framePicker;
        }

        const fontColorPicker = document.querySelector('.font-color-picker');
        if (fontColorPicker) {
            fontColorPicker.value = defaultSettings.fontPicker;
        }

        const fontItems = document.querySelectorAll('.font-item');
        fontItems.forEach(item => item.classList.remove('active'));

        sessionStorage.removeItem('cvBuilderSelectedTemplate');
        sessionStorage.removeItem('cvBuilderSelectedBorder');
        sessionStorage.removeItem('cvBuilderSelectedIcon');

        const stored = sessionStorage.getItem('cvBuilderFormData');
        if (stored) {
            try {
                const parsed = JSON.parse(stored);
                delete parsed.template_image;
                delete parsed.ganesha_icon;
                sessionStorage.setItem('cvBuilderFormData', JSON.stringify(parsed));
            } catch (error) {
                console.error('Template Preview: Failed to reset stored form data.', error);
            }
        }

        applyBackgroundForViewport(defaultSettings.templateImage);
        setGaneshaIcon(defaultSettings.ganeshaIcon);
        storeGaneshaIcon(defaultSettings.ganeshaIcon);
    }

    if (resetButton) {
        resetButton.addEventListener('click', function (e) {
            e.preventDefault();
            resetCustomization();
        });
    }
});

function formatLabelFromKey(key) {
    if (!key) {
        return '';
    }
    const formatted = key.toString().replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim();
    return formatted.charAt(0).toUpperCase() + formatted.slice(1);
}

function populatePreviewFromFormData(formData) {
    if (!formData || typeof formData !== 'object') {
        return;
    }

    const sectionContainers = {
        '.personal-details-section': '.personal-info-list',
        '.family-details-section': '.family-info-list',
        '.contact-details-section': '.contact-info-list'
    };

    const applySectionData = (sectionSelector, sectionData = {}) => {
        if (!sectionData || typeof sectionData !== 'object') {
            return;
        }

        const sectionEl = document.querySelector(sectionSelector);
        if (!sectionEl) {
            return;
        }

        const listSelector = sectionContainers[sectionSelector] || null;
        let listContainer = null;

        if (listSelector) {
            listContainer = sectionEl.querySelector(listSelector);
        }

        if (!listContainer) {
            const firstItem = sectionEl.querySelector('.info-item');
            if (firstItem && firstItem.parentElement) {
                listContainer = firstItem.parentElement;
            }
        }

        Object.keys(sectionData).forEach((fieldKey) => {
            const rawData = sectionData[fieldKey];
            let fieldValue = rawData;
            let fieldLabel = null;

            if (rawData && typeof rawData === 'object' && ('value' in rawData || 'label' in rawData)) {
                fieldValue = rawData.value;
                fieldLabel = rawData.label || null;
            }

            const normalizedValue = fieldValue === undefined || fieldValue === null
                ? ''
                : String(fieldValue);

            const displayValue = normalizedValue.trim() === '' ? '—' : normalizedValue;

            let item = sectionEl.querySelector('.info-item[data-field="' + fieldKey + '"]');

            if (!item && listContainer) {
                item = document.createElement('div');
                item.className = 'info-item';
                item.setAttribute('data-field', fieldKey);

                const keySpan = document.createElement('span');
                keySpan.className = 'info-key';
                keySpan.textContent = fieldLabel || formatLabelFromKey(fieldKey);

                const valueSpan = document.createElement('span');
                valueSpan.className = 'info-value';
                valueSpan.textContent = ': ' + displayValue;

                item.appendChild(keySpan);
                item.appendChild(valueSpan);
                listContainer.appendChild(item);
                return;
            }

            const keyEl = item.querySelector('.info-key');
            const valueEl = item.querySelector('.info-value');

            if (keyEl) {
                const resolvedLabel = fieldLabel || keyEl.textContent || formatLabelFromKey(fieldKey);
                keyEl.textContent = resolvedLabel;
            }

            if (valueEl) {
                valueEl.textContent = ': ' + displayValue;
            }
        });
    };

    applySectionData('.personal-details-section', formData.personal);
    applySectionData('.family-details-section', formData.family);
    applySectionData('.contact-details-section', formData.contact);

    // Update profile photo
    if (formData.photo) {
        const profilePicture = document.querySelector('.profile-picture');
        if (profilePicture) {
            profilePicture.style.backgroundImage = 'url(' + formData.photo + ')';
        }
    }

    const iconWrapper = document.querySelector('.ganesha-icon');
    if (iconWrapper) {
        iconWrapper.innerHTML = '';
        const defaultIcon = iconWrapper.dataset.defaultIcon || '../assets/images/icon3.png';
        const iconSrc = formData.ganesha_icon || defaultIcon;
        if (iconSrc) {
            const img = document.createElement('img');
            img.src = iconSrc;
            img.alt = 'Religious Symbol';
            iconWrapper.appendChild(img);
            storeGaneshaIcon(iconSrc);
        } else {
            storeGaneshaIcon(defaultIcon);
        }
    }

    if (formData.template_image) {
        try {
            sessionStorage.setItem('cvBuilderSelectedTemplate', formData.template_image);
        } catch (error) {
            console.error('Template Preview: Failed to store template image.', error);
        }
        const cardImg = document.querySelector('.card-02-content img');
        if (cardImg) {
            cardImg.src = formData.template_image;
        }
        const cardContent = document.querySelector('.card-02-content');
        if (cardContent) {
            cardContent.setAttribute('data-template-bg', formData.template_image);
        }
        applyBackgroundForViewport(formData.template_image);
    }

    // Update Shree Ganesh text and Biodata heading
    if (formData.shree_ganesh_text) {
        const shreeText = document.querySelector('.shree-ganesh-text');
        if (shreeText) {
            shreeText.textContent = formData.shree_ganesh_text;
        }
    }

    if (formData.biodata_text) {
        const heading = document.querySelector('.biodata-heading');
        if (heading) {
            heading.textContent = formData.biodata_text;
        }
    }
}

