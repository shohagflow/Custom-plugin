<?php
/**
 * Plugin Name: CV Builder
 * Plugin URI: https://example.com/cv-builder
 * Description: Create personalized marriage biodata/CV with customizable templates
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * Text Domain: cv-builder
 * Requires Plugins:  gtranslate
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('CV_BUILDER_VERSION', '1.0.1');
define('CV_BUILDER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CV_BUILDER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CV_BUILDER_PLUGIN_PATH', CV_BUILDER_PLUGIN_DIR);

class CV_Builder {

    private static $shortcode_used = false;
    private $default_templates = array();
    private $localized_settings = null;

    public function __construct() {
        $this->default_templates = array(
            array(
                'label' => __('Template 1', 'cv-builder'),
                'image' => CV_BUILDER_PLUGIN_URL . 'templete-preview/images/10.png',
                'border' => '',
                'is_premium' => false,
                'price' => '',
            ),
            array(
                'label' => __('Template 2', 'cv-builder'),
                'image' => CV_BUILDER_PLUGIN_URL . 'templete-preview/images/13.png',
                'border' => '',
                'is_premium' => false,
                'price' => '',
            ),
            array(
                'label' => __('Template 3', 'cv-builder'),
                'image' => CV_BUILDER_PLUGIN_URL . 'templete-preview/images/image.png',
                'border' => '',
                'is_premium' => false,
                'price' => '',
            ),
        );

        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'maybe_save_templates'));
        add_action('admin_init', array($this, 'maybe_save_shortcode'));
        add_action('admin_init', array($this, 'maybe_save_shortcut'));
        add_action('admin_init', array($this, 'maybe_save_payment_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_action('wp_footer', array($this, 'enqueue_footer_scripts'));
        add_shortcode('cv_builder', array($this, 'render_shortcode'));
    }
    
    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_frontend_scripts() {
        global $post;
        
        // Check if shortcode exists in current post/page content
        $has_shortcode = false;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'cv_builder')) {
            $has_shortcode = true;
        }
        
        // Enqueue if shortcode is found or if we're on a page that might have it
        if ($has_shortcode || self::$shortcode_used) {
            wp_enqueue_style(
                'cv-builder-frontend',
                CV_BUILDER_PLUGIN_URL . 'assets/css/admin.css',
                array(),
                CV_BUILDER_VERSION . '.' . time() // Cache busting
            );
            
            wp_enqueue_script(
                'cv-builder-frontend',
                CV_BUILDER_PLUGIN_URL . 'assets/js/admin.js',
                array('jquery', 'jquery-ui-datepicker', 'cropper-js'),
                CV_BUILDER_VERSION . '.' . time(), // Cache busting
                true
            );

            wp_localize_script(
                'cv-builder-frontend',
                'cvBuilderSettings',
                $this->get_frontend_settings()
            );
            
            // Enqueue Cropper.js for image cropping (must load before our script)
            wp_enqueue_style('cropper-css', 'https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.css');
            wp_enqueue_script('cropper-js', 'https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.js', array('jquery'), '1.5.13', false);
            
            // Enqueue jQuery UI CSS for datepicker
            wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.12.1/themes/ui-lightness/jquery-ui.css');
            
            // Ensure translator plugin scripts are loaded if shortcode is present
            $saved_shortcode = get_option('cv_builder_shortcode', '');
            if (!empty($saved_shortcode)) {
                // Trigger action to let other plugins know to enqueue their assets
                do_action('cv_builder_translator_shortcode_loaded');
                
                // Try to enqueue GT Translate scripts if available
                if (function_exists('gtranslate_enqueue_scripts')) {
                    gtranslate_enqueue_scripts();
                }
                if (function_exists('gt_enqueue_scripts')) {
                    gt_enqueue_scripts();
                }
            }
        }
    }
    
    /**
     * Enqueue scripts in footer (after shortcode processing)
     * This ensures scripts load even if shortcode is in widgets or dynamically added
     */
    public function enqueue_footer_scripts() {
        // If shortcode was used but assets weren't enqueued, add them inline
        if (self::$shortcode_used && !wp_style_is('cv-builder-frontend', 'enqueued')) {
            // Add CSS link in footer as fallback
            $css_url = CV_BUILDER_PLUGIN_URL . 'assets/css/admin.css?ver=' . CV_BUILDER_VERSION . '.' . time();
            echo '<link rel="stylesheet" href="' . esc_url($css_url) . '" type="text/css" media="all">';
            
            // Enqueue Cropper.js for image cropping (must load before our script)
            wp_enqueue_style('cropper-css', 'https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.css');
            wp_enqueue_script('cropper-js', 'https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.js', array('jquery'), '1.5.13', false);
            
            // Enqueue script normally (scripts can go in footer)
            wp_enqueue_script(
                'cv-builder-frontend',
                CV_BUILDER_PLUGIN_URL . 'assets/js/admin.js',
                array('jquery', 'cropper-js'),
                CV_BUILDER_VERSION . '.' . time(),
                true
            );

            wp_localize_script(
                'cv-builder-frontend',
                'cvBuilderSettings',
                $this->get_frontend_settings()
            );
        }
    }
    
    /**
     * Shortcode handler
     */
    public function render_shortcode($atts = array(), $content = null, $tag = 'cv_builder') {
        // Mark that shortcode is used
        self::$shortcode_used = true;
        
        // Parse shortcode attributes
        $atts = shortcode_atts(array(
            'title' => 'Start Building Marriage Biodata',
            'subtitle' => 'Fill in the details below to create your personalized marriage biodata.',
        ), $atts, $tag);
        
        // Generate unique instance ID
        $instance_id = 'cv-' . uniqid();
        
        // Start output buffering
        ob_start();
        
        // Make variables available to template
        $template_atts = $atts;
        $template_instance_id = $instance_id;
        
        // Include the frontend template
        include CV_BUILDER_PLUGIN_DIR . 'templates/frontend-form.php';
        
        // Get the output
        return ob_get_clean();
    }

    public function add_admin_menu() {
        add_menu_page(
            __('CV Builder Templates', 'cv-builder'),
            __('CV Templates', 'cv-builder'),
            'manage_options',
            'cv-builder-templates',
            array($this, 'render_admin_page'),
            'dashicons-media-default',
            81
        );

        add_submenu_page(
            'cv-builder-templates',
            __('Payment Setup', 'cv-builder'),
            __('Payment Setup', 'cv-builder'),
            'manage_options',
            'cv-builder-payments',
            array($this, 'render_payment_page')
        );
    }

    public function enqueue_admin_assets($hook) {
        $allowed_hooks = array(
            'toplevel_page_cv-builder-templates',
            'cv-builder-templates_page_cv-builder-payments',
        );

        if (!in_array($hook, $allowed_hooks, true)) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style(
            'cv-builder-admin-settings',
            CV_BUILDER_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            CV_BUILDER_VERSION
        );
        wp_enqueue_script(
            'cv-builder-admin-settings',
            CV_BUILDER_PLUGIN_URL . 'assets/js/admin-settings.js',
            array('jquery'),
            CV_BUILDER_VERSION,
            true
        );
        
        // Localize script with nonce for shortcode save
        wp_localize_script(
            'cv-builder-admin-settings',
            'cvBuilderAdmin',
            array(
                'shortcodeNonce' => wp_create_nonce('cv_builder_save_shortcode'),
                'shortcutNonce' => wp_create_nonce('cv_builder_save_shortcut'),
                'ajaxUrl' => admin_url('admin-ajax.php')
            )
        );
    }
    
    /**
     * Save shortcut handler (form submission)
     */
    public function maybe_save_shortcut() {
        // Check if this is a shortcut save request
        if (!isset($_POST['cv_builder_shortcut_nonce']) || !isset($_POST['action']) || $_POST['action'] !== 'save_shortcut') {
            return;
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['cv_builder_shortcut_nonce'], 'cv_builder_save_shortcut')) {
            add_settings_error(
                'cv-builder-shortcut',
                'cvBuilderShortcutError',
                __('Security check failed. Please try again.', 'cv-builder'),
                'error'
            );
            wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcut-saved' => '1'), admin_url('admin.php')));
            exit;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            add_settings_error(
                'cv-builder-shortcut',
                'cvBuilderShortcutError',
                __('You do not have permission.', 'cv-builder'),
                'error'
            );
            wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcut-saved' => '1'), admin_url('admin.php')));
            exit;
        }
        
        // Get and validate input
        $shortcut = isset($_POST['shortcut_input']) ? trim($_POST['shortcut_input']) : '';
        
        if (empty($shortcut)) {
            add_settings_error(
                'cv-builder-shortcut',
                'cvBuilderShortcutError',
                __('Please enter something.', 'cv-builder'),
                'error'
            );
            wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcut-saved' => '1'), admin_url('admin.php')));
            exit;
        }
        
        // Sanitize input
        $shortcut = wp_unslash($shortcut);
        $shortcut = sanitize_text_field($shortcut);
        
        // Save to WordPress options
        $saved = update_option('saved_custom_shortcode', $shortcut);
        
        if ($saved === false) {
            // Try add_option if update_option failed
            delete_option('saved_custom_shortcode');
            $saved = add_option('saved_custom_shortcode', $shortcut, '', 'no');
        }
        
        if ($saved !== false) {
            add_settings_error(
                'cv-builder-shortcut',
                'cvBuilderShortcutSaved',
                __('Shortcut successfully saved.', 'cv-builder'),
                'updated'
            );
        } else {
            add_settings_error(
                'cv-builder-shortcut',
                'cvBuilderShortcutError',
                __('Failed to save shortcut.', 'cv-builder'),
                'error'
            );
        }
        
        // Store errors in transient for display after redirect
        $settings_errors = get_settings_errors('cv-builder-shortcut');
        if (!empty($settings_errors)) {
            set_transient('cv_builder_shortcut_settings_errors', $settings_errors, 30);
        }
        
        // Redirect to prevent resubmission
        wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcut-saved' => '1'), admin_url('admin.php')));
        exit;
    }

    public function maybe_save_templates() {
        if (!isset($_POST['cv_builder_templates_nonce'])) {
            return;
        }

        if (!current_user_can('manage_options')) {
            return;
        }

        if (!wp_verify_nonce($_POST['cv_builder_templates_nonce'], 'cv_builder_save_templates')) {
            return;
        }

        $templates = array();
        $names   = isset($_POST['cv_builder_template_names']) ? (array) $_POST['cv_builder_template_names'] : array();
        $images  = isset($_POST['cv_builder_templates']) ? (array) $_POST['cv_builder_templates'] : array();
        $borders = isset($_POST['cv_builder_template_borders']) ? (array) $_POST['cv_builder_template_borders'] : array();
        $types   = isset($_POST['cv_builder_template_types']) ? (array) $_POST['cv_builder_template_types'] : array();
        $prices  = isset($_POST['cv_builder_template_prices']) ? (array) $_POST['cv_builder_template_prices'] : array();

        $max = max(count($names), count($images), count($borders), count($types), count($prices));
        for ($i = 0; $i < $max; $i++) {
            $image  = isset($images[$i]) ? esc_url_raw(trim(wp_unslash($images[$i]))) : '';
            $name   = isset($names[$i]) ? sanitize_text_field(wp_unslash($names[$i])) : '';
            $border = isset($borders[$i]) ? esc_url_raw(trim(wp_unslash($borders[$i]))) : '';
            $type   = isset($types[$i]) ? sanitize_text_field(wp_unslash($types[$i])) : 'free';
            $price  = isset($prices[$i]) ? sanitize_text_field(wp_unslash($prices[$i])) : '';

            if (empty($image)) {
                continue;
            }

            $templates[] = array(
                'label' => !empty($name) ? $name : sprintf(__('Template %d', 'cv-builder'), ($i + 1)),
                'image' => $image,
                'thumb' => $image,
                'border' => $border,
                'is_premium' => ($type === 'premium'),
                'price' => ($type === 'premium') ? $price : '',
            );
        }

        update_option('cv_builder_templates', $templates);

        // Save custom shortcode (always save, even if empty)
        $shortcode = '';
        if (isset($_POST['cv_builder_shortcode'])) {
            // Get the shortcode value
            $shortcode = isset($_POST['cv_builder_shortcode']) ? $_POST['cv_builder_shortcode'] : '';
            $shortcode = wp_unslash($shortcode);
            $shortcode = trim($shortcode);
            
            // Preserve shortcode format - remove only dangerous content
            // Remove script and style tags
            $shortcode = preg_replace('/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi', '', $shortcode);
            $shortcode = preg_replace('/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi', '', $shortcode);
        }
        
        // Always save the shortcode (even if empty to clear it)
        $shortcode_saved = update_option('cv_builder_shortcode', $shortcode);
        
        // Debug: Log shortcode save (remove in production if needed)
        // error_log('CV Builder: Shortcode save attempt. Value: ' . $shortcode . ', Saved: ' . ($shortcode_saved ? 'true' : 'false'));

        $message = __('Templates updated successfully.', 'cv-builder');
        if (!empty($shortcode)) {
            $message .= ' ' . __('Shortcode saved.', 'cv-builder');
        }
        
        add_settings_error(
            'cv-builder-templates',
            'cvBuilderTemplatesSaved',
            $message,
            'updated'
        );

        wp_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'settings-updated' => 'true'), admin_url('admin.php')));
        exit;
    }

    /**
     * Save shortcode separately
     */
    public function maybe_save_shortcode() {
        // Check if this is a shortcode save request
        if (!isset($_POST['action']) || $_POST['action'] !== 'save_cv_builder_shortcode') {
            return;
        }
        
        // Verify nonce - required for security
        if (!isset($_POST['cv_builder_shortcode_nonce']) || !wp_verify_nonce($_POST['cv_builder_shortcode_nonce'], 'cv_builder_save_shortcode')) {
            add_settings_error(
                'cv-builder-shortcode',
                'cvBuilderShortcodeError',
                __('Security check failed. Please try again.', 'cv-builder'),
                'error'
            );
            // Still redirect to show error
            wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcode-saved' => '1'), admin_url('admin.php')));
            exit;
        }

        // Check permissions
        if (!current_user_can('manage_options')) {
            add_settings_error(
                'cv-builder-shortcode',
                'cvBuilderShortcodeError',
                __('You do not have permission to perform this action.', 'cv-builder'),
                'error'
            );
            return;
        }

        // Get the shortcode value
        $shortcode = isset($_POST['cv_builder_shortcode']) ? $_POST['cv_builder_shortcode'] : '';
        $shortcode = wp_unslash($shortcode);
        $shortcode = trim($shortcode);
        
        // Remove only dangerous content, preserve shortcode format
        if (!empty($shortcode)) {
            $shortcode = preg_replace('/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi', '', $shortcode);
            $shortcode = preg_replace('/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi', '', $shortcode);
        }
        
        // Save the shortcode - always save (even if empty)
        $saved = update_option('cv_builder_shortcode', $shortcode);
        
        // If update_option returns false, the option might not exist yet
        if ($saved === false) {
            // Try to add it as a new option
            $saved = add_option('cv_builder_shortcode', $shortcode, '', 'no');
        }

        // Set success message
        if ($saved !== false) {
            add_settings_error(
                'cv-builder-shortcode',
                'cvBuilderShortcodeSaved',
                __('Shortcode saved successfully!', 'cv-builder'),
                'updated'
            );
        } else {
            add_settings_error(
                'cv-builder-shortcode',
                'cvBuilderShortcodeError',
                __('Failed to save shortcode. Please try again.', 'cv-builder'),
                'error'
            );
        }

        // Store settings errors in transient before redirect (WordPress clears them on redirect)
        $settings_errors = get_settings_errors('cv-builder-shortcode');
        if (!empty($settings_errors)) {
            set_transient('cv_builder_shortcode_settings_errors', $settings_errors, 30);
        }

        // Redirect to prevent resubmission and show message
        wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcode-saved' => '1'), admin_url('admin.php')));
        exit;
    }

    /**
     * Save payment settings
     */
    public function maybe_save_payment_settings() {
        if (!isset($_POST['cv_builder_payments_nonce'])) {
            return;
        }

        if (!current_user_can('manage_options')) {
            return;
        }

        if (!wp_verify_nonce($_POST['cv_builder_payments_nonce'], 'cv_builder_save_payments')) {
            add_settings_error(
                'cv-builder-payments',
                'cvBuilderPaymentsError',
                __('Security check failed. Please try again.', 'cv-builder'),
                'error'
            );
            return;
        }

        $settings = array(
            'provider' => isset($_POST['cv_payment_provider']) ? sanitize_text_field(wp_unslash($_POST['cv_payment_provider'])) : '',
            'mode' => isset($_POST['cv_payment_mode']) ? sanitize_text_field(wp_unslash($_POST['cv_payment_mode'])) : 'sandbox',
            'api_key' => isset($_POST['cv_payment_api_key']) ? sanitize_text_field(wp_unslash($_POST['cv_payment_api_key'])) : '',
            'api_secret' => isset($_POST['cv_payment_api_secret']) ? sanitize_text_field(wp_unslash($_POST['cv_payment_api_secret'])) : '',
            'webhook_url' => isset($_POST['cv_payment_webhook_url']) ? esc_url_raw(wp_unslash($_POST['cv_payment_webhook_url'])) : '',
            'currency' => isset($_POST['cv_payment_currency']) ? sanitize_text_field(wp_unslash($_POST['cv_payment_currency'])) : '',
        );

        update_option('cv_builder_payment_settings', $settings);

        add_settings_error(
            'cv-builder-payments',
            'cvBuilderPaymentsSaved',
            __('Payment settings saved.', 'cv-builder'),
            'updated'
        );

        wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-payments', 'settings-updated' => 'true'), admin_url('admin.php')));
        exit;
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $templates = $this->get_templates();
        $saved_shortcode = get_option('cv_builder_shortcode', '');
        ?>
        <div class="wrap cv-builder-settings">
            <h1><?php esc_html_e('CV Builder Templates', 'cv-builder'); ?></h1>
            <?php 
            // Display all settings errors
            settings_errors('cv-builder-templates');
            
            // Check for shortcode-saved parameter and show message
            if (isset($_GET['shortcode-saved']) && $_GET['shortcode-saved'] == '1') {
                // Get stored errors from transient
                $stored_errors = get_transient('cv_builder_shortcode_settings_errors');
                if ($stored_errors) {
                    // Restore the errors
                    foreach ($stored_errors as $error) {
                        add_settings_error(
                            $error['setting'],
                            $error['code'],
                            $error['message'],
                            $error['type']
                        );
                    }
                    delete_transient('cv_builder_shortcode_settings_errors');
                } else {
                    // Default success message if no errors stored
                    add_settings_error(
                        'cv-builder-shortcode',
                        'cvBuilderShortcodeSaved',
                        __('Shortcode saved successfully!', 'cv-builder'),
                        'updated'
                    );
                }
            }
            
            // Display shortcode errors
            settings_errors('cv-builder-shortcode');
            ?>
            
            <!-- Shortcut Input Section -->
            <div class="cv-shortcut-input-section" style="margin-bottom: 30px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <h2 style="margin-top: 0;"><?php esc_html_e('Shortcut Input', 'cv-builder'); ?></h2>
                <form method="post" id="cv-builder-shortcut-form">
                    <?php wp_nonce_field('cv_builder_save_shortcut', 'cv_builder_shortcut_nonce'); ?>
                    <input type="hidden" name="action" value="save_shortcut">
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">
                                <label for="shortcut-input"><?php esc_html_e('Shortcode', 'cv-builder'); ?></label>
                            </th>
                            <td>
                                <?php $saved_shortcut = get_option('saved_custom_shortcode', ''); ?>
                                <input type="text" id="shortcut-input" name="shortcut_input" class="regular-text" value="<?php echo esc_attr($saved_shortcut); ?>" placeholder="<?php esc_attr_e('Paste your shortcode here...', 'cv-builder'); ?>">
                                <p class="description">
                                    <?php esc_html_e('Enter any shortcode you want to save.', 'cv-builder'); ?>
                                </p>
                                <p>
                                    <button type="submit" class="button button-primary" id="cv-builder-save-shortcut-btn"><?php esc_html_e('Save Shortcut', 'cv-builder'); ?></button>
                                </p>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            
            <?php 
            // Display shortcut save messages
            if (isset($_GET['shortcut-saved']) && $_GET['shortcut-saved'] == '1') {
                $stored_errors = get_transient('cv_builder_shortcut_settings_errors');
                if ($stored_errors) {
                    foreach ($stored_errors as $error) {
                        add_settings_error(
                            $error['setting'],
                            $error['code'],
                            $error['message'],
                            $error['type']
                        );
                    }
                    delete_transient('cv_builder_shortcut_settings_errors');
                }
            }
            settings_errors('cv-builder-shortcut');
            ?>
            
            <!-- Templates Form -->
            <form method="post">
                <?php wp_nonce_field('cv_builder_save_templates', 'cv_builder_templates_nonce'); ?>
                <p class="description">
                    <?php esc_html_e('Upload the template preview images you want to offer in the Customize tab. The first template will be used by default.', 'cv-builder'); ?>
                </p>

                <div id="cv-builder-template-list" class="cv-template-list">
                    <?php foreach ($templates as $template) : ?>
                        <div class="cv-template-row">
                            <div class="cv-template-thumb-wrapper">
                                <?php if (!empty($template['image'])) : ?>
                                    <img src="<?php echo esc_url($template['image']); ?>" alt="" class="cv-template-thumb" />
                                <?php else : ?>
                                    <img src="" alt="" class="cv-template-thumb hidden" />
                                <?php endif; ?>
                            </div>
                            <div class="cv-template-fields">
                                <p>
                                    <label>
                                        <?php esc_html_e('Template Name', 'cv-builder'); ?><br>
                                        <input type="text" name="cv_builder_template_names[]" class="regular-text"
                                            value="<?php echo esc_attr(isset($template['label']) ? $template['label'] : ''); ?>"
                                            placeholder="<?php esc_attr_e('e.g. Classic Blue', 'cv-builder'); ?>">
                                    </label>
                                </p>
                                <p>
                                    <label>
                                        <?php esc_html_e('Resume Image', 'cv-builder'); ?><br>
                                        <input type="hidden" name="cv_builder_templates[]" class="cv-template-input"
                                            value="<?php echo esc_url(isset($template['image']) ? $template['image'] : ''); ?>" />
                                        <div class="cv-image-upload-field cv-resume-upload-field">
                                            <?php if (!empty($template['image'])) : ?>
                                                <div class="cv-image-preview">
                                                    <img src="<?php echo esc_url($template['image']); ?>" alt="Resume Preview" class="cv-image-preview-img" />
                                                    <button type="button" class="cv-image-remove" data-target="resume">×</button>
                                                </div>
                                            <?php else : ?>
                                                <div class="cv-image-placeholder">
                                                    <span class="cv-image-placeholder-text">No image uploaded</span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </label>
                                </p>
                                <p>
                                    <label>
                                        <?php esc_html_e('Resume Border Image', 'cv-builder'); ?><br>
                                        <input type="hidden" name="cv_builder_template_borders[]" class="cv-template-border-input"
                                            value="<?php echo esc_url(isset($template['border']) ? $template['border'] : ''); ?>" />
                                        <div class="cv-image-upload-field cv-border-upload-field">
                                            <?php if (!empty($template['border'])) : ?>
                                                <div class="cv-image-preview">
                                                    <img src="<?php echo esc_url($template['border']); ?>" alt="Border Preview" class="cv-image-preview-img" />
                                                    <button type="button" class="cv-image-remove" data-target="border">×</button>
                                                </div>
                                            <?php else : ?>
                                                <div class="cv-image-placeholder">
                                                    <span class="cv-image-placeholder-text">No border uploaded</span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </label>
                                </p>
                                <p>
                                    <label>
                                        <?php esc_html_e('Access', 'cv-builder'); ?><br>
                                        <select name="cv_builder_template_types[]">
                                            <option value="free" <?php selected(empty($template['is_premium'])); ?>><?php esc_html_e('Free', 'cv-builder'); ?></option>
                                            <option value="premium" <?php selected(!empty($template['is_premium'])); ?>><?php esc_html_e('Premium', 'cv-builder'); ?></option>
                                        </select>
                                    </label>
                                </p>
                                <p>
                                    <label>
                                        <?php esc_html_e('Price (if premium)', 'cv-builder'); ?><br>
                                        <input type="text" name="cv_builder_template_prices[]" class="regular-text"
                                            value="<?php echo esc_attr(isset($template['price']) ? $template['price'] : ''); ?>"
                                            placeholder="<?php esc_attr_e('e.g. 9.99', 'cv-builder'); ?>">
                                    </label>
                                </p>
                                <div class="cv-template-actions">
                                    <button type="button" class="button cv-template-upload" data-target="resume"><?php esc_html_e('Select Resume Image', 'cv-builder'); ?></button>
                                    <button type="button" class="button cv-template-border-upload" data-target="border"><?php esc_html_e('Select Border Image', 'cv-builder'); ?></button>
                                    <button type="button" class="button cv-template-clear"><?php esc_html_e('Clear Resume', 'cv-builder'); ?></button>
                                    <button type="button" class="button cv-template-border-clear"><?php esc_html_e('Clear Border', 'cv-builder'); ?></button>
                                    <button type="button" class="button cv-template-remove"><?php esc_html_e('Remove', 'cv-builder'); ?></button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <p>
                    <button type="button" class="button button-secondary" id="cv-builder-add-template"><?php esc_html_e('Add Template', 'cv-builder'); ?></button>
                </p>

                <p>
                    <button type="submit" class="button button-primary"><?php esc_html_e('Save Templates', 'cv-builder'); ?></button>
                </p>
            </form>
        </div>
        <?php
    }

    public function render_payment_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = get_option('cv_builder_payment_settings', array(
            'provider' => '',
            'mode' => 'sandbox',
            'api_key' => '',
            'api_secret' => '',
            'webhook_url' => '',
            'currency' => '',
        ));
        ?>
        <div class="wrap cv-builder-settings">
            <h1><?php esc_html_e('Payment Setup', 'cv-builder'); ?></h1>
            <?php settings_errors('cv-builder-payments'); ?>

            <form method="post">
                <?php wp_nonce_field('cv_builder_save_payments', 'cv_builder_payments_nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="cv-payment-provider"><?php esc_html_e('Provider', 'cv-builder'); ?></label></th>
                        <td>
                            <input type="text" id="cv-payment-provider" name="cv_payment_provider" class="regular-text"
                                value="<?php echo esc_attr($settings['provider']); ?>" placeholder="<?php esc_attr_e('e.g. Stripe, PayPal', 'cv-builder'); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Mode', 'cv-builder'); ?></th>
                        <td>
                            <label><input type="radio" name="cv_payment_mode" value="sandbox" <?php checked($settings['mode'], 'sandbox'); ?>> <?php esc_html_e('Sandbox', 'cv-builder'); ?></label><br>
                            <label><input type="radio" name="cv_payment_mode" value="live" <?php checked($settings['mode'], 'live'); ?>> <?php esc_html_e('Live', 'cv-builder'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="cv-payment-api-key"><?php esc_html_e('API Key / Client ID', 'cv-builder'); ?></label></th>
                        <td>
                            <input type="text" id="cv-payment-api-key" name="cv_payment_api_key" class="regular-text"
                                value="<?php echo esc_attr($settings['api_key']); ?>" autocomplete="off">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="cv-payment-api-secret"><?php esc_html_e('API Secret', 'cv-builder'); ?></label></th>
                        <td>
                            <input type="password" id="cv-payment-api-secret" name="cv_payment_api_secret" class="regular-text"
                                value="<?php echo esc_attr($settings['api_secret']); ?>" autocomplete="off">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="cv-payment-webhook"><?php esc_html_e('Webhook URL', 'cv-builder'); ?></label></th>
                        <td>
                            <input type="url" id="cv-payment-webhook" name="cv_payment_webhook_url" class="regular-text"
                                value="<?php echo esc_url($settings['webhook_url']); ?>" placeholder="https://example.com/webhook">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="cv-payment-currency"><?php esc_html_e('Currency', 'cv-builder'); ?></label></th>
                        <td>
                            <input type="text" id="cv-payment-currency" name="cv_payment_currency" class="regular-text"
                                value="<?php echo esc_attr($settings['currency']); ?>" placeholder="<?php esc_attr_e('e.g. USD, INR', 'cv-builder'); ?>">
                        </td>
                    </tr>
                </table>
                <p>
                    <button type="submit" class="button button-primary"><?php esc_html_e('Save Payment Settings', 'cv-builder'); ?></button>
                </p>
            </form>
        </div>
        <?php
    }

    private function get_frontend_settings() {
        if ($this->localized_settings !== null) {
            return $this->localized_settings;
        }

        $this->localized_settings = array(
            'previewUrl' => CV_BUILDER_PLUGIN_URL . 'templete-preview/index.html',
            'templates'  => $this->get_templates(),
        );

        return $this->localized_settings;
    }

    private function get_templates() {
        $saved = get_option('cv_builder_templates', array());
        $templates = array();

        if (is_array($saved) && !empty($saved)) {
            $index = 1;
            foreach ($saved as $item) {
                // Backward compatibility: item might be a URL string
                if (is_string($item)) {
                    $item = array(
                        'label' => sprintf(__('Template %d', 'cv-builder'), $index),
                        'image' => esc_url_raw($item),
                        'thumb' => esc_url_raw($item),
                        'border' => '',
                        'is_premium' => false,
                        'price' => '',
                    );
                }

                $image = isset($item['image']) ? esc_url_raw($item['image']) : '';
                if (empty($image)) {
                    continue;
                }

                $templates[] = array(
                    'label' => isset($item['label']) ? sanitize_text_field($item['label']) : sprintf(__('Template %d', 'cv-builder'), $index),
                    'image' => $image,
                    'thumb' => isset($item['thumb']) ? esc_url_raw($item['thumb']) : $image,
                    'border' => isset($item['border']) ? esc_url_raw($item['border']) : '',
                    'is_premium' => !empty($item['is_premium']),
                    'price' => isset($item['price']) ? sanitize_text_field($item['price']) : '',
                );

                $index++;
            }
        }

        if (empty($templates)) {
            foreach ($this->default_templates as $index => $template) {
                $templates[] = array(
                    'label' => $template['label'],
                    'image' => $template['image'],
                    'thumb' => $template['image'],
                    'border' => isset($template['border']) ? $template['border'] : '',
                    'is_premium' => isset($template['is_premium']) ? $template['is_premium'] : false,
                    'price' => isset($template['price']) ? $template['price'] : '',
                );
            }
        }

        return $templates;
    }
}

// Initialize the plugin
new CV_Builder();

