<?php
/**
 * Club login and registration — modern layout matching My Account.
 *
 * @package OilmazingSFC
 *
 * @var string $default_tab login|register
 * @var string $redirect
 * @var string $context
 */

defined( 'ABSPATH' ) || exit;

$default_tab = in_array( $default_tab, array( 'login', 'register' ), true ) ? $default_tab : 'login';
$redirect    = isset( $redirect ) ? esc_url( $redirect ) : '';
$register_on = Oilmazing_SFC_Auth::registration_enabled();
$lost_url    = wp_lostpassword_url( $redirect ? $redirect : get_permalink() );
?>
<div
	id="oilmazing-sfc-auth-root"
	class="oilmazing-sfc-wc-account oilmazing-sfc-wc-account--guest oilmazing-sfc-auth"
	data-default-tab="<?php echo esc_attr( $default_tab ); ?>"
	data-redirect="<?php echo esc_url( $redirect ); ?>"
>
	<header class="oilmazing-sfc-wc-account__hero">
		<div class="oilmazing-sfc-wc-account__hero-copy">
			<p class="oilmazing-sfc-wc-account__eyebrow"><?php esc_html_e( 'Members Only', 'oilmazing-sfc' ); ?></p>
			<h1 class="oilmazing-sfc-wc-account__title"><?php esc_html_e( 'Scent Freedom Club', 'oilmazing-sfc' ); ?></h1>
			<p class="oilmazing-sfc-wc-account__lead">
				<?php esc_html_e( 'Plan your monthly scents, unlock member deals, track rewards, and connect with the community.', 'oilmazing-sfc' ); ?>
			</p>
		</div>
		<div class="oilmazing-sfc-wc-account__hero-user oilmazing-sfc-wc-account__hero-features">
			<ul class="oilmazing-sfc-wc-account__feature-list">
				<li><i class="fa-solid fa-calendar-days" aria-hidden="true"></i> <?php esc_html_e( 'Personal scent calendar', 'oilmazing-sfc' ); ?></li>
				<li><i class="fa-solid fa-gift" aria-hidden="true"></i> <?php esc_html_e( 'Exclusive member deals', 'oilmazing-sfc' ); ?></li>
				<li><i class="fa-solid fa-users" aria-hidden="true"></i> <?php esc_html_e( 'Community hub access', 'oilmazing-sfc' ); ?></li>
			</ul>
		</div>
	</header>

	<div class="oilmazing-sfc-wc-account__auth-shell">
		<section class="oilmazing-sfc-wc-account__auth-panel" aria-label="<?php esc_attr_e( 'Member access', 'oilmazing-sfc' ); ?>">
			<div class="oilmazing-sfc-wc-account__auth-tabs oilmazing-sfc-ui-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Authentication mode', 'oilmazing-sfc' ); ?>">
				<button
					type="button"
					class="oilmazing-sfc-wc-account__auth-tab oilmazing-sfc-ui-tab<?php echo 'login' === $default_tab ? ' is-active' : ''; ?>"
					data-auth-tab="login"
					role="tab"
					aria-selected="<?php echo 'login' === $default_tab ? 'true' : 'false'; ?>"
					aria-controls="oilmazing-sfc-auth-login"
				>
					<i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i>
					<?php esc_html_e( 'Sign In', 'oilmazing-sfc' ); ?>
				</button>
				<?php if ( $register_on ) : ?>
					<button
						type="button"
						class="oilmazing-sfc-wc-account__auth-tab oilmazing-sfc-ui-tab<?php echo 'register' === $default_tab ? ' is-active' : ''; ?>"
						data-auth-tab="register"
						role="tab"
						aria-selected="<?php echo 'register' === $default_tab ? 'true' : 'false'; ?>"
						aria-controls="oilmazing-sfc-auth-register"
					>
						<i class="fa-solid fa-user-plus" aria-hidden="true"></i>
						<?php esc_html_e( 'Create an account', 'oilmazing-sfc' ); ?>
					</button>
				<?php endif; ?>
			</div>

			<div class="oilmazing-sfc-auth__message oilmazing-sfc-wc-account__auth-message" role="alert" aria-live="polite" hidden></div>

			<form
				id="oilmazing-sfc-auth-login"
				class="oilmazing-sfc-wc-account__auth-form<?php echo 'login' === $default_tab ? ' is-active' : ''; ?>"
				data-auth-form="login"
				role="tabpanel"
				novalidate
			>
				<div class="oilmazing-sfc-wc-account__auth-field">
					<label for="oilmazing-sfc-login-email"><?php esc_html_e( 'Email address', 'oilmazing-sfc' ); ?></label>
					<input
						id="oilmazing-sfc-login-email"
						type="email"
						name="email"
						autocomplete="email"
						required
						placeholder="<?php esc_attr_e( 'you@example.com', 'oilmazing-sfc' ); ?>"
					/>
				</div>
				<div class="oilmazing-sfc-wc-account__auth-field">
					<label for="oilmazing-sfc-login-password"><?php esc_html_e( 'Password', 'oilmazing-sfc' ); ?></label>
					<input
						id="oilmazing-sfc-login-password"
						type="password"
						name="password"
						autocomplete="current-password"
						required
						placeholder="<?php esc_attr_e( 'Your password', 'oilmazing-sfc' ); ?>"
					/>
				</div>
				<div class="oilmazing-sfc-wc-account__auth-row">
					<label class="oilmazing-sfc-wc-account__auth-checkbox">
						<input type="checkbox" name="remember" value="1" checked />
						<span><?php esc_html_e( 'Remember me', 'oilmazing-sfc' ); ?></span>
					</label>
					<a class="oilmazing-sfc-wc-account__auth-link" href="<?php echo esc_url( $lost_url ); ?>">
						<?php esc_html_e( 'Forgot password?', 'oilmazing-sfc' ); ?>
					</a>
				</div>
				<button type="submit" class="oilmazing-sfc-ui-btn oilmazing-sfc-wc-account__auth-submit">
					<?php esc_html_e( 'Sign In', 'oilmazing-sfc' ); ?>
				</button>
			</form>

			<?php if ( $register_on ) : ?>
				<form
					id="oilmazing-sfc-auth-register"
					class="oilmazing-sfc-wc-account__auth-form<?php echo 'register' === $default_tab ? ' is-active' : ''; ?>"
					data-auth-form="register"
					role="tabpanel"
					novalidate
					<?php echo 'register' === $default_tab ? '' : 'hidden'; ?>
				>
					<div class="oilmazing-sfc-wc-account__auth-grid">
						<div class="oilmazing-sfc-wc-account__auth-field">
							<label for="oilmazing-sfc-register-first-name"><?php esc_html_e( 'First name', 'oilmazing-sfc' ); ?></label>
							<input
								id="oilmazing-sfc-register-first-name"
								type="text"
								name="first_name"
								autocomplete="given-name"
								required
								placeholder="<?php esc_attr_e( 'First name', 'oilmazing-sfc' ); ?>"
							/>
						</div>
						<div class="oilmazing-sfc-wc-account__auth-field">
							<label for="oilmazing-sfc-register-last-name"><?php esc_html_e( 'Last name', 'oilmazing-sfc' ); ?></label>
							<input
								id="oilmazing-sfc-register-last-name"
								type="text"
								name="last_name"
								autocomplete="family-name"
								placeholder="<?php esc_attr_e( 'Last name', 'oilmazing-sfc' ); ?>"
							/>
						</div>
					</div>
					<div class="oilmazing-sfc-wc-account__auth-field">
						<label for="oilmazing-sfc-register-email"><?php esc_html_e( 'Email address', 'oilmazing-sfc' ); ?></label>
						<input
							id="oilmazing-sfc-register-email"
							type="email"
							name="email"
							autocomplete="email"
							required
							placeholder="<?php esc_attr_e( 'you@example.com', 'oilmazing-sfc' ); ?>"
						/>
					</div>
					<div class="oilmazing-sfc-wc-account__auth-field">
						<label for="oilmazing-sfc-register-password"><?php esc_html_e( 'Password', 'oilmazing-sfc' ); ?></label>
						<input
							id="oilmazing-sfc-register-password"
							type="password"
							name="password"
							autocomplete="new-password"
							required
							minlength="8"
							placeholder="<?php esc_attr_e( 'Create a password', 'oilmazing-sfc' ); ?>"
						/>
					</div>
					<p class="oilmazing-sfc-wc-account__auth-hint">
						<?php esc_html_e( 'By joining, you agree to receive member updates and club offers.', 'oilmazing-sfc' ); ?>
					</p>
					<button type="submit" class="oilmazing-sfc-ui-btn oilmazing-sfc-wc-account__auth-submit">
						<?php esc_html_e( 'Create an account', 'oilmazing-sfc' ); ?>
					</button>
				</form>
			<?php endif; ?>
		</section>
	</div>
</div>
