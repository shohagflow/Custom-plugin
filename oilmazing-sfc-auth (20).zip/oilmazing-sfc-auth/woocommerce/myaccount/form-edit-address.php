<?php
/**
 * Edit address form — modern layout.
 *
 * @package OilmazingSFC
 * @version 9.3.0
 */

defined( 'ABSPATH' ) || exit;

$page_title = ( 'billing' === $load_address ) ? esc_html__( 'Billing address', 'woocommerce' ) : esc_html__( 'Shipping address', 'woocommerce' );

do_action( 'woocommerce_before_edit_account_address_form' );

if ( ! $load_address ) {
	wc_get_template( 'myaccount/my-address.php' );
} else {
	$back_url = wc_get_endpoint_url( 'edit-address' );
	$icon     = 'billing' === $load_address ? 'fa-file-invoice' : 'fa-truck-fast';
	?>
	<div class="oilmazing-sfc-wc-account__address-form">
		<div class="oilmazing-sfc-wc-account__address-form-header">
			<a class="oilmazing-sfc-wc-account__address-back" href="<?php echo esc_url( $back_url ); ?>">
				<i class="fa-solid fa-arrow-left" aria-hidden="true"></i>
				<?php esc_html_e( 'Back to addresses', 'oilmazing-sfc' ); ?>
			</a>

			<div class="oilmazing-sfc-wc-account__address-form-title">
				<span class="oilmazing-sfc-wc-account__address-card-icon" aria-hidden="true">
					<i class="fa-solid <?php echo esc_attr( $icon ); ?>"></i>
				</span>
				<h2><?php echo apply_filters( 'woocommerce_my_account_edit_address_title', $page_title, $load_address ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></h2>
			</div>

			<p class="oilmazing-sfc-wc-account__address-form-lead">
				<?php esc_html_e( 'Update your details below. These will be used at checkout.', 'oilmazing-sfc' ); ?>
			</p>
		</div>

		<form class="oilmazing-sfc-wc-account__address-form-card" method="post" novalidate>
			<div class="woocommerce-address-fields">
				<?php do_action( "woocommerce_before_edit_address_form_{$load_address}" ); ?>

				<div class="woocommerce-address-fields__field-wrapper">
					<?php
					foreach ( $address as $key => $field ) {
						woocommerce_form_field( $key, $field, wc_get_post_data_by_key( $key, $field['value'] ) );
					}
					?>
				</div>

				<?php do_action( "woocommerce_after_edit_address_form_{$load_address}" ); ?>

				<p class="oilmazing-sfc-wc-account__address-form-actions">
					<button type="submit" class="button<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="save_address" value="<?php esc_attr_e( 'Save address', 'woocommerce' ); ?>">
						<?php esc_html_e( 'Save address', 'woocommerce' ); ?>
					</button>
					<?php wp_nonce_field( 'woocommerce-edit_address', 'woocommerce-edit-address-nonce' ); ?>
					<input type="hidden" name="action" value="edit_address" />
				</p>
			</div>
		</form>
	</div>
	<?php
}

do_action( 'woocommerce_after_edit_account_address_form' );
