<?php
/**
 * My Account navigation — modern sidebar with icons.
 *
 * @package OilmazingSFC
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_account_navigation' );
?>
<nav class="woocommerce-MyAccount-navigation oilmazing-sfc-wc-account__nav" aria-label="<?php esc_attr_e( 'Account pages', 'woocommerce' ); ?>">
	<p class="oilmazing-sfc-wc-account__nav-label"><?php esc_html_e( 'Account menu', 'oilmazing-sfc' ); ?></p>
	<ul>
		<?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
			<li class="<?php echo esc_attr( wc_get_account_menu_item_classes( $endpoint ) ); ?>">
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>" <?php echo wc_is_current_account_menu_item( $endpoint ) ? 'aria-current="page"' : ''; ?>>
					<span class="oilmazing-sfc-wc-account__nav-icon" aria-hidden="true">
						<i class="fa-solid <?php echo esc_attr( Oilmazing_SFC_My_Account::get_menu_icon( $endpoint ) ); ?>"></i>
					</span>
					<span class="oilmazing-sfc-wc-account__nav-text"><?php echo esc_html( $label ); ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>
<?php
do_action( 'woocommerce_after_account_navigation' );
