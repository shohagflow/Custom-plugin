<?php
/**
 * My Account page — modern Oilmazing layout.
 *
 * @package OilmazingSFC
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

$current_user = wp_get_current_user();
$avatar_url   = get_avatar_url( $current_user->ID, array( 'size' => 96 ) );
$display_name = $current_user->first_name ? $current_user->first_name : $current_user->display_name;
?>
<div class="oilmazing-sfc-wc-account">
	<header class="oilmazing-sfc-wc-account__hero">
		<div class="oilmazing-sfc-wc-account__hero-copy">
			<p class="oilmazing-sfc-wc-account__eyebrow"><?php esc_html_e( 'My Account', 'oilmazing-sfc' ); ?></p>
			<h1 class="oilmazing-sfc-wc-account__title">
				<?php
				printf(
					/* translators: %s: customer name */
					esc_html__( 'Hello, %s', 'oilmazing-sfc' ),
					esc_html( $display_name )
				);
				?>
			</h1>
			<p class="oilmazing-sfc-wc-account__lead">
				<?php esc_html_e( 'Manage your orders, subscription, addresses, and account details in one place.', 'oilmazing-sfc' ); ?>
			</p>
		</div>
		<div class="oilmazing-sfc-wc-account__hero-user">
			<img src="<?php echo esc_url( $avatar_url ); ?>" alt="" class="oilmazing-sfc-wc-account__hero-avatar" width="72" height="72" loading="lazy" decoding="async" />
			<div>
				<strong><?php echo esc_html( $display_name ); ?></strong>
				<span><?php echo esc_html( $current_user->user_email ); ?></span>
			</div>
		</div>
	</header>

	<div class="oilmazing-sfc-wc-account__layout">
		<?php do_action( 'woocommerce_account_navigation' ); ?>

		<div class="woocommerce-MyAccount-content oilmazing-sfc-wc-account__content">
			<?php do_action( 'woocommerce_account_content' ); ?>
		</div>
	</div>
</div>
