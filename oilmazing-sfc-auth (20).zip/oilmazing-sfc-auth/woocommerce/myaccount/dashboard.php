<?php
/**
 * My Account dashboard — quick links and welcome cards.
 *
 * @package OilmazingSFC
 * @version 1.1.0
 */

defined( 'ABSPATH' ) || exit;

$dashboard_url = class_exists( 'Oilmazing_SFC_Membership' )
	? Oilmazing_SFC_Membership::get_dashboard_url()
	: home_url( '/' );
$subscribe_url = class_exists( 'Oilmazing_SFC_Membership' )
	? Oilmazing_SFC_Membership::get_subscribe_url()
	: $dashboard_url;
$has_membership = class_exists( 'Oilmazing_SFC_Membership' ) && Oilmazing_SFC_Membership::has_active_membership();

$cards = array(
	array(
		'icon'  => 'fa-spa',
		'title' => __( 'Scent Freedom Club', 'oilmazing-sfc' ),
		'desc'  => $has_membership
			? __( 'Open your member dashboard, calendar, and deals.', 'oilmazing-sfc' )
			: __( 'Choose a membership plan to unlock the full club experience.', 'oilmazing-sfc' ),
		'url'   => $has_membership ? $dashboard_url : $subscribe_url,
		'label' => $has_membership ? __( 'Open dashboard', 'oilmazing-sfc' ) : __( 'Choose membership', 'oilmazing-sfc' ),
	),
	array(
		'icon'  => 'fa-box',
		'title' => __( 'Orders', 'woocommerce' ),
		'desc'  => __( 'Track purchases and order history.', 'oilmazing-sfc' ),
		'url'   => wc_get_endpoint_url( 'orders' ),
		'label' => __( 'View orders', 'oilmazing-sfc' ),
	),
	array(
		'icon'  => 'fa-location-dot',
		'title' => __( 'Addresses', 'woocommerce' ),
		'desc'  => __( 'Update billing and shipping details.', 'oilmazing-sfc' ),
		'url'   => wc_get_endpoint_url( 'edit-address' ),
		'label' => __( 'Manage addresses', 'oilmazing-sfc' ),
	),
	array(
		'icon'  => 'fa-user-gear',
		'title' => __( 'Account details', 'woocommerce' ),
		'desc'  => __( 'Change your name, email, or password.', 'oilmazing-sfc' ),
		'url'   => wc_get_endpoint_url( 'edit-account' ),
		'label' => __( 'Edit account', 'oilmazing-sfc' ),
	),
);

if ( function_exists( 'wcs_get_users_subscriptions' ) || class_exists( 'WC_Subscriptions' ) ) {
	array_splice(
		$cards,
		2,
		0,
		array(
			array(
				'icon'  => 'fa-arrows-rotate',
				'title' => __( 'Subscriptions', 'woocommerce-subscriptions' ),
				'desc'  => __( 'Manage your membership billing.', 'oilmazing-sfc' ),
				'url'   => wc_get_endpoint_url( 'subscriptions' ),
				'label' => __( 'Manage plan', 'oilmazing-sfc' ),
			),
		)
	);
}
?>
<div class="oilmazing-sfc-wc-account__dashboard">
	<p class="oilmazing-sfc-wc-account__dashboard-intro">
		<?php
		printf(
			/* translators: 1: user display name 2: logout url */
			wp_kses_post( __( 'Signed in as <strong>%1$s</strong>. <a href="%2$s">Log out</a>', 'oilmazing-sfc' ) ),
			esc_html( $current_user->display_name ),
			esc_url( wc_logout_url() )
		);
		?>
	</p>

	<div class="oilmazing-sfc-wc-account__cards">
		<?php foreach ( $cards as $card ) : ?>
			<a class="oilmazing-sfc-wc-account__card" href="<?php echo esc_url( $card['url'] ); ?>">
				<span class="oilmazing-sfc-wc-account__card-top">
					<span class="oilmazing-sfc-wc-account__card-icon" aria-hidden="true">
						<i class="fa-solid <?php echo esc_attr( $card['icon'] ); ?>"></i>
					</span>
					<span class="oilmazing-sfc-wc-account__card-body">
						<strong><?php echo esc_html( $card['title'] ); ?></strong>
						<span><?php echo esc_html( $card['desc'] ); ?></span>
					</span>
				</span>
				<span class="oilmazing-sfc-wc-account__card-action">
					<?php echo esc_html( $card['label'] ); ?>
					<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
				</span>
			</a>
		<?php endforeach; ?>
	</div>
</div>

<?php do_action( 'woocommerce_account_dashboard' ); ?>
