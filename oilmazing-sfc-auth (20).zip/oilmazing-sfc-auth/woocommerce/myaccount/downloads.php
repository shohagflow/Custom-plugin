<?php
/**
 * Downloads — modern empty state and table layout.
 *
 * @package OilmazingSFC
 * @version 7.8.0
 */

defined( 'ABSPATH' ) || exit;

$downloads     = WC()->customer->get_downloadable_products();
$has_downloads = (bool) $downloads;

do_action( 'woocommerce_before_account_downloads', $has_downloads );

if ( $has_downloads ) :
	do_action( 'woocommerce_before_available_downloads' );
	do_action( 'woocommerce_available_downloads', $downloads );
	do_action( 'woocommerce_after_available_downloads' );
else :
	$shop_url = esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) );
	?>
	<div class="oilmazing-sfc-wc-account__empty-state">
		<div class="oilmazing-sfc-wc-account__empty-state-icon" aria-hidden="true">
			<i class="fa-solid fa-download"></i>
		</div>
		<h3 class="oilmazing-sfc-wc-account__empty-state-title">
			<?php esc_html_e( 'No downloads available yet.', 'woocommerce' ); ?>
		</h3>
		<p class="oilmazing-sfc-wc-account__empty-state-text">
			<?php esc_html_e( 'When you purchase downloadable products, they will appear here for easy access.', 'oilmazing-sfc' ); ?>
		</p>
		<a class="oilmazing-sfc-wc-account__button" href="<?php echo $shop_url; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
			<?php esc_html_e( 'Browse products', 'woocommerce' ); ?>
			<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
		</a>
	</div>
	<?php
endif;

do_action( 'woocommerce_after_account_downloads', $has_downloads );
