<?php
/**
 * My Addresses — modern card layout.
 *
 * @package OilmazingSFC
 * @version 9.3.0
 */

defined( 'ABSPATH' ) || exit;

$customer_id = get_current_user_id();

if ( ! wc_ship_to_billing_address_only() && wc_shipping_enabled() ) {
	$get_addresses = apply_filters(
		'woocommerce_my_account_get_addresses',
		array(
			'billing'  => __( 'Billing address', 'woocommerce' ),
			'shipping' => __( 'Shipping address', 'woocommerce' ),
		),
		$customer_id
	);
} else {
	$get_addresses = apply_filters(
		'woocommerce_my_account_get_addresses',
		array(
			'billing' => __( 'Billing address', 'woocommerce' ),
		),
		$customer_id
	);
}

$address_icons = array(
	'billing'  => 'fa-file-invoice',
	'shipping' => 'fa-truck-fast',
);
?>
<div class="oilmazing-sfc-wc-account__addresses">
	<p class="oilmazing-sfc-wc-account__addresses-intro">
		<?php echo apply_filters( 'woocommerce_my_account_my_address_description', esc_html__( 'The following addresses will be used on the checkout page by default.', 'woocommerce' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</p>

	<div class="oilmazing-sfc-wc-account__address-grid woocommerce-Addresses addresses">
		<?php foreach ( $get_addresses as $name => $address_title ) : ?>
			<?php
			$address   = wc_get_account_formatted_address( $name );
			$icon      = isset( $address_icons[ $name ] ) ? $address_icons[ $name ] : 'fa-location-dot';
			$edit_url  = wc_get_endpoint_url( 'edit-address', $name );
			$has_value = (bool) $address;
			$action    = $has_value
				? sprintf(
					/* translators: %s: Address title */
					esc_html__( 'Edit %s', 'woocommerce' ),
					esc_html( $address_title )
				)
				: sprintf(
					/* translators: %s: Address title */
					esc_html__( 'Add %s', 'woocommerce' ),
					esc_html( $address_title )
				);
			?>
			<div class="oilmazing-sfc-wc-account__address-card woocommerce-Address u-column1 col-1">
				<div class="oilmazing-sfc-wc-account__address-card-top">
					<span class="oilmazing-sfc-wc-account__address-card-icon" aria-hidden="true">
						<i class="fa-solid <?php echo esc_attr( $icon ); ?>"></i>
					</span>
					<div class="oilmazing-sfc-wc-account__address-card-head">
						<h2 class="woocommerce-Address-title title"><?php echo esc_html( $address_title ); ?></h2>
						<?php if ( $has_value ) : ?>
							<span class="oilmazing-sfc-wc-account__address-badge"><?php esc_html_e( 'Saved', 'oilmazing-sfc' ); ?></span>
						<?php else : ?>
							<span class="oilmazing-sfc-wc-account__address-badge oilmazing-sfc-wc-account__address-badge--empty"><?php esc_html_e( 'Not set', 'oilmazing-sfc' ); ?></span>
						<?php endif; ?>
					</div>
				</div>

				<address class="oilmazing-sfc-wc-account__address-body">
					<?php
					if ( $has_value ) {
						echo wp_kses_post( $address );
					} else {
						esc_html_e( 'You have not set up this type of address yet.', 'woocommerce' );
					}

					do_action( 'woocommerce_my_account_after_my_address', $name );
					?>
				</address>

				<a class="oilmazing-sfc-wc-account__address-action edit" href="<?php echo esc_url( $edit_url ); ?>">
					<?php echo esc_html( $action ); ?>
					<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>
		<?php endforeach; ?>
	</div>
</div>
