<?php
/**
 * Payment methods — modern empty state and table layout.
 *
 * @package OilmazingSFC
 * @version 8.9.0
 */

defined( 'ABSPATH' ) || exit;

$saved_methods = wc_get_customer_saved_methods_list( get_current_user_id() );
$has_methods   = (bool) $saved_methods;

do_action( 'woocommerce_before_account_payment_methods', $has_methods );

if ( $has_methods ) :
	?>
	<div class="oilmazing-sfc-wc-account__payment-methods">
		<table class="woocommerce-MyAccount-paymentMethods shop_table shop_table_responsive account-payment-methods-table">
			<thead>
				<tr>
					<?php foreach ( wc_get_account_payment_methods_columns() as $column_id => $column_name ) : ?>
						<th class="woocommerce-PaymentMethod woocommerce-PaymentMethod--<?php echo esc_attr( $column_id ); ?> payment-method-<?php echo esc_attr( $column_id ); ?>">
							<span class="nobr"><?php echo esc_html( $column_name ); ?></span>
						</th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<?php foreach ( $saved_methods as $type => $methods ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited ?>
				<?php foreach ( $methods as $method ) : ?>
					<tr class="payment-method<?php echo ! empty( $method['is_default'] ) ? ' default-payment-method' : ''; ?>">
						<?php foreach ( wc_get_account_payment_methods_columns() as $column_id => $column_name ) : ?>
							<td class="woocommerce-PaymentMethod woocommerce-PaymentMethod--<?php echo esc_attr( $column_id ); ?> payment-method-<?php echo esc_attr( $column_id ); ?>" data-title="<?php echo esc_attr( $column_name ); ?>">
								<?php
								if ( has_action( 'woocommerce_account_payment_methods_column_' . $column_id ) ) {
									do_action( 'woocommerce_account_payment_methods_column_' . $column_id, $method );
								} elseif ( 'method' === $column_id ) {
									if ( ! empty( $method['method']['last4'] ) ) {
										printf(
											/* translators: 1: credit card type 2: last 4 digits */
											esc_html__( '%1$s ending in %2$s', 'woocommerce' ),
											esc_html( wc_get_credit_card_type_label( $method['method']['brand'] ) ),
											esc_html( $method['method']['last4'] )
										);
									} else {
										echo esc_html( wc_get_credit_card_type_label( $method['method']['brand'] ) );
									}
								} elseif ( 'expires' === $column_id ) {
									echo esc_html( $method['expires'] );
								} elseif ( 'actions' === $column_id ) {
									foreach ( $method['actions'] as $key => $action ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
										echo '<a href="' . esc_url( $action['url'] ) . '" class="button ' . sanitize_html_class( $key ) . '">' . esc_html( $action['name'] ) . '</a>&nbsp;';
									}
								}
								?>
							</td>
						<?php endforeach; ?>
					</tr>
				<?php endforeach; ?>
			<?php endforeach; ?>
		</table>
	</div>
	<?php
else :
	$add_method_url = WC()->payment_gateways->get_available_payment_gateways()
		? wc_get_endpoint_url( 'add-payment-method' )
		: '';
	?>
	<div class="oilmazing-sfc-wc-account__empty-state">
		<div class="oilmazing-sfc-wc-account__empty-state-icon" aria-hidden="true">
			<i class="fa-solid fa-credit-card"></i>
		</div>
		<h3 class="oilmazing-sfc-wc-account__empty-state-title">
			<?php esc_html_e( 'No saved methods found.', 'woocommerce' ); ?>
		</h3>
		<p class="oilmazing-sfc-wc-account__empty-state-text">
			<?php esc_html_e( 'Save a payment method during checkout to manage billing faster next time.', 'oilmazing-sfc' ); ?>
		</p>
		<?php if ( $add_method_url ) : ?>
			<a class="oilmazing-sfc-wc-account__button oilmazing-sfc-wc-account__empty-state-action" href="<?php echo esc_url( $add_method_url ); ?>">
				<?php esc_html_e( 'Add payment method', 'woocommerce' ); ?>
				<i class="fa-solid fa-plus" aria-hidden="true"></i>
			</a>
		<?php endif; ?>
	</div>
	<?php
endif;

do_action( 'woocommerce_after_account_payment_methods', $has_methods );

if ( $has_methods && WC()->payment_gateways->get_available_payment_gateways() ) :
	?>
	<p class="oilmazing-sfc-wc-account__payment-methods-action">
		<a class="oilmazing-sfc-wc-account__button" href="<?php echo esc_url( wc_get_endpoint_url( 'add-payment-method' ) ); ?>">
			<?php esc_html_e( 'Add payment method', 'woocommerce' ); ?>
			<i class="fa-solid fa-plus" aria-hidden="true"></i>
		</a>
	</p>
	<?php
endif;
