<?php
/**
 * Login Form — modern layout matching My Account.
 *
 * @package OilmazingSFC
 * @version 9.9.0
 */

defined( 'ABSPATH' ) || exit;

$registration_enabled = 'yes' === get_option( 'woocommerce_enable_myaccount_registration' );

do_action( 'woocommerce_before_customer_login_form' );
?>
<div class="oilmazing-sfc-wc-account oilmazing-sfc-wc-account--guest">
	<header class="oilmazing-sfc-wc-account__hero">
		<div class="oilmazing-sfc-wc-account__hero-copy">
			<p class="oilmazing-sfc-wc-account__eyebrow"><?php esc_html_e( 'Welcome back', 'oilmazing-sfc' ); ?></p>
			<h1 class="oilmazing-sfc-wc-account__title"><?php esc_html_e( 'My Account', 'woocommerce' ); ?></h1>
			<p class="oilmazing-sfc-wc-account__lead">
				<?php esc_html_e( 'Sign in to manage your orders, addresses, subscriptions, and account details.', 'oilmazing-sfc' ); ?>
			</p>
		</div>
		<div class="oilmazing-sfc-wc-account__hero-user oilmazing-sfc-wc-account__hero-features">
			<ul class="oilmazing-sfc-wc-account__feature-list">
				<li><i class="fa-solid fa-box" aria-hidden="true"></i> <?php esc_html_e( 'Track your orders', 'oilmazing-sfc' ); ?></li>
				<li><i class="fa-solid fa-location-dot" aria-hidden="true"></i> <?php esc_html_e( 'Manage addresses', 'oilmazing-sfc' ); ?></li>
				<li><i class="fa-solid fa-user-gear" aria-hidden="true"></i> <?php esc_html_e( 'Update account details', 'oilmazing-sfc' ); ?></li>
			</ul>
		</div>
	</header>

	<div class="oilmazing-sfc-wc-account__auth-shell<?php echo $registration_enabled ? ' oilmazing-sfc-wc-account__auth-shell--split' : ''; ?>">
		<section class="oilmazing-sfc-wc-account__auth-card" aria-label="<?php esc_attr_e( 'Login', 'woocommerce' ); ?>">
			<div class="oilmazing-sfc-wc-account__auth-card-head">
				<span class="oilmazing-sfc-wc-account__auth-card-icon" aria-hidden="true">
					<i class="fa-solid fa-right-to-bracket"></i>
				</span>
				<h2><?php esc_html_e( 'Login', 'woocommerce' ); ?></h2>
			</div>

			<form class="woocommerce-form woocommerce-form-login login oilmazing-sfc-wc-account__auth-form is-active" method="post" novalidate>
				<?php do_action( 'woocommerce_login_form_start' ); ?>

				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide oilmazing-sfc-wc-account__auth-field">
					<label for="username"><?php esc_html_e( 'Username or email address', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
					<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) && is_string( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" required aria-required="true" /><?php // @codingStandardsIgnoreLine ?>
				</p>
				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide oilmazing-sfc-wc-account__auth-field">
					<label for="password"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
					<input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password" required aria-required="true" />
				</p>

				<?php do_action( 'woocommerce_login_form' ); ?>

				<div class="oilmazing-sfc-wc-account__auth-row form-row">
					<label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme oilmazing-sfc-wc-account__auth-checkbox">
						<input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" />
						<span><?php esc_html_e( 'Remember me', 'woocommerce' ); ?></span>
					</label>
					<a class="oilmazing-sfc-wc-account__auth-link" href="<?php echo esc_url( wp_lostpassword_url() ); ?>">
						<?php esc_html_e( 'Lost your password?', 'woocommerce' ); ?>
					</a>
				</div>

				<p class="form-row oilmazing-sfc-wc-account__auth-actions">
					<?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
					<button type="submit" class="woocommerce-button button woocommerce-form-login__submit oilmazing-sfc-ui-btn<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="login" value="<?php esc_attr_e( 'Log in', 'woocommerce' ); ?>">
						<?php esc_html_e( 'Log in', 'woocommerce' ); ?>
					</button>
				</p>

				<?php do_action( 'woocommerce_login_form_end' ); ?>
			</form>
		</section>

		<?php if ( $registration_enabled ) : ?>
			<section class="oilmazing-sfc-wc-account__auth-card" aria-label="<?php esc_attr_e( 'Create an account', 'oilmazing-sfc' ); ?>">
				<div class="oilmazing-sfc-wc-account__auth-card-head">
					<span class="oilmazing-sfc-wc-account__auth-card-icon" aria-hidden="true">
						<i class="fa-solid fa-user-plus"></i>
					</span>
					<h2><?php esc_html_e( 'Create an account', 'oilmazing-sfc' ); ?></h2>
				</div>

				<form method="post" class="woocommerce-form woocommerce-form-register register oilmazing-sfc-wc-account__auth-form is-active" <?php do_action( 'woocommerce_register_form_tag' ); ?>>
					<?php do_action( 'woocommerce_register_form_start' ); ?>

					<?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide oilmazing-sfc-wc-account__auth-field">
							<label for="reg_username"><?php esc_html_e( 'Username', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
							<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" required aria-required="true" /><?php // @codingStandardsIgnoreLine ?>
						</p>
					<?php endif; ?>

					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide oilmazing-sfc-wc-account__auth-field">
						<label for="reg_email"><?php esc_html_e( 'Email address', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
						<input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" required aria-required="true" /><?php // @codingStandardsIgnoreLine ?>
					</p>

					<?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide oilmazing-sfc-wc-account__auth-field">
							<label for="reg_password"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
							<input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" required aria-required="true" />
						</p>
					<?php else : ?>
						<p class="oilmazing-sfc-wc-account__auth-hint">
							<?php esc_html_e( 'A link to set a new password will be sent to your email address.', 'woocommerce' ); ?>
						</p>
					<?php endif; ?>

					<?php do_action( 'woocommerce_register_form' ); ?>

					<p class="woocommerce-form-row form-row oilmazing-sfc-wc-account__auth-actions">
						<?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
						<button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit oilmazing-sfc-ui-btn<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="register" value="<?php esc_attr_e( 'Create an account', 'oilmazing-sfc' ); ?>">
							<?php esc_html_e( 'Create an account', 'oilmazing-sfc' ); ?>
						</button>
					</p>

					<?php do_action( 'woocommerce_register_form_end' ); ?>
				</form>
			</section>
		<?php endif; ?>
	</div>
</div>
<?php
do_action( 'woocommerce_after_customer_login_form' );
