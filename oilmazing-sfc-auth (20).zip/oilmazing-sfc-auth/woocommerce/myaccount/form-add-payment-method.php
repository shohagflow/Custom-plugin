<?php
/**
 * Add payment method form — modern layout.
 *
 * @package OilmazingSFC
 * @version 7.8.0
 */

defined( 'ABSPATH' ) || exit;

$available_gateways = WC()->payment_gateways->get_available_payment_gateways();

if ( $available_gateways ) :
	?>
	<form id="add_payment_method" class="oilmazing-sfc-wc-account__payment-form" method="post">
		<div id="payment" class="woocommerce-Payment">
			<ul class="woocommerce-PaymentMethods payment_methods methods">
				<?php
				if ( count( $available_gateways ) ) {
					current( $available_gateways )->set_current();
				}

				foreach ( $available_gateways as $gateway ) {
					?>
					<li class="woocommerce-PaymentMethod woocommerce-PaymentMethod--<?php echo esc_attr( $gateway->id ); ?> payment_method_<?php echo esc_attr( $gateway->id ); ?>">
						<input id="payment_method_<?php echo esc_attr( $gateway->id ); ?>" type="radio" class="input-radio" name="payment_method" value="<?php echo esc_attr( $gateway->id ); ?>" <?php checked( $gateway->chosen, true ); ?> />
						<label for="payment_method_<?php echo esc_attr( $gateway->id ); ?>">
							<span class="oilmazing-sfc-wc-account__payment-label-text"><?php echo wp_kses_post( $gateway->get_title() ); ?></span>
							<span class="oilmazing-sfc-wc-account__payment-label-icon"><?php echo wp_kses_post( $gateway->get_icon() ); ?></span>
						</label>
						<?php
						if ( $gateway->has_fields() || $gateway->get_description() ) {
							echo '<div class="woocommerce-PaymentBox woocommerce-PaymentBox--' . esc_attr( $gateway->id ) . ' payment_box payment_method_' . esc_attr( $gateway->id ) . '" style="display: none;">';
							$gateway->payment_fields();
							echo '</div>';
						}
						?>
					</li>
					<?php
				}
				?>
			</ul>

			<?php do_action( 'woocommerce_add_payment_method_form_bottom' ); ?>

			<div class="form-row oilmazing-sfc-wc-account__payment-form-actions">
				<?php wp_nonce_field( 'woocommerce-add-payment-method', 'woocommerce-add-payment-method-nonce' ); ?>
				<button type="submit" class="woocommerce-Button woocommerce-Button--alt button alt<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" id="place_order" value="<?php esc_attr_e( 'Add payment method', 'woocommerce' ); ?>"><?php esc_html_e( 'Add payment method', 'woocommerce' ); ?></button>
				<input type="hidden" name="woocommerce_add_payment_method" id="woocommerce_add_payment_method" value="1" />
			</div>
		</div>
	</form>
	<?php
else :
	?>
	<div class="oilmazing-sfc-wc-account__empty-state">
		<div class="oilmazing-sfc-wc-account__empty-state-icon" aria-hidden="true">
			<i class="fa-solid fa-credit-card"></i>
		</div>
		<h3 class="oilmazing-sfc-wc-account__empty-state-title">
			<?php esc_html_e( 'Payment methods unavailable', 'oilmazing-sfc' ); ?>
		</h3>
		<p class="oilmazing-sfc-wc-account__empty-state-text">
			<?php esc_html_e( 'New payment methods can only be added during checkout. Please contact us if you require assistance.', 'woocommerce' ); ?>
		</p>
	</div>
	<?php
endif;
