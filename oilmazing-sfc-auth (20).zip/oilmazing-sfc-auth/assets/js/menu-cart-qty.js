( function ( $ ) {
	'use strict';

	var config = window.oilmazingSfcMenuCartQty || {};
	var pending = {};

	function parseQty( value ) {
		var qty = parseInt( value, 10 );
		return isNaN( qty ) ? 0 : Math.max( 0, qty );
	}

	function getMax( $input ) {
		var maxAttr = $input.attr( 'max' );
		if ( maxAttr === undefined || maxAttr === '' ) {
			return null;
		}
		var max = parseInt( maxAttr, 10 );
		return isNaN( max ) ? null : max;
	}

	function clampQty( qty, $input ) {
		var max = getMax( $input );
		if ( max !== null && qty > max ) {
			qty = max;
		}
		return Math.max( 0, qty );
	}

	function isCheckoutContext( $wrap ) {
		return $wrap.data( 'context' ) === 'checkout' || $wrap.closest( '#order_review, form.checkout, .woocommerce-checkout-review-order' ).length > 0;
	}

	function applyFragments( fragments ) {
		if ( ! fragments ) {
			return;
		}

		$.each( fragments, function ( key, value ) {
			$( key ).replaceWith( value );
		} );
	}

	function keepMenuCartOpen() {
		var tries = 0;
		var timer = setInterval( function () {
			tries += 1;
			$( '.elementor-widget-woocommerce-menu-cart' ).each( function () {
				var $widget = $( this );
				$widget.addClass( 'elementor-menu-cart--shown' );
				$widget.find( '.elementor-menu-cart__container' ).attr( 'aria-hidden', 'false' );
			} );
			if ( tries >= 12 ) {
				clearInterval( timer );
			}
		}, 120 );
	}

	function refreshCheckout() {
		$( document.body ).trigger( 'update_checkout' );
	}

	function updateQuantity( $wrap, quantity ) {
		var cartItemKey = $wrap.data( 'cart-item-key' );
		var $input = $wrap.find( '.oilmazing-sfc-menu-cart-qty__input' );
		var onCheckout = isCheckoutContext( $wrap );

		if ( ! cartItemKey || ! config.ajaxUrl ) {
			return;
		}

		quantity = clampQty( quantity, $input );
		$input.val( quantity );

		if ( pending[ cartItemKey ] ) {
			pending[ cartItemKey ].abort();
		}

		var wasOpen = $( '.elementor-menu-cart--shown' ).length > 0;
		$wrap.addClass( 'is-updating' );

		pending[ cartItemKey ] = $.ajax( {
			url: config.ajaxUrl,
			type: 'POST',
			dataType: 'json',
			data: {
				action: config.action,
				nonce: config.nonce,
				cart_item_key: cartItemKey,
				quantity: quantity
			}
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success || ! response.data ) {
					return;
				}

				if ( response.data.cart_empty && onCheckout && response.data.cart_url ) {
					window.location.href = response.data.cart_url;
					return;
				}

				if ( onCheckout ) {
					refreshCheckout();
					return;
				}

				applyFragments( response.data.fragments );

				// Refresh Elementor Menu Cart without treating this as a new add-to-cart.
				$( document.body ).trigger( 'wc_fragments_refreshed' );

				if ( wasOpen ) {
					keepMenuCartOpen();
				}
			} )
			.always( function () {
				delete pending[ cartItemKey ];
				$wrap.removeClass( 'is-updating' );
			} );
	}

	function onButtonClick( event ) {
		event.preventDefault();
		event.stopPropagation();

		var $btn = $( event.currentTarget );
		var $wrap = $btn.closest( '.oilmazing-sfc-menu-cart-qty' );
		var $input = $wrap.find( '.oilmazing-sfc-menu-cart-qty__input' );
		var current = parseQty( $input.val() );
		var action = $btn.data( 'action' );
		var next = action === 'plus' ? current + 1 : current - 1;

		updateQuantity( $wrap, next );
	}

	function onInputChange( event ) {
		var $input = $( event.currentTarget );
		var $wrap = $input.closest( '.oilmazing-sfc-menu-cart-qty' );
		updateQuantity( $wrap, parseQty( $input.val() ) );
	}

	$( document ).on( 'click', '.oilmazing-sfc-menu-cart-qty__btn', onButtonClick );
	$( document ).on( 'change', '.oilmazing-sfc-menu-cart-qty__input', onInputChange );

	// Prevent Enter from submitting checkout / other forms.
	$( document ).on( 'keydown', '.oilmazing-sfc-menu-cart-qty__input', function ( event ) {
		if ( event.key === 'Enter' ) {
			event.preventDefault();
			$( event.currentTarget ).trigger( 'change' );
		}
	} );
}( jQuery ) );
