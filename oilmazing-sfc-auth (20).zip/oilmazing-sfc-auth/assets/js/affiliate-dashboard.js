(function () {
	'use strict';

	function renderAffiliateProgramCard(affiliate) {
		var card = document.getElementById('sfc-affiliate-program-card');
		if (!card) {
			return;
		}

		var affiliateLink = affiliate && (affiliate.affiliate_link || affiliate.subscription_link);
		if (!affiliate || !affiliate.is_affiliate || !affiliateLink) {
			card.classList.add('hidden');
			return;
		}

		var firstRate = affiliate.commission_rate_label
			|| (affiliate.commission_percent != null ? String(affiliate.commission_percent) + '%' : '—');
		var renewalRate = affiliate.recurring_commission_percent != null
			? String(affiliate.recurring_commission_percent) + '%'
			: '—';
		var summary = affiliate.commission_summary
			|| ('Share your affiliate link. When someone joins through your link and buys a club subscription, you earn ' + firstRate + ' on the first payment'
			+ (affiliate.recurring_commissions_enabled
				? ' and ' + renewalRate + ' on every monthly renewal.'
				: '.'));

		var summaryEl = document.getElementById('sfc-affiliate-commission-summary');
		var firstRateEl = document.getElementById('sfc-affiliate-first-rate');
		var renewalRateEl = document.getElementById('sfc-affiliate-renewal-rate');
		var renewalWrap = document.getElementById('sfc-affiliate-renewal-rate-wrap');
		var input = document.getElementById('sfcAffiliateSubscriptionLink');
		var copyBtn = card.querySelector('[data-copy-affiliate-link]');

		if (summaryEl) {
			summaryEl.textContent = summary;
		}
		if (firstRateEl) {
			firstRateEl.textContent = firstRate;
		}
		if (renewalRateEl) {
			renewalRateEl.textContent = renewalRate;
		}
		if (renewalWrap) {
			renewalWrap.classList.toggle('hidden', !affiliate.recurring_commissions_enabled);
		}
		if (input) {
			input.value = affiliateLink;
		}

		if (copyBtn && input && !copyBtn.dataset.bound) {
			copyBtn.dataset.bound = '1';
			copyBtn.addEventListener('click', function () {
				input.select();
				input.setSelectionRange(0, 99999);

				function resetLabel() {
					window.setTimeout(function () {
						copyBtn.textContent = 'Copy';
					}, 1800);
				}

				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(input.value).then(function () {
						copyBtn.textContent = 'Copied';
						resetLabel();
					}).catch(function () {});
					return;
				}

				try {
					document.execCommand('copy');
					copyBtn.textContent = 'Copied';
					resetLabel();
				} catch (error) {
					if (typeof showModal === 'function') {
						showModal('Copy Link', 'Please copy the link manually.');
					}
				}
			});
		}

		card.classList.remove('hidden');
	}

	window.renderAffiliateProgramCard = renderAffiliateProgramCard;

	var originalApply = window.applyReferralProgramToUI;
	window.applyReferralProgramToUI = function (data) {
		if (typeof originalApply === 'function') {
			originalApply(data);
		}

		if (data && data.affiliate) {
			renderAffiliateProgramCard(data.affiliate);
		}
	};

	var originalSwitchView = window.switchView;
	if (typeof originalSwitchView === 'function') {
		window.switchView = function (viewId) {
			originalSwitchView(viewId);

			if (viewId === 'refer' && typeof window.loadReferralProgram === 'function') {
				window.loadReferralProgram();
			}
		};
	}
})();
