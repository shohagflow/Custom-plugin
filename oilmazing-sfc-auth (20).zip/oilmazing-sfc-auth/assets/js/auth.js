(function () {
	'use strict';

	var root = document.getElementById('oilmazing-sfc-auth-root');
	if (!root || typeof oilmazingSfcAuth === 'undefined') {
		return;
	}

	var messageEl = root.querySelector('.oilmazing-sfc-wc-account__auth-message') || root.querySelector('.oilmazing-sfc-auth__message');
	var loginForm = root.querySelector('[data-auth-form="login"]');
	var registerForm = root.querySelector('[data-auth-form="register"]');
	var tabs = root.querySelectorAll('[data-auth-tab]');

	function showMessage(text, type) {
		if (!messageEl) {
			return;
		}

		if (!text) {
			messageEl.hidden = true;
			messageEl.textContent = '';
			messageEl.className = 'oilmazing-sfc-auth__message oilmazing-sfc-wc-account__auth-message';
			return;
		}

		messageEl.hidden = false;
		messageEl.textContent = text;
		messageEl.className = 'oilmazing-sfc-auth__message oilmazing-sfc-wc-account__auth-message is-' + (type || 'error');
	}

	function setLoading(form, loading, loadingText) {
		var button = form ? form.querySelector('.oilmazing-sfc-ui-btn') : null;
		if (!button) {
			return;
		}

		if (loading) {
			if (!button.dataset.defaultLabel) {
				button.dataset.defaultLabel = button.textContent;
			}
			button.disabled = true;
			button.textContent = loadingText;
			return;
		}

		button.disabled = false;
		button.textContent = button.dataset.defaultLabel || button.textContent;
	}

	function switchTab(tabName) {
		tabs.forEach(function (tab) {
			var active = tab.getAttribute('data-auth-tab') === tabName;
			tab.classList.toggle('is-active', active);
			tab.setAttribute('aria-selected', active ? 'true' : 'false');
		});

		if (loginForm) {
			loginForm.classList.toggle('is-active', tabName === 'login');
			loginForm.hidden = tabName !== 'login';
		}

		if (registerForm) {
			registerForm.classList.toggle('is-active', tabName === 'register');
			registerForm.hidden = tabName !== 'register';
		}

		showMessage('');
	}

	function getFormValue(form, name) {
		var field = form.querySelector('[name="' + name + '"]');
		if (!field) {
			return '';
		}

		if (field.type === 'checkbox') {
			return field.checked;
		}

		return field.value.trim();
	}

	function postAuth(endpoint, payload) {
		return fetch(oilmazingSfcAuth.restUrl + endpoint, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-Oilmazing-Auth-Nonce': oilmazingSfcAuth.nonce,
			},
			body: JSON.stringify(payload),
		}).then(function (response) {
			return response.json().then(function (data) {
				return {
					ok: response.ok,
					data: data,
				};
			});
		});
	}

	function handleSuccess(data) {
		if (data.message) {
			showMessage(data.message, 'success');
		}

		window.setTimeout(function () {
			window.location.href = data.redirect_url || window.location.href;
		}, data.message ? 500 : 0);
	}

	function handleError(data) {
		var text = oilmazingSfcAuth.i18n.error;

		if (data && data.message) {
			text = data.message;
		} else if (data && data.data && data.data.message) {
			text = data.data.message;
		}

		showMessage(text, 'error');
	}

	tabs.forEach(function (tab) {
		tab.addEventListener('click', function () {
			switchTab(tab.getAttribute('data-auth-tab'));
		});
	});

	if (loginForm) {
		loginForm.addEventListener('submit', function (event) {
			event.preventDefault();
			showMessage('');
			setLoading(loginForm, true, oilmazingSfcAuth.i18n.signingIn);

			postAuth('auth/login', {
				email: getFormValue(loginForm, 'email'),
				password: getFormValue(loginForm, 'password'),
				remember: getFormValue(loginForm, 'remember'),
				redirect: oilmazingSfcAuth.redirect || root.dataset.redirect || '',
			})
				.then(function (result) {
					if (result.ok && result.data && result.data.success) {
						handleSuccess(result.data);
						return;
					}

					handleError(result.data);
				})
				.catch(function () {
					showMessage(oilmazingSfcAuth.i18n.error, 'error');
				})
				.finally(function () {
					setLoading(loginForm, false);
				});
		});
	}

	if (registerForm) {
		registerForm.addEventListener('submit', function (event) {
			event.preventDefault();
			showMessage('');
			setLoading(registerForm, true, oilmazingSfcAuth.i18n.creating);

			postAuth('auth/register', {
				first_name: getFormValue(registerForm, 'first_name'),
				last_name: getFormValue(registerForm, 'last_name'),
				email: getFormValue(registerForm, 'email'),
				password: getFormValue(registerForm, 'password'),
				redirect: oilmazingSfcAuth.redirect || root.dataset.redirect || '',
			})
				.then(function (result) {
					if (result.ok && result.data && result.data.success) {
						handleSuccess(result.data);
						return;
					}

					handleError(result.data);
				})
				.catch(function () {
					showMessage(oilmazingSfcAuth.i18n.error, 'error');
				})
				.finally(function () {
					setLoading(registerForm, false);
				});
		});
	}

	switchTab(root.dataset.defaultTab || 'login');
})();
