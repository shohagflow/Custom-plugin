(function () {
	'use strict';

	var config = window.oilmazingSfcChatEnhance || {};
	var activeConversationKey = '';
	var presenceTimer = null;

	function escapeHtml(value) {
		return String(value || '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function getThreadName() {
		return document.getElementById('chat-thread-name')?.textContent?.trim() || '';
	}

	function enhanceBubble(bubble) {
		if (!bubble || bubble.dataset.chatEnhanced === '1') {
			return;
		}

		const isSent = bubble.classList.contains('chat-bubble-sent');
		const row = document.createElement('div');
		row.className = 'chat-message-row ' + (isSent ? 'is-sent' : 'is-received');

		const label = document.createElement('span');
		label.className = 'chat-message-label';
		label.textContent = isSent
			? (config.i18n?.you || 'You')
			: getThreadName() || 'Member';

		bubble.parentNode.insertBefore(row, bubble);
		row.appendChild(label);
		row.appendChild(bubble);
		bubble.dataset.chatEnhanced = '1';
	}

	function enhanceChatMessages() {
		const container = document.getElementById('chat-messages');
		if (!container) {
			return;
		}

		container.querySelectorAll('.chat-bubble').forEach(enhanceBubble);
	}

	function observeChatMessages() {
		const container = document.getElementById('chat-messages');
		if (!container || container.dataset.chatObserver === '1') {
			return;
		}

		const observer = new MutationObserver(function () {
			enhanceChatMessages();
		});

		observer.observe(container, { childList: true, subtree: true });
		container.dataset.chatObserver = '1';
		enhanceChatMessages();
	}

	function renderPresenceStatus(conversation) {
		const statusEl = document.getElementById('chat-thread-status');
		if (!statusEl || !conversation) {
			return;
		}

		const isOnline = !!conversation.online;
		const label = conversation.status_label || (isOnline ? (config.i18n?.online || 'Online') : (config.i18n?.offline || 'Offline'));

		statusEl.className = 'text-[10px] font-medium flex items-center ' + (isOnline ? 'is-online' : 'is-offline');
		statusEl.innerHTML = '<span class="presence-dot" aria-hidden="true"></span>' + escapeHtml(label);
	}

	function postPresence(conversationKey) {
		const body = new URLSearchParams();
		body.append('action', 'oilmazing_sfc_presence_heartbeat');
		body.append('nonce', config.nonce || '');
		body.append('conversation_key', conversationKey || '');

		return fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
			},
			body: body.toString()
		}).then(function (response) {
			return response.json();
		});
	}

	function refreshPresence() {
		const threadView = document.getElementById('chat-thread-view');
		if (!threadView || threadView.classList.contains('hidden') || !activeConversationKey) {
			return;
		}

		postPresence(activeConversationKey).then(function (result) {
			if (result && result.success && result.data) {
				renderPresenceStatus(result.data);
			}
		}).catch(function () {});
	}

	function startPresencePolling() {
		if (presenceTimer) {
			window.clearInterval(presenceTimer);
		}

		presenceTimer = window.setInterval(refreshPresence, 20000);
	}

	function patchSfcApi() {
		if (!window.SfcApi) {
			return;
		}

		if (typeof window.SfcApi.getMessages === 'function' && !window.SfcApi.getMessages.__chatEnhanced) {
			const originalGetMessages = window.SfcApi.getMessages.bind(window.SfcApi);
			window.SfcApi.getMessages = async function (conversationKey) {
				activeConversationKey = conversationKey || '';
				const result = await originalGetMessages(conversationKey);
				if (result?.conversation) {
					renderPresenceStatus(result.conversation);
				}
				window.setTimeout(enhanceChatMessages, 0);
				return result;
			};
			window.SfcApi.getMessages.__chatEnhanced = true;
		}

		if (typeof window.SfcApi.sendMessage === 'function' && !window.SfcApi.sendMessage.__chatEnhanced) {
			const originalSendMessage = window.SfcApi.sendMessage.bind(window.SfcApi);
			window.SfcApi.sendMessage = async function (conversationKey, body) {
				activeConversationKey = conversationKey || activeConversationKey;
				const result = await originalSendMessage(conversationKey, body);
				window.setTimeout(enhanceChatMessages, 0);
				return result;
			};
			window.SfcApi.sendMessage.__chatEnhanced = true;
		}

		postPresence(activeConversationKey).catch(function () {});
	}

	document.addEventListener('DOMContentLoaded', function () {
		observeChatMessages();
		patchSfcApi();
		startPresencePolling();
		postPresence('').catch(function () {});
	});
})();
