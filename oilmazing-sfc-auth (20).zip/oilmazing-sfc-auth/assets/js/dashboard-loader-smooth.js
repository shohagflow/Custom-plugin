(function () {
    'use strict';

    function stripLoader() {
        var root = document.getElementById('oilmazing-sfc-root');
        if (!root) {
            return;
        }

        root.classList.remove('oilmazing-sfc-is-loading');

        var loader = document.getElementById('oilmazing-sfc-loader');
        if (loader && loader.parentNode) {
            loader.parentNode.removeChild(loader);
        }

        var app = root.querySelector('.oilmazing-sfc-app');
        if (app) {
            app.removeAttribute('aria-hidden');
        }
    }

    function smoothHideDashboardLoader() {
        stripLoader();
    }

    if (!document.getElementById('oilmazing-sfc-root')) {
        return;
    }

    window.hideDashboardLoader = smoothHideDashboardLoader;
    window.oilmazingSfcHideLoader = smoothHideDashboardLoader;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', stripLoader);
    } else {
        stripLoader();
    }
})();
