(function () {
	'use strict';

	var cfg = window.oilmazingSfcWebpAdmin || {};
	var startBtn = document.getElementById('oilmazing-sfc-webp-bulk-start');
	var panel = document.getElementById('oilmazing-sfc-webp-bulk-panel');
	var progressBar = document.getElementById('oilmazing-sfc-webp-bulk-progress');
	var statusEl = document.getElementById('oilmazing-sfc-webp-bulk-status');
	var metaEl = document.getElementById('oilmazing-sfc-webp-bulk-meta');
	var countEl = document.getElementById('oilmazing-sfc-webp-convertible-count');

	if (!startBtn || !panel || !progressBar || !statusEl) {
		return;
	}

	var running = false;
	var total = 0;
	var convertedTotal = 0;
	var savedBytesTotal = 0;

	function formatBytes(bytes) {
		var value = Number(bytes) || 0;
		if (value < 1024) {
			return value + ' B';
		}
		if (value < 1048576) {
			return (value / 1024).toFixed(1) + ' KB';
		}
		return (value / 1048576).toFixed(2) + ' MB';
	}

	function postAjax(action, data) {
		var body = new URLSearchParams();
		body.append('action', action);
		body.append('nonce', cfg.nonce || '');
		Object.keys(data || {}).forEach(function (key) {
			body.append(key, String(data[key]));
		});

		return fetch(cfg.ajaxUrl || '', {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
			},
			body: body.toString()
		}).then(function (response) {
			return response.json();
		});
	}

	function setProgress(doneCount) {
		var percent = total > 0 ? Math.min(100, Math.round((doneCount / total) * 100)) : 100;
		progressBar.style.width = percent + '%';
	}

	function finish(message) {
		running = false;
		startBtn.disabled = false;
		statusEl.textContent = message || ((cfg.i18n && cfg.i18n.complete) || 'Complete.');
		if (countEl) {
			countEl.textContent = '0';
		}
		startBtn.disabled = true;
	}

	function runBatch(offset) {
		return postAjax('oilmazing_sfc_webp_convert_batch', { offset: offset }).then(function (result) {
			if (!result || !result.success) {
				throw new Error((result && result.data && result.data.message) || ((cfg.i18n && cfg.i18n.failed) || 'Failed'));
			}

			var data = result.data || {};
			convertedTotal += Number(data.converted || 0);
			savedBytesTotal += Number(data.saved_bytes || 0);

			var doneCount = Math.max(0, total - Number(data.remaining || 0));
			setProgress(doneCount);

			statusEl.textContent = ((cfg.i18n && cfg.i18n.converting) || 'Converting…')
				+ ' ' + doneCount + ' / ' + total;

			if (metaEl) {
				metaEl.textContent = convertedTotal + ' converted, ' + formatBytes(savedBytesTotal) + ' saved';
			}

			if (countEl) {
				countEl.textContent = String(Number(data.remaining || 0));
			}

			if (data.done) {
				finish((cfg.i18n && cfg.i18n.complete) || 'Complete.');
				return;
			}

			return runBatch(Number(data.next_offset || 0));
		});
	}

	startBtn.addEventListener('click', function () {
		if (running) {
			return;
		}

		running = true;
		convertedTotal = 0;
		savedBytesTotal = 0;
		startBtn.disabled = true;
		panel.hidden = false;
		statusEl.textContent = (cfg.i18n && cfg.i18n.starting) || 'Starting…';
		metaEl.textContent = '';
		setProgress(0);

		postAjax('oilmazing_sfc_webp_scan', {}).then(function (result) {
			if (!result || !result.success) {
				throw new Error((result && result.data && result.data.message) || ((cfg.i18n && cfg.i18n.failed) || 'Failed'));
			}

			if (!result.data || !result.data.supported) {
				throw new Error((cfg.i18n && cfg.i18n.unsupported) || 'Unsupported');
			}

			total = Number(result.data.total || 0);
			if (total <= 0) {
				finish((cfg.i18n && cfg.i18n.complete) || 'Complete.');
				return;
			}

			return runBatch(0);
		}).catch(function (error) {
			running = false;
			startBtn.disabled = false;
			statusEl.textContent = error && error.message ? error.message : ((cfg.i18n && cfg.i18n.failed) || 'Failed');
		});
	});
})();
