(function () {
	'use strict';

	var cfg = window.oilmazingSfcApPanel || {};
	var injected = false;

	function escapeHtml(value) {
		return String(value || '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function buildCard() {
		var wrap = document.createElement('div');
		wrap.className = 'ap-chart-data-card ap-affiliat-panel-pading oilmazing-sfc-ap-club-commission';
		wrap.id = 'oilmazing-sfc-ap-club-injected';

		var renewalHtml = cfg.renewalEnabled
			? '<div class="oilmazing-sfc-ap-rate-card">'
				+ '<div class="oilmazing-sfc-ap-rate-card__label">' + escapeHtml(cfg.renewalLabel) + '</div>'
				+ '<div class="oilmazing-sfc-ap-rate-card__value">' + escapeHtml(cfg.renewalRate) + '</div>'
				+ '</div>'
			: '';

		var firstBasisHtml = cfg.firstBasis
			? '<div class="oilmazing-sfc-ap-rate-card__meta">' + escapeHtml(cfg.firstBasis) + '</div>'
			: '';

		wrap.innerHTML = '<div class="ap-tab-heading">' + escapeHtml(cfg.title) + '</div>'
			+ '<p class="oilmazing-sfc-ap-club-commission__summary">' + escapeHtml(cfg.summary) + '</p>'
			+ '<div class="oilmazing-sfc-ap-rates">'
			+ '<div class="oilmazing-sfc-ap-rate-card">'
			+ '<div class="oilmazing-sfc-ap-rate-card__label">' + escapeHtml(cfg.firstLabel) + '</div>'
			+ '<div class="oilmazing-sfc-ap-rate-card__value">' + escapeHtml(cfg.firstRate) + '</div>'
			+ firstBasisHtml
			+ '</div>'
			+ renewalHtml
			+ '</div>';

		return wrap;
	}

	function findInjectionPoint() {
		if (document.getElementById('oilmazing-sfc-ap-club-vue')) {
			return null;
		}

		var chart = document.getElementById('revenue_chart');
		if (chart) {
			var reportsCard = chart.closest('.ap-chart-data-card');
			if (reportsCard && reportsCard.parentElement) {
				return { parent: reportsCard.parentElement, before: reportsCard };
			}
		}

		var dashboardPanels = document.querySelectorAll('.ap-affiliate-panel-content .ap-panel-detail');
		var index;
		for (index = 0; index < dashboardPanels.length; index += 1) {
			var panel = dashboardPanels[index];
			if (!panel.querySelector('.ap-box-card')) {
				continue;
			}

			var chartCard = panel.querySelector('.ap-chart-data-card');
			if (chartCard && chartCard.parentElement) {
				return { parent: chartCard.parentElement, before: chartCard };
			}

			if (panel.parentElement) {
				return { parent: panel, before: null };
			}
		}

		return null;
	}

	function tryInject() {
		if (injected || document.getElementById('oilmazing-sfc-ap-club-injected') || document.getElementById('oilmazing-sfc-ap-club-vue')) {
			injected = true;
			return;
		}

		var point = findInjectionPoint();
		if (!point || !point.parent) {
			return;
		}

		var card = buildCard();
		if (point.before) {
			point.parent.insertBefore(card, point.before);
		} else {
			point.parent.appendChild(card);
		}

		injected = true;
	}

	function boot() {
		tryInject();

		var observer = new MutationObserver(function () {
			tryInject();
		});
		observer.observe(document.body, { childList: true, subtree: true });

		document.addEventListener('click', function () {
			window.setTimeout(tryInject, 300);
		});

		window.setInterval(tryInject, 1500);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
