(function ($) {
    'use strict';

    if (!$ || $.fn.sticky) {
        return;
    }

    $.fn.sticky = function (options) {
        if (options === 'destroy') {
            return this;
        }

        return this;
    };
})(window.jQuery);
