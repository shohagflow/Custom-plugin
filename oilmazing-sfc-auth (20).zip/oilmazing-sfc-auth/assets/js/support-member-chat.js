(function () {
	'use strict';

	var lastSupportMessages = [];

	function decorateSupportMessageNames() {
		var container = document.getElementById('chat-messages');
		if (!container || !lastSupportMessages.length) {
			return;
		}

		var received = lastSupportMessages.filter(function (message) {
			return message && message.from !== 'me';
		});
		var bubbles = container.querySelectorAll('.chat-bubble-received');

		received.forEach(function (message, index) {
			var bubble = bubbles[index];
			if (!bubble || !message.sender_name) {
				return;
			}

			var existingWrap = bubble.closest('.chat-bubble-wrap');
			if (existingWrap && existingWrap.querySelector('.chat-bubble-sender')) {
				return;
			}

			var wrap = document.createElement('div');
			wrap.className = 'chat-bubble-wrap chat-bubble-wrap-received';

			var nameEl = document.createElement('p');
			nameEl.className = 'chat-bubble-sender text-[10px] font-semibold text-zinc-500 mb-1';
			nameEl.textContent = message.sender_name;

			var parent = bubble.parentNode;
			if (!parent) {
				return;
			}

			parent.insertBefore(wrap, bubble);
			wrap.appendChild(nameEl);
			wrap.appendChild(bubble);
		});
	}

	function rememberSupportMessages(response) {
		if (!response || !response.conversation || !response.conversation.is_support) {
			lastSupportMessages = [];
			return;
		}

		lastSupportMessages = Array.isArray(response.messages) ? response.messages.slice() : [];
		window.setTimeout(decorateSupportMessageNames, 0);
	}

	function patchGetMessages() {
		if (typeof SfcApi === 'undefined' || typeof SfcApi.getMessages !== 'function' || SfcApi.getMessages.__oilmazingSupportPatched) {
			return;
		}

		var original = SfcApi.getMessages.bind(SfcApi);
		SfcApi.getMessages = function patchedGetMessages(conversationKey) {
			return original(conversationKey).then(function (response) {
				rememberSupportMessages(response);
				return response;
			});
		};
		SfcApi.getMessages.__oilmazingSupportPatched = true;
	}

	function observeChatMessages() {
		var container = document.getElementById('chat-messages');
		if (!container || container.__oilmazingSupportObserver) {
			return;
		}

		var observer = new MutationObserver(function () {
			decorateSupportMessageNames();
		});
		observer.observe(container, { childList: true, subtree: false });
		container.__oilmazingSupportObserver = observer;
	}

	function boot() {
		patchGetMessages();
		observeChatMessages();
	}

	boot();
	document.addEventListener('DOMContentLoaded', boot);
})();
