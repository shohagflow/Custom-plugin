(function () {
	'use strict';

	var config = window.oilmazingSfcMembership || {};
	var root = document.getElementById('oilmazing-sfc-membership-root');

	if (!root) {
		return;
	}

	var messageEl = root.querySelector('.oilmazing-sfc-membership__message');
	var checkoutBtn = root.querySelector('[data-membership-checkout]');
	var selectedId = checkoutBtn ? (checkoutBtn.getAttribute('data-plan-id') || checkoutBtn.getAttribute('data-product-id') || '') : '';

	function showMessage(text, type) {
		if (!messageEl) {
			return;
		}

		messageEl.textContent = text;
		messageEl.hidden = !text;
		messageEl.classList.remove('is-error', 'is-success');
		if (type) {
			messageEl.classList.add('is-' + type);
		}
	}

	function setSelectedPlan(planId) {
		selectedId = String(planId);
		if (checkoutBtn) {
			checkoutBtn.setAttribute('data-plan-id', selectedId);
		}

		root.querySelectorAll('.oilmazing-sfc-membership__plan').forEach(function (card) {
			var isSelected = card.getAttribute('data-plan-id') === selectedId;
			card.classList.toggle('is-selected', isSelected);

			var selectBtn = card.querySelector('[data-membership-select]');
			if (selectBtn) {
				selectBtn.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
				selectBtn.textContent = isSelected
					? (config.i18n && config.i18n.selected ? config.i18n.selected : 'Selected')
					: 'Select plan';
			}
		});
	}

	root.querySelectorAll('[data-membership-select]').forEach(function (button) {
		button.addEventListener('click', function () {
			setSelectedPlan(button.getAttribute('data-membership-select'));
		});
	});

	if (checkoutBtn) {
		checkoutBtn.addEventListener('click', function () {
			if (!selectedId) {
				showMessage(config.i18n && config.i18n.error ? config.i18n.error : 'Please select a plan.', 'error');
				return;
			}

			checkoutBtn.disabled = true;
			showMessage(config.i18n && config.i18n.loading ? config.i18n.loading : 'Joining...', 'success');

			var payload = { plan_id: selectedId };
			if (/^\d+$/.test(selectedId)) {
				payload.product_id = parseInt(selectedId, 10);
			}

			fetch((config.restUrl || '') + 'membership', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': config.nonce || ''
				},
				credentials: 'same-origin',
				body: JSON.stringify(payload)
			})
				.then(function (response) {
					return response.json().then(function (body) {
						return { ok: response.ok, body: body };
					});
				})
				.then(function (result) {
					var data = result.body && result.body.data ? result.body.data : result.body;

					if (!result.ok) {
						throw new Error(
							(data && data.message) ||
								(result.body && result.body.message) ||
								(config.i18n && config.i18n.error ? config.i18n.error : 'Join failed.')
						);
					}

					if (data && data.dashboard_url) {
						window.location.href = data.dashboard_url;
						return;
					}

					if (data && data.checkout_url) {
						window.location.href = data.checkout_url;
						return;
					}

					throw new Error(config.i18n && config.i18n.error ? config.i18n.error : 'Join failed.');
				})
				.catch(function (error) {
					checkoutBtn.disabled = false;
					showMessage(error.message || (config.i18n && config.i18n.error ? config.i18n.error : 'Join failed.'), 'error');
				});
		});
	}
})();
