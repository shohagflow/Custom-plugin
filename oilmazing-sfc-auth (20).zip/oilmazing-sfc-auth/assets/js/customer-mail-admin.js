(function () {
	'use strict';

	var config = window.oilmazingSfcCustomerMail || {};
	var selected = new Map();
	var searchTimer = null;
	var isSending = false;

	function escapeHtml(value) {
		return String(value || '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function postAjax(action, data) {
		var body = new URLSearchParams();
		body.append('action', action);
		body.append('nonce', config.nonce || '');

		Object.keys(data || {}).forEach(function (key) {
			var value = data[key];
			if (Array.isArray(value)) {
				value.forEach(function (item) {
					body.append(key + '[]', item);
				});
				return;
			}
			body.append(key, value);
		});

		return fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
			},
			body: body.toString()
		}).then(function (response) {
			return response.json();
		});
	}

	function showToast(type, title, message) {
		var stack = document.querySelector('[data-mail-toast-stack]');
		if (!stack) {
			return;
		}

		var toast = document.createElement('div');
		toast.className = 'oilmazing-sfc-customer-mail__toast is-' + type;
		toast.innerHTML =
			'<div class="oilmazing-sfc-customer-mail__toast__body">' +
				'<strong>' + escapeHtml(title) + '</strong>' +
				(message ? '<p>' + escapeHtml(message) + '</p>' : '') +
			'</div>' +
			'<button type="button" class="oilmazing-sfc-customer-mail__toast__close" aria-label="Dismiss">&times;</button>';

		stack.appendChild(toast);

		toast.querySelector('.oilmazing-sfc-customer-mail__toast__close').addEventListener('click', function () {
			toast.remove();
		});

		window.requestAnimationFrame(function () {
			toast.classList.add('is-visible');
		});

		window.setTimeout(function () {
			if (toast.parentNode) {
				toast.classList.remove('is-visible');
				window.setTimeout(function () {
					if (toast.parentNode) {
						toast.remove();
					}
				}, 220);
			}
		}, 5200);
	}

	function buildSuccessToasts(result) {
		var recipients = (result.data && result.data.sent_recipients) || [];
		var failed = Number((result.data && result.data.failed) || 0);

		if (recipients.length === 1) {
			var singleName = recipients[0].name || recipients[0].email || 'Customer';
			showToast(
				'success',
				singleName,
				(config.i18n && config.i18n.emailSentTo)
					? config.i18n.emailSentTo.replace('%s', singleName)
					: 'Email sent successfully.'
			);
		} else if (recipients.length > 1 && recipients.length <= 5) {
			recipients.forEach(function (recipient) {
				var name = recipient.name || recipient.email || 'Customer';
				showToast(
					'success',
					name,
					(config.i18n && config.i18n.emailSentTo)
						? config.i18n.emailSentTo.replace('%s', name)
						: 'Email sent successfully.'
				);
			});
		} else if (result.data && result.data.message) {
			showToast('success', 'Email sent', result.data.message);
		}

		if (failed > 0) {
			showToast(
				'error',
				'Delivery issue',
				(config.i18n && config.i18n.deliveryFailed)
					? config.i18n.deliveryFailed.replace('%d', String(failed))
					: failed + ' delivery failed.'
			);
		}
	}

	function renderSelectedRecipients() {
		var list = document.querySelector('[data-selected-list]');
		var countEl = document.querySelector('[data-selected-count]');
		if (!list) {
			return;
		}

		if (!selected.size) {
			list.innerHTML = '<p class="oilmazing-sfc-customer-mail__empty">' + escapeHtml('Search and add customers to build your recipient list.') + '</p>';
		} else {
			list.innerHTML = Array.from(selected.values()).map(function (customer) {
				return (
					'<div class="oilmazing-sfc-customer-mail__chip">' +
						'<span class="oilmazing-sfc-customer-mail__chip-copy">' +
							'<strong>' + escapeHtml(customer.name) + '</strong>' +
							'<small>' + escapeHtml(customer.email) + '</small>' +
						'</span>' +
						'<button type="button" class="button-link-delete" data-remove-id="' + escapeHtml(customer.id) + '">' + escapeHtml((config.i18n && config.i18n.remove) || 'Remove') + '</button>' +
						'<input type="hidden" name="recipient_ids[]" value="' + escapeHtml(customer.id) + '" />' +
					'</div>'
				);
			}).join('');
		}

		if (countEl) {
			countEl.textContent = selected.size + ' ' + ((config.i18n && config.i18n.selected) || 'selected');
		}
	}

	function addRecipient(customer) {
		if (!customer || !customer.id) {
			return;
		}
		selected.set(String(customer.id), customer);
		renderSelectedRecipients();
	}

	function bindAudienceToggle() {
		var searchWrap = document.querySelector('[data-recipient-search-wrap]');
		var selectedWrap = document.querySelector('[data-selected-recipients]');

		document.querySelectorAll('[data-audience-input]').forEach(function (input) {
			input.addEventListener('change', function () {
				var isSelected = input.value === 'selected' && input.checked;
				if (searchWrap) {
					searchWrap.style.display = isSelected ? '' : 'none';
				}
				if (selectedWrap) {
					selectedWrap.style.display = isSelected ? '' : 'none';
				}
			});
		});
	}

	function bindSearch() {
		var input = document.getElementById('oilmazing-sfc-customer-mail-search');
		var results = document.getElementById('oilmazing-sfc-customer-mail-search-results');
		if (!input || !results) {
			return;
		}

		function showStatus(className, message) {
			results.hidden = false;
			results.className = 'oilmazing-sfc-customer-mail__search-results ' + className;
			results.innerHTML = '<p>' + escapeHtml(message) + '</p>';
		}

		input.addEventListener('input', function () {
			var query = input.value.trim();
			if (searchTimer) {
				window.clearTimeout(searchTimer);
			}

			if (query.length < 2) {
				results.hidden = true;
				results.innerHTML = '';
				return;
			}

			searchTimer = window.setTimeout(function () {
				showStatus('is-loading', (config.i18n && config.i18n.searching) || 'Searching…');
				postAjax('oilmazing_sfc_customer_mail_search', { query: query }).then(function (result) {
					if (!result || !result.success) {
						throw new Error('Search failed');
					}

					var customers = (result.data && result.data.customers) || [];
					if (!customers.length) {
						showStatus('is-empty', (config.i18n && config.i18n.noResults) || 'No customers found.');
						return;
					}

					results.hidden = false;
					results.className = 'oilmazing-sfc-customer-mail__search-results';
					results.innerHTML = customers.map(function (customer) {
						return (
							'<button type="button" class="oilmazing-sfc-customer-mail__search-item" data-customer-id="' + escapeHtml(customer.id) + '">' +
								'<span class="oilmazing-sfc-customer-mail__search-item-copy">' +
									'<strong>' + escapeHtml(customer.name) + '</strong>' +
									'<small>' + escapeHtml(customer.email) + (customer.label ? ' · ' + escapeHtml(customer.label) : '') + '</small>' +
								'</span>' +
								'<span class="oilmazing-sfc-customer-mail__search-item-action">' + escapeHtml((config.i18n && config.i18n.addRecipient) || 'Add recipient') + '</span>' +
							'</button>'
						);
					}).join('');

					results.querySelectorAll('[data-customer-id]').forEach(function (button) {
						button.addEventListener('click', function () {
							var id = button.getAttribute('data-customer-id');
							var match = customers.find(function (customer) {
								return String(customer.id) === String(id);
							});
							if (match) {
								addRecipient(match);
								results.hidden = true;
								input.value = '';
							}
						});
					});
				}).catch(function () {
					showStatus('is-empty', (config.i18n && config.i18n.noResults) || 'No customers found.');
				});
			}, 250);
		});
	}

	function bindSelectedList() {
		document.addEventListener('click', function (event) {
			var button = event.target.closest('[data-remove-id]');
			if (!button) {
				return;
			}
			selected.delete(String(button.getAttribute('data-remove-id')));
			renderSelectedRecipients();
		});
	}

	function setFieldInvalid(field, invalid) {
		if (!field) {
			return;
		}
		field.classList.toggle('is-invalid', !!invalid);
	}

	function resetFormAfterSend() {
		var subject = document.getElementById('oilmazing-sfc-customer-mail-subject');
		var message = document.getElementById('oilmazing-sfc-customer-mail-message');
		if (subject) {
			subject.value = '';
			setFieldInvalid(subject, false);
		}
		if (message) {
			message.value = '';
			setFieldInvalid(message, false);
		}
		selected.clear();
		renderSelectedRecipients();
	}

	function bindAjaxSend() {
		var form = document.querySelector('.oilmazing-sfc-customer-mail__form');
		var sendButton = document.querySelector('[data-send-button]');
		if (!form) {
			return;
		}

		form.addEventListener('submit', function (event) {
			event.preventDefault();

			if (isSending) {
				return;
			}

			var audience = form.querySelector('input[name="audience"]:checked');
			var subjectField = document.getElementById('oilmazing-sfc-customer-mail-subject');
			var messageField = document.getElementById('oilmazing-sfc-customer-mail-message');
			var subject = subjectField ? subjectField.value.trim() : '';
			var message = messageField ? messageField.value.trim() : '';

			setFieldInvalid(subjectField, false);
			setFieldInvalid(messageField, false);

			if (audience && audience.value === 'selected' && !selected.size) {
				showToast('error', 'Recipients required', (config.i18n && config.i18n.selectRecipient) || 'Please add at least one customer.');
				return;
			}

			if (!subject) {
				setFieldInvalid(subjectField, true);
				showToast('error', 'Subject required', (config.i18n && config.i18n.enterSubject) || 'Please enter a subject.');
				if (subjectField) {
					subjectField.focus();
				}
				return;
			}

			if (!message) {
				setFieldInvalid(messageField, true);
				showToast('error', 'Message required', (config.i18n && config.i18n.enterMessage) || 'Please enter a message.');
				if (messageField) {
					messageField.focus();
				}
				return;
			}

			isSending = true;
			if (sendButton) {
				sendButton.classList.add('is-loading');
				sendButton.textContent = (config.i18n && config.i18n.sending) || 'Sending…';
			}

			postAjax('oilmazing_sfc_send_customer_mail', {
				audience: audience ? audience.value : 'selected',
				subject: subject,
				message: message,
				recipient_ids: Array.from(selected.keys())
			}).then(function (result) {
				if (!result || !result.success) {
					var errorMessage = (result && result.data && result.data.message) || (config.i18n && config.i18n.sendFailed) || 'Send failed.';
					showToast('error', 'Send failed', errorMessage);
					return;
				}

				buildSuccessToasts(result);
				resetFormAfterSend();
			}).catch(function () {
				showToast('error', 'Send failed', (config.i18n && config.i18n.sendFailed) || 'The email could not be sent.');
			}).finally(function () {
				isSending = false;
				if (sendButton) {
					sendButton.classList.remove('is-loading');
					sendButton.textContent = (config.i18n && config.i18n.sendEmail) || 'Send email';
				}
			});
		});
	}

	document.addEventListener('DOMContentLoaded', function () {
		bindAudienceToggle();
		bindSearch();
		bindSelectedList();
		bindAjaxSend();
		renderSelectedRecipients();
	});
})();
