(function () {
	'use strict';

	var config = window.oilmazingSfcSupportNotify || {};
	var lastCount = parseInt(config.unreadTotal, 10) || 0;
	var pollTimer = null;

	function postUnreadStatus() {
		var body = new URLSearchParams();
		body.append('action', 'oilmazing_sfc_support_unread_status');
		body.append('nonce', config.nonce || '');

		return fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
			},
			body: body.toString()
		}).then(function (response) {
			return response.json();
		});
	}

	function renderBadge(count) {
		if (count > 0) {
			return ' <span class="awaiting-mod count-' + count + ' oilmazing-sfc-support-menu-badge"><span class="pending-count">' + count + '</span></span>';
		}
		return '';
	}

	function updateSidebarMenu(count) {
		var menuItem = document.getElementById('toplevel_page_' + (config.pageSlug || 'oilmazing-support'));
		if (!menuItem) {
			return;
		}

		var link = menuItem.querySelector('.wp-menu-name');
		if (!link) {
			return;
		}

		var label = (config.menuLabel || 'Support').trim();
		link.innerHTML = label + renderBadge(count);
	}

	function updateAdminBar(count) {
		var node = document.getElementById('wp-admin-bar-oilmazing-sfc-support-inbox');
		if (!node) {
			return;
		}

		var anchor = node.querySelector('a.ab-item');
		if (!anchor) {
			return;
		}

		var label = (config.menuLabel || 'Support').trim();
		anchor.innerHTML = label + renderBadge(count).replace('oilmazing-sfc-support-menu-badge', 'oilmazing-sfc-support-adminbar-badge');
	}

	function removeAdminNotice() {
		document.querySelectorAll('[data-oilmazing-support-notice]').forEach(function (node) {
			node.remove();
		});
	}

	function showToast(summary) {
		var existing = document.getElementById('oilmazing-sfc-support-toast');
		if (existing) {
			existing.remove();
		}

		var count = parseInt(summary.unread_total, 10) || 0;
		var latest = summary.latest || {};
		var toast = document.createElement('div');
		toast.id = 'oilmazing-sfc-support-toast';
		toast.className = 'oilmazing-sfc-support-toast';
		toast.innerHTML =
			'<div class="oilmazing-sfc-support-toast__body">' +
				'<strong>' + (config.i18n && config.i18n.newMessage ? config.i18n.newMessage : 'New support message received.') + '</strong>' +
				(latest.member_name ? '<p>' + latest.member_name + (latest.preview ? ': ' + latest.preview : '') + '</p>' : '') +
				'<span class="oilmazing-sfc-support-toast__count">' + count + ' ' + (config.i18n && config.i18n.unreadLabel ? config.i18n.unreadLabel : 'unread support messages') + '</span>' +
			'</div>' +
			'<a class="button button-primary" href="' + (latest.url || config.inboxUrl || '#') + '">' +
				(config.i18n && config.i18n.openInbox ? config.i18n.openInbox : 'Open inbox') +
			'</a>' +
			'<button type="button" class="oilmazing-sfc-support-toast__close" aria-label="Dismiss">&times;</button>';

		document.body.appendChild(toast);

		toast.querySelector('.oilmazing-sfc-support-toast__close').addEventListener('click', function () {
			toast.remove();
		});

		window.setTimeout(function () {
			if (toast.parentNode) {
				toast.classList.add('is-visible');
			}
		}, 20);

		window.setTimeout(function () {
			if (toast.parentNode) {
				toast.remove();
			}
		}, 12000);
	}

	function applyUnreadSummary(summary, showNewToast) {
		var count = parseInt(summary.unread_total, 10) || 0;

		updateSidebarMenu(count);
		updateAdminBar(count);

		if (count <= 0) {
			removeAdminNotice();
		}

		if (showNewToast && count > lastCount) {
			showToast(summary);
		}

		lastCount = count;
	}

	function pollUnreadStatus(showNewToast) {
		postUnreadStatus().then(function (result) {
			if (result && result.success && result.data) {
				applyUnreadSummary(result.data, showNewToast);
			}
		}).catch(function () {});
	}

	function startPolling() {
		if (pollTimer) {
			window.clearInterval(pollTimer);
		}

		pollTimer = window.setInterval(function () {
			pollUnreadStatus(true);
		}, parseInt(config.pollMs, 10) || 20000);
	}

	document.addEventListener('DOMContentLoaded', function () {
		applyUnreadSummary({
			unread_total: lastCount,
			latest: null
		}, false);
		startPolling();
	});
})();
