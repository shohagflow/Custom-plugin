(function () {
	'use strict';

	var config = window.oilmazingSfcSupport || {};
	var pollTimer = null;
	var searchTimer = null;

	function escapeHtml(value) {
		return String(value || '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function postForm(action, data) {
		var body = new URLSearchParams();
		body.append('action', action);
		body.append('nonce', config.nonce || '');

		Object.keys(data).forEach(function (key) {
			body.append(key, data[key]);
		});

		return fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
			},
			body: body.toString()
		}).then(function (response) {
			return response.json();
		});
	}

	function getMessagesContainer() {
		return document.getElementById('oilmazing-sfc-support-messages');
	}

	function scrollMessagesToBottom() {
		var container = getMessagesContainer();
		if (container) {
			container.scrollTop = container.scrollHeight;
		}
	}

	function renderMessage(message) {
		var container = getMessagesContainer();
		var memberName = container ? (container.getAttribute('data-member-name') || 'Member') : 'Member';
		var isAdmin = !!message.is_admin;
		var rowClass = isAdmin ? 'is-mine' : 'is-theirs';
		var label = isAdmin
			? (message.sender_name || ((config.i18n && config.i18n.support) || 'Support'))
			: memberName;

		return (
			'<div class="oilmazing-sfc-support-admin__message-row ' + rowClass + '">' +
				'<span class="oilmazing-sfc-support-admin__message-label">' + escapeHtml(label) + '</span>' +
				'<div class="oilmazing-sfc-support-admin__message' + (isAdmin ? ' is-admin' : ' is-member') + '">' +
					'<div class="oilmazing-sfc-support-admin__message-meta">' +
						'<span>' + escapeHtml((message.date || '') + ' · ' + (message.time || '')) + '</span>' +
					'</div>' +
					'<div class="oilmazing-sfc-support-admin__message-body">' + escapeHtml(message.body) + '</div>' +
				'</div>' +
			'</div>'
		);
	}

	function renderMessages(messages) {
		var container = getMessagesContainer();
		if (!container) {
			return;
		}

		if (!messages || !messages.length) {
			container.innerHTML = '<div class="oilmazing-sfc-support-admin__thread-empty"><p>No messages in this conversation yet.</p></div>';
			return;
		}

		container.innerHTML = messages.map(renderMessage).join('');
		scrollMessagesToBottom();
	}

	function bindMemberSearch() {
		var input = document.getElementById('oilmazing-sfc-support-member-search');
		var results = document.getElementById('oilmazing-sfc-support-member-results');
		if (!input || !results) {
			return;
		}

		function hideResults() {
			results.hidden = true;
			results.className = 'oilmazing-sfc-support-admin__search-results';
			results.innerHTML = '';
		}

		function showStatus(className, message) {
			results.hidden = false;
			results.className = 'oilmazing-sfc-support-admin__search-results ' + className;
			results.innerHTML = '<p>' + escapeHtml(message) + '</p>';
		}

		function renderResults(members) {
			if (!members.length) {
				showStatus('is-empty', (config.i18n && config.i18n.noMembers) || 'No members found.');
				return;
			}

			results.hidden = false;
			results.className = 'oilmazing-sfc-support-admin__search-results';
			results.innerHTML = members.map(function (member) {
				return (
					'<button type="button" class="oilmazing-sfc-support-admin__search-item" data-member-id="' + escapeHtml(member.id) + '">' +
						'<img src="' + escapeHtml(member.avatar_url) + '" alt="" />' +
						'<span class="oilmazing-sfc-support-admin__search-item-copy">' +
							'<strong>' + escapeHtml(member.name) + '</strong>' +
							'<span>' + escapeHtml(member.email) + (member.subscription_label ? ' · ' + escapeHtml(member.subscription_label) : '') + '</span>' +
						'</span>' +
						'<span class="oilmazing-sfc-support-admin__search-item-action">' + escapeHtml((config.i18n && config.i18n.message) || 'Message') + '</span>' +
					'</button>'
				);
			}).join('');
		}

		function openConversation(memberId) {
			showStatus('is-loading', (config.i18n && config.i18n.searching) || 'Opening conversation…');

			postForm('oilmazing_sfc_support_start_conversation', {
				member_id: memberId
			}).then(function (result) {
				if (!result || !result.success || !result.data || !result.data.redirect_url) {
					throw new Error((result && result.data && result.data.message) || (config.i18n && config.i18n.openFailed) || 'Could not open conversation.');
				}

				window.location.href = result.data.redirect_url;
			}).catch(function (error) {
				showStatus('is-empty', error.message || (config.i18n && config.i18n.openFailed) || 'Could not open conversation.');
			});
		}

		input.addEventListener('input', function () {
			var query = input.value.trim();

			if (searchTimer) {
				window.clearTimeout(searchTimer);
			}

			if (query.length < 2) {
				hideResults();
				return;
			}

			searchTimer = window.setTimeout(function () {
				showStatus('is-loading', (config.i18n && config.i18n.searching) || 'Searching…');

				postForm('oilmazing_sfc_support_search_members', {
					query: query
				}).then(function (result) {
					if (!result || !result.success) {
						throw new Error((result && result.data && result.data.message) || 'Search failed.');
					}

					renderResults((result.data && result.data.members) || []);
				}).catch(function (error) {
					showStatus('is-empty', error.message || (config.i18n && config.i18n.noMembers) || 'No members found.');
				});
			}, 250);
		});

		results.addEventListener('click', function (event) {
			var button = event.target.closest('[data-member-id]');
			if (!button) {
				return;
			}

			openConversation(button.getAttribute('data-member-id'));
		});

		document.addEventListener('click', function (event) {
			if (!event.target.closest('[data-support-member-search]')) {
				if (input.value.trim().length < 2) {
					hideResults();
				}
			}
		});

		input.addEventListener('keydown', function (event) {
			if (event.key === 'Enter') {
				event.preventDefault();
				var first = results.querySelector('[data-member-id]');
				if (first) {
					openConversation(first.getAttribute('data-member-id'));
				}
			}
		});
	}

	function bindReplyForm() {
		var form = document.getElementById('oilmazing-sfc-support-reply-form');
		if (!form) {
			return;
		}

		var textarea = document.getElementById('oilmazing-sfc-support-reply');
		var submitBtn = form.querySelector('button[type="submit"]');
		var conversationId = form.getAttribute('data-conversation-id');

		form.addEventListener('submit', function (event) {
			event.preventDefault();

			var body = textarea ? textarea.value.trim() : '';
			if (!body) {
				window.alert((config.i18n && config.i18n.empty) || 'Please enter a reply.');
				return;
			}

			if (submitBtn) {
				submitBtn.disabled = true;
				submitBtn.textContent = (config.i18n && config.i18n.sending) || 'Sending…';
			}

			postForm('oilmazing_sfc_support_send_reply', {
				conversation_id: conversationId,
				body: body
			})
				.then(function (result) {
					if (!result || !result.success) {
						throw new Error((result && result.data && result.data.message) || (config.i18n && config.i18n.sendFailed) || 'Send failed');
					}

					var container = getMessagesContainer();
					if (container) {
						var emptyState = container.querySelector('.oilmazing-sfc-support-admin__thread-empty');
						if (emptyState) {
							container.innerHTML = '';
						}
						container.insertAdjacentHTML('beforeend', renderMessage(result.data.message));
						scrollMessagesToBottom();
					}

					if (textarea) {
						textarea.value = '';
						textarea.focus();
					}
				})
				.catch(function (error) {
					window.alert(error.message || (config.i18n && config.i18n.sendFailed) || 'Send failed');
				})
				.finally(function () {
					if (submitBtn) {
						submitBtn.disabled = false;
						submitBtn.textContent = (config.i18n && config.i18n.send) || 'Send reply';
					}
				});
		});
	}

	function refreshThread() {
		var container = getMessagesContainer();
		if (!container) {
			return;
		}

		var conversationId = container.getAttribute('data-conversation-id');
		if (!conversationId) {
			return;
		}

		postForm('oilmazing_sfc_support_refresh_thread', {
			conversation_id: conversationId
		}).then(function (result) {
			if (result && result.success && result.data && Array.isArray(result.data.messages)) {
				renderMessages(result.data.messages);
			}
		}).catch(function () {});
	}

	function startPolling() {
		if (pollTimer) {
			window.clearInterval(pollTimer);
		}

		if (!getMessagesContainer()) {
			return;
		}

		pollTimer = window.setInterval(function () {
			refreshThread();
			refreshMemberPresence();
		}, 15000);
	}

	function refreshMemberPresence() {
		var statusEl = document.getElementById('oilmazing-sfc-support-member-status');
		if (!statusEl) {
			return;
		}

		var memberId = statusEl.getAttribute('data-member-id');
		if (!memberId) {
			return;
		}

		postForm('oilmazing_sfc_support_member_presence', {
			member_id: memberId
		}).then(function (result) {
			if (!result || !result.success || !result.data) {
				return;
			}

			statusEl.classList.toggle('is-online', !!result.data.online);
			statusEl.classList.toggle('is-offline', !result.data.online);

			var labelEl = statusEl.querySelector('.oilmazing-sfc-support-admin__presence-label');
			if (labelEl) {
				labelEl.textContent = result.data.status_label || ((config.i18n && config.i18n.offline) || 'Offline');
			}
		}).catch(function () {});
	}

	document.addEventListener('DOMContentLoaded', function () {
		bindMemberSearch();
		bindReplyForm();
		scrollMessagesToBottom();
		refreshMemberPresence();
		startPolling();
	});
})();
