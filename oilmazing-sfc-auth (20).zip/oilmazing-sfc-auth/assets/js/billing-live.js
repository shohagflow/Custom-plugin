(function () {
    'use strict';

    var lastSubscription = null;

    function getBillingConfig() {
        return window.oilmazingSfcBilling || {};
    }

    function getFallbackManageUrl() {
        const cfg = getBillingConfig();
        return cfg.paymentUrl || cfg.myAccountUrl || cfg.dashboardUrl || '';
    }

    function isBrokenManageUrl(url) {
        if (!url || typeof url !== 'string') {
            return true;
        }

        try {
            const parsed = new URL(url, window.location.origin);
            const path = (parsed.pathname || '').replace(/\/+$/, '') || '/';
            return path === '/subscriptions';
        } catch (e) {
            return /^\/?subscriptions\/?$/i.test(url.trim());
        }
    }

    function resolveManageUrl(subscription) {
        const candidate = subscription && subscription.manage_url ? String(subscription.manage_url) : '';
        if (candidate && !isBrokenManageUrl(candidate)) {
            return candidate;
        }

        const paymentUrl = subscription && subscription.payment_url ? String(subscription.payment_url) : '';
        if (paymentUrl && !isBrokenManageUrl(paymentUrl)) {
            return paymentUrl;
        }

        return getFallbackManageUrl();
    }

    function openManagePlanPanel(subscription) {
        const panel = document.getElementById('manage-plan-panel');
        if (!panel) {
            const url = resolveManageUrl(subscription);
            if (url) {
                window.location.href = url;
            }
            return;
        }

        const cfg = getBillingConfig();
        const paymentUrl = (subscription && subscription.payment_url) || cfg.paymentUrl || resolveManageUrl(subscription);
        const changePlanUrl = (subscription && subscription.change_plan_url) || cfg.changePlanUrl || cfg.subscribeUrl || '';
        const accountUrl = (subscription && subscription.my_account_url) || cfg.myAccountUrl || '';

        const paymentBtn = document.getElementById('manage-plan-payment');
        const changeBtn = document.getElementById('manage-plan-change');
        const shippingBtn = document.getElementById('manage-plan-shipping');
        const accountBtn = document.getElementById('manage-plan-account');

        if (paymentBtn) {
            paymentBtn.href = paymentUrl || '#';
            paymentBtn.classList.toggle('opacity-50', !paymentUrl);
            paymentBtn.onclick = function (e) {
                if (!paymentUrl) {
                    e.preventDefault();
                }
            };
        }

        if (changeBtn) {
            changeBtn.href = changePlanUrl || '#';
            changeBtn.classList.toggle('opacity-50', !changePlanUrl);
            changeBtn.onclick = function (e) {
                if (!changePlanUrl) {
                    e.preventDefault();
                }
            };
        }

        if (accountBtn) {
            accountBtn.href = accountUrl || '#';
            accountBtn.classList.toggle('opacity-50', !accountUrl);
            accountBtn.onclick = function (e) {
                if (!accountUrl) {
                    e.preventDefault();
                }
            };
        }

        if (shippingBtn) {
            shippingBtn.onclick = function (e) {
                e.preventDefault();
                panel.classList.add('hidden');
                if (typeof switchView === 'function') {
                    switchView('profile');
                }
            };
        }

        panel.classList.remove('hidden');
    }

    function applySubscriptionToUI(subscription) {
        if (!subscription) {
            return;
        }

        lastSubscription = subscription;

        const isActive = subscription.status === 'active'
            || subscription.status === 'club'
            || subscription.status === 'trialing';

        const statusEl = document.getElementById('subscription-status-badge');
        if (statusEl) {
            statusEl.textContent = subscription.status_label || (isActive ? 'Active' : 'Inactive');
            statusEl.className = 'px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider '
                + (isActive ? 'bg-emerald-600 text-white' : 'bg-zinc-200 text-zinc-700');
        }

        const planEl = document.getElementById('subscription-plan-name');
        if (planEl && subscription.plan) {
            planEl.textContent = subscription.plan;
        }

        const descEl = document.getElementById('subscription-plan-desc');
        if (descEl) {
            descEl.textContent = subscription.description || '';
            descEl.classList.toggle('hidden', !subscription.description);
        }

        const priceEl = document.getElementById('subscription-plan-price');
        if (priceEl && subscription.price_html) {
            const suffix = subscription.interval_suffix || '/mo';
            priceEl.innerHTML = `${subscription.price_html}<span class="text-xs text-zinc-400 font-normal">${suffix}</span>`;
        }

        const billingEl = document.getElementById('subscription-next-billing');
        if (billingEl) {
            billingEl.textContent = subscription.billing
                ? `Next billing date: ${subscription.billing}`
                : (isActive ? 'Billing date unavailable' : '');
        }

        const freqEl = document.getElementById('subscription-frequency');
        if (freqEl && subscription.frequency) {
            freqEl.textContent = subscription.frequency;
        }

        const manageBtn = document.getElementById('subscription-manage-btn');
        if (manageBtn) {
            manageBtn.onclick = function (e) {
                e.preventDefault();
                openManagePlanPanel(subscription || lastSubscription);
            };
        }
    }

    function bindManagePlanPanelChrome() {
        const panel = document.getElementById('manage-plan-panel');
        if (!panel || panel.__oilmazingBound) {
            return;
        }
        panel.__oilmazingBound = true;

        panel.querySelectorAll('[data-manage-plan-close]').forEach(function (el) {
            el.addEventListener('click', function () {
                panel.classList.add('hidden');
            });
        });
    }

    function wrapApplyUserToUI() {
        const original = window.applyUserToUI;
        if (typeof original !== 'function' || original.__oilmazingBillingPatched) {
            return;
        }

        window.applyUserToUI = function patchedApplyUserToUI(user, subscription) {
            original(user, subscription);
            applySubscriptionToUI(subscription);
        };
        window.applyUserToUI.__oilmazingBillingPatched = true;
    }

    wrapApplyUserToUI();
    document.addEventListener('DOMContentLoaded', function () {
        wrapApplyUserToUI();
        bindManagePlanPanelChrome();

        const manageBtn = document.getElementById('subscription-manage-btn');
        if (manageBtn && !manageBtn.__oilmazingManageBound) {
            manageBtn.__oilmazingManageBound = true;
            manageBtn.addEventListener('click', function (e) {
                e.preventDefault();
                openManagePlanPanel(lastSubscription);
            });
        }
    });
})();
