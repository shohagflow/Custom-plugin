(function () {
	'use strict';

	var config = window.oilmazingSfcQrAdmin || {};

	function postAjax(action, data) {
		var body = new URLSearchParams();
		body.append('action', action);
		body.append('nonce', config.nonce || '');

		Object.keys(data || {}).forEach(function (key) {
			body.append(key, data[key]);
		});

		return fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
			},
			body: body.toString()
		}).then(function (response) {
			return response.json();
		});
	}

	function showNotice(type, message) {
		var notice = document.querySelector('[data-qr-admin-notice]');
		if (!notice) {
			return;
		}
		notice.hidden = false;
		notice.className = 'oilmazing-sfc-qr-admin__notice is-' + type;
		notice.textContent = message;
	}

	function updateRow(row, qr) {
		if (!row || !qr) {
			return;
		}

		var preview = row.querySelector('[data-qr-preview]');
		var status = row.querySelector('[data-qr-status]');
		var actions = row.querySelector('.oilmazing-sfc-qr-admin__actions');
		var affiliateId = String(qr.affiliate_id || row.getAttribute('data-affiliate-row'));

		if (preview && qr.qr_url) {
			preview.innerHTML = '<img src="' + qr.qr_url + '" alt="QR preview" width="72" height="72" />';
		}

		if (status) {
			status.className = 'oilmazing-sfc-qr-admin__status is-' + (qr.status || 'inactive');
			status.textContent = qr.status === 'active' ? 'Active' : 'Inactive';
		}

		if (actions) {
			var downloadUrl = (config.ajaxUrl || '') + '?action=oilmazing_sfc_qr_download&affiliate_id=' + encodeURIComponent(affiliateId) + '&nonce=' + encodeURIComponent(config.nonce || '');
			var toggleStatus = qr.status === 'active' ? 'inactive' : 'active';
			var toggleLabel = qr.status === 'active'
				? ((config.i18n && config.i18n.deactivate) || 'Deactivate')
				: ((config.i18n && config.i18n.activate) || 'Activate');
			var toggleClass = qr.status === 'active'
				? 'button oilmazing-sfc-qr-admin__btn oilmazing-sfc-qr-admin__btn--danger'
				: 'button oilmazing-sfc-qr-admin__btn oilmazing-sfc-qr-admin__btn--primary';

			actions.innerHTML =
				'<button type="button" class="button oilmazing-sfc-qr-admin__btn oilmazing-sfc-qr-admin__btn--secondary" data-qr-generate data-affiliate-id="' + affiliateId + '">' + ((config.i18n && config.i18n.generate) || 'Generate QR') + '</button>' +
				'<a class="button oilmazing-sfc-qr-admin__btn oilmazing-sfc-qr-admin__btn--secondary" data-qr-download href="' + downloadUrl + '">' + ((config.i18n && config.i18n.download) || 'Download') + '</a>' +
				'<button type="button" class="' + toggleClass + '" data-qr-toggle data-status="' + toggleStatus + '" data-affiliate-id="' + affiliateId + '">' + toggleLabel + '</button>';
		}
	}

	function bindFormSettingsMedia() {
		if (!window.wp || !wp.media) {
			return;
		}

		document.querySelectorAll('[data-qr-media-field]').forEach(function (field) {
			var input = field.querySelector('[data-qr-media-id]');
			var previewButton = field.querySelector('.oilmazing-sfc-qr-admin__media-preview');
			var removeButton = field.querySelector('[data-qr-media-remove]');
			var openButtons = field.querySelectorAll('[data-qr-media-open]');
			var mediaTitle = field.getAttribute('data-media-title') || ((config.i18n && config.i18n.selectImage) || 'Select Image');
			var frame = null;

			function renderPreview(url) {
				if (!previewButton) {
					return;
				}

				if (url) {
					previewButton.innerHTML = '<img src="' + url + '" alt="" data-qr-media-image />';
					if (removeButton) {
						removeButton.hidden = false;
					}
					openButtons.forEach(function (button) {
						if (button !== previewButton) {
							button.textContent = (config.i18n && config.i18n.changeImage) || 'Change Image';
						}
					});
					return;
				}

				previewButton.innerHTML = '<span class="oilmazing-sfc-qr-admin__media-placeholder" data-qr-media-placeholder>' + ((config.i18n && config.i18n.noImage) || 'No image selected') + '</span>';
				if (removeButton) {
					removeButton.hidden = true;
				}
				openButtons.forEach(function (button) {
					if (button !== previewButton) {
						button.textContent = (config.i18n && config.i18n.selectImage) || 'Select Image';
					}
				});
			}

			function openMediaFrame() {
				if (!frame) {
					frame = wp.media({
						title: mediaTitle,
						button: {
							text: (config.i18n && config.i18n.useImage) || 'Use this image'
						},
						library: {
							type: 'image'
						},
						multiple: false
					});

					frame.on('select', function () {
						var attachment = frame.state().get('selection').first().toJSON();
						if (!input || !attachment || !attachment.id) {
							return;
						}

						input.value = String(attachment.id);
						renderPreview(attachment.url || (attachment.sizes && attachment.sizes.medium && attachment.sizes.medium.url) || '');
					});
				}

				frame.open();
			}

			openButtons.forEach(function (button) {
				button.addEventListener('click', function (event) {
					event.preventDefault();
					openMediaFrame();
				});
			});

			if (removeButton) {
				removeButton.addEventListener('click', function (event) {
					event.preventDefault();
					if (input) {
						input.value = '0';
					}
					renderPreview('');
				});
			}
		});
	}

	function bindActions() {
		document.addEventListener('click', function (event) {
			var generateBtn = event.target.closest('[data-qr-generate]');
			var toggleBtn = event.target.closest('[data-qr-toggle]');

			if (generateBtn) {
				event.preventDefault();
				var row = generateBtn.closest('[data-affiliate-row]');
				var affiliateId = generateBtn.getAttribute('data-affiliate-id');
				generateBtn.classList.add('is-loading');
				generateBtn.textContent = (config.i18n && config.i18n.generating) || 'Generating…';

				postAjax('oilmazing_sfc_qr_generate', { affiliate_id: affiliateId }).then(function (result) {
					if (!result || !result.success) {
						throw new Error((result && result.data && result.data.message) || 'Failed');
					}
					updateRow(row, result.data.qr);
					showNotice('success', result.data.message || ((config.i18n && config.i18n.success) || 'Updated'));
				}).catch(function (error) {
					showNotice('error', error.message || ((config.i18n && config.i18n.error) || 'Error'));
				}).finally(function () {
					generateBtn.classList.remove('is-loading');
					generateBtn.textContent = (config.i18n && config.i18n.generate) || 'Generate QR';
				});
				return;
			}

			if (toggleBtn) {
				event.preventDefault();
				var toggleRow = toggleBtn.closest('[data-affiliate-row]');
				var toggleAffiliateId = toggleBtn.getAttribute('data-affiliate-id');
				var status = toggleBtn.getAttribute('data-status');
				toggleBtn.classList.add('is-loading');

				postAjax('oilmazing_sfc_qr_toggle_status', {
					affiliate_id: toggleAffiliateId,
					status: status
				}).then(function (result) {
					if (!result || !result.success) {
						throw new Error((result && result.data && result.data.message) || 'Failed');
					}
					updateRow(toggleRow, result.data.qr);
					showNotice('success', result.data.message || ((config.i18n && config.i18n.success) || 'Updated'));
				}).catch(function (error) {
					showNotice('error', error.message || ((config.i18n && config.i18n.error) || 'Error'));
				}).finally(function () {
					toggleBtn.classList.remove('is-loading');
				});
			}
		});
	}

	document.addEventListener('DOMContentLoaded', function () {
		bindActions();
		bindFormSettingsMedia();
	});
})();
