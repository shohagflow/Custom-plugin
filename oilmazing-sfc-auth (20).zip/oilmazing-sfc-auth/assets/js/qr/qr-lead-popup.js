(function () {
	'use strict';

	var config = window.oilmazingSfcQrLead || {};
	var bound = false;
	var defaultButtonText = '';

	function isValidEmail(value) {
		return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
	}

	function showPopup() {
		var popup = document.querySelector('[data-qr-lead-popup]');
		if (!popup) {
			return;
		}

		popup.hidden = false;
		document.documentElement.classList.add('lead-popup-open');

		var input = popup.querySelector('#oilmazing-sfc-qr-lead-first-name');
		if (input && document.activeElement !== input) {
			window.requestAnimationFrame(function () {
				input.focus({ preventScroll: true });
			});
		}
	}

	function hidePopup() {
		var popup = document.querySelector('[data-qr-lead-popup]');
		if (!popup) {
			return;
		}

		popup.hidden = true;
		document.documentElement.classList.remove('lead-popup-open');
	}

	function setError(errorEl, input, message) {
		if (input) {
			input.classList.add('is-invalid');
		}
		if (errorEl) {
			errorEl.hidden = false;
			errorEl.textContent = message;
		}
	}

	function clearError(errorEl, inputs) {
		inputs.forEach(function (input) {
			if (input) {
				input.classList.remove('is-invalid');
			}
		});
		if (errorEl) {
			errorEl.hidden = true;
		}
	}

	function bindPopup() {
		if (bound) {
			return;
		}

		var popup = document.querySelector('[data-qr-lead-popup]');
		if (!popup) {
			return;
		}

		bound = true;
		showPopup();

		popup.querySelectorAll('[data-qr-lead-close]').forEach(function (button) {
			button.addEventListener('click', hidePopup);
		});

		var form = popup.querySelector('[data-qr-lead-form]');
		var firstName = popup.querySelector('#oilmazing-sfc-qr-lead-first-name');
		var email = popup.querySelector('#oilmazing-sfc-qr-lead-email');
		var phone = popup.querySelector('#oilmazing-sfc-qr-lead-phone');
		var submit = popup.querySelector('[data-qr-lead-submit]');
		var error = popup.querySelector('[data-qr-lead-error]');
		var success = popup.querySelector('[data-qr-lead-success]');

		if (!form || !firstName || !email || !phone || !submit) {
			return;
		}

		defaultButtonText = submit.textContent.trim();

		form.addEventListener('submit', function (event) {
			event.preventDefault();
			event.stopImmediatePropagation();
			clearError(error, [firstName, email, phone]);

			var firstNameValue = firstName.value.trim();
			var emailValue = email.value.trim();
			var phoneValue = phone.value.trim();

			if (!firstNameValue) {
				setError(error, firstName, (config.i18n && config.i18n.firstNameRequired) || 'Please enter your first name.');
				firstName.focus();
				return;
			}

			if (!emailValue) {
				setError(error, email, (config.i18n && config.i18n.emailRequired) || 'Please enter your email address.');
				email.focus();
				return;
			}

			if (!isValidEmail(emailValue)) {
				setError(error, email, (config.i18n && config.i18n.emailInvalid) || 'Please enter a valid email address.');
				email.focus();
				return;
			}

			if (!phoneValue) {
				setError(error, phone, (config.i18n && config.i18n.phoneRequired) || 'Please enter your phone number.');
				phone.focus();
				return;
			}

			submit.classList.add('is-loading');
			submit.textContent = (config.i18n && config.i18n.submitting) || 'Submitting…';

			var body = new URLSearchParams();
			body.append('action', 'oilmazing_sfc_qr_submit_lead');
			body.append('nonce', config.nonce || '');
			body.append('affiliate_id', String(config.affiliate || 0));
			body.append('first_name', firstNameValue);
			body.append('email', emailValue);
			body.append('phone', phoneValue);

			fetch(config.ajaxUrl || '/wp-admin/admin-ajax.php', {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
				},
				body: body.toString()
			}).then(function (response) {
				return response.json();
			}).then(function (result) {
				if (!result || !result.success) {
					throw new Error((result && result.data && result.data.message) || ((config.i18n && config.i18n.error) || 'Error'));
				}

				if (success) {
					success.hidden = false;
					success.textContent = result.data.message || ((config.i18n && config.i18n.success) || 'Thanks!');
				}

				window.setTimeout(function () {
					window.location.href = result.data.shop_url || config.shopUrl || '/shop/';
				}, 1200);
			}).catch(function (submitError) {
				if (error) {
					error.hidden = false;
					error.textContent = submitError.message || ((config.i18n && config.i18n.error) || 'Error');
				}
			}).finally(function () {
				submit.classList.remove('is-loading');
				submit.textContent = defaultButtonText || ((config.i18n && config.i18n.submit) || 'CLAIM MY VIBRATION');
			});
		}, true);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', bindPopup);
	} else {
		bindPopup();
	}
})();
