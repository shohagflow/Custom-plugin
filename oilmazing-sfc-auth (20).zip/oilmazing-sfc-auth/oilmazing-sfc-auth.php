<?php
/**
 * Plugin Name:       Oilmazing SFC Auth
 * Description:       Custom login and registration for the Scent Freedom Club dashboard.
 * Version:           1.9.42
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            oilmazing
 * Text Domain:       oilmazing-sfc
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

define( 'OILMAZING_SFC_AUTH_VERSION', '1.9.42' );
define( 'OILMAZING_SFC_AUTH_FILE', __FILE__ );
define( 'OILMAZING_SFC_AUTH_PATH', plugin_dir_path( __FILE__ ) );
define( 'OILMAZING_SFC_AUTH_URL', plugin_dir_url( __FILE__ ) );

require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-admin-notices.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-auth.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-membership.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-membership-admin.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-affiliate-integration.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-support.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-support-admin.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-elementor-compat.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-assets-guard.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-compat-patches.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-presence.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-customer-mail-admin.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-quantity-discount.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-quantity-discount-admin.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-webp-converter.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-webp-admin.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-cart-summary-ui.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-menu-cart-qty.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-my-account.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-woo-loop-product-fix.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/qr/class-oilmazing-sfc-qr-module.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/class-oilmazing-sfc-auth-bootstrap.php';

add_action(
	'plugins_loaded',
	static function () {
		if ( ! defined( 'OILMAZING_SFC_PLUGIN_DIR' ) ) {
			add_action(
				'admin_notices',
				static function () {
					printf(
						'<div class="notice notice-error"><p>%s</p></div>',
						esc_html__( 'Oilmazing SFC Auth requires the Oilmazing Scent Freedom Club plugin.', 'oilmazing-sfc' )
					);
				}
			);
			return;
		}

		Oilmazing_SFC_Auth_Bootstrap::init();
	},
	25
);

/**
 * Default role for new club members.
 *
 * @return string
 */
function oilmazing_sfc_get_member_role() {
	return class_exists( 'WooCommerce' ) ? 'customer' : 'subscriber';
}
