<?php
/**
 * Convert uploaded and existing images to WebP.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_WebP_Converter
 */
class Oilmazing_SFC_WebP_Converter {

	const OPTION_ENABLED         = 'oilmazing_sfc_webp_convert_enabled';

	const OPTION_QUALITY         = 'oilmazing_sfc_webp_quality';

	const OPTION_DELETE_ORIGINAL = 'oilmazing_sfc_webp_delete_original';

	const SUPPORTED_MIME_TYPES = array(
		'image/jpeg',
		'image/png',
		'image/gif',
	);

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_filter( 'wp_handle_upload', array( __CLASS__, 'handle_upload_convert' ) );
	}

	/**
	 * @return bool
	 */
	public static function is_enabled() {
		return 'yes' === get_option( self::OPTION_ENABLED, 'yes' );
	}

	/**
	 * @return int
	 */
	public static function get_quality() {
		$quality = (int) get_option( self::OPTION_QUALITY, 82 );

		return max( 1, min( 100, $quality ) );
	}

	/**
	 * @return bool
	 */
	public static function should_delete_original() {
		return 'yes' === get_option( self::OPTION_DELETE_ORIGINAL, 'yes' );
	}

	/**
	 * @param string $value Raw value.
	 * @return string
	 */
	public static function sanitize_yes_no( $value ) {
		return 'yes' === $value ? 'yes' : 'no';
	}

	/**
	 * @param mixed $value Raw value.
	 * @return int
	 */
	public static function sanitize_quality( $value ) {
		return max( 1, min( 100, (int) $value ) );
	}

	/**
	 * @return bool
	 */
	public static function is_conversion_supported() {
		return self::is_wp_editor_webp_supported() || self::is_cli_conversion_available();
	}

	/**
	 * @return bool
	 */
	public static function is_wp_editor_webp_supported() {
		if ( ! extension_loaded( 'imagick' ) && ! extension_loaded( 'gd' ) ) {
			return false;
		}

		if ( function_exists( 'wp_image_editor_supports' ) ) {
			return (bool) wp_image_editor_supports(
				array(
					'mime_type' => 'image/webp',
				)
			);
		}

		if ( extension_loaded( 'gd' ) && function_exists( 'gd_info' ) ) {
			$gd_info = gd_info();

			return ! empty( $gd_info['WebP Support'] );
		}

		return extension_loaded( 'imagick' );
	}

	/**
	 * @return bool
	 */
	public static function is_cli_conversion_available() {
		return '' !== self::get_cli_converter_path();
	}

	/**
	 * @return string imagick|gd|cwebp|none
	 */
	public static function get_converter_engine() {
		if ( self::is_wp_editor_webp_supported() ) {
			if ( extension_loaded( 'imagick' ) ) {
				require_once ABSPATH . WPINC . '/class-wp-image-editor-imagick.php';
				if ( class_exists( 'WP_Image_Editor_Imagick' ) && WP_Image_Editor_Imagick::test( array( 'mime_type' => 'image/webp' ) ) ) {
					return 'imagick';
				}
			}

			return 'gd';
		}

		if ( self::is_cli_conversion_available() ) {
			return 'cwebp';
		}

		return 'none';
	}

	/**
	 * @return array{engine:string,label:string,detail:string}
	 */
	public static function get_support_diagnostics() {
		$engine = self::get_converter_engine();

		if ( 'imagick' === $engine ) {
			return array(
				'engine' => $engine,
				'label'  => __( 'Imagick', 'oilmazing-sfc' ),
				'detail' => __( 'WordPress image editor will create WebP files directly.', 'oilmazing-sfc' ),
			);
		}

		if ( 'gd' === $engine ) {
			return array(
				'engine' => $engine,
				'label'  => __( 'GD', 'oilmazing-sfc' ),
				'detail' => __( 'WordPress image editor will create WebP files directly.', 'oilmazing-sfc' ),
			);
		}

		if ( 'cwebp' === $engine ) {
			return array(
				'engine' => $engine,
				'label'  => __( 'cwebp CLI', 'oilmazing-sfc' ),
				'detail' => sprintf(
					/* translators: %s: cwebp binary path */
					__( 'Using command-line converter: %s', 'oilmazing-sfc' ),
					self::get_cli_converter_path()
				),
			);
		}

		return array(
			'engine' => 'none',
			'label'  => __( 'Unavailable', 'oilmazing-sfc' ),
			'detail' => __( 'Enable Imagick or GD with WebP support, or install the cwebp command-line tool.', 'oilmazing-sfc' ),
		);
	}

	/**
	 * Convert uploads to WebP when enabled.
	 *
	 * @param array<string, string> $upload Upload data.
	 * @return array<string, string>
	 */
	public static function handle_upload_convert( $upload ) {
		if ( ! self::is_enabled() || ! self::is_conversion_supported() || ! is_array( $upload ) ) {
			return $upload;
		}

		$mime_type = isset( $upload['type'] ) ? (string) $upload['type'] : '';
		if ( ! in_array( $mime_type, self::SUPPORTED_MIME_TYPES, true ) ) {
			return $upload;
		}

		$file_path = isset( $upload['file'] ) ? (string) $upload['file'] : '';
		if ( '' === $file_path || ! file_exists( $file_path ) ) {
			return $upload;
		}

		$converted = self::convert_path_to_webp( $file_path, self::get_quality() );
		if ( is_wp_error( $converted ) ) {
			return $upload;
		}

		$new_path = isset( $converted['path'] ) ? (string) $converted['path'] : '';
		if ( '' === $new_path || ! file_exists( $new_path ) ) {
			return $upload;
		}

		$upload['file'] = $new_path;
		$upload['type'] = 'image/webp';

		if ( ! empty( $upload['url'] ) ) {
			$upload['url'] = str_replace( wp_basename( (string) $upload['url'] ), wp_basename( $new_path ), (string) $upload['url'] );
		}

		if ( self::should_delete_original() && $file_path !== $new_path ) {
			self::delete_file( $file_path );
		}

		return $upload;
	}

	/**
	 * @param string $file_path Absolute file path.
	 * @param int    $quality   WebP quality.
	 * @return array<string, mixed>|WP_Error
	 */
	public static function convert_path_to_webp( $file_path, $quality = 82 ) {
		$file_path = (string) $file_path;
		if ( '' === $file_path || ! file_exists( $file_path ) ) {
			return new WP_Error( 'oilmazing_sfc_webp_missing_file', __( 'Image file was not found.', 'oilmazing-sfc' ) );
		}

		if ( ! self::is_conversion_supported() ) {
			return new WP_Error( 'oilmazing_sfc_webp_unsupported', __( 'This server cannot create WebP images.', 'oilmazing-sfc' ) );
		}

		$checked = wp_check_filetype( $file_path );
		$mime    = isset( $checked['type'] ) ? (string) $checked['type'] : '';
		if ( ! in_array( $mime, self::SUPPORTED_MIME_TYPES, true ) ) {
			return new WP_Error( 'oilmazing_sfc_webp_invalid_type', __( 'Only JPG, PNG, and GIF images can be converted.', 'oilmazing-sfc' ) );
		}

		if ( self::is_wp_editor_webp_supported() ) {
			return self::convert_path_to_webp_with_editor( $file_path, $quality );
		}

		if ( self::is_cli_conversion_available() ) {
			return self::convert_path_to_webp_cli( $file_path, $quality );
		}

		return new WP_Error( 'oilmazing_sfc_webp_unsupported', __( 'This server cannot create WebP images.', 'oilmazing-sfc' ) );
	}

	/**
	 * @param string $file_path Absolute file path.
	 * @param int    $quality   WebP quality.
	 * @return array<string, mixed>|WP_Error
	 */
	private static function convert_path_to_webp_with_editor( $file_path, $quality ) {
		$image_editor = wp_get_image_editor( $file_path );
		if ( is_wp_error( $image_editor ) ) {
			return $image_editor;
		}

		if ( method_exists( $image_editor, 'set_quality' ) ) {
			$image_editor->set_quality( max( 1, min( 100, (int) $quality ) ) );
		}

		$file_info = pathinfo( $file_path );
		$dirname   = isset( $file_info['dirname'] ) ? (string) $file_info['dirname'] : '';
		$filename  = isset( $file_info['filename'] ) ? (string) $file_info['filename'] : '';
		if ( '' === $dirname || '' === $filename ) {
			return new WP_Error( 'oilmazing_sfc_webp_invalid_path', __( 'Could not determine the image path.', 'oilmazing-sfc' ) );
		}

		$new_filename = wp_unique_filename( $dirname, $filename . '.webp' );
		$new_path     = trailingslashit( $dirname ) . $new_filename;
		$saved        = $image_editor->save( $new_path, 'image/webp' );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		if ( empty( $saved['path'] ) || ! file_exists( $saved['path'] ) ) {
			return new WP_Error( 'oilmazing_sfc_webp_save_failed', __( 'WebP conversion failed.', 'oilmazing-sfc' ) );
		}

		return $saved;
	}

	/**
	 * @param string $file_path Absolute file path.
	 * @param int    $quality   WebP quality.
	 * @return array<string, mixed>|WP_Error
	 */
	private static function convert_path_to_webp_cli( $file_path, $quality, $width = 0, $height = 0 ) {
		$binary = self::get_cli_converter_path();
		if ( '' === $binary ) {
			return new WP_Error( 'oilmazing_sfc_webp_cli_missing', __( 'The cwebp command-line tool was not found.', 'oilmazing-sfc' ) );
		}

		$file_info = pathinfo( $file_path );
		$dirname   = isset( $file_info['dirname'] ) ? (string) $file_info['dirname'] : '';
		$filename  = isset( $file_info['filename'] ) ? (string) $file_info['filename'] : '';
		if ( '' === $dirname || '' === $filename ) {
			return new WP_Error( 'oilmazing_sfc_webp_invalid_path', __( 'Could not determine the image path.', 'oilmazing-sfc' ) );
		}

		$new_filename = wp_unique_filename( $dirname, $filename . '.webp' );
		$new_path     = trailingslashit( $dirname ) . $new_filename;
		$resize_args  = '';

		if ( $width > 0 || $height > 0 ) {
			$resize_args = sprintf(
				' -resize %d %d',
				max( 0, (int) $width ),
				max( 0, (int) $height )
			);
		}

		$command = sprintf(
			'%s -quiet%s -q %d %s -o %s 2>&1',
			escapeshellarg( $binary ),
			$resize_args,
			max( 1, min( 100, (int) $quality ) ),
			escapeshellarg( $file_path ),
			escapeshellarg( $new_path )
		);

		$output = array();
		$code   = 1;
		exec( $command, $output, $code );

		if ( 0 !== $code || ! file_exists( $new_path ) ) {
			return new WP_Error(
				'oilmazing_sfc_webp_cli_failed',
				__( 'WebP conversion failed using the cwebp command-line tool.', 'oilmazing-sfc' ),
				array(
					'command' => $command,
					'output'  => $output,
				)
			);
		}

		$image_size = @getimagesize( $new_path );

		return array(
			'path'      => $new_path,
			'file'      => wp_basename( $new_path ),
			'width'     => isset( $image_size[0] ) ? (int) $image_size[0] : 0,
			'height'    => isset( $image_size[1] ) ? (int) $image_size[1] : 0,
			'mime-type' => 'image/webp',
			'filesize'  => (int) filesize( $new_path ),
		);
	}

	/**
	 * Convert a media library attachment to WebP.
	 *
	 * @param int  $attachment_id   Attachment ID.
	 * @param bool $delete_original Delete the original file and generated sizes.
	 * @return array<string, mixed>|WP_Error
	 */
	public static function convert_attachment( $attachment_id, $delete_original = true ) {
		$attachment_id = absint( $attachment_id );
		if ( $attachment_id <= 0 || 'attachment' !== get_post_type( $attachment_id ) ) {
			return new WP_Error( 'oilmazing_sfc_webp_invalid_attachment', __( 'Invalid attachment.', 'oilmazing-sfc' ) );
		}

		$mime_type = (string) get_post_mime_type( $attachment_id );
		if ( 'image/webp' === $mime_type ) {
			return new WP_Error( 'oilmazing_sfc_webp_already_converted', __( 'Attachment is already WebP.', 'oilmazing-sfc' ) );
		}

		if ( ! in_array( $mime_type, self::SUPPORTED_MIME_TYPES, true ) ) {
			return new WP_Error( 'oilmazing_sfc_webp_unsupported_type', __( 'Attachment type is not supported for WebP conversion.', 'oilmazing-sfc' ) );
		}

		$file_path = get_attached_file( $attachment_id );
		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return new WP_Error( 'oilmazing_sfc_webp_missing_file', __( 'Attachment file was not found.', 'oilmazing-sfc' ) );
		}

		$old_meta    = wp_get_attachment_metadata( $attachment_id );
		$old_bytes   = (int) filesize( $file_path );
		$source_path = $file_path;
		$converted   = self::convert_path_to_webp( $file_path, self::get_quality() );
		if ( is_wp_error( $converted ) ) {
			return $converted;
		}

		$new_path = (string) $converted['path'];
		$new_rel  = _wp_relative_upload_path( $new_path );
		if ( ! $new_rel ) {
			return new WP_Error( 'oilmazing_sfc_webp_relative_path', __( 'Could not resolve the converted file path.', 'oilmazing-sfc' ) );
		}

		update_attached_file( $attachment_id, $new_rel );

		$upload_dir = wp_upload_dir();
		$new_url    = trailingslashit( $upload_dir['baseurl'] ) . ltrim( $new_rel, '/' );

		wp_update_post(
			array(
				'ID'             => $attachment_id,
				'post_mime_type' => 'image/webp',
				'guid'           => $new_url,
			)
		);

		require_once ABSPATH . 'wp-admin/includes/image.php';

		if ( self::uses_cli_converter_engine() ) {
			$new_meta = self::build_attachment_metadata_cli( $source_path, $new_path );
		} else {
			$new_meta = wp_generate_attachment_metadata( $attachment_id, $new_path );
		}

		if ( is_array( $new_meta ) && ! empty( $new_meta ) ) {
			wp_update_attachment_metadata( $attachment_id, $new_meta );
		}

		if ( $delete_original ) {
			self::delete_attachment_files( $source_path, is_array( $old_meta ) ? $old_meta : array() );
		}

		$new_bytes = file_exists( $new_path ) ? (int) filesize( $new_path ) : 0;

		return array(
			'attachment_id' => $attachment_id,
			'file_name'     => wp_basename( $new_path ),
			'old_bytes'     => $old_bytes,
			'new_bytes'     => $new_bytes,
			'saved_bytes'   => max( 0, $old_bytes - $new_bytes ),
		);
	}

	/**
	 * @return int
	 */
	public static function count_convertible_attachments() {
		$query = new WP_Query(
			array(
				'post_type'              => 'attachment',
				'post_status'            => 'inherit',
				'post_mime_type'         => self::SUPPORTED_MIME_TYPES,
				'posts_per_page'         => 1,
				'fields'                 => 'ids',
				'no_found_rows'          => false,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		return (int) $query->found_posts;
	}

	/**
	 * @param int $limit  Batch size.
	 * @param int $offset Offset.
	 * @return array<int>
	 */
	public static function get_convertible_attachment_ids( $limit = 10, $offset = 0 ) {
		$query = new WP_Query(
			array(
				'post_type'              => 'attachment',
				'post_status'            => 'inherit',
				'post_mime_type'         => self::SUPPORTED_MIME_TYPES,
				'posts_per_page'         => max( 1, (int) $limit ),
				'offset'                 => max( 0, (int) $offset ),
				'orderby'                => 'ID',
				'order'                  => 'ASC',
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		return array_map( 'absint', $query->posts );
	}

	/**
	 * @return bool
	 */
	private static function uses_cli_converter_engine() {
		return self::is_cli_conversion_available() && ! self::is_wp_editor_webp_supported();
	}

	/**
	 * @param string $source_path   Original image path.
	 * @param string $webp_main_path Converted WebP path.
	 * @return array<string, mixed>
	 */
	private static function build_attachment_metadata_cli( $source_path, $webp_main_path ) {
		$image_size = @getimagesize( $webp_main_path );
		if ( ! $image_size ) {
			return array();
		}

		$relative_file = _wp_relative_upload_path( $webp_main_path );
		$metadata      = array(
			'width'  => (int) $image_size[0],
			'height' => (int) $image_size[1],
			'file'   => $relative_file ? $relative_file : wp_basename( $webp_main_path ),
			'sizes'  => self::generate_webp_subsizes_cli( $source_path, $webp_main_path, (int) $image_size[0], (int) $image_size[1] ),
		);

		return $metadata;
	}

	/**
	 * @param string $source_path    Original image path.
	 * @param string $webp_main_path Converted WebP path.
	 * @param int    $full_width     Full image width.
	 * @param int    $full_height    Full image height.
	 * @return array<string, array<string, int|string>>
	 */
	private static function generate_webp_subsizes_cli( $source_path, $webp_main_path, $full_width, $full_height ) {
		$sizes    = array();
		$subsizes = wp_get_registered_image_subsizes();
		$info     = pathinfo( $webp_main_path );
		$dir      = isset( $info['dirname'] ) ? (string) $info['dirname'] : '';
		$basename = isset( $info['filename'] ) ? (string) $info['filename'] : '';

		if ( '' === $dir || '' === $basename || empty( $subsizes ) ) {
			return $sizes;
		}

		foreach ( $subsizes as $size_name => $size_data ) {
			if ( empty( $size_data['width'] ) && empty( $size_data['height'] ) ) {
				continue;
			}

			$crop = ! empty( $size_data['crop'] );
			$dims = image_resize_dimensions(
				$full_width,
				$full_height,
				(int) $size_data['width'],
				(int) $size_data['height'],
				$crop
			);

			if ( ! $dims ) {
				continue;
			}

			$dest_w = (int) $dims[4];
			$dest_h = (int) $dims[5];
			if ( $dest_w < 1 || $dest_h < 1 ) {
				continue;
			}

			$filename  = $basename . '-' . $dest_w . 'x' . $dest_h . '.webp';
			$dest_path = trailingslashit( $dir ) . wp_unique_filename( $dir, $filename );
			$converted = self::convert_path_to_webp_cli( $source_path, self::get_quality(), $dest_w, $dest_h );
			if ( is_wp_error( $converted ) ) {
				continue;
			}

			$dest_path = (string) $converted['path'];
			$sizes[ $size_name ] = array(
				'file'      => wp_basename( $dest_path ),
				'width'     => isset( $converted['width'] ) && (int) $converted['width'] > 0 ? (int) $converted['width'] : $dest_w,
				'height'    => isset( $converted['height'] ) && (int) $converted['height'] > 0 ? (int) $converted['height'] : $dest_h,
				'mime-type' => 'image/webp',
			);
		}

		return $sizes;
	}

	/**
	 * @return string
	 */
	private static function get_cli_converter_path() {
		static $resolved = null;

		if ( null !== $resolved ) {
			return $resolved;
		}

		if ( ! self::can_run_shell_commands() ) {
			$resolved = '';

			return $resolved;
		}

		$candidates = array();
		if ( defined( 'OILMAZING_SFC_WEBP_CWEBP_PATH' ) ) {
			$candidates[] = (string) OILMAZING_SFC_WEBP_CWEBP_PATH;
		}

		$candidates = array_merge(
			$candidates,
			array(
				'cwebp',
				'/opt/homebrew/bin/cwebp',
				'/usr/local/bin/cwebp',
				'/usr/bin/cwebp',
			)
		);

		foreach ( $candidates as $candidate ) {
			if ( self::cli_binary_works( $candidate ) ) {
				$resolved = $candidate;

				return $resolved;
			}
		}

		$resolved = '';

		return $resolved;
	}

	/**
	 * @return bool
	 */
	private static function can_run_shell_commands() {
		if ( ! function_exists( 'exec' ) ) {
			return false;
		}

		$disabled = (string) ini_get( 'disable_functions' );
		if ( '' === $disabled ) {
			return true;
		}

		$disabled = array_map( 'trim', explode( ',', strtolower( $disabled ) ) );

		return ! in_array( 'exec', $disabled, true );
	}

	/**
	 * @param string $binary Binary name or path.
	 * @return bool
	 */
	private static function cli_binary_works( $binary ) {
		$binary = trim( (string) $binary );
		if ( '' === $binary ) {
			return false;
		}

		if ( 'cwebp' !== $binary && ! is_executable( $binary ) ) {
			return false;
		}

		$command = escapeshellarg( $binary ) . ' -version 2>&1';
		$output  = array();
		$code    = 1;
		exec( $command, $output, $code );

		return 0 === $code;
	}

	/**
	 * @param string               $main_file Main file path.
	 * @param array<string, mixed> $metadata  Attachment metadata.
	 */
	private static function delete_attachment_files( $main_file, $metadata ) {
		self::delete_file( $main_file );

		if ( empty( $metadata['sizes'] ) || ! is_array( $metadata['sizes'] ) ) {
			return;
		}

		$base_dir = pathinfo( $main_file, PATHINFO_DIRNAME );
		foreach ( $metadata['sizes'] as $size ) {
			if ( empty( $size['file'] ) ) {
				continue;
			}

			self::delete_file( trailingslashit( $base_dir ) . $size['file'] );
		}
	}

	/**
	 * @param string $file_path File path.
	 */
	private static function delete_file( $file_path ) {
		$file_path = (string) $file_path;
		if ( '' !== $file_path && file_exists( $file_path ) ) {
			wp_delete_file( $file_path );
		}
	}
}
