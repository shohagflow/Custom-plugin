<?php
/**
 * Sanitize and render helpers for membership admin.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Membership_Admin
 */
class Oilmazing_SFC_Membership_Admin {

	const PAGE_SLUG = 'oilmazing-sfc-membership';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 99 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Register submenu under Scent Freedom Club if available.
	 */
	public static function register_menu() {
		$parent = class_exists( 'Oilmazing_SFC_Admin' ) ? Oilmazing_SFC_Admin::PAGE_SLUG : 'options-general.php';
		$title  = __( 'Club Membership', 'oilmazing-sfc' );

		$hook = add_submenu_page(
			$parent,
			$title,
			$title,
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);

		if ( $hook ) {
			add_action( "load-{$hook}", array( __CLASS__, 'enqueue_page_assets' ) );
			add_action( "admin_enqueue_scripts-{$hook}", array( __CLASS__, 'enqueue_page_assets' ) );
			add_action( "admin_print_styles-{$hook}", array( __CLASS__, 'enqueue_page_assets' ) );
		}
	}

	/**
	 * Ensure membership page gets the same admin shell styles as other club screens.
	 */
	public static function enqueue_page_assets() {
		if ( function_exists( 'oilmazing_sfc_enqueue_admin_assets' ) ) {
			$version = defined( 'OILMAZING_SFC_VERSION' ) ? OILMAZING_SFC_VERSION : OILMAZING_SFC_AUTH_VERSION;

			if ( ! wp_style_is( 'oilmazing-sfc-admin', 'enqueued' ) && ! wp_style_is( 'oilmazing-sfc-admin', 'done' ) && function_exists( 'oilmazing_sfc_url' ) ) {
				wp_enqueue_style(
					'oilmazing-sfc-admin',
					oilmazing_sfc_url( 'assets/css/admin.css' ),
					array(),
					$version
				);
			}
		}

		if ( class_exists( 'Oilmazing_SFC_Auth_Bootstrap' ) ) {
			Oilmazing_SFC_Auth_Bootstrap::enqueue_admin_menu_assets( 'oilmazing-sfc-membership' );
		}

		wp_enqueue_style(
			'oilmazing-sfc-membership-admin',
			OILMAZING_SFC_AUTH_URL . 'assets/css/membership-admin.css',
			array( 'oilmazing-sfc-admin', 'oilmazing-sfc-admin-menu' ),
			OILMAZING_SFC_AUTH_VERSION
		);
	}

	/**
	 * Register settings.
	 */
	public static function register_settings() {
		register_setting(
			'oilmazing_sfc_membership_settings',
			Oilmazing_SFC_Membership::OPTION_KEY,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
			)
		);
	}

	/**
	 * Sanitize settings payload.
	 *
	 * @param array<string, mixed> $input Raw settings.
	 * @return array<string, mixed>
	 */
	public static function sanitize_settings( $input ) {
		$input   = is_array( $input ) ? $input : array();
		$current = Oilmazing_SFC_Membership::get_resolved_settings();

		$product_ids = isset( $input['product_ids'] ) ? (string) $input['product_ids'] : '';
		$product_ids = array_filter( array_map( 'absint', preg_split( '/[\s,]+/', $product_ids ) ) );

		return array(
			'require_membership'  => ! empty( $input['require_membership'] ) ? 'yes' : 'no',
			'product_ids'         => array_values( $product_ids ),
			'membership_page_url' => isset( $input['membership_page_url'] ) ? esc_url_raw( $input['membership_page_url'] ) : '',
			'club_plans'          => self::sanitize_club_plans( $input['club_plans'] ?? array() ),
			'benefits'            => $current['benefits'],
		);
	}

	/**
	 * @param mixed $plans Raw plan rows.
	 * @return array<int, array<string, mixed>>
	 */
	private static function sanitize_club_plans( $plans ) {
		if ( ! is_array( $plans ) ) {
			return Oilmazing_SFC_Membership::default_club_plans();
		}

		$sanitized = array();
		$index     = 0;

		foreach ( $plans as $plan ) {
			if ( ! is_array( $plan ) ) {
				continue;
			}

			$name = isset( $plan['name'] ) ? sanitize_text_field( $plan['name'] ) : '';
			if ( '' === $name ) {
				continue;
			}

			$raw_id = isset( $plan['id'] ) ? sanitize_key( (string) $plan['id'] ) : '';
			if ( '' === $raw_id ) {
				$raw_id = sanitize_key( 'sfc-plan-' . ( $index + 1 ) );
			}

			$interval = isset( $plan['interval'] ) ? sanitize_key( (string) $plan['interval'] ) : 'month';
			if ( ! in_array( $interval, array( 'month', 'year', 'lifetime' ), true ) ) {
				$interval = 'month';
			}

			$sanitized[] = array(
				'id'           => $raw_id,
				'name'         => $name,
				'description'  => isset( $plan['description'] ) ? sanitize_textarea_field( $plan['description'] ) : '',
				'price'        => isset( $plan['price'] ) ? (string) max( 0, (float) $plan['price'] ) : '0',
				'interval'     => $interval,
				'featured'     => ! empty( $plan['featured'] ) ? 'yes' : 'no',
				'enabled'      => ! empty( $plan['enabled'] ) ? 'yes' : 'no',
				'checkout_url' => isset( $plan['checkout_url'] ) ? esc_url_raw( $plan['checkout_url'] ) : '',
				'product_id'   => isset( $plan['product_id'] ) ? absint( $plan['product_id'] ) : 0,
			);

			++$index;
			if ( $index >= 3 ) {
				break;
			}
		}

		if ( empty( $sanitized ) ) {
			return Oilmazing_SFC_Membership::default_club_plans();
		}

		return $sanitized;
	}

	/**
	 * Render settings page.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings       = Oilmazing_SFC_Membership::get_resolved_settings();
		$product_ids    = implode( ', ', array_map( 'strval', (array) $settings['product_ids'] ) );
		$club_plans     = isset( $settings['club_plans'] ) && is_array( $settings['club_plans'] ) ? $settings['club_plans'] : Oilmazing_SFC_Membership::default_club_plans();
		$affiliate      = class_exists( 'Oilmazing_SFC_Affiliate_Integration' ) ? Oilmazing_SFC_Affiliate_Integration::get_settings() : array();
		$ap_status        = class_exists( 'Oilmazing_SFC_Affiliate_Integration' ) ? Oilmazing_SFC_Affiliate_Integration::get_connection_status() : array();
		$detected_plans = Oilmazing_SFC_Membership::get_plans();
		$plans_empty    = empty( $detected_plans ) ? Oilmazing_SFC_Membership::get_plans_empty_info() : array();

		if ( function_exists( 'oilmazing_sfc_load_template' ) ) {
			oilmazing_sfc_load_template(
				'admin/membership.php',
				compact( 'settings', 'product_ids', 'club_plans', 'affiliate', 'ap_status', 'detected_plans', 'plans_empty' )
			);
			return;
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'Club Membership', 'oilmazing-sfc' ) . '</h1></div>';
	}
}
