<?php
/**
 * Member presence (online/offline) for messaging.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Presence
 */
class Oilmazing_SFC_Presence {

	const ONLINE_THRESHOLD = 900;

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_filter( 'rest_request_after_callbacks', array( __CLASS__, 'patch_message_responses' ), 10, 3 );
		add_action( 'wp_ajax_oilmazing_sfc_presence_heartbeat', array( __CLASS__, 'ajax_heartbeat' ) );
		add_action( 'wp_ajax_oilmazing_sfc_support_member_presence', array( __CLASS__, 'ajax_support_member_presence' ) );
	}

	/**
	 * Meta key used for last activity.
	 *
	 * @return string
	 */
	public static function meta_key() {
		return class_exists( 'Oilmazing_SFC_Community' )
			? Oilmazing_SFC_Community::META_LAST_SEEN
			: 'oilmazing_sfc_last_seen';
	}

	/**
	 * Mark the current user as active.
	 *
	 * @param int $user_id Optional user ID.
	 */
	public static function touch_last_seen( $user_id = 0 ) {
		$user_id = $user_id ? (int) $user_id : get_current_user_id();
		if ( $user_id <= 0 ) {
			return;
		}

		if ( class_exists( 'Oilmazing_SFC_Community' ) && $user_id === get_current_user_id() ) {
			Oilmazing_SFC_Community::touch_last_seen();
			return;
		}

		update_user_meta( $user_id, self::meta_key(), time() );
	}

	/**
	 * Whether a user is currently online.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	public static function is_user_online( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return false;
		}

		$last_seen = (int) get_user_meta( $user_id, self::meta_key(), true );
		$threshold = class_exists( 'Oilmazing_SFC_Community' )
			? (int) Oilmazing_SFC_Community::ONLINE_THRESHOLD
			: self::ONLINE_THRESHOLD;

		return $last_seen > 0 && ( time() - $last_seen ) <= $threshold;
	}

	/**
	 * Whether any support admin is currently online.
	 *
	 * @return bool
	 */
	public static function is_support_available() {
		$admins = get_users(
			array(
				'role'   => 'administrator',
				'number' => 25,
				'fields' => 'ID',
			)
		);

		foreach ( (array) $admins as $admin_id ) {
			if ( self::is_user_online( (int) $admin_id ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Human-readable presence label.
	 *
	 * @param int  $user_id    User ID.
	 * @param bool $is_support Support conversation flag.
	 * @return string
	 */
	public static function get_status_label( $user_id, $is_support = false ) {
		if ( $is_support ) {
			return self::is_support_available()
				? __( 'Online', 'oilmazing-sfc' )
				: __( 'Offline', 'oilmazing-sfc' );
		}

		return self::is_user_online( $user_id )
			? __( 'Online', 'oilmazing-sfc' )
			: __( 'Offline', 'oilmazing-sfc' );
	}

	/**
	 * Add online state to a conversation payload.
	 *
	 * @param array<string, mixed> $conversation Conversation data.
	 * @return array<string, mixed>
	 */
	public static function enrich_conversation( $conversation ) {
		if ( ! is_array( $conversation ) ) {
			return $conversation;
		}

		$is_support = ! empty( $conversation['is_support'] ) || ( isset( $conversation['id'] ) && 'support' === $conversation['id'] );
		$user_id    = (int) ( $conversation['user_id'] ?? 0 );

		if ( $is_support ) {
			$conversation['online']        = self::is_support_available();
			$conversation['status_label']  = self::get_status_label( 0, true );
		} else {
			$conversation['online']       = self::is_user_online( $user_id );
			$conversation['status_label'] = self::get_status_label( $user_id, false );
		}

		return $conversation;
	}

	/**
	 * Patch messaging REST payloads with presence data.
	 *
	 * @param WP_REST_Response|WP_HTTP_Response|WP_Error $response Response.
	 * @param array                                      $handler  Route handler.
	 * @param WP_REST_Request                            $request  Request.
	 * @return WP_REST_Response|WP_HTTP_Response|WP_Error
	 */
	public static function patch_message_responses( $response, $handler, $request ) {
		if ( is_wp_error( $response ) || ! ( $response instanceof WP_REST_Response ) ) {
			return $response;
		}

		$route = untrailingslashit( (string) $request->get_route() );
		if ( 0 !== strpos( $route, '/oilmazing-sfc/v1/' ) ) {
			return $response;
		}

		if ( is_user_logged_in() && self::is_message_route( $route, $request ) ) {
			self::touch_last_seen();
		}

		$data = $response->get_data();
		if ( ! is_array( $data ) ) {
			return $response;
		}

		if ( ! empty( $data['conversation'] ) && is_array( $data['conversation'] ) ) {
			$data['conversation'] = self::enrich_conversation( $data['conversation'] );
		}

		if ( ! empty( $data['conversations'] ) && is_array( $data['conversations'] ) ) {
			$data['conversations'] = array_map( array( __CLASS__, 'enrich_conversation' ), $data['conversations'] );
		}

		$response->set_data( $data );
		return $response;
	}

	/**
	 * @param string            $route   REST route.
	 * @param WP_REST_Request   $request Request.
	 * @return bool
	 */
	private static function is_message_route( $route, $request ) {
		if ( in_array( $route, array( '/oilmazing-sfc/v1/messages', '/oilmazing-sfc/v1/messages/conversations', '/oilmazing-sfc/v1/messages/read', '/oilmazing-sfc/v1/community' ), true ) ) {
			return true;
		}

		return '/oilmazing-sfc/v1/messages' === $route && in_array( $request->get_method(), array( 'GET', 'POST' ), true );
	}

	/**
	 * AJAX heartbeat for dashboard chat presence.
	 */
	public static function ajax_heartbeat() {
		check_ajax_referer( 'oilmazing_sfc_presence', 'nonce' );

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		self::touch_last_seen();

		$conversation_key = isset( $_POST['conversation_key'] ) ? sanitize_text_field( wp_unslash( $_POST['conversation_key'] ) ) : '';
		$presence       = array(
			'online'        => false,
			'status_label'  => __( 'Offline', 'oilmazing-sfc' ),
		);

		if ( 'support' === $conversation_key ) {
			$presence['online']       = self::is_support_available();
			$presence['status_label'] = self::get_status_label( 0, true );
		} elseif ( preg_match( '/^user-(\d+)$/', $conversation_key, $matches ) ) {
			$user_id                  = (int) $matches[1];
			$presence['online']       = self::is_user_online( $user_id );
			$presence['status_label'] = self::get_status_label( $user_id, false );
		}

		wp_send_json_success( $presence );
	}

	/**
	 * AJAX presence lookup for admin support thread header.
	 */
	public static function ajax_support_member_presence() {
		check_ajax_referer( 'oilmazing_sfc_support', 'nonce' );

		if ( ! Oilmazing_SFC_Support::user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		$member_id = isset( $_POST['member_id'] ) ? absint( wp_unslash( $_POST['member_id'] ) ) : 0;
		if ( $member_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Member not found.', 'oilmazing-sfc' ) ), 404 );
		}

		wp_send_json_success(
			array(
				'online'       => self::is_user_online( $member_id ),
				'status_label' => self::get_status_label( $member_id, false ),
			)
		);
	}
}
