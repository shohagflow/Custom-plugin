<?php
/**
 * Admin screen for emailing club customers directly.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Customer_Mail_Admin
 */
class Oilmazing_SFC_Customer_Mail_Admin {

	const PAGE_SLUG = 'oilmazing-sfc-customer-mail';

	const ACTION_SEND = 'oilmazing_sfc_send_customer_mail';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 99 );
		add_action( 'admin_post_' . self::ACTION_SEND, array( __CLASS__, 'handle_send' ) );
		add_action( 'wp_ajax_oilmazing_sfc_customer_mail_search', array( __CLASS__, 'ajax_search_recipients' ) );
		add_action( 'wp_ajax_oilmazing_sfc_send_customer_mail', array( __CLASS__, 'ajax_send' ) );
	}

	/**
	 * Register submenu under Scent Freedom Club.
	 */
	public static function register_menu() {
		$parent = class_exists( 'Oilmazing_SFC_Admin' ) ? Oilmazing_SFC_Admin::PAGE_SLUG : 'options-general.php';

		$hook = add_submenu_page(
			$parent,
			__( 'Customer Email', 'oilmazing-sfc' ),
			__( 'Customer Email', 'oilmazing-sfc' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);

		if ( $hook ) {
			add_action( "load-{$hook}", array( __CLASS__, 'enqueue_assets' ) );
			add_action( "admin_enqueue_scripts-{$hook}", array( __CLASS__, 'enqueue_assets' ) );
		}
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook_suffix Hook suffix.
	 */
	public static function enqueue_assets( $hook_suffix = '' ) {
		unset( $hook_suffix );

		if ( function_exists( 'oilmazing_sfc_enqueue_admin_assets' ) ) {
			oilmazing_sfc_enqueue_admin_assets();
		}

		if ( class_exists( 'Oilmazing_SFC_Auth_Bootstrap' ) ) {
			Oilmazing_SFC_Auth_Bootstrap::enqueue_admin_menu_assets( self::PAGE_SLUG );
		}

		wp_enqueue_style( 'dashicons' );

		wp_enqueue_style(
			'oilmazing-sfc-customer-mail-admin',
			OILMAZING_SFC_AUTH_URL . 'assets/css/customer-mail-admin.css',
			array( 'oilmazing-sfc-admin' ),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_enqueue_script(
			'oilmazing-sfc-customer-mail-admin',
			OILMAZING_SFC_AUTH_URL . 'assets/js/customer-mail-admin.js',
			array(),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		wp_localize_script(
			'oilmazing-sfc-customer-mail-admin',
			'oilmazingSfcCustomerMail',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'oilmazing_sfc_customer_mail' ),
				'i18n'    => array(
					'searching'        => __( 'Searching…', 'oilmazing-sfc' ),
					'noResults'        => __( 'No customers found.', 'oilmazing-sfc' ),
					'addRecipient'     => __( 'Add recipient', 'oilmazing-sfc' ),
					'remove'           => __( 'Remove', 'oilmazing-sfc' ),
					'selected'         => __( 'selected', 'oilmazing-sfc' ),
					'sending'          => __( 'Sending…', 'oilmazing-sfc' ),
					'sendEmail'        => __( 'Send email', 'oilmazing-sfc' ),
					'selectRecipient'  => __( 'Please add at least one customer or choose a bulk audience.', 'oilmazing-sfc' ),
					'enterSubject'     => __( 'Please enter a subject.', 'oilmazing-sfc' ),
					'enterMessage'     => __( 'Please enter a message.', 'oilmazing-sfc' ),
					'sendFailed'       => __( 'The email could not be sent. Check your WordPress mail settings and try again.', 'oilmazing-sfc' ),
					'emailSentTo'      => __( 'Email sent to %s', 'oilmazing-sfc' ),
					'emailSentToMany'  => __( 'Email sent to %1$s and %2$d more customers', 'oilmazing-sfc' ),
					'emailSentCount'   => __( 'Email sent to %d customers', 'oilmazing-sfc' ),
					'deliveryFailed'   => __( '%d delivery failed.', 'oilmazing-sfc' ),
				),
			)
		);
	}

	/**
	 * Render compose screen.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'oilmazing-sfc' ) );
		}

		$audience_counts = self::get_audience_counts();
		$notice          = self::get_flash_notice();

		if ( function_exists( 'oilmazing_sfc_load_template' ) ) {
			oilmazing_sfc_load_template(
				'admin/customer-mail.php',
				compact( 'audience_counts', 'notice' )
			);
			return;
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'Customer Email', 'oilmazing-sfc' ) . '</h1></div>';
	}

	/**
	 * Handle email send form.
	 */
	public static function handle_send() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to send customer email.', 'oilmazing-sfc' ) );
		}

		check_admin_referer( self::ACTION_SEND );

		$audience = isset( $_POST['audience'] ) ? sanitize_key( wp_unslash( $_POST['audience'] ) ) : 'selected';
		$subject  = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$message  = isset( $_POST['message'] ) ? wp_kses_post( wp_unslash( $_POST['message'] ) ) : '';
		$user_ids = isset( $_POST['recipient_ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['recipient_ids'] ) ) : array();

		$result = self::process_send( $audience, $subject, $message, $user_ids );

		if ( is_wp_error( $result ) ) {
			self::redirect_with_notice( 'error', $result->get_error_message() );
		}

		self::redirect_with_notice( 'success', self::format_success_message( $result ) );
	}

	/**
	 * AJAX email send handler.
	 */
	public static function ajax_send() {
		check_ajax_referer( 'oilmazing_sfc_customer_mail', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		$audience = isset( $_POST['audience'] ) ? sanitize_key( wp_unslash( $_POST['audience'] ) ) : 'selected';
		$subject  = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$message  = isset( $_POST['message'] ) ? wp_kses_post( wp_unslash( $_POST['message'] ) ) : '';
		$user_ids = isset( $_POST['recipient_ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['recipient_ids'] ) ) : array();

		$result = self::process_send( $audience, $subject, $message, $user_ids );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
				)
			);
		}

		wp_send_json_success(
			array(
				'message'          => self::format_success_message( $result ),
				'sent'             => (int) $result['sent'],
				'failed'           => (int) $result['failed'],
				'sent_recipients'  => array_values( (array) ( $result['sent_recipients'] ?? array() ) ),
			)
		);
	}

	/**
	 * Validate and send customer email.
	 *
	 * @param string         $audience Audience key.
	 * @param string         $subject  Email subject.
	 * @param string         $message  Email body.
	 * @param array<int,int> $user_ids Selected user IDs.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function process_send( $audience, $subject, $message, $user_ids ) {
		if ( '' === trim( $subject ) ) {
			return new WP_Error( 'missing_subject', __( 'Please enter a subject.', 'oilmazing-sfc' ) );
		}

		if ( '' === trim( wp_strip_all_tags( $message ) ) ) {
			return new WP_Error( 'missing_message', __( 'Please enter a message.', 'oilmazing-sfc' ) );
		}

		$recipients = self::resolve_recipients( $audience, $user_ids );
		if ( empty( $recipients ) ) {
			return new WP_Error( 'no_recipients', __( 'No valid customer email addresses were found for this send.', 'oilmazing-sfc' ) );
		}

		if ( count( $recipients ) > 500 ) {
			return new WP_Error( 'too_many_recipients', __( 'Please limit each send to 500 customers or fewer.', 'oilmazing-sfc' ) );
		}

		$result = self::send_bulk_mail( $recipients, $subject, $message );

		if ( $result['sent'] <= 0 ) {
			return new WP_Error(
				'send_failed',
				__( 'The email could not be sent. Check your WordPress mail settings and try again.', 'oilmazing-sfc' )
			);
		}

		return $result;
	}

	/**
	 * Build a human-readable success message.
	 *
	 * @param array<string,mixed> $result Send result.
	 * @return string
	 */
	private static function format_success_message( $result ) {
		$sent_recipients = array_values( (array) ( $result['sent_recipients'] ?? array() ) );
		$sent            = (int) ( $result['sent'] ?? 0 );
		$failed          = (int) ( $result['failed'] ?? 0 );

		if ( 1 === $sent && ! empty( $sent_recipients[0]['name'] ) ) {
			$message_text = sprintf(
				/* translators: %s: customer name */
				__( 'Email sent to %s.', 'oilmazing-sfc' ),
				(string) $sent_recipients[0]['name']
			);
		} elseif ( $sent <= 3 && ! empty( $sent_recipients ) ) {
			$names = array_map(
				static function ( $recipient ) {
					return (string) ( $recipient['name'] ?? '' );
				},
				$sent_recipients
			);
			$names = array_filter( $names );
			$message_text = sprintf(
				/* translators: %s: comma-separated customer names */
				__( 'Email sent to %s.', 'oilmazing-sfc' ),
				implode( ', ', $names )
			);
		} else {
			$message_text = sprintf(
				/* translators: %d: sent count */
				_n( 'Email sent to %d customer.', 'Email sent to %d customers.', $sent, 'oilmazing-sfc' ),
				$sent
			);
		}

		if ( $failed > 0 ) {
			$message_text .= ' ' . sprintf(
				/* translators: %d: failed count */
				_n( '%d delivery failed.', '%d deliveries failed.', $failed, 'oilmazing-sfc' ),
				$failed
			);
		}

		return $message_text;
	}

	/**
	 * AJAX recipient search.
	 */
	public static function ajax_search_recipients() {
		check_ajax_referer( 'oilmazing_sfc_customer_mail', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		$query = isset( $_POST['query'] ) ? sanitize_text_field( wp_unslash( $_POST['query'] ) ) : '';

		wp_send_json_success(
			array(
				'customers' => self::search_customers( $query ),
			)
		);
	}

	/**
	 * Search customers by name or email.
	 *
	 * @param string $query Search query.
	 * @param int    $limit Result limit.
	 * @return array<int, array<string, mixed>>
	 */
	public static function search_customers( $query, $limit = 10 ) {
		$query = trim( (string) $query );
		if ( strlen( $query ) < 2 ) {
			return array();
		}

		if ( class_exists( 'Oilmazing_SFC_Support' ) ) {
			$rows = Oilmazing_SFC_Support::search_members( $query, $limit );
		} elseif ( class_exists( 'Oilmazing_SFC_Members_Admin' ) ) {
			$result = Oilmazing_SFC_Members_Admin::query_members(
				array(
					'search'   => $query,
					'paged'    => 1,
					'per_page' => $limit,
				)
			);
			$rows   = array();
			foreach ( (array) ( $result['members'] ?? array() ) as $member ) {
				$rows[] = array(
					'id'                 => (int) ( $member['id'] ?? 0 ),
					'name'               => (string) ( $member['name'] ?? '' ),
					'email'              => (string) ( $member['email'] ?? '' ),
					'subscription_label' => (string) ( $member['subscription_label'] ?? '' ),
				);
			}
		} else {
			$rows = array();
		}

		$customers = array();
		foreach ( $rows as $row ) {
			$user_id = (int) ( $row['id'] ?? 0 );
			$user    = get_userdata( $user_id );
			if ( ! $user || ! is_email( $user->user_email ) || user_can( $user, 'manage_options' ) ) {
				continue;
			}

			$customers[] = array(
				'id'    => $user_id,
				'name'  => (string) ( $row['name'] ?? $user->display_name ),
				'email' => $user->user_email,
				'label' => (string) ( $row['subscription_label'] ?? '' ),
			);
		}

		return $customers;
	}

	/**
	 * Audience counts for the compose UI.
	 *
	 * @return array<string, int>
	 */
	public static function get_audience_counts() {
		return array(
			'club_members'  => count( self::resolve_recipients( 'club_members', array() ) ),
			'all_customers' => count( self::resolve_recipients( 'all_customers', array() ) ),
		);
	}

	/**
	 * Resolve recipient rows for a send action.
	 *
	 * @param string       $audience Audience key.
	 * @param array<int,int> $user_ids Selected user IDs.
	 * @return array<int, array<string, mixed>>
	 */
	public static function resolve_recipients( $audience, $user_ids = array() ) {
		$audience = sanitize_key( (string) $audience );
		$rows     = array();

		if ( 'club_members' === $audience ) {
			$rows = self::get_club_member_recipients();
		} elseif ( 'all_customers' === $audience ) {
			$rows = self::get_all_customer_recipients();
		} else {
			$rows = self::get_selected_recipients( $user_ids );
		}

		$unique = array();
		foreach ( $rows as $row ) {
			$email = strtolower( (string) ( $row['email'] ?? '' ) );
			if ( '' === $email || isset( $unique[ $email ] ) ) {
				continue;
			}
			$unique[ $email ] = $row;
		}

		return array_values( $unique );
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	private static function get_selected_recipients( $user_ids ) {
		$rows = array();

		foreach ( array_unique( array_map( 'absint', (array) $user_ids ) ) as $user_id ) {
			if ( $user_id <= 0 ) {
				continue;
			}

			$row = self::format_recipient_row( $user_id );
			if ( $row ) {
				$rows[] = $row;
			}
		}

		return $rows;
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	private static function get_all_customer_recipients() {
		$roles  = class_exists( 'WooCommerce' ) ? array( 'customer', 'subscriber' ) : array( 'subscriber', 'customer' );
		$users  = get_users(
			array(
				'role__in' => $roles,
				'number'   => 5000,
				'fields'   => 'ID',
				'orderby'  => 'registered',
				'order'    => 'DESC',
			)
		);
		$rows   = array();

		foreach ( (array) $users as $user_id ) {
			$row = self::format_recipient_row( (int) $user_id );
			if ( $row ) {
				$rows[] = $row;
			}
		}

		return $rows;
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	private static function get_club_member_recipients() {
		$rows = array();

		if ( ! class_exists( 'Oilmazing_SFC_Membership' ) ) {
			return $rows;
		}

		$user_query = new WP_User_Query(
			array(
				'number'  => 5000,
				'fields'  => 'ID',
				'orderby' => 'registered',
				'order'   => 'DESC',
			)
		);

		foreach ( array_map( 'intval', (array) $user_query->get_results() ) as $user_id ) {
			if ( ! Oilmazing_SFC_Membership::has_active_membership( $user_id ) ) {
				continue;
			}

			$row = self::format_recipient_row( $user_id );
			if ( $row ) {
				$rows[] = $row;
			}
		}

		return $rows;
	}

	/**
	 * @param int $user_id User ID.
	 * @return array<string, mixed>|null
	 */
	private static function format_recipient_row( $user_id ) {
		$user = get_userdata( (int) $user_id );
		if ( ! $user || ! is_email( $user->user_email ) || user_can( $user, 'manage_options' ) ) {
			return null;
		}

		return array(
			'id'    => (int) $user->ID,
			'name'  => $user->display_name ? $user->display_name : $user->user_login,
			'email' => $user->user_email,
		);
	}

	/**
	 * Send email to each recipient individually.
	 *
	 * @param array<int, array<string, mixed>> $recipients Recipient rows.
	 * @param string                            $subject    Email subject.
	 * @param string                            $message    Email body.
	 * @return array{sent:int, failed:int, sent_recipients:array<int, array<string, mixed>>}
	 */
	private static function send_bulk_mail( $recipients, $subject, $message ) {
		$sent              = 0;
		$failed            = 0;
		$sent_recipients   = array();

		$from_name  = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$from_email = sanitize_email( get_option( 'admin_email' ) );
		$headers    = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . sprintf( '%s <%s>', $from_name, $from_email ),
		);

		$body = wpautop( $message );
		$body = self::wrap_email_html( $subject, $body );

		foreach ( $recipients as $recipient ) {
			$to      = sanitize_email( (string) ( $recipient['email'] ?? '' ) );
			$name    = (string) ( $recipient['name'] ?? '' );
			$personal = str_replace( '{name}', $name, $body );

			if ( ! $to || ! wp_mail( $to, $subject, $personal, $headers ) ) {
				++$failed;
				continue;
			}

			++$sent;
			$sent_recipients[] = array(
				'id'    => (int) ( $recipient['id'] ?? 0 ),
				'name'  => $name,
				'email' => $to,
			);
		}

		return array(
			'sent'             => $sent,
			'failed'           => $failed,
			'sent_recipients'  => $sent_recipients,
		);
	}

	/**
	 * @param string $subject Subject line.
	 * @param string $body    HTML body.
	 * @return string
	 */
	private static function wrap_email_html( $subject, $body ) {
		$site_name = esc_html( get_bloginfo( 'name' ) );

		return '<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.6;color:#18181b;max-width:640px;margin:0 auto;">'
			. '<p style="margin:0 0 18px;font-size:13px;color:#71717a;">' . esc_html( $site_name ) . '</p>'
			. $body
			. '<p style="margin:24px 0 0;font-size:12px;color:#a1a1aa;">' . esc_html__( 'This message was sent from your Scent Freedom Club admin team.', 'oilmazing-sfc' ) . '</p>'
			. '</div>';
	}

	/**
	 * @param string $type    Notice type.
	 * @param string $message Notice message.
	 */
	private static function redirect_with_notice( $type, $message ) {
		$key = 'oilmazing_sfc_customer_mail_' . wp_generate_password( 8, false, false );
		set_transient(
			$key,
			array(
				'type'    => sanitize_key( $type ),
				'message' => (string) $message,
			),
			60
		);

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => self::PAGE_SLUG,
					'mail_notice' => $key,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * @return array<string, string>|null
	 */
	private static function get_flash_notice() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Flash notice lookup only.
		$key = isset( $_GET['mail_notice'] ) ? sanitize_key( wp_unslash( $_GET['mail_notice'] ) ) : '';
		if ( '' === $key ) {
			return null;
		}

		$notice = get_transient( $key );
		delete_transient( $key );

		return is_array( $notice ) ? $notice : null;
	}
}
