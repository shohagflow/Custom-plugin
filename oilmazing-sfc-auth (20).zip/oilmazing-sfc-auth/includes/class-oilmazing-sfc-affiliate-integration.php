<?php
/**
 * AffiliatePress integration for Scent Freedom Club subscriptions.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Affiliate_Integration
 */
class Oilmazing_SFC_Affiliate_Integration {

	const SOURCE = 'scent_freedom_club';

	const META_ORDER_AFFILIATE = '_oilmazing_sfc_affiliate_id';

	const META_USER_AFFILIATE = 'oilmazing_sfc_affiliate_referrer_id';

	const META_COMMISSION_PAID = '_oilmazing_sfc_affiliate_commission_paid';

	const META_SUBSCRIPTION_AFFILIATE = '_oilmazing_sfc_affiliate_id';

	const OPTION_KEY = 'oilmazing_sfc_affiliate_settings';

	const DEFAULT_COMMISSION_PERCENT = 30;

	const DEFAULT_RECURRING_COMMISSION_PERCENT = 10;

	const AP_SETTING_RECURRING_ENABLED = 'scent_freedom_club_recurring_commissions';

	const AP_SETTING_RECURRING_PERCENT = 'scent_freedom_club_recurring_commission_percent';

	const AP_SETTING_RECURRING_BILLING_CYCLE = 'scent_freedom_club_recurring_commission_billing_cycle';

	const AP_SETTING_RECURRING_DAY_OF_BILLING_CYCLE = 'scent_freedom_club_recurring_day_of_billing_cycle';

	const AP_SETTINGS_INSTALLED_OPTION = 'oilmazing_sfc_affiliatepress_settings_installed';

	const RENEWAL_AUTO_PAYOUT_OPTION = 'oilmazing_sfc_renewal_auto_payout_process';

	const DEFAULT_RECURRING_BILLING_CYCLE = 'monthly';

	const DEFAULT_RECURRING_DAY_OF_BILLING_CYCLE = 3;

	/**
	 * Commission IDs temporarily held from payout queries.
	 *
	 * @var array<int, int>
	 */
	private static $held_commission_snapshot = array();

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'boot' ), 100 );
	}

	/**
	 * Boot integration after AffiliatePress has loaded.
	 */
	public static function boot() {
		if ( ! self::is_affiliatepress_active() ) {
			return;
		}

		add_filter( 'affiliatepress_auto_load_settings', array( __CLASS__, 'register_affiliatepress_settings' ) );
		add_filter( 'affiliatepress_backend_modify_settings_data_fields', array( __CLASS__, 'add_affiliatepress_settings_form_defaults' ) );
		add_filter( 'affiliatepress_settings_dynamic_on_load_methods', array( __CLASS__, 'normalize_affiliatepress_settings_tab_on_load' ), 5, 1 );
		add_action( 'affiliatepress_extra_commissions_setting_section_html', array( __CLASS__, 'render_commissions_club_sections' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_install_affiliatepress_settings' ), 20 );

		add_action( 'woocommerce_checkout_create_order', array( __CLASS__, 'capture_affiliate_on_order' ), 20, 2 );
		add_action( 'user_register', array( __CLASS__, 'capture_affiliate_on_register' ), 15, 1 );
		add_action( 'woocommerce_subscription_status_active', array( __CLASS__, 'maybe_create_subscription_commission' ), 30, 1 );
		add_action( 'woocommerce_subscription_renewal_payment_complete', array( __CLASS__, 'maybe_create_renewal_commission' ), 30, 2 );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'maybe_create_renewal_commission_from_order' ), 25, 1 );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'maybe_create_renewal_commission_from_order' ), 25, 1 );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'maybe_create_membership_commission_from_order' ), 22, 1 );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'maybe_create_membership_commission_from_order' ), 22, 1 );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'approve_pending_commission' ), 30, 1 );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'approve_pending_commission' ), 30, 1 );
		add_filter( 'rest_post_dispatch', array( __CLASS__, 'enrich_referrals_response' ), 10, 3 );
		add_filter( 'affiliatepress_modify_commission_link', array( __CLASS__, 'filter_commission_order_link' ), 10, 2 );
		add_filter( 'affiliatepress_affiliate_panel_data_fields', array( __CLASS__, 'filter_affiliate_panel_data_fields' ), 10, 1 );
		add_action( 'affiliatepress_payout_hourly_event', array( __CLASS__, 'hold_renewal_commissions_before_standard_payout' ), 9 );
		add_action( 'affiliatepress_payout_hourly_event', array( __CLASS__, 'restore_held_commissions_after_standard_payout' ), 11 );
		add_action( 'affiliatepress_payout_hourly_event', array( __CLASS__, 'maybe_generate_renewal_auto_payout' ), 20 );

		if ( is_admin() ) {
			add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		}
	}

	/**
	 * @return bool
	 */
	public static function is_affiliatepress_active() {
		return class_exists( 'AffiliatePress_Core' ) || class_exists( 'AffiliatePress' );
	}

	/**
	 * Settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_settings() {
		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		$first_rate = self::get_affiliatepress_first_purchase_rate();

		return array(
			'commission_percent'           => $first_rate['percent'],
			'commission_rate_type'         => $first_rate['type'],
			'commission_rate_label'        => $first_rate['label'],
			'recurring_commission_percent' => self::get_recurring_commission_percent(),
			'recurring_commissions'        => self::recurring_commissions_enabled() ? 'yes' : 'no',
			'club_landing_url'             => isset( $stored['club_landing_url'] ) ? (string) $stored['club_landing_url'] : '',
			'commission_managed_by'        => 'affiliatepress',
			'affiliatepress_settings_url'  => self::get_affiliatepress_commissions_settings_url(),
			'affiliatepress_integrations_url' => self::get_affiliatepress_integrations_settings_url(),
		);
	}

	/**
	 * Register admin settings.
	 */
	public static function register_settings() {
		register_setting(
			'oilmazing_sfc_membership_settings',
			self::OPTION_KEY,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
			)
		);
	}

	/**
	 * @param array<string, mixed> $input Raw settings.
	 * @return array<string, mixed>
	 */
	public static function sanitize_settings( $input ) {
		$input = is_array( $input ) ? $input : array();
		$current = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}

		return array(
			'club_landing_url' => isset( $input['club_landing_url'] ) ? esc_url_raw( $input['club_landing_url'] ) : ( $current['club_landing_url'] ?? '' ),
		);
	}

	/**
	 * Register Scent Freedom Club renewal settings with AffiliatePress.
	 *
	 * @param array<int, array<string, mixed>> $settings AffiliatePress default settings.
	 * @return array<int, array<string, mixed>>
	 */
	public static function register_affiliatepress_settings( $settings ) {
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$settings[] = array(
			'ap_setting_name'  => self::AP_SETTING_RECURRING_ENABLED,
			'ap_setting_value' => 'true',
			'ap_setting_type'  => 'commissions_settings',
			'auto_load'        => 1,
			'type'             => 'text',
		);
		$settings[] = array(
			'ap_setting_name'  => self::AP_SETTING_RECURRING_PERCENT,
			'ap_setting_value' => (string) self::DEFAULT_RECURRING_COMMISSION_PERCENT,
			'ap_setting_type'  => 'commissions_settings',
			'auto_load'        => 1,
			'type'             => 'float',
		);
		$settings[] = array(
			'ap_setting_name'  => self::AP_SETTING_RECURRING_BILLING_CYCLE,
			'ap_setting_value' => self::DEFAULT_RECURRING_BILLING_CYCLE,
			'ap_setting_type'  => 'commissions_settings',
			'auto_load'        => 1,
			'type'             => 'text',
		);
		$settings[] = array(
			'ap_setting_name'  => self::AP_SETTING_RECURRING_DAY_OF_BILLING_CYCLE,
			'ap_setting_value' => (string) self::DEFAULT_RECURRING_DAY_OF_BILLING_CYCLE,
			'ap_setting_type'  => 'commissions_settings',
			'auto_load'        => 1,
			'type'             => 'integer',
		);

		return $settings;
	}

	/**
	 * Vue defaults for AffiliatePress commissions settings form.
	 *
	 * @param array<string, mixed> $fields Dynamic settings fields.
	 * @return array<string, mixed>
	 */
	public static function add_affiliatepress_settings_form_defaults( $fields ) {
		if ( ! is_array( $fields ) ) {
			return $fields;
		}

		if ( ! empty( $fields['selected_tab_name'] ) ) {
			$fields['selected_tab_name'] = self::normalize_affiliatepress_settings_tab_name( (string) $fields['selected_tab_name'] );
		}

		if ( empty( $fields['commissions_setting_form'] ) || ! is_array( $fields['commissions_setting_form'] ) ) {
			return $fields;
		}

		$fields['commissions_setting_form'][ self::AP_SETTING_RECURRING_ENABLED ] = true;
		$fields['commissions_setting_form'][ self::AP_SETTING_RECURRING_PERCENT ] = (string) self::DEFAULT_RECURRING_COMMISSION_PERCENT;
		$fields['commissions_setting_form'][ self::AP_SETTING_RECURRING_BILLING_CYCLE ] = self::DEFAULT_RECURRING_BILLING_CYCLE;
		$fields['commissions_setting_form'][ self::AP_SETTING_RECURRING_DAY_OF_BILLING_CYCLE ] = (string) self::DEFAULT_RECURRING_DAY_OF_BILLING_CYCLE;

		return $fields;
	}

	/**
	 * Map short AffiliatePress setting_page slugs to Vue tab names.
	 *
	 * @param string $tab_name Tab slug from the settings URL.
	 * @return string
	 */
	private static function normalize_affiliatepress_settings_tab_name( $tab_name ) {
		$tab_name = sanitize_key( $tab_name );
		$map      = array(
			'affiliate'          => 'affiliate_settings',
			'commissions'        => 'commissions_settings',
			'integrations'       => 'integrations_settings',
			'email_notification' => 'email_notification_settings',
			'messages'           => 'message_settings',
			'appearance'         => 'appearance_settings',
			'debug_log'          => 'debug_log_settings',
		);

		return $map[ $tab_name ] ?? $tab_name;
	}

	/**
	 * Fix AffiliatePress settings deep links that use short tab slugs.
	 *
	 * @param string $methods Vue on-load JavaScript.
	 * @return string
	 */
	public static function normalize_affiliatepress_settings_tab_on_load( $methods ) {
		$prefix = '
			var oilmazingSfcApTabMap = {
				affiliate: "affiliate_settings",
				commissions: "commissions_settings",
				integrations: "integrations_settings",
				email_notification: "email_notification_settings",
				messages: "message_settings",
				appearance: "appearance_settings",
				debug_log: "debug_log_settings"
			};
			var oilmazingSfcApStoredTab = sessionStorage.getItem("current_affiliatpress_tabname");
			if (oilmazingSfcApStoredTab && oilmazingSfcApTabMap[oilmazingSfcApStoredTab]) {
				sessionStorage.setItem("current_affiliatpress_tabname", oilmazingSfcApTabMap[oilmazingSfcApStoredTab]);
			}
		';

		return $prefix . $methods;
	}

	/**
	 * @param string $setting_name Setting key.
	 * @return string
	 */
	private static function get_affiliatepress_commission_setting( $setting_name ) {
		global $AffiliatePress;

		if ( ! isset( $AffiliatePress ) || ! method_exists( $AffiliatePress, 'affiliatepress_get_settings' ) ) {
			return '';
		}

		$value = (string) $AffiliatePress->affiliatepress_get_settings( $setting_name, 'commissions_settings' );
		if ( '' !== $value ) {
			return $value;
		}

		return (string) $AffiliatePress->affiliatepress_get_settings( $setting_name, 'integrations_settings' );
	}

	/**
	 * Ensure AffiliatePress has our renewal settings stored.
	 */
	public static function maybe_install_affiliatepress_settings() {
		global $AffiliatePress;

		if ( ! isset( $AffiliatePress ) || ! method_exists( $AffiliatePress, 'affiliatepress_update_settings' ) ) {
			return;
		}

		$installed_version = (string) get_option( self::AP_SETTINGS_INSTALLED_OPTION, '' );
		if ( $installed_version === OILMAZING_SFC_AUTH_VERSION ) {
			return;
		}

		$legacy = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $legacy ) ) {
			$legacy = array();
		}

		$recurring_enabled = $legacy['recurring_commissions'] ?? 'yes';
		$recurring_percent = isset( $legacy['recurring_commission_percent'] ) ? (float) $legacy['recurring_commission_percent'] : self::DEFAULT_RECURRING_COMMISSION_PERCENT;

		$settings_to_install = array(
			self::AP_SETTING_RECURRING_ENABLED              => 'yes' === $recurring_enabled ? 'true' : 'false',
			self::AP_SETTING_RECURRING_PERCENT              => (string) max( 0, min( 100, $recurring_percent ) ),
			self::AP_SETTING_RECURRING_BILLING_CYCLE        => self::DEFAULT_RECURRING_BILLING_CYCLE,
			self::AP_SETTING_RECURRING_DAY_OF_BILLING_CYCLE => (string) self::DEFAULT_RECURRING_DAY_OF_BILLING_CYCLE,
		);

		foreach ( $settings_to_install as $setting_name => $default_value ) {
			$current_value = self::get_affiliatepress_commission_setting( $setting_name );
			if ( '' === $current_value ) {
				$AffiliatePress->affiliatepress_update_settings( $setting_name, 'commissions_settings', $default_value );
			} elseif ( '' === (string) $AffiliatePress->affiliatepress_get_settings( $setting_name, 'commissions_settings' ) ) {
				$AffiliatePress->affiliatepress_update_settings( $setting_name, 'commissions_settings', $current_value );
			}
		}

		self::cleanup_legacy_integration_settings();
		if ( method_exists( $AffiliatePress, 'affiliatepress_update_all_auto_load_settings' ) ) {
			$AffiliatePress->affiliatepress_update_all_auto_load_settings();
		}

		update_option( self::AP_SETTINGS_INSTALLED_OPTION, OILMAZING_SFC_AUTH_VERSION, false );
	}

	/**
	 * Remove duplicate legacy Scent Freedom Club rows from integrations_settings.
	 */
	private static function cleanup_legacy_integration_settings() {
		global $wpdb, $affiliatepress_tbl_ap_settings;

		if ( ! isset( $wpdb, $affiliatepress_tbl_ap_settings ) ) {
			return;
		}

		$setting_names = array(
			self::AP_SETTING_RECURRING_ENABLED,
			self::AP_SETTING_RECURRING_PERCENT,
			self::AP_SETTING_RECURRING_BILLING_CYCLE,
			self::AP_SETTING_RECURRING_DAY_OF_BILLING_CYCLE,
			'scent_freedom_club_landing_url',
		);

		foreach ( $setting_names as $setting_name ) {
			$wpdb->delete(
				$affiliatepress_tbl_ap_settings,
				array(
					'ap_setting_name' => $setting_name,
					'ap_setting_type' => 'integrations_settings',
				),
				array( '%s', '%s' )
			);
		}
	}

	/**
	 * Separate Scent Freedom Club commission sections in AffiliatePress → Commissions.
	 */
	public static function render_commissions_club_sections() {
		$enabled_key       = esc_attr( self::AP_SETTING_RECURRING_ENABLED );
		$percent_key       = esc_attr( self::AP_SETTING_RECURRING_PERCENT );
		$billing_cycle_key = esc_attr( self::AP_SETTING_RECURRING_BILLING_CYCLE );
		$billing_day_key   = esc_attr( self::AP_SETTING_RECURRING_DAY_OF_BILLING_CYCLE );
		?>
		<div class="ap-gs__cb--item oilmazing-sfc-club-commission-block">
			<div class="ap-gs__cb--item-heading ap-gs__cb--item--main-heading">
				<?php esc_html_e( 'Scent Freedom Club — first membership purchase', 'oilmazing-sfc' ); ?>
			</div>
			<div class="ap-gs__cb--item-body">
				<el-row type="flex" class="ap-gs--tabs-pb__cb-item-row" :gutter="32">
					<el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="24" class="ap-gs__cb-item-left">
						<el-row type="flex" class="ap-gs--tabs-fields-description">
							<div><?php esc_html_e( 'First membership purchase only. This automatically uses the normal AffiliatePress Commission Rate and Commission Basis fields at the top of this tab. No separate rate here — it stays in sync with AffiliatePress.', 'oilmazing-sfc' ); ?></div>
						</el-row>
					</el-col>
				</el-row>
				<el-row type="flex" class="ap-gs--tabs-pb__cb-item-row" :gutter="32">
					<el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="ap-gs__cb-item-left ap-gs-col-first">
						<div class="ap-combine-field">
							<label><span class="ap-form-label"><?php esc_html_e( 'First purchase commission rate', 'oilmazing-sfc' ); ?></span></label>
							<div class="oilmazing-sfc-ap-readonly-value">
								<span v-if="commissions_setting_form.default_discount_type === 'percentage'">{{ commissions_setting_form.default_discount_val }}%</span>
								<span v-else>{{ current_currency_symbol }}{{ commissions_setting_form.default_discount_val }}</span>
							</div>
						</div>
					</el-col>
					<el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="ap-gs__cb-item-left">
						<div class="ap-combine-field">
							<label><span class="ap-form-label"><?php esc_html_e( 'Commission basis', 'oilmazing-sfc' ); ?></span></label>
							<div class="oilmazing-sfc-ap-readonly-value">
								<span v-if="commissions_setting_form.flat_rate_commission_basis === 'pre_product'"><?php esc_html_e( 'Per product sold', 'oilmazing-sfc' ); ?></span>
								<span v-else><?php esc_html_e( 'Per order', 'oilmazing-sfc' ); ?></span>
							</div>
						</div>
					</el-col>
				</el-row>
			</div>
		</div>

		<div class="ap-gs__cb--item oilmazing-sfc-club-commission-block">
			<div class="ap-gs__cb--item-heading ap-gs__cb--item--main-heading">
				<?php esc_html_e( 'Scent Freedom Club — monthly renewal', 'oilmazing-sfc' ); ?>
			</div>
			<div class="ap-gs__cb--item-body">
				<el-row type="flex" class="ap-gs--tabs-pb__cb-item-row" :gutter="32">
					<el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="24" class="ap-gs__cb-item-left">
						<el-row type="flex" class="ap-gs--tabs-fields-description">
							<div><?php esc_html_e( 'Completely separate from first purchase commission above. Only the 10% renewal commission uses these settings, including when affiliates are paid each month.', 'oilmazing-sfc' ); ?></div>
						</el-row>
					</el-col>
				</el-row>
				<el-row type="flex" class="ap-gs--tabs-pb__cb-item-row" :gutter="32">
					<el-col :xs="20" :sm="20" :md="20" :lg="18" :xl="18" class="ap-gs__cb-item-left">
						<el-row type="flex" class="ap-gs--tabs-fields-label">
							<h4><?php esc_html_e( 'Pay renewal commission', 'oilmazing-sfc' ); ?></h4>
						</el-row>
					</el-col>
					<el-col :xs="4" :sm="4" :md="4" :lg="6" :xl="6" class="ap-gs__cb-item-right">
						<el-form-item prop="<?php echo $enabled_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
							<el-switch v-model="commissions_setting_form.<?php echo $enabled_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"/>
						</el-form-item>
					</el-col>
				</el-row>
				<el-row type="flex" class="ap-gs--tabs-pb__cb-item-row" :gutter="32">
					<el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="ap-gs__cb-item-left ap-gs-col-first">
						<div class="ap-combine-field">
							<label><span class="ap-form-label"><?php esc_html_e( 'Renewal commission rate', 'oilmazing-sfc' ); ?></span></label>
							<el-form-item prop="<?php echo $percent_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
								<el-input class="ap-form-control ap-append-input-select" type="text" v-model="commissions_setting_form.<?php echo $percent_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" size="large" placeholder="<?php esc_attr_e( 'Enter renewal rate', 'oilmazing-sfc' ); ?>">
									<template #append><?php esc_html_e( '%', 'oilmazing-sfc' ); ?></template>
								</el-input>
							</el-form-item>
						</div>
					</el-col>
				</el-row>
				<el-row type="flex" class="ap-gs--tabs-pb__cb-item-row" :gutter="32">
					<el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="ap-gs__cb-item-left ap-gs-col-first">
						<div class="ap-combine-field">
							<label><span class="ap-form-label"><?php esc_html_e( 'Commission Billing Cycle For Automatic-Payout', 'oilmazing-sfc' ); ?></span></label>
							<el-form-item prop="<?php echo $billing_cycle_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
								<el-select @change="(val) => { if (val === 'weekly' || val === 'yearly') { commissions_setting_form.<?php echo $billing_day_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> = '1'; } }" class="ap-form-control" v-model="commissions_setting_form.<?php echo $billing_cycle_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" placeholder="<?php esc_attr_e( 'Select', 'oilmazing-sfc' ); ?>" size="large">
									<el-option v-for="item in billing_cycle" :key="item.value" :label="item.label" :value="item.value"/>
								</el-select>
							</el-form-item>
						</div>
					</el-col>
					<el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="ap-gs__cb-item-left" v-if="commissions_setting_form.<?php echo $billing_cycle_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> != 'disabled'">
						<div class="ap-combine-field">
							<label>
								<span class="ap-form-label" v-if="commissions_setting_form.<?php echo $billing_cycle_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> == 'yearly'">
									<?php esc_html_e( 'Month of Billing Cycle For Automatic-Payout', 'oilmazing-sfc' ); ?>
								</span>
								<span class="ap-form-label" v-else>
									<?php esc_html_e( 'Day of Billing Cycle For Automatic-Payout', 'oilmazing-sfc' ); ?>
								</span>
							</label>
							<el-form-item v-if="commissions_setting_form.<?php echo $billing_cycle_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> == 'monthly'" prop="<?php echo $billing_day_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
								<el-input-number v-model="commissions_setting_form.<?php echo $billing_day_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" class="ap-form-control--number" :min="1" :max="31" size="large" />
							</el-form-item>
							<el-form-item v-else-if="commissions_setting_form.<?php echo $billing_cycle_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> == 'weekly'" prop="<?php echo $billing_day_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
								<el-select class="ap-form-control" v-model="commissions_setting_form.<?php echo $billing_day_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" placeholder="<?php esc_attr_e( 'Select', 'oilmazing-sfc' ); ?>" size="large">
									<el-option v-for="item in weekly_cycle_days" :key="item.value" :label="item.text" :value="item.value"/>
								</el-select>
							</el-form-item>
							<el-form-item v-else-if="commissions_setting_form.<?php echo $billing_cycle_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> == 'yearly'" prop="<?php echo $billing_day_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
								<el-select class="ap-form-control" v-model="commissions_setting_form.<?php echo $billing_day_key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" placeholder="<?php esc_attr_e( 'Select', 'oilmazing-sfc' ); ?>" size="large">
									<el-option v-for="item in yearly_cycle_months" :key="item.value" :label="item.text" :value="item.value"/>
								</el-select>
							</el-form-item>
						</div>
					</el-col>
				</el-row>
			</div>
		</div>
		<?php
	}

	/**
	 * @return array{percent:float,type:string,label:string}
	 */
	public static function get_affiliatepress_first_purchase_rate() {
		global $AffiliatePress;

		$percent = self::DEFAULT_COMMISSION_PERCENT;
		$type    = 'percentage';
		$label   = self::DEFAULT_COMMISSION_PERCENT . '%';

		if ( ! isset( $AffiliatePress ) || ! method_exists( $AffiliatePress, 'affiliatepress_get_settings' ) ) {
			return compact( 'percent', 'type', 'label' );
		}

		$rate_type = (string) $AffiliatePress->affiliatepress_get_settings( 'default_discount_type', 'commissions_settings' );
		$rate_val  = (float) $AffiliatePress->affiliatepress_get_settings( 'default_discount_val', 'commissions_settings' );

		if ( 'percentage' === $rate_type ) {
			$percent = max( 0, min( 100, $rate_val ) );
			$label   = $percent . '%';
		} else {
			$type    = 'fixed';
			$percent = 0.0;
			$symbol  = method_exists( $AffiliatePress, 'affiliatepress_get_default_currency_symbol' )
				? (string) $AffiliatePress->affiliatepress_get_default_currency_symbol()
				: '$';
			$label   = $symbol . number_format( $rate_val, 2 );
		}

		return array(
			'percent' => $percent,
			'type'    => $type,
			'label'   => $label,
		);
	}

	/**
	 * @return string
	 */
	private static function get_first_purchase_basis_label() {
		global $AffiliatePress;

		if ( ! isset( $AffiliatePress ) || ! method_exists( $AffiliatePress, 'affiliatepress_get_settings' ) ) {
			return __( 'Per product sold', 'oilmazing-sfc' );
		}

		$basis = (string) $AffiliatePress->affiliatepress_get_settings( 'flat_rate_commission_basis', 'commissions_settings' );

		return 'pre_order' === $basis
			? __( 'Per order', 'oilmazing-sfc' )
			: __( 'Per product sold', 'oilmazing-sfc' );
	}

	/**
	 * @return float
	 */
	public static function get_recurring_commission_percent() {
		$value = (float) self::get_affiliatepress_commission_setting( self::AP_SETTING_RECURRING_PERCENT );
		if ( $value <= 0 ) {
			$value = self::DEFAULT_RECURRING_COMMISSION_PERCENT;
		}

		return max( 0, min( 100, $value ) );
	}

	/**
	 * @return bool
	 */
	public static function recurring_commissions_enabled() {
		$value = self::get_affiliatepress_commission_setting( self::AP_SETTING_RECURRING_ENABLED );
		if ( '' === $value ) {
			return true;
		}

		return 'true' === $value;
	}

	/**
	 * @return string
	 */
	public static function get_recurring_billing_cycle() {
		$value = self::get_affiliatepress_commission_setting( self::AP_SETTING_RECURRING_BILLING_CYCLE );

		return '' !== $value ? (string) $value : self::DEFAULT_RECURRING_BILLING_CYCLE;
	}

	/**
	 * @return int
	 */
	public static function get_recurring_day_of_billing_cycle() {
		$value = self::get_affiliatepress_commission_setting( self::AP_SETTING_RECURRING_DAY_OF_BILLING_CYCLE );

		return '' !== $value ? (int) $value : self::DEFAULT_RECURRING_DAY_OF_BILLING_CYCLE;
	}

	/**
	 * Keep renewal commissions out of the standard AffiliatePress auto payout.
	 */
	public static function hold_renewal_commissions_before_standard_payout() {
		if ( ! self::recurring_commissions_enabled() || 'disabled' === self::get_recurring_billing_cycle() ) {
			return;
		}

		self::hold_commissions_for_payout_scope( 'exclude_renewals' );
	}

	/**
	 * Restore renewal commissions after the standard AffiliatePress auto payout runs.
	 */
	public static function restore_held_commissions_after_standard_payout() {
		self::restore_held_commissions();
	}

	/**
	 * Generate automatic payout for renewal commissions on the renewal billing cycle.
	 */
	public static function maybe_generate_renewal_auto_payout() {
		global $affiliatepress_payout, $AffiliatePress, $affiliatepress_tbl_ap_payouts, $affiliatepress_tracking;

		if ( ! self::recurring_commissions_enabled() ) {
			return;
		}

		$billing_cycle = self::get_recurring_billing_cycle();
		if ( 'disabled' === $billing_cycle || ! isset( $affiliatepress_payout, $AffiliatePress, $affiliatepress_tracking ) || ! is_object( $affiliatepress_payout ) ) {
			return;
		}

		$auto_payout_date = self::get_auto_payout_date_for_settings( $billing_cycle, self::get_recurring_day_of_billing_cycle() );
		if ( empty( $auto_payout_date ) ) {
			return;
		}

		$last_processed = (string) get_option( self::RENEWAL_AUTO_PAYOUT_OPTION, '' );
		if ( $last_processed === $auto_payout_date ) {
			return;
		}

		$payout_added_affiliate = 0;
		if ( isset( $affiliatepress_tbl_ap_payouts ) && method_exists( $affiliatepress_payout, 'affiliatepress_select_record' ) ) {
			$payout_added_affiliate = (int) $affiliatepress_payout->affiliatepress_select_record(
				true,
				'',
				$affiliatepress_tbl_ap_payouts,
				'count(ap_payout_id)',
				'WHERE DATE(ap_payout_upto_date) >= %s ',
				array( $auto_payout_date ),
				'',
				'',
				'',
				true,
				false,
				ARRAY_A
			);
		}

		if ( $payout_added_affiliate > 0 || $auto_payout_date >= gmdate( 'Y-m-d', current_time( 'timestamp' ) ) ) {
			return;
		}

		self::hold_commissions_for_payout_scope( 'only_non_renewals' );

		$minimum_payment_amount = $AffiliatePress->affiliatepress_get_settings( 'minimum_payment_amount', 'commissions_settings' );
		$minimum_payment_order  = $affiliatepress_tracking->affiliatepress_get_payout_minimum_payment_order();
		$payout_args            = array(
			'ap_payout_created_by'         => 0,
			'ap_payout_upto_date'          => $auto_payout_date,
			'ap_payout_total_affiliate'    => 0,
			'ap_payout_selected_affiliate' => '',
			'ap_payment_method'            => '',
			'ap_payment_min_amount'        => $minimum_payment_amount,
			'ap_payout_process'            => 0,
			'ap_payment_min_order'         => $minimum_payment_order,
		);

		$payout_id = 0;
		if ( method_exists( $affiliatepress_payout, 'affiliatepress_insert_record' ) ) {
			$payout_id = (int) $affiliatepress_payout->affiliatepress_insert_record( $affiliatepress_tbl_ap_payouts, $payout_args );
		}

		if ( $payout_id > 0 && method_exists( $affiliatepress_payout, 'affiliatepress_generate_payout_process' ) ) {
			$affiliatepress_payout->affiliatepress_generate_payout_process( true );
			update_option( self::RENEWAL_AUTO_PAYOUT_OPTION, $auto_payout_date, false );
		}

		self::restore_held_commissions();
	}

	/**
	 * @param string $billing_cycle Billing cycle slug.
	 * @param int    $day_of_cycle  Day/weekday/month value.
	 * @return string
	 */
	private static function get_auto_payout_date_for_settings( $billing_cycle, $day_of_cycle ) {
		$given_date = gmdate( 'Y-m-d', current_time( 'timestamp' ) );

		if ( 'weekly' === $billing_cycle ) {
			$days = array(
				1 => 'Monday',
				2 => 'Tuesday',
				3 => 'Wednesday',
				4 => 'Thursday',
				5 => 'Friday',
				6 => 'Saturday',
				7 => 'Sunday',
			);
			$day_name = $days[ max( 1, min( 7, (int) $day_of_cycle ) ) ] ?? 'Monday';

			return gmdate( 'Y-m-d', strtotime( $day_name . ' ', strtotime( $given_date ) ) );
		}

		if ( 'monthly' === $billing_cycle ) {
			$date                       = new DateTime( 'last day of this month' );
			$last_day_of_previous_month = $date->format( 'Y-m-d' );
			$date                       = new DateTime( 'first day of this month' );
			$adjusted_day               = max( 0, (int) $day_of_cycle - 1 );
			if ( $adjusted_day > 0 ) {
				$date->modify( '+' . $adjusted_day . ' days' );
			}
			$possible_date = $date->format( 'Y-m-d' );
			if ( $possible_date > $last_day_of_previous_month ) {
				$possible_date = $last_day_of_previous_month;
			}
			$today = new DateTime( 'now' );
			if ( $possible_date < $today->format( 'Y-m-d' ) ) {
				$date                       = new DateTime( 'last day of next month' );
				$last_day_of_previous_month = $date->format( 'Y-m-d' );
				$date                       = new DateTime( 'first day of next month' );
				if ( $adjusted_day > 0 ) {
					$date->modify( '+' . $adjusted_day . ' days' );
				}
				$possible_date = $date->format( 'Y-m-d' );
				if ( $possible_date > $last_day_of_previous_month ) {
					$possible_date = $last_day_of_previous_month;
				}
			}

			return $possible_date;
		}

		if ( 'yearly' === $billing_cycle ) {
			$selected_month = (int) $day_of_cycle;
			if ( 1 === $selected_month ) {
				$selected_month = 12;
			} else {
				$selected_month -= 1;
			}
			$today = new DateTime();
			$today->setTime( 0, 0, 0 );
			$date = new DateTime();
			$date->setDate( (int) gmdate( 'Y' ), $selected_month, 1 );
			$date->modify( 'last day of this month' );
			$date->setTime( 0, 0, 0 );
			if ( $date < $today ) {
				$date->modify( '+1 year' );
			}

			return $date->format( 'Y-m-d' );
		}

		return '';
	}

	/**
	 * Temporarily move commissions out of approved status so payout queries skip them.
	 *
	 * @param string $scope exclude_renewals|only_non_renewals
	 */
	private static function hold_commissions_for_payout_scope( $scope ) {
		global $wpdb, $affiliatepress_tbl_ap_affiliate_commissions;

		if ( ! isset( $wpdb, $affiliatepress_tbl_ap_affiliate_commissions ) || ! empty( self::$held_commission_snapshot ) ) {
			return;
		}

		$table = $affiliatepress_tbl_ap_affiliate_commissions;
		if ( 'exclude_renewals' === $scope ) {
			$sql = $wpdb->prepare(
				"SELECT ap_commission_id, ap_commission_status FROM {$table} WHERE ap_commission_status = %d AND ap_commission_payment_id = %d AND ap_commission_source = %s AND ap_commission_type = %s",
				1,
				0,
				self::SOURCE,
				'recurring'
			);
		} else {
			$sql = $wpdb->prepare(
				"SELECT ap_commission_id, ap_commission_status FROM {$table} WHERE ap_commission_status = %d AND ap_commission_payment_id = %d AND NOT (ap_commission_source = %s AND ap_commission_type = %s)",
				1,
				0,
				self::SOURCE,
				'recurring'
			);
		}

		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		if ( empty( $rows ) || ! is_array( $rows ) ) {
			return;
		}

		foreach ( $rows as $row ) {
			$commission_id = isset( $row['ap_commission_id'] ) ? (int) $row['ap_commission_id'] : 0;
			if ( $commission_id <= 0 ) {
				continue;
			}

			self::$held_commission_snapshot[ $commission_id ] = (int) ( $row['ap_commission_status'] ?? 1 );
			$wpdb->update(
				$table,
				array( 'ap_commission_status' => 2 ),
				array( 'ap_commission_id' => $commission_id ),
				array( '%d' ),
				array( '%d' )
			);
		}
	}

	/**
	 * Restore commissions that were temporarily held from payout.
	 */
	private static function restore_held_commissions() {
		global $wpdb, $affiliatepress_tbl_ap_affiliate_commissions;

		if ( empty( self::$held_commission_snapshot ) || ! isset( $wpdb, $affiliatepress_tbl_ap_affiliate_commissions ) ) {
			self::$held_commission_snapshot = array();
			return;
		}

		foreach ( self::$held_commission_snapshot as $commission_id => $status ) {
			$wpdb->update(
				$affiliatepress_tbl_ap_affiliate_commissions,
				array( 'ap_commission_status' => (int) $status ),
				array( 'ap_commission_id' => (int) $commission_id ),
				array( '%d' ),
				array( '%d' )
			);
		}

		self::$held_commission_snapshot = array();
	}

	/**
	 * @return string
	 */
	public static function get_affiliatepress_commissions_settings_url() {
		return admin_url( 'admin.php?page=affiliatepress_settings&setting_page=commissions_settings' );
	}

	/**
	 * @return string
	 */
	public static function get_affiliatepress_integrations_settings_url() {
		return admin_url( 'admin.php?page=affiliatepress_settings&setting_page=integrations_settings' );
	}

	/**
	 * Affiliate program data for dashboard/API.
	 *
	 * @param int $user_id User ID.
	 * @return array<string, mixed>
	 */
	public static function get_affiliate_program_data( $user_id = 0 ) {
		$user_id = $user_id ? (int) $user_id : get_current_user_id();

		$payload = array(
			'is_affiliate'          => false,
			'affiliate_id'          => 0,
			'affiliate_link'        => '',
			'subscription_link'     => '',
			'affiliate_dashboard_url' => self::get_affiliate_panel_url(),
		);

		if ( $user_id <= 0 || ! self::is_affiliatepress_active() ) {
			return $payload;
		}

		$affiliate_id = self::get_affiliate_id_for_user( $user_id );
		if ( $affiliate_id <= 0 || ! self::is_valid_affiliate( $affiliate_id ) ) {
			return $payload;
		}

		$payload['is_affiliate']      = true;
		$payload['affiliate_id']      = $affiliate_id;
		$payload['affiliate_link']    = self::get_affiliate_link( $affiliate_id );
		$payload['subscription_link'] = $payload['affiliate_link'];

		return $payload;
	}

	/**
	 * Show AffiliatePress first-purchase commission rate on the affiliate panel (not renewal %).
	 *
	 * @param array<string, mixed> $fields Panel data fields.
	 * @return array<string, mixed>
	 */
	public static function filter_affiliate_panel_data_fields( $fields ) {
		if ( ! is_array( $fields ) ) {
			return $fields;
		}

		$first_rate = self::get_affiliatepress_first_purchase_rate();
		if ( ! empty( $first_rate['label'] ) ) {
			$fields['default_commission_rate'] = (string) $first_rate['label'];
		}

		return $fields;
	}

	/**
	 * Save affiliate referrer on checkout.
	 *
	 * @param WC_Order $order Order.
	 * @param array    $data  Checkout data.
	 */
	public static function capture_affiliate_on_order( $order, $data ) {
		unset( $data );

		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$affiliate_id = self::resolve_affiliate_id();
		if ( $affiliate_id <= 0 ) {
			return;
		}

		$order->update_meta_data( self::META_ORDER_AFFILIATE, $affiliate_id );

		$user_id = (int) $order->get_user_id();
		if ( $user_id > 0 ) {
			update_user_meta( $user_id, self::META_USER_AFFILIATE, $affiliate_id );
		}
	}

	/**
	 * Save affiliate referrer when a new user registers.
	 *
	 * @param int $user_id User ID.
	 */
	public static function capture_affiliate_on_register( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 || get_user_meta( $user_id, self::META_USER_AFFILIATE, true ) ) {
			return;
		}

		$affiliate_id = self::resolve_affiliate_id();
		if ( $affiliate_id <= 0 ) {
			return;
		}

		$affiliate_user_id = self::get_user_id_for_affiliate( $affiliate_id );
		if ( $affiliate_user_id === $user_id ) {
			return;
		}

		update_user_meta( $user_id, self::META_USER_AFFILIATE, $affiliate_id );
	}

	/**
	 * Create initial commission when a referred membership subscription activates.
	 *
	 * @param WC_Subscription $subscription Subscription.
	 */
	public static function maybe_create_subscription_commission( $subscription ) {
		if ( ! is_object( $subscription ) || ! method_exists( $subscription, 'get_id' ) ) {
			return;
		}

		$parent_order = method_exists( $subscription, 'get_parent' ) ? $subscription->get_parent() : null;
		if ( ! $parent_order instanceof WC_Order ) {
			return;
		}

		if ( function_exists( 'wcs_order_contains_renewal' ) && wcs_order_contains_renewal( $parent_order ) ) {
			return;
		}

		$order_id = (int) $parent_order->get_id();
		if ( $order_id <= 0 || $parent_order->get_meta( self::META_COMMISSION_PAID ) ) {
			return;
		}

		$affiliate_id = self::resolve_affiliate_id_for_order( $parent_order );
		if ( $affiliate_id <= 0 ) {
			return;
		}

		self::persist_affiliate_referrer( $parent_order, $affiliate_id );
		$subscription->update_meta_data( self::META_SUBSCRIPTION_AFFILIATE, $affiliate_id );
		$subscription->save();

		$commission_id = self::create_commission_for_order(
			$parent_order,
			$affiliate_id,
			null,
			'subscription'
		);

		if ( $commission_id <= 0 ) {
			return;
		}

		$parent_order->update_meta_data( self::META_COMMISSION_PAID, $commission_id );
		$parent_order->save();

		if ( in_array( $parent_order->get_status(), array( 'processing', 'completed' ), true ) ) {
			self::approve_pending_commission( $order_id );
		}
	}

	/**
	 * Create recurring commission after a subscription renewal payment.
	 *
	 * @param WC_Subscription $subscription   Subscription.
	 * @param WC_Order        $renewal_order  Renewal order.
	 */
	public static function maybe_create_renewal_commission( $subscription, $renewal_order ) {
		if ( ! $subscription instanceof WC_Subscription || ! $renewal_order instanceof WC_Order ) {
			return;
		}

		self::process_renewal_commission( $renewal_order, $subscription );
	}

	/**
	 * Fallback renewal commission handler for completed/processing renewal orders.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function maybe_create_renewal_commission_from_order( $order_id ) {
		if ( ! function_exists( 'wcs_order_contains_renewal' ) || ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order || ! wcs_order_contains_renewal( $order ) ) {
			return;
		}

		$subscriptions = function_exists( 'wcs_get_subscriptions_for_renewal_order' )
			? wcs_get_subscriptions_for_renewal_order( $order )
			: array();

		$subscription = ! empty( $subscriptions ) ? reset( $subscriptions ) : null;
		if ( ! $subscription instanceof WC_Subscription ) {
			return;
		}

		self::process_renewal_commission( $order, $subscription );
	}

	/**
	 * Create affiliate commission for simple-product club membership orders.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function maybe_create_membership_commission_from_order( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( ! in_array( $order->get_status(), array( 'processing', 'completed', 'on-hold' ), true ) ) {
			return;
		}

		if ( ! self::order_contains_membership_product( $order ) ) {
			return;
		}

		$order_id = (int) $order->get_id();
		if ( $order_id <= 0 || $order->get_meta( self::META_COMMISSION_PAID ) ) {
			return;
		}

		if ( function_exists( 'wcs_order_contains_renewal' ) && wcs_order_contains_renewal( $order ) ) {
			return;
		}

		if ( function_exists( 'wcs_order_contains_subscription' ) && wcs_order_contains_subscription( $order ) ) {
			return;
		}

		$affiliate_id = self::resolve_affiliate_id_for_order( $order );
		if ( $affiliate_id <= 0 ) {
			return;
		}

		self::persist_affiliate_referrer( $order, $affiliate_id );

		$user_id    = (int) $order->get_user_id();
		$is_renewal = self::is_membership_renewal_commission_order( $user_id, $order );

		if ( $is_renewal ) {
			if ( ! self::recurring_commissions_enabled() ) {
				return;
			}

			$percent         = self::get_recurring_commission_percent();
			$commission_type = 'recurring';
		} else {
			$percent         = null;
			$commission_type = 'sale';
		}

		$commission_id = self::create_commission_for_order( $order, $affiliate_id, $percent, $commission_type );
		if ( $commission_id <= 0 ) {
			return;
		}

		$order->update_meta_data( self::META_COMMISSION_PAID, $commission_id );
		$order->save();

		self::approve_pending_commission( $order_id );

		if ( 'recurring' === $commission_type ) {
			do_action( 'oilmazing_sfc_affiliate_recurring_commission_created', $commission_id, $affiliate_id, $order_id, null );
		}
	}

	/**
	 * Shared renewal commission logic.
	 *
	 * @param WC_Order        $renewal_order Renewal order.
	 * @param WC_Subscription $subscription  Subscription.
	 */
	private static function process_renewal_commission( $renewal_order, $subscription ) {
		if ( ! self::recurring_commissions_enabled() ) {
			return;
		}

		$order_id = (int) $renewal_order->get_id();
		if ( $order_id <= 0 || $renewal_order->get_meta( self::META_COMMISSION_PAID ) ) {
			return;
		}

		if ( ! self::subscription_contains_membership_product( $subscription ) && ! self::order_contains_membership_product( $renewal_order ) ) {
			return;
		}

		$affiliate_id = self::resolve_affiliate_id_for_subscription( $subscription, $renewal_order );
		self::persist_affiliate_referrer( $renewal_order, $affiliate_id );
		$commission_id = self::create_commission_for_order(
			$renewal_order,
			$affiliate_id,
			self::get_recurring_commission_percent(),
			'recurring'
		);

		if ( $commission_id <= 0 ) {
			return;
		}

		$renewal_order->update_meta_data( self::META_COMMISSION_PAID, $commission_id );
		$renewal_order->save();

		if ( in_array( $renewal_order->get_status(), array( 'processing', 'completed' ), true ) ) {
			self::approve_pending_commission( $order_id );
		}

		do_action( 'oilmazing_sfc_affiliate_recurring_commission_created', $commission_id, $affiliate_id, $order_id, $subscription );
	}

	/**
	 * Insert an AffiliatePress commission for a membership order.
	 *
	 * @param WC_Order   $order           Order.
	 * @param int        $affiliate_id    Affiliate ID.
	 * @param float|null $percent         Commission percent for renewals. Null uses AffiliatePress rules for first purchase.
	 * @param string     $commission_type Commission type.
	 * @return int Commission ID or 0.
	 */
	private static function create_commission_for_order( $order, $affiliate_id, $percent, $commission_type = 'subscription' ) {
		if ( ! $order instanceof WC_Order ) {
			return 0;
		}

		$order_id = (int) $order->get_id();
		$affiliate_id = (int) $affiliate_id;

		if ( $order_id <= 0 || $affiliate_id <= 0 || ! self::is_valid_affiliate( $affiliate_id ) ) {
			return 0;
		}

		if ( ! self::order_contains_membership_product( $order ) ) {
			return 0;
		}

		global $AffiliatePress, $affiliatepress_tracking;

		if ( ! isset( $AffiliatePress, $affiliatepress_tracking ) || ! is_object( $affiliatepress_tracking ) ) {
			return 0;
		}

		$customer_user_id  = (int) $order->get_user_id();
		$affiliate_user_id = self::get_user_id_for_affiliate( $affiliate_id );
		if ( $customer_user_id > 0 && $affiliate_user_id === $customer_user_id ) {
			return 0;
		}

		$billing_email = sanitize_email( (string) $order->get_billing_email() );
		if ( $billing_email && method_exists( $AffiliatePress, 'affiliatepress_affiliate_has_email' ) && $AffiliatePress->affiliatepress_affiliate_has_email( $affiliate_id, $billing_email ) ) {
			return 0;
		}

		if ( method_exists( $AffiliatePress, 'affiliatepress_get_all_commission_by_order_and_source' ) ) {
			$existing = $AffiliatePress->affiliatepress_get_all_commission_by_order_and_source( $order_id, self::SOURCE );
			if ( ! empty( $existing ) ) {
				return 0;
			}
		}

		$amounts = self::calculate_membership_totals( $order, $affiliate_id, $commission_type, $percent );
		if ( $amounts['commission_amount'] <= 0 ) {
			return 0;
		}

		$visit_id = 0;
		if ( method_exists( $affiliatepress_tracking, 'affiliatepress_get_referral_visit' ) ) {
			$visit_id = (int) $affiliatepress_tracking->affiliatepress_get_referral_visit( self::SOURCE, array( 'order_id' => $order_id ) );
		}

		$customer_id = 0;
		if ( method_exists( $AffiliatePress, 'affiliatepress_add_commission_customer' ) ) {
			$customer_id = (int) $AffiliatePress->affiliatepress_add_commission_customer(
				array(
					'email'        => $billing_email,
					'user_id'      => $customer_user_id,
					'first_name'   => sanitize_text_field( (string) $order->get_billing_first_name() ),
					'last_name'    => sanitize_text_field( (string) $order->get_billing_last_name() ),
					'affiliate_id' => $affiliate_id,
				)
			);
		}

		$reference_detail = $amounts['product_names'];
		if ( 'recurring' === $commission_type ) {
			$reference_detail = sprintf(
				/* translators: %s: product names */
				__( 'Monthly renewal: %s', 'oilmazing-sfc' ),
				$amounts['product_names']
			);
		}

		$commission_data = array(
			'ap_affiliates_id'               => $affiliate_id,
			'ap_visit_id'                    => $visit_id,
			'ap_commission_type'             => $commission_type,
			'ap_commission_status'           => 2,
			'ap_commission_reference_id'     => $order_id,
			'ap_commission_reference_detail' => $reference_detail,
			'ap_commission_product_ids'      => $amounts['product_ids'],
			'ap_commission_source'           => self::SOURCE,
			'ap_commission_amount'           => $amounts['commission_amount'],
			'ap_commission_reference_amount' => $amounts['reference_amount'],
			'ap_commission_order_amount'     => $amounts['order_total'],
			'ap_commission_currency'         => method_exists( $AffiliatePress, 'affiliatepress_get_default_currency_code' ) ? $AffiliatePress->affiliatepress_get_default_currency_code() : $order->get_currency(),
			'ap_commission_ip_address'       => method_exists( $AffiliatePress, 'affiliatepress_get_ip_address' ) ? $AffiliatePress->affiliatepress_get_ip_address() : '',
			'ap_customer_id'                 => $customer_id,
			'ap_commission_created_date'     => gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) ),
		);

		$commission_id = (int) $affiliatepress_tracking->affiliatepress_insert_commission( $commission_data, $affiliate_id, $visit_id );
		if ( $commission_id > 0 ) {
			do_action( 'oilmazing_sfc_affiliate_commission_created', $commission_id, $affiliate_id, $order_id, $amounts, $commission_type );
		}

		return $commission_id;
	}

	/**
	 * Approve pending club subscription commissions.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function approve_pending_commission( $order_id ) {
		$order_id = absint( $order_id );
		if ( $order_id <= 0 ) {
			return;
		}

		global $wpdb, $AffiliatePress, $affiliatepress_tracking, $affiliatepress_tbl_ap_affiliate_commissions;

		if ( ! isset( $AffiliatePress, $affiliatepress_tracking ) || ! is_object( $affiliatepress_tracking ) ) {
			return;
		}

		$commissions = $AffiliatePress->affiliatepress_get_all_commission_by_order_and_source(
			$order_id,
			self::SOURCE,
			' AND (ap_commission_status = 2 OR ap_commission_status = 3) '
		);

		if ( empty( $commissions ) || ! is_array( $commissions ) ) {
			return;
		}

		$default_status = $affiliatepress_tracking->affiliatepress_get_default_commission_status();
		$new_status     = ( 'auto' === $default_status ) ? 1 : (int) $default_status;

		foreach ( $commissions as $row ) {
			$commission_id = isset( $row['ap_commission_id'] ) ? (int) $row['ap_commission_id'] : 0;
			if ( $commission_id <= 0 || 2 === $new_status ) {
				continue;
			}

			if ( isset( $affiliatepress_tbl_ap_affiliate_commissions ) ) {
				$wpdb->update(
					$affiliatepress_tbl_ap_affiliate_commissions,
					array(
						'ap_commission_updated_date' => current_time( 'mysql', true ),
						'ap_commission_status'       => $new_status,
					),
					array( 'ap_commission_id' => $commission_id ),
					array( '%s', '%d' ),
					array( '%d' )
				);
			}

			do_action( 'affiliatepress_after_commissions_status_change', $commission_id, $new_status, 2 );
		}
	}

	/**
	 * Link club commissions to WooCommerce orders inside AffiliatePress admin.
	 *
	 * @param int|string $reference_id Commission reference ID.
	 * @param string     $source       Commission source.
	 * @return int|string
	 */
	public static function filter_commission_order_link( $reference_id, $source ) {
		if ( self::SOURCE !== $source ) {
			return $reference_id;
		}

		$order_id = absint( $reference_id );
		if ( $order_id <= 0 ) {
			return $reference_id;
		}

		if ( class_exists( 'Automattic\WooCommerce\Utilities\OrderUtil' ) && Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			$url = admin_url( 'admin.php?page=wc-orders&action=edit&id=' . $order_id );
		} else {
			$url = admin_url( 'post.php?post=' . $order_id . '&action=edit' );
		}

		return '<a target="_blank" class="ap-refrance-link" href="' . esc_url( $url ) . '">' . esc_html( (string) $order_id ) . '</a>';
	}

	/**
	 * Human-readable connection details for admin screens.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_connection_status() {
		global $AffiliatePress, $affiliatepress_tracking;

		$active = self::is_affiliatepress_active();
		$tracking_ready = isset( $affiliatepress_tracking ) && is_object( $affiliatepress_tracking );
		$core_ready = isset( $AffiliatePress ) && is_object( $AffiliatePress );

		return array(
			'connected'        => $active && $tracking_ready && $core_ready,
			'plugin_active'    => $active,
			'tracking_ready'   => $tracking_ready,
			'core_ready'       => $core_ready,
			'source'           => self::SOURCE,
			'cookie_name'      => 'affiliatepress_ref_cookie',
			'panel_url'        => self::get_affiliate_panel_url(),
		);
	}

	/**
	 *
	 * @param WP_REST_Response $response Response.
	 * @param WP_REST_Server   $server   Server.
	 * @param WP_REST_Request  $request  Request.
	 * @return WP_REST_Response
	 */
	public static function enrich_referrals_response( $response, $server, $request ) {
		unset( $server );

		if ( ! $request instanceof WP_REST_Request || ! $response instanceof WP_REST_Response ) {
			return $response;
		}

		if ( ! defined( 'OILMAZING_SFC_REST_NAMESPACE' ) ) {
			return $response;
		}

		$route = (string) $request->get_route();
		if ( false === strpos( $route, '/' . OILMAZING_SFC_REST_NAMESPACE . '/referrals' ) ) {
			return $response;
		}

		$data = $response->get_data();
		if ( ! is_array( $data ) ) {
			return $response;
		}

		$data['affiliate'] = self::get_affiliate_program_data( get_current_user_id() );
		$response->set_data( $data );

		return $response;
	}

	/**
	 * @param int $user_id User ID.
	 * @return bool
	 */
	public static function user_is_affiliate( $user_id ) {
		$data = self::get_affiliate_program_data( $user_id );
		return ! empty( $data['is_affiliate'] );
	}

	/**
	 * Same affiliate link shown on the AffiliatePress member dashboard.
	 *
	 * @param int $affiliate_id Affiliate ID.
	 * @return string
	 */
	public static function get_affiliate_link( $affiliate_id ) {
		global $AffiliatePress;

		$affiliate_id = absint( $affiliate_id );
		if ( $affiliate_id <= 0 || ! isset( $AffiliatePress ) || ! method_exists( $AffiliatePress, 'affiliatepress_get_affiliate_common_link' ) ) {
			return '';
		}

		$link = (string) $AffiliatePress->affiliatepress_get_affiliate_common_link( $affiliate_id );

		return (string) apply_filters( 'affiliatepress_modify_affiliate_link', $link, $affiliate_id );
	}

	/**
	 * @deprecated Use get_affiliate_link().
	 *
	 * @param int $affiliate_id Affiliate ID.
	 * @return string
	 */
	public static function get_club_subscription_link( $affiliate_id ) {
		return self::get_affiliate_link( $affiliate_id );
	}

	/**
	 * @return string
	 */
	public static function get_club_landing_url() {
		$settings = self::get_settings();
		if ( ! empty( $settings['club_landing_url'] ) ) {
			return $settings['club_landing_url'];
		}

		if ( class_exists( 'Oilmazing_SFC_Referrals' ) ) {
			$url = Oilmazing_SFC_Referrals::get_signup_url();
			if ( $url ) {
				return $url;
			}
		}

		if ( class_exists( 'Oilmazing_SFC_Membership' ) ) {
			$membership_settings = Oilmazing_SFC_Membership::get_settings();
			if ( ! empty( $membership_settings['membership_page_url'] ) ) {
				return $membership_settings['membership_page_url'];
			}
		}

		return home_url( '/' );
	}

	/**
	 * @return string
	 */
	public static function get_affiliate_panel_url() {
		global $AffiliatePress;

		if ( isset( $AffiliatePress ) && method_exists( $AffiliatePress, 'affiliatepress_get_settings' ) ) {
			$page_id = (int) $AffiliatePress->affiliatepress_get_settings( 'affiliate_account_page_id', 'affiliate_settings' );
			if ( $page_id > 0 ) {
				$url = get_permalink( $page_id );
				if ( $url ) {
					return (string) $url;
				}
			}
		}

		$page_id = (int) get_option( 'affiliatepress_affiliate_area_page_id', 0 );
		if ( $page_id > 0 ) {
			return (string) get_permalink( $page_id );
		}

		return home_url( '/' );
	}

	/**
	 * @param int $user_id User ID.
	 * @return int
	 */
	private static function get_affiliate_id_for_user( $user_id ) {
		global $AffiliatePress;

		if ( ! isset( $AffiliatePress ) || ! method_exists( $AffiliatePress, 'affiliatepress_get_affiliate_id_by_userid' ) ) {
			return 0;
		}

		return (int) $AffiliatePress->affiliatepress_get_affiliate_id_by_userid( (int) $user_id );
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 * @return int
	 */
	private static function get_user_id_for_affiliate( $affiliate_id ) {
		global $AffiliatePress;

		if ( ! isset( $AffiliatePress ) || ! method_exists( $AffiliatePress, 'affiliatepress_get_affiliate_user_id' ) ) {
			return 0;
		}

		return (int) $AffiliatePress->affiliatepress_get_affiliate_user_id( (int) $affiliate_id );
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 * @return bool
	 */
	private static function is_valid_affiliate( $affiliate_id ) {
		global $affiliatepress_affiliates;

		if ( ! isset( $affiliatepress_affiliates ) || ! is_object( $affiliatepress_affiliates ) || ! method_exists( $affiliatepress_affiliates, 'affiliatepress_is_valid_affiliate' ) ) {
			return $affiliate_id > 0;
		}

		return (bool) $affiliatepress_affiliates->affiliatepress_is_valid_affiliate( (int) $affiliate_id );
	}

	/**
	 * @return int
	 */
	private static function resolve_affiliate_id() {
		global $affiliatepress_tracking;

		if ( isset( $affiliatepress_tracking ) && is_object( $affiliatepress_tracking ) && method_exists( $affiliatepress_tracking, 'affiliatepress_get_referral_affiliate' ) ) {
			$affiliate_id = (int) $affiliatepress_tracking->affiliatepress_get_referral_affiliate( self::SOURCE );
			if ( $affiliate_id > 0 ) {
				return $affiliate_id;
			}
		}

		if ( ! empty( $_COOKIE['affiliatepress_ref_cookie'] ) ) {
			return absint( wp_unslash( $_COOKIE['affiliatepress_ref_cookie'] ) );
		}

		return 0;
	}

	/**
	 * Persist affiliate referrer on the order and customer account.
	 *
	 * @param WC_Order $order        Order.
	 * @param int      $affiliate_id Affiliate ID.
	 */
	private static function persist_affiliate_referrer( $order, $affiliate_id ) {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$affiliate_id = (int) $affiliate_id;
		if ( $affiliate_id <= 0 ) {
			return;
		}

		$order->update_meta_data( self::META_ORDER_AFFILIATE, $affiliate_id );
		$order->save();

		$user_id = (int) $order->get_user_id();
		if ( $user_id > 0 ) {
			update_user_meta( $user_id, self::META_USER_AFFILIATE, $affiliate_id );
		}
	}

	/**
	 * Whether this membership order is a monthly renewal commission (10%), not first purchase.
	 *
	 * Only orders that already received a Scent Freedom Club affiliate commission count as renewals.
	 * A customer who bought membership before without a referral still gets the full AP rate on
	 * their first referred membership purchase.
	 *
	 * @param int      $user_id       Customer user ID.
	 * @param WC_Order $current_order Current order.
	 * @return bool
	 */
	private static function is_membership_renewal_commission_order( $user_id, $current_order ) {
		if ( ! $current_order instanceof WC_Order || ! function_exists( 'wc_get_orders' ) ) {
			return false;
		}

		$current_id = (int) $current_order->get_id();
		$query_args = array(
			'limit'   => 50,
			'orderby' => 'date',
			'order'   => 'ASC',
			'status'  => array( 'processing', 'completed', 'on-hold' ),
			'return'  => 'ids',
		);

		if ( $current_id > 0 ) {
			$query_args['exclude'] = array( $current_id );
		}

		$user_id = (int) $user_id;
		if ( $user_id > 0 ) {
			$query_args['customer_id'] = $user_id;
		} else {
			$email = sanitize_email( (string) $current_order->get_billing_email() );
			if ( '' === $email ) {
				return false;
			}
			$query_args['billing_email'] = $email;
		}

		$order_ids = wc_get_orders( $query_args );
		if ( empty( $order_ids ) || ! is_array( $order_ids ) ) {
			return false;
		}

		foreach ( $order_ids as $order_id ) {
			$order_id = (int) $order_id;
			if ( $order_id <= 0 || $order_id === $current_id ) {
				continue;
			}

			$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			if ( ! self::order_contains_membership_product( $order ) ) {
				continue;
			}

			if ( (int) $order->get_meta( self::META_COMMISSION_PAID ) > 0 ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param WC_Order $order Order.
	 * @return int
	 */
	private static function resolve_affiliate_id_for_order( $order ) {
		$affiliate_id = (int) $order->get_meta( self::META_ORDER_AFFILIATE );
		if ( $affiliate_id > 0 ) {
			return $affiliate_id;
		}

		$user_id = (int) $order->get_user_id();
		if ( $user_id > 0 ) {
			$affiliate_id = (int) get_user_meta( $user_id, self::META_USER_AFFILIATE, true );
			if ( $affiliate_id > 0 ) {
				return $affiliate_id;
			}
		}

		return self::resolve_affiliate_id();
	}

	/**
	 * @param WC_Subscription $subscription Subscription.
	 * @param WC_Order        $renewal_order Optional renewal order.
	 * @return int
	 */
	private static function resolve_affiliate_id_for_subscription( $subscription, $renewal_order = null ) {
		if ( $subscription instanceof WC_Subscription ) {
			$affiliate_id = (int) $subscription->get_meta( self::META_SUBSCRIPTION_AFFILIATE );
			if ( $affiliate_id > 0 ) {
				return $affiliate_id;
			}

			$parent_order = method_exists( $subscription, 'get_parent' ) ? $subscription->get_parent() : null;
			if ( $parent_order instanceof WC_Order ) {
				$affiliate_id = self::resolve_affiliate_id_for_order( $parent_order );
				if ( $affiliate_id > 0 ) {
					return $affiliate_id;
				}
			}

			$customer_user_id = method_exists( $subscription, 'get_user_id' ) ? (int) $subscription->get_user_id() : 0;
			if ( $customer_user_id > 0 ) {
				$affiliate_id = (int) get_user_meta( $customer_user_id, self::META_USER_AFFILIATE, true );
				if ( $affiliate_id > 0 ) {
					return $affiliate_id;
				}
			}
		}

		if ( $renewal_order instanceof WC_Order ) {
			return self::resolve_affiliate_id_for_order( $renewal_order );
		}

		return 0;
	}

	/**
	 * @param WC_Subscription $subscription Subscription.
	 * @return bool
	 */
	private static function subscription_contains_membership_product( $subscription ) {
		if ( ! $subscription instanceof WC_Subscription || ! method_exists( $subscription, 'get_items' ) ) {
			return false;
		}

		foreach ( $subscription->get_items() as $item ) {
			$product_id = method_exists( $item, 'get_product_id' ) ? (int) $item->get_product_id() : 0;
			$variation_id = method_exists( $item, 'get_variation_id' ) ? (int) $item->get_variation_id() : 0;

			if ( ( $product_id && self::is_membership_product_id( $product_id ) ) || ( $variation_id && self::is_membership_product_id( $variation_id ) ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param WC_Order $order Order.
	 * @return bool
	 */
	private static function order_contains_membership_product( $order ) {
		foreach ( $order->get_items() as $item ) {
			$product_id = $item->get_product_id();
			if ( $product_id && self::is_membership_product_id( $product_id ) ) {
				return true;
			}

			$variation_id = method_exists( $item, 'get_variation_id' ) ? (int) $item->get_variation_id() : 0;
			if ( $variation_id && self::is_membership_product_id( $variation_id ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	private static function is_membership_product_id( $product_id ) {
		$product_id = (int) $product_id;
		if ( $product_id <= 0 ) {
			return false;
		}

		if ( class_exists( 'Oilmazing_SFC_Membership' ) ) {
			$settings = Oilmazing_SFC_Membership::get_settings();
			$ids      = array_filter( array_map( 'absint', (array) $settings['product_ids'] ) );
			if ( ! empty( $ids ) && in_array( $product_id, $ids, true ) ) {
				return true;
			}

			$club_plans = isset( $settings['club_plans'] ) && is_array( $settings['club_plans'] ) ? $settings['club_plans'] : array();
			foreach ( $club_plans as $plan ) {
				if ( ! is_array( $plan ) ) {
					continue;
				}

				$plan_product_id = absint( $plan['product_id'] ?? 0 );
				if ( $plan_product_id > 0 && $plan_product_id === $product_id ) {
					return true;
				}

				$plan_slug = sanitize_key( (string) ( $plan['id'] ?? '' ) );
				if ( '' !== $plan_slug ) {
					$cached_product_id = absint( get_option( 'oilmazing_sfc_plan_product_' . $plan_slug, 0 ) );
					if ( $cached_product_id > 0 && $cached_product_id === $product_id ) {
						return true;
					}
				}
			}
		}

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
		if ( ! $product ) {
			return false;
		}

		if ( $product->is_type( array( 'subscription', 'variable-subscription', 'subscription_variation' ) ) ) {
			return true;
		}

		return has_term( array( 'scent-freedom-club', 'sfc-membership', 'membership' ), 'product_tag', $product_id );
	}

	/**
	 * @param WC_Order   $order           Order.
	 * @param int        $affiliate_id    Affiliate ID.
	 * @param string     $commission_type Commission type.
	 * @param float|null $percent         Flat percent for renewals.
	 * @return array<string, mixed>
	 */
	private static function calculate_membership_totals( $order, $affiliate_id = 0, $commission_type = 'subscription', $percent = null ) {
		global $AffiliatePress, $affiliatepress_tracking;

		$affiliate_id        = (int) $affiliate_id;
		$reference_amount    = 0.0;
		$commission_amount   = 0.0;
		$product_ids         = array();
		$product_names       = array();
		$membership_items    = array();
		$exclude_taxes       = true;
		$exclude_shipping    = true;
		$cart_shipping       = 0.0;

		if ( $order instanceof WC_Order ) {
			$cart_shipping = (float) $order->get_shipping_total( 'edit' );
			if ( isset( $AffiliatePress ) && method_exists( $AffiliatePress, 'affiliatepress_get_settings' ) ) {
				$exclude_taxes    = 'true' === (string) $AffiliatePress->affiliatepress_get_settings( 'woocommerce_exclude_taxes', 'integrations_settings' );
				$exclude_shipping = 'true' === (string) $AffiliatePress->affiliatepress_get_settings( 'woocommerce_exclude_shipping', 'integrations_settings' );
			}
			if ( ! $exclude_taxes ) {
				$cart_shipping += (float) $order->get_shipping_tax( 'edit' );
			}
		}

		foreach ( $order->get_items() as $item ) {
			$product_id   = (int) $item->get_product_id();
			$variation_id = method_exists( $item, 'get_variation_id' ) ? (int) $item->get_variation_id() : 0;
			$line_id      = $variation_id > 0 ? $variation_id : $product_id;

			if ( ! self::is_membership_product_id( $line_id ) && ! self::is_membership_product_id( $product_id ) ) {
				continue;
			}

			$line_amount = (float) $item->get_total( 'edit' );
			if ( ! $exclude_taxes ) {
				$line_amount += (float) $item->get_total_tax( 'edit' );
			}

			$membership_items[] = array(
				'item'         => $item,
				'line_id'      => $line_id,
				'product_id'   => $product_id,
				'line_amount'  => $line_amount,
				'product_name' => $item->get_name(),
				'quantity'     => method_exists( $item, 'get_quantity' ) ? (int) $item->get_quantity() : 1,
			);
			$reference_amount  += $line_amount;
			$product_ids[]      = (string) $line_id;
			$product_names[]    = $item->get_name();
		}

		if ( empty( $membership_items ) ) {
			return array(
				'reference_amount'  => 0.0,
				'commission_amount' => 0.0,
				'product_ids'       => '',
				'product_names'     => '',
				'order_total'       => $order instanceof WC_Order ? (float) $order->get_total( 'edit' ) : 0.0,
			);
		}

		if ( 'recurring' === $commission_type && null !== $percent ) {
			$commission_amount = round( ( $reference_amount * (float) $percent ) / 100, wc_get_price_decimals() );
		} elseif ( isset( $affiliatepress_tracking ) && is_object( $affiliatepress_tracking ) && $affiliate_id > 0 ) {
			$commission_basis = $affiliatepress_tracking->affiliatepress_is_commission_basis_per_order() ? 'per_order' : 'per_product';
			$order_currency   = $order instanceof WC_Order ? $order->get_currency( 'edit' ) : '';
			$order_id         = $order instanceof WC_Order ? (int) $order->get_id() : 0;

			if ( 'per_order' === $commission_basis ) {
				$order_reference_amount = $reference_amount;
				if ( $exclude_shipping && $order instanceof WC_Order && count( $membership_items ) > 0 ) {
					$order_reference_amount -= $cart_shipping * ( count( $membership_items ) / max( 1, count( $order->get_items() ) ) );
				}

				$args = array(
					'origin'           => 'woocommerce',
					'type'             => 'sale',
					'affiliate_id'     => $affiliate_id,
					'product_id'       => 0,
					'order_id'         => $order_id,
					'commission_basis' => 'per_order',
					'quntity'          => 1,
				);
				$rules             = $affiliatepress_tracking->affiliatepress_calculate_commission_amount( max( 0, $order_reference_amount ), $order_currency, $args );
				$commission_amount = (float) ( $rules['commission_amount'] ?? 0 );
			} else {
				foreach ( $membership_items as $membership_item ) {
					$item_amount = $membership_item['line_amount'];
					if ( ! $exclude_shipping && count( $membership_items ) > 0 ) {
						$item_amount += $cart_shipping / count( $membership_items );
					}

					$product = function_exists( 'wc_get_product' ) ? wc_get_product( $membership_item['line_id'] ) : null;
					$ap_type = ( $product && $product->is_type( array( 'subscription', 'variable-subscription', 'subscription_variation' ) ) ) ? 'subscription' : 'sale';

					$args = array(
						'origin'           => 'woocommerce',
						'type'             => $ap_type,
						'affiliate_id'     => $affiliate_id,
						'product_id'       => $membership_item['line_id'],
						'order_id'         => $order_id,
						'commission_basis' => 'per_product',
						'quntity'          => max( 1, $membership_item['quantity'] ),
					);
					$rules              = $affiliatepress_tracking->affiliatepress_calculate_commission_amount( max( 0, $item_amount ), $order_currency, $args );
					$commission_amount += (float) ( $rules['commission_amount'] ?? 0 );
				}
				$commission_amount = round( $commission_amount, wc_get_price_decimals() );
			}
		} else {
			$fallback_percent  = null === $percent ? (float) self::get_affiliatepress_first_purchase_rate()['percent'] : (float) $percent;
			$commission_amount = round( ( $reference_amount * $fallback_percent ) / 100, wc_get_price_decimals() );
		}

		return array(
			'reference_amount'  => $reference_amount,
			'commission_amount' => $commission_amount,
			'product_ids'       => implode( ',', $product_ids ),
			'product_names'     => implode( ', ', $product_names ),
			'order_total'       => $order instanceof WC_Order ? (float) $order->get_total( 'edit' ) : 0.0,
		);
	}
}
