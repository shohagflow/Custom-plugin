<?php
/**
 * Support inbox helpers for member support conversations.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Support
 */
class Oilmazing_SFC_Support {

	/**
	 * @return bool
	 */
	public static function is_available() {
		return class_exists( 'Oilmazing_SFC_Messages' );
	}

	/**
	 * Capability required for the Support admin menu.
	 *
	 * @return string
	 */
	public static function get_menu_capability() {
		return class_exists( 'WooCommerce' ) ? 'manage_woocommerce' : 'manage_options';
	}

	/**
	 * @param int $user_id Optional user ID.
	 * @return bool
	 */
	public static function user_can_manage( $user_id = 0 ) {
		$user_id = $user_id ? (int) $user_id : get_current_user_id();

		if ( $user_id <= 0 ) {
			return false;
		}

		return user_can( $user_id, 'manage_options' ) || user_can( $user_id, 'manage_woocommerce' );
	}

	/**
	 * @return string
	 */
	public static function conversations_table() {
		return class_exists( 'Oilmazing_SFC_Messages' )
			? Oilmazing_SFC_Messages::conversations_table()
			: '';
	}

	/**
	 * @return string
	 */
	public static function messages_table() {
		return class_exists( 'Oilmazing_SFC_Messages' )
			? Oilmazing_SFC_Messages::messages_table()
			: '';
	}

	/**
	 * Ensure message tables exist.
	 */
	public static function maybe_install() {
		if ( class_exists( 'Oilmazing_SFC_Messages' ) ) {
			Oilmazing_SFC_Messages::maybe_install_tables();
		}
	}

	/**
	 * Total unread member messages for admins.
	 *
	 * @param int $admin_id Admin user ID.
	 * @return int
	 */
	public static function get_admin_unread_count( $admin_id = 0 ) {
		global $wpdb;

		if ( ! self::is_available() ) {
			return 0;
		}

		unset( $admin_id );

		$conversations = self::conversations_table();
		$messages      = self::messages_table();

		return (int) $wpdb->get_var(
			"SELECT COUNT(m.id) FROM {$messages} m
			INNER JOIN {$conversations} c ON c.id = m.conversation_id
			WHERE c.is_support = 1 AND m.sender_id = c.user_one_id AND m.is_read = 0"
		);
	}

	/**
	 * Unread support summary for admin notifications.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_unread_summary() {
		global $wpdb;

		$count = self::get_admin_unread_count();
		$latest = null;

		if ( $count > 0 && self::is_available() ) {
			$conversations = self::conversations_table();
			$messages      = self::messages_table();

			$row = $wpdb->get_row(
				"SELECT m.body, m.created_at, c.id AS conversation_id, c.user_one_id
				FROM {$messages} m
				INNER JOIN {$conversations} c ON c.id = m.conversation_id
				WHERE c.is_support = 1 AND m.sender_id = c.user_one_id AND m.is_read = 0
				ORDER BY m.id DESC
				LIMIT 1",
				ARRAY_A
			);

			if ( $row ) {
				$member = get_userdata( (int) $row['user_one_id'] );
				$latest = array(
					'conversation_id' => (int) $row['conversation_id'],
					'member_name'     => $member ? $member->display_name : __( 'Member', 'oilmazing-sfc' ),
					'preview'         => wp_trim_words( wp_strip_all_tags( (string) $row['body'] ), 14, '…' ),
					'time_label'      => self::format_time_label( $row['created_at'] ),
					'url'             => add_query_arg(
						'conversation',
						(int) $row['conversation_id'],
						admin_url( 'admin.php?page=oilmazing-support' )
					),
				);
			}
		}

		return array(
			'unread_total' => $count,
			'latest'       => $latest,
			'inbox_url'    => admin_url( 'admin.php?page=oilmazing-support' ),
		);
	}

	/**
	 * List all support conversations for the admin inbox.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_inbox() {
		global $wpdb;

		if ( ! self::is_available() ) {
			return array();
		}

		$admin_id      = get_current_user_id();
		$conversations = self::conversations_table();
		$messages      = self::messages_table();

		$rows = $wpdb->get_results(
			"SELECT * FROM {$conversations} WHERE is_support = 1 ORDER BY last_message_at DESC, id DESC",
			ARRAY_A
		);

		$items = array();

		foreach ( (array) $rows as $row ) {
			$member_id = (int) $row['user_one_id'];
			$member    = get_userdata( $member_id );
			if ( ! $member ) {
				continue;
			}

			$conversation_id = (int) $row['id'];
			$last_message    = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT body, created_at, sender_id FROM {$messages}
					WHERE conversation_id = %d ORDER BY id DESC LIMIT 1",
					$conversation_id
				),
				ARRAY_A
			);

			$unread = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$messages}
					WHERE conversation_id = %d AND sender_id = %d AND is_read = 0",
					$conversation_id,
					$member_id
				)
			);

			$items[] = array(
				'id'              => $conversation_id,
				'member_id'       => $member_id,
				'member_name'     => $member->display_name,
				'member_email'    => $member->user_email,
				'member_avatar'   => get_avatar_url( $member_id, array( 'size' => 96 ) ),
				'preview'         => $last_message ? wp_strip_all_tags( $last_message['body'] ) : __( 'No messages yet', 'oilmazing-sfc' ),
				'last_message_at' => $last_message['created_at'] ?? $row['last_message_at'],
				'last_from_admin' => $last_message && (int) $last_message['sender_id'] === $admin_id,
				'unread'          => $unread,
				'time_label'      => self::format_time_label( $last_message['created_at'] ?? $row['last_message_at'] ),
			);
		}

		return $items;
	}

	/**
	 * Search members by name or email for admin outreach.
	 *
	 * @param string $query Search query.
	 * @param int    $limit Result limit.
	 * @return array<int, array<string, mixed>>
	 */
	public static function search_members( $query, $limit = 8 ) {
		$query = trim( (string) $query );
		if ( strlen( $query ) < 2 ) {
			return array();
		}

		$limit   = max( 1, min( 20, (int) $limit ) );
		$members = array();

		if ( class_exists( 'Oilmazing_SFC_Members_Admin' ) ) {
			$result = Oilmazing_SFC_Members_Admin::query_members(
				array(
					'search'   => $query,
					'paged'    => 1,
					'per_page' => $limit,
				)
			);

			foreach ( (array) ( $result['members'] ?? array() ) as $member ) {
				$members[] = self::format_member_search_result( $member );
			}

			return $members;
		}

		$user_query = new WP_User_Query(
			array(
				'number'         => $limit,
				'search'         => '*' . $query . '*',
				'search_columns' => array( 'user_login', 'user_email', 'display_name' ),
				'orderby'        => 'display_name',
				'order'          => 'ASC',
				'fields'         => 'all',
			)
		);

		foreach ( (array) $user_query->get_results() as $user ) {
			if ( ! $user instanceof WP_User ) {
				continue;
			}

			if ( self::user_can_manage( (int) $user->ID ) ) {
				continue;
			}

			$members[] = self::format_member_search_result(
				array(
					'id'                 => (int) $user->ID,
					'name'               => $user->display_name ? $user->display_name : $user->user_login,
					'email'              => $user->user_email,
					'subscription_label' => '',
					'avatar_url'         => get_avatar_url( $user->ID, array( 'size' => 96 ) ),
				)
			);
		}

		return $members;
	}

	/**
	 * Normalize a member row for search results.
	 *
	 * @param array<string, mixed> $member Member row.
	 * @return array<string, mixed>
	 */
	private static function format_member_search_result( $member ) {
		$member_id = (int) ( $member['id'] ?? 0 );

		return array(
			'id'                 => $member_id,
			'name'               => (string) ( $member['name'] ?? '' ),
			'email'              => (string) ( $member['email'] ?? '' ),
			'subscription_label' => (string) ( $member['subscription_label'] ?? '' ),
			'avatar_url'         => (string) ( $member['avatar_url'] ?? get_avatar_url( $member_id, array( 'size' => 96 ) ) ),
			'conversation_id'    => self::find_conversation_id_for_member( $member_id ),
		);
	}

	/**
	 * Find an existing support conversation for a member.
	 *
	 * @param int $member_id Member user ID.
	 * @return int
	 */
	public static function find_conversation_id_for_member( $member_id ) {
		global $wpdb;

		$member_id = (int) $member_id;
		if ( $member_id <= 0 || ! self::is_available() ) {
			return 0;
		}

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id FROM ' . self::conversations_table() . ' WHERE user_one_id = %d AND user_two_id = 0 AND is_support = 1 LIMIT 1',
				$member_id
			)
		);
	}

	/**
	 * Open or create a support conversation with a member.
	 *
	 * @param int $member_id Member user ID.
	 * @return array<string, mixed>|WP_Error
	 */
	public static function open_member_conversation( $member_id ) {
		if ( ! self::user_can_manage() ) {
			return new WP_Error( 'oilmazing_sfc_forbidden', __( 'You are not allowed to message members.', 'oilmazing-sfc' ), array( 'status' => 403 ) );
		}

		$member_id = (int) $member_id;
		$member    = get_userdata( $member_id );

		if ( ! $member || ! $member->exists() ) {
			return new WP_Error( 'oilmazing_sfc_member_not_found', __( 'Member not found.', 'oilmazing-sfc' ), array( 'status' => 404 ) );
		}

		if ( self::user_can_manage( $member_id ) ) {
			return new WP_Error( 'oilmazing_sfc_invalid_member', __( 'Please choose a club member, not a store manager or administrator.', 'oilmazing-sfc' ), array( 'status' => 400 ) );
		}

		if ( ! class_exists( 'Oilmazing_SFC_Messages' ) ) {
			return new WP_Error( 'oilmazing_sfc_messages_unavailable', __( 'Messaging is not available.', 'oilmazing-sfc' ), array( 'status' => 500 ) );
		}

		$conversation = Oilmazing_SFC_Messages::get_or_create_support_conversation( $member_id );
		if ( ! $conversation || empty( $conversation['id'] ) ) {
			return new WP_Error( 'oilmazing_sfc_conversation_failed', __( 'Could not open a support conversation.', 'oilmazing-sfc' ), array( 'status' => 500 ) );
		}

		$conversation_id = (int) $conversation['id'];

		return array(
			'conversation_id' => $conversation_id,
			'member'          => array(
				'id'         => $member_id,
				'name'       => $member->display_name,
				'email'      => $member->user_email,
				'avatar_url' => get_avatar_url( $member_id, array( 'size' => 96 ) ),
			),
			'redirect_url'    => add_query_arg(
				'conversation',
				$conversation_id,
				admin_url( 'admin.php?page=oilmazing-support' )
			),
		);
	}

	/**
	 * Fetch a support conversation row.
	 *
	 * @param int $conversation_id Conversation ID.
	 * @return array<string, mixed>|null
	 */
	public static function get_conversation( $conversation_id ) {
		global $wpdb;

		$conversation_id = (int) $conversation_id;
		if ( $conversation_id <= 0 || ! self::is_available() ) {
			return null;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::conversations_table() . ' WHERE id = %d AND is_support = 1 LIMIT 1',
				$conversation_id
			),
			ARRAY_A
		);

		return $row ?: null;
	}

	/**
	 * Messages for admin thread view.
	 *
	 * @param int $conversation_id Conversation ID.
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_thread_messages( $conversation_id ) {
		global $wpdb;

		$conversation = self::get_conversation( $conversation_id );
		if ( ! $conversation ) {
			return array();
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, sender_id, body, created_at FROM ' . self::messages_table() . '
				WHERE conversation_id = %d ORDER BY id ASC',
				$conversation_id
			),
			ARRAY_A
		);

		$messages = array();

		foreach ( (array) $rows as $row ) {
			$sender_id   = (int) $row['sender_id'];
			$is_admin    = self::user_can_manage( $sender_id );
			$sender      = get_userdata( $sender_id );
			$messages[]  = array(
				'id'          => (int) $row['id'],
				'sender_id'   => $sender_id,
				'sender_name' => $sender ? ( $sender->display_name ? $sender->display_name : $sender->user_login ) : __( 'Support', 'oilmazing-sfc' ),
				'is_admin'    => $is_admin,
				'body'        => wp_strip_all_tags( $row['body'] ),
				'time'        => mysql2date( get_option( 'time_format' ), $row['created_at'] ),
				'date'        => mysql2date( get_option( 'date_format' ), $row['created_at'] ),
			);
		}

		return $messages;
	}

	/**
	 * Mark member messages as read for the current admin.
	 *
	 * @param int $conversation_id Conversation ID.
	 * @return bool
	 */
	public static function mark_read( $conversation_id ) {
		global $wpdb;

		$conversation_id = (int) $conversation_id;
		$conversation    = self::get_conversation( $conversation_id );
		if ( ! $conversation ) {
			return false;
		}

		$member_id = (int) $conversation['user_one_id'];

		$wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . self::messages_table() . '
				SET is_read = 1
				WHERE conversation_id = %d AND sender_id = %d AND is_read = 0',
				$conversation_id,
				$member_id
			)
		);

		return true;
	}

	/**
	 * Send a support reply to a member conversation.
	 *
	 * @param int    $conversation_id Conversation ID.
	 * @param string $body            Message body.
	 * @return array<string, mixed>|WP_Error
	 */
	public static function send_reply( $conversation_id, $body ) {
		global $wpdb;

		if ( ! self::user_can_manage() ) {
			return new WP_Error( 'oilmazing_sfc_forbidden', __( 'You are not allowed to reply.', 'oilmazing-sfc' ), array( 'status' => 403 ) );
		}

		$conversation = self::get_conversation( $conversation_id );
		if ( ! $conversation ) {
			return new WP_Error( 'oilmazing_sfc_invalid_conversation', __( 'Conversation not found.', 'oilmazing-sfc' ), array( 'status' => 404 ) );
		}

		$body = trim( wp_strip_all_tags( (string) $body ) );
		if ( '' === $body ) {
			return new WP_Error( 'oilmazing_sfc_empty_message', __( 'Message cannot be empty.', 'oilmazing-sfc' ), array( 'status' => 400 ) );
		}

		if ( strlen( $body ) > 2000 ) {
			return new WP_Error( 'oilmazing_sfc_message_too_long', __( 'Message is too long.', 'oilmazing-sfc' ), array( 'status' => 400 ) );
		}

		$admin_id = get_current_user_id();
		$now      = current_time( 'mysql', true );

		$inserted = $wpdb->insert(
			self::messages_table(),
			array(
				'conversation_id' => $conversation_id,
				'sender_id'       => $admin_id,
				'body'            => $body,
				'is_read'         => 0,
				'created_at'      => $now,
			),
			array( '%d', '%d', '%s', '%d', '%s' )
		);

		if ( ! $inserted ) {
			return new WP_Error( 'oilmazing_sfc_message_failed', __( 'Could not send reply.', 'oilmazing-sfc' ), array( 'status' => 500 ) );
		}

		$wpdb->update(
			self::conversations_table(),
			array( 'last_message_at' => $now ),
			array( 'id' => $conversation_id ),
			array( '%s' ),
			array( '%d' )
		);

		$admin = get_userdata( $admin_id );

		return array(
			'id'          => (int) $wpdb->insert_id,
			'sender_id'   => $admin_id,
			'sender_name' => $admin ? ( $admin->display_name ? $admin->display_name : $admin->user_login ) : __( 'Support', 'oilmazing-sfc' ),
			'is_admin'    => true,
			'body'        => $body,
			'time'        => mysql2date( get_option( 'time_format' ), $now ),
			'date'        => mysql2date( get_option( 'date_format' ), $now ),
		);
	}

	/**
	 * @param string|null $datetime MySQL datetime.
	 * @return string
	 */
	private static function format_time_label( $datetime ) {
		if ( empty( $datetime ) ) {
			return '';
		}

		$timestamp = strtotime( $datetime . ' UTC' );
		if ( ! $timestamp ) {
			return '';
		}

		$diff = time() - $timestamp;

		if ( $diff < 60 ) {
			return __( 'Just now', 'oilmazing-sfc' );
		}
		if ( $diff < 3600 ) {
			return sprintf(
				/* translators: %d: minutes */
				_n( '%d min ago', '%d mins ago', max( 1, (int) floor( $diff / 60 ) ), 'oilmazing-sfc' ),
				max( 1, (int) floor( $diff / 60 ) )
			);
		}
		if ( $diff < 86400 ) {
			return sprintf(
				/* translators: %d: hours */
				_n( '%d hour ago', '%d hours ago', max( 1, (int) floor( $diff / 3600 ) ), 'oilmazing-sfc' ),
				max( 1, (int) floor( $diff / 3600 ) )
			);
		}

		return mysql2date( 'M j, g:i A', gmdate( 'Y-m-d H:i:s', $timestamp ) );
	}
}
