<?php
/**
 * Universal cart summary UI: discount tags for Addons, Elementor, and WooCommerce carts.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Cart_Summary_UI
 */
class Oilmazing_SFC_Cart_Summary_UI {

	const AJAX_ACTION = 'oilmazing_sfc_cart_summary_ui';

	const NONCE_ACTION = 'oilmazing_sfc_cart_summary_ui';

	/**
	 * Register hooks.
	 */
	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		add_action( 'wp_ajax_' . self::AJAX_ACTION, array( __CLASS__, 'ajax_summary' ) );
		add_action( 'wp_ajax_nopriv_' . self::AJAX_ACTION, array( __CLASS__, 'ajax_summary' ) );
		add_filter( 'woocommerce_add_to_cart_fragments', array( __CLASS__, 'cart_summary_fragments' ), 40 );
		add_action( 'woocommerce_widget_shopping_cart_before_buttons', array( __CLASS__, 'render_widget_discount_row' ), 5 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 100000 );
		add_action( 'wp', array( __CLASS__, 'register_late_fragments' ), 20 );
	}

	/**
	 * Register after VillaTheme Cart All In One (also uses PHP_INT_MAX).
	 */
	public static function register_late_fragments() {
		add_filter( 'woocommerce_add_to_cart_fragments', array( __CLASS__, 'cart_summary_fragments_late' ), PHP_INT_MAX );
	}

	/**
	 * AJAX summary for all cart sidebars.
	 */
	public static function ajax_summary() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			wp_send_json_error(
				array(
					'message' => __( 'Cart is unavailable.', 'oilmazing-sfc' ),
				),
				400
			);
		}

		wp_send_json_success( self::get_summary_payload() );
	}

	/**
	 * @param array<string,string> $fragments Fragments.
	 * @return array<string,string>
	 */
	public static function cart_summary_fragments( $fragments ) {
		$summary = self::get_summary_payload();

		$fragments['.addons-cart__count']                 = '<sup class="addons-cart__count">' . esc_html( $summary['count'] ) . '</sup>';
		$fragments['.addons-cart__summary-count']         = self::render_addons_count_html( $summary );
		$fragments['.addons-cart__summary-subtotal']      = self::render_addons_subtotal_html( $summary );
		$fragments['.addons-cart__summary-discount']      = esc_html( $summary['discount'] );
		$fragments['.addons-cart__summary-total']         = '<dd class="addons-cart__summary-total">' . esc_html( $summary['total'] ) . '</dd>';
		$fragments['.addons-cart__summary-row--discount']   = self::render_addons_discount_row_html( $summary );
		$fragments['.elementor-menu-cart__subtotal']      = self::render_elementor_subtotal_html( $summary );
		$fragments['p.woocommerce-mini-cart__total']      = self::render_wc_mini_cart_total_html( $summary );
		$fragments['.oilmazing-sfc-cart-discount-row']    = self::render_discount_row_markup( $summary );

		if ( ! empty( $summary['has_discount'] ) ) {
			$fragments['.elementor-menu-cart__toggle_button span.elementor-button-text'] = '<span class="elementor-button-text">' . esc_html( $summary['total'] ) . '</span>';
		}

		if ( isset( $fragments['div.widget_shopping_cart_content'] ) ) {
			$fragments['div.widget_shopping_cart_content'] = self::inject_discount_into_widget_content(
				$fragments['div.widget_shopping_cart_content'],
				$summary
			);
		}

		return $fragments;
	}

	/**
	 * Late fragments for VillaTheme WooCommerce Cart All In One sidebar cart.
	 *
	 * @param array<string,string> $fragments Fragments.
	 * @return array<string,string>
	 */
	public static function cart_summary_fragments_late( $fragments ) {
		if ( ! self::is_viwcaio_active() ) {
			return $fragments;
		}

		$summary = self::get_summary_payload();

		$fragments['.vi-wcaio-sidebar-cart-footer-cart_total1'] = self::render_viwcaio_cart_total1_html( $summary );

		return $fragments;
	}

	/**
	 * Discount row for default WooCommerce mini cart widgets.
	 */
	public static function render_widget_discount_row() {
		$summary = self::get_summary_payload();
		if ( empty( $summary['has_discount'] ) ) {
			return;
		}

		echo self::render_discount_row_markup( $summary ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function get_summary_payload() {
		$count_raw = self::get_cart_count();
		$is_empty  = $count_raw <= 0;

		if ( $is_empty ) {
			return array(
				'count'            => self::format_count( 0 ),
				'count_raw'        => 0,
				'subtotal'         => self::format_money( 0 ),
				'subtotal_raw'     => 0.0,
				'discount'         => self::format_money( 0 ),
				'discount_raw'     => 0.0,
				'discount_percent' => 0.0,
				'total'            => self::format_money( 0 ),
				'total_raw'        => 0.0,
				'has_discount'     => false,
				'is_empty'         => true,
			);
		}

		WC()->cart->calculate_totals();

		$total_raw = (float) WC()->cart->get_total( 'edit' );

		if ( class_exists( 'Oilmazing_Bundle_Cart' ) ) {
			$bundle_summary = Oilmazing_Bundle_Cart::get_checkout_summary();

			if ( ! empty( $bundle_summary['has_bundle'] ) && (float) $bundle_summary['savings'] > 0 ) {
				$discounted_subtotal = (float) $bundle_summary['cart_subtotal'];

				return array(
					'count'               => self::format_count( $count_raw ),
					'count_raw'           => $count_raw,
					'subtotal'            => self::format_money( $discounted_subtotal ),
					'subtotal_raw'        => $discounted_subtotal,
					'discount'            => self::format_discount( (float) $bundle_summary['savings'] ),
					'discount_raw'        => (float) $bundle_summary['savings'],
					'discount_percent'    => 0.0,
					'total'               => self::format_money( $total_raw ),
					'total_raw'           => $total_raw,
					'has_discount'        => true,
					'uses_bundle_pricing' => true,
					'is_empty'            => false,
				);
			}
		}

		$subtotal_raw = (float) WC()->cart->get_subtotal();
		$discount_raw = self::get_cart_discount_total();

		return array(
			'count'              => self::format_count( $count_raw ),
			'count_raw'          => $count_raw,
			'subtotal'           => self::format_money( $subtotal_raw ),
			'subtotal_raw'       => $subtotal_raw,
			'discount'           => self::format_discount( $discount_raw ),
			'discount_raw'       => $discount_raw,
			'discount_percent'   => 0.0,
			'total'              => self::format_money( $total_raw ),
			'total_raw'          => $total_raw,
			'has_discount'       => $discount_raw > 0,
			'uses_bundle_pricing'=> false,
			'is_empty'           => false,
		);
	}

	/**
	 * @param array<string,mixed> $summary Summary payload.
	 * @return string
	 */
	public static function render_elementor_subtotal_html( $summary ) {
		$amount = self::get_discounted_display_amount( $summary );

		$html  = '<div class="elementor-menu-cart__subtotal oilmazing-sfc-cart-subtotal-wrap">';
		$html .= '<strong>' . esc_html__( 'Subtotal', 'woocommerce' ) . ':</strong> ';
		$html .= '<span class="oilmazing-sfc-cart-subtotal-amount">' . esc_html( $amount ) . '</span>';
		$html .= self::render_discount_row_markup( $summary );
		$html .= '</div>';

		return $html;
	}

	/**
	 * @param array<string,mixed> $summary Summary payload.
	 * @return string
	 */
	public static function render_viwcaio_cart_total1_html( $summary ) {
		$mode   = self::get_viwcaio_footer_mode();
		$amount = self::get_viwcaio_display_amount( $summary, $mode );

		$html  = '<div class="vi-wcaio-sidebar-cart-footer-cart_total1 vi-wcaio-sidebar-cart-footer-cart_total1-' . esc_attr( $mode ) . ' oilmazing-sfc-cart-subtotal-wrap">';
		$html .= '<span class="oilmazing-sfc-cart-subtotal-amount">' . esc_html( $amount ) . '</span>';
		$html .= '</div>';

		return $html;
	}

	/**
	 * @param array<string,mixed> $summary Summary payload.
	 * @param string              $mode    Footer display mode.
	 * @return string
	 */
	private static function get_viwcaio_display_amount( $summary, $mode ) {
		if ( 'total' === $mode ) {
			return $summary['total'];
		}

		return self::get_discounted_display_amount( $summary );
	}

	/**
	 * @param array<string,mixed> $summary Summary payload.
	 * @return string
	 */
	private static function get_discounted_display_amount( $summary ) {
		if ( ! empty( $summary['uses_bundle_pricing'] ) ) {
			return $summary['subtotal'];
		}

		if ( ! empty( $summary['has_discount'] ) ) {
			return $summary['total'];
		}

		return $summary['subtotal'];
	}

	/**
	 * @param array<string,mixed> $summary Summary payload.
	 * @return string
	 */
	public static function render_wc_mini_cart_total_html( $summary ) {
		$html  = '<p class="woocommerce-mini-cart__total total oilmazing-sfc-cart-subtotal-wrap">';
		$html .= '<strong>' . esc_html__( 'Subtotal', 'woocommerce' ) . ':</strong> ';
		$html .= '<span class="oilmazing-sfc-cart-subtotal-line">';
		$html .= '<span class="oilmazing-sfc-cart-subtotal-amount amount">' . esc_html( $summary['subtotal'] ) . '</span>';

		if ( ! empty( $summary['has_discount'] ) && empty( $summary['uses_bundle_pricing'] ) ) {
			if ( ! empty( $summary['discount'] ) ) {
				$html .= '<span class="oilmazing-sfc-cart-discount-tag oilmazing-sfc-cart-discount-tag--amount">' . esc_html( $summary['discount'] ) . '</span>';
			}
		}

		$html .= '</span>';
		$html .= '</p>';

		return $html;
	}

	/**
	 * @param array<string,mixed> $summary Summary payload.
	 * @return string
	 */
	public static function render_discount_row_markup( $summary ) {
		if ( empty( $summary['has_discount'] ) ) {
			return '<p class="oilmazing-sfc-cart-discount-row" hidden></p>';
		}

		$html  = '<p class="oilmazing-sfc-cart-discount-row">';
		$html .= '<span class="oilmazing-sfc-cart-discount-row__label">';
		$html .= esc_html__( 'Discount', 'oilmazing-sfc' );
		$html .= '</span>';
		$html .= '<span class="oilmazing-sfc-cart-discount-row__amount">' . esc_html( $summary['discount'] ) . '</span>';
		$html .= '</p>';

		return $html;
	}

	/**
	 * @param string              $html    Widget cart HTML.
	 * @param array<string,mixed> $summary Summary payload.
	 * @return string
	 */
	private static function inject_discount_into_widget_content( $html, $summary ) {
		$discount_row = self::render_discount_row_markup( $summary );

		if ( false !== strpos( $html, 'woocommerce-mini-cart__buttons' ) && false === strpos( $html, 'oilmazing-sfc-cart-discount-row' ) && false === strpos( $html, 'elementor-menu-cart__main' ) ) {
			$replacement = $discount_row . '<p class="woocommerce-mini-cart__buttons buttons">';
			$html        = preg_replace( '/<p class="woocommerce-mini-cart__buttons buttons">/', $replacement, $html, 1 );
		}

		return $html;
	}

	/**
	 * @param array<string,mixed> $summary Summary payload.
	 * @return string
	 */
	private static function render_addons_count_html( $summary ) {
		$html = '<dd class="addons-cart__summary-count">' . esc_html( $summary['count'] );

		if ( ! empty( $summary['has_discount'] ) && ! empty( $summary['discount'] ) ) {
			$html .= '<span class="oilmazing-sfc-cart-discount-tag oilmazing-sfc-cart-discount-tag--count">' . esc_html( $summary['discount'] ) . '</span>';
		}

		$html .= '</dd>';

		return $html;
	}

	/**
	 * @param array<string,mixed> $summary Summary payload.
	 * @return string
	 */
	private static function render_addons_subtotal_html( $summary ) {
		$html = '<dd class="addons-cart__summary-subtotal"><span class="oilmazing-sfc-cart-subtotal-amount">' . esc_html( $summary['subtotal'] ) . '</span>';

		if ( ! empty( $summary['has_discount'] ) && empty( $summary['uses_bundle_pricing'] ) ) {
			if ( ! empty( $summary['discount'] ) ) {
				$html .= '<span class="oilmazing-sfc-cart-discount-tag oilmazing-sfc-cart-discount-tag--amount">' . esc_html( $summary['discount'] ) . '</span>';
			}
		}

		$html .= '</dd>';

		return $html;
	}

	/**
	 * @param array<string,mixed> $summary Summary payload.
	 * @return string
	 */
	private static function render_addons_discount_row_html( $summary ) {
		$hidden = empty( $summary['has_discount'] ) ? ' style="display:none;"' : '';

		$html  = '<div class="addons-cart__summary-row addons-cart__summary-row--discount"' . $hidden . '>';
		$html .= '<dt>';
		$html .= esc_html__( 'Discount', 'oilmazing-sfc' );
		$html .= '</dt>';
		$html .= '<dd class="addons-cart__summary-discount">' . esc_html( $summary['discount'] ) . '</dd>';
		$html .= '</div>';

		return $html;
	}

	/**
	 * @return bool
	 */
	private static function is_viwcaio_active() {
		return class_exists( 'VI_WOO_CART_ALL_IN_ONE_Frontend' ) || class_exists( 'VI_WOO_CART_ALL_IN_ONE_DATA' );
	}

	/**
	 * @return string
	 */
	private static function get_viwcaio_footer_mode() {
		if ( ! class_exists( 'VI_WOO_CART_ALL_IN_ONE_DATA' ) ) {
			return 'subtotal';
		}

		$settings = new VI_WOO_CART_ALL_IN_ONE_DATA();
		$mode     = $settings->get_params( 'sc_footer_cart_total' );

		return 'total' === $mode ? 'total' : 'subtotal';
	}

	/**
	 * @return float
	 */
	private static function get_cart_discount_total() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return 0.0;
		}

		if ( class_exists( 'Oilmazing_Bundle_Cart' ) ) {
			$bundle_summary = Oilmazing_Bundle_Cart::get_checkout_summary();

			if ( ! empty( $bundle_summary['has_bundle'] ) && (float) $bundle_summary['savings'] > 0 ) {
				return (float) $bundle_summary['savings'];
			}
		}

		$total  = (float) WC()->cart->get_discount_total();
		$total += (float) WC()->cart->get_discount_tax();

		foreach ( WC()->cart->get_fees() as $fee ) {
			$amount = isset( $fee->amount ) ? (float) $fee->amount : 0.0;
			if ( $amount < 0 ) {
				$total += abs( $amount );
			}
		}

		foreach ( WC()->cart->get_cart() as $cart_item ) {
			$product = isset( $cart_item['data'] ) ? $cart_item['data'] : null;

			if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
				continue;
			}

			$reference_price = 0.0;

			if ( class_exists( 'Oilmazing_Bundle_Cart' ) ) {
				$reference_price = Oilmazing_Bundle_Cart::get_display_unit_price( $cart_item, $product );
			}

			if ( $reference_price <= 0 ) {
				$reference_price = (float) $product->get_regular_price();
			}

			$price = (float) $product->get_price();

			if ( $reference_price <= 0 || $price >= $reference_price ) {
				continue;
			}

			$total += ( $reference_price - $price ) * (int) $cart_item['quantity'];
		}

		return max( 0.0, $total );
	}

	/**
	 * @return int
	 */
	private static function get_cart_count() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return 0;
		}

		return (int) WC()->cart->get_cart_contents_count();
	}

	/**
	 * @param int $count Count.
	 * @return string
	 */
	private static function format_count( $count ) {
		return str_pad( (string) max( 0, (int) $count ), 2, '0', STR_PAD_LEFT );
	}

	/**
	 * @param float $amount Amount.
	 * @return string
	 */
	private static function format_money( $amount ) {
		$html = wc_price( $amount );
		$text = wp_strip_all_tags( $html );

		return html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * @param float $amount Amount.
	 * @return string
	 */
	private static function format_discount( $amount ) {
		$formatted = self::format_money( $amount );

		if ( $amount <= 0 ) {
			return $formatted;
		}

		return '-' . ltrim( $formatted, '-' );
	}

	/**
	 * Enqueue cart summary UI assets.
	 */
	public static function enqueue_assets() {
		if ( is_admin() || ! function_exists( 'WC' ) ) {
			return;
		}

		wp_enqueue_style(
			'oilmazing-sfc-cart-summary-ui',
			OILMAZING_SFC_AUTH_URL . 'assets/css/cart-summary-ui.css',
			array(),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_enqueue_script(
			'oilmazing-sfc-cart-summary-ui',
			OILMAZING_SFC_AUTH_URL . 'assets/js/cart-summary-ui.js',
			array( 'jquery' ),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		wp_localize_script(
			'oilmazing-sfc-cart-summary-ui',
			'oilmazingSfcCartSummaryUi',
			array(
				'ajaxUrl'           => admin_url( 'admin-ajax.php' ),
				'nonce'             => wp_create_nonce( self::NONCE_ACTION ),
				'summary'           => self::get_summary_payload(),
				'viwcaioFooterMode' => self::get_viwcaio_footer_mode(),
				'i18n'              => array(
					'discount' => __( 'Discount', 'oilmazing-sfc' ),
					'subtotal' => __( 'Subtotal', 'woocommerce' ),
				),
			)
		);
	}
}
