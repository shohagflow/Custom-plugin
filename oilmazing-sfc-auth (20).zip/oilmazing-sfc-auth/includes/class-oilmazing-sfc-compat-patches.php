<?php
/**
 * Compatibility patches for core plugin files that cannot be edited in-place.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Compat_Patches
 */
class Oilmazing_SFC_Compat_Patches {

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_filter( 'rest_request_after_callbacks', array( __CLASS__, 'patch_rest_response' ), 10, 3 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_dashboard_patches' ), 1001 );
	}

	/**
	 * Patch REST payloads until core plugin files are updated.
	 *
	 * @param WP_REST_Response|WP_HTTP_Response|WP_Error $response Response object.
	 * @param array                                      $handler  Route handler.
	 * @param WP_REST_Request                            $request  Request object.
	 * @return WP_REST_Response|WP_HTTP_Response|WP_Error
	 */
	public static function patch_rest_response( $response, $handler, $request ) {
		if ( is_wp_error( $response ) || ! ( $response instanceof WP_REST_Response ) ) {
			return $response;
		}

		$route = untrailingslashit( (string) $request->get_route() );
		$data  = $response->get_data();

		if ( ! is_array( $data ) ) {
			return $response;
		}

		if ( '/oilmazing-sfc/v1/user' === $route && 'GET' === $request->get_method() ) {
			$data['subscription'] = Oilmazing_SFC_Membership::get_subscription_summary( get_current_user_id() );
			$response->set_data( $data );
			return $response;
		}

		if ( 0 !== strpos( $route, '/oilmazing-sfc/v1/' ) ) {
			return $response;
		}

		if ( '/oilmazing-sfc/v1/messages' === $route && 'GET' === $request->get_method() ) {
			if ( ! empty( $data['conversation']['is_support'] ) && ! empty( $data['messages'] ) && is_array( $data['messages'] ) ) {
				$data['messages'] = self::enrich_support_messages_with_sender_names(
					$data['messages'],
					(int) ( $data['conversation']['conversation_id'] ?? 0 )
				);
				$response->set_data( $data );
			}

			return $response;
		}

		if ( array_key_exists( 'unread_total', $data ) ) {
			$data['unread_total'] = self::get_unread_message_count( get_current_user_id() );
			$response->set_data( $data );
		}

		return $response;
	}

	/**
	 * Correct unread message count (fixes core SQL typo: $conversations_table).
	 *
	 * @param int $user_id User ID.
	 * @return int
	 */
	public static function get_unread_message_count( $user_id ) {
		global $wpdb;

		if ( ! class_exists( 'Oilmazing_SFC_Messages' ) ) {
			return 0;
		}

		$user_id        = (int) $user_id;
		$messages_table = Oilmazing_SFC_Messages::messages_table();
		$conversations  = Oilmazing_SFC_Messages::conversations_table();

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(m.id) FROM {$messages_table} m
				INNER JOIN {$conversations} c ON c.id = m.conversation_id
				WHERE m.sender_id != %d AND m.is_read = 0
				AND (
					(c.is_support = 0 AND (c.user_one_id = %d OR c.user_two_id = %d))
					OR (c.is_support = 1 AND c.user_one_id = %d)
				)",
				$user_id,
				$user_id,
				$user_id,
				$user_id
			)
		);
	}

	/**
	 * Billing UI patch script for live membership data.
	 */
	public static function enqueue_dashboard_patches() {
		if ( ! class_exists( 'Oilmazing_SFC_Elementor_Compat' ) || ! Oilmazing_SFC_Elementor_Compat::is_club_frontend_page() ) {
			return;
		}

		if ( ! class_exists( 'Oilmazing_SFC_Assets_Guard' ) || ! Oilmazing_SFC_Assets_Guard::should_load_dashboard_assets() ) {
			return;
		}

		if ( ! wp_script_is( 'oilmazing-sfc-main', 'enqueued' ) ) {
			return;
		}

		wp_enqueue_script(
			'oilmazing-sfc-billing-live',
			OILMAZING_SFC_AUTH_URL . 'assets/js/billing-live.js',
			array( 'oilmazing-sfc-api-client', 'oilmazing-sfc-main' ),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		$my_account_url = function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'myaccount' ) : '';
		if ( '' === $my_account_url && function_exists( 'wc_get_page_id' ) ) {
			$page_id = (int) wc_get_page_id( 'myaccount' );
			$my_account_url = $page_id > 0 ? (string) get_permalink( $page_id ) : '';
		}
		if ( '' === $my_account_url || false === strpos( $my_account_url, 'http' ) ) {
			$my_account_url = home_url( '/my-account/' );
		}

		$payment_url = function_exists( 'wc_get_account_endpoint_url' )
			? (string) wc_get_account_endpoint_url( 'payment-methods', '', $my_account_url )
			: trailingslashit( $my_account_url ) . 'payment-methods/';

		$change_plan_url = class_exists( 'Oilmazing_SFC_Membership' )
			? (string) Oilmazing_SFC_Membership::get_subscribe_url()
			: $my_account_url;

		wp_localize_script(
			'oilmazing-sfc-billing-live',
			'oilmazingSfcBilling',
			array(
				'myAccountUrl'  => esc_url_raw( $my_account_url ),
				'paymentUrl'    => esc_url_raw( $payment_url ),
				'changePlanUrl' => esc_url_raw( $change_plan_url ),
				'subscribeUrl'  => esc_url_raw( $change_plan_url ),
				'dashboardUrl'  => class_exists( 'Oilmazing_SFC_Membership' )
					? esc_url_raw( Oilmazing_SFC_Membership::get_dashboard_url() )
					: esc_url_raw( home_url( '/' ) ),
			)
		);

		wp_enqueue_script(
			'oilmazing-sfc-support-member-chat',
			OILMAZING_SFC_AUTH_URL . 'assets/js/support-member-chat.js',
			array( 'oilmazing-sfc-api-client', 'oilmazing-sfc-main' ),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);
	}

	/**
	 * Add staff display names to support thread messages.
	 *
	 * @param array<int, array<string, mixed>> $messages        Message rows.
	 * @param int                             $conversation_id Conversation ID.
	 * @return array<int, array<string, mixed>>
	 */
	public static function enrich_support_messages_with_sender_names( $messages, $conversation_id ) {
		global $wpdb;

		$conversation_id = (int) $conversation_id;
		if ( $conversation_id <= 0 || ! class_exists( 'Oilmazing_SFC_Messages' ) || ! is_array( $messages ) ) {
			return $messages;
		}

		$table = Oilmazing_SFC_Messages::messages_table();
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, sender_id FROM {$table} WHERE conversation_id = %d",
				$conversation_id
			),
			ARRAY_A
		);

		$sender_map = array();
		foreach ( (array) $rows as $row ) {
			$sender_map[ (int) $row['id'] ] = (int) $row['sender_id'];
		}

		$user_id = get_current_user_id();

		foreach ( $messages as &$message ) {
			if ( ! is_array( $message ) || ( $message['from'] ?? '' ) !== 'them' || ! empty( $message['sender_name'] ) ) {
				continue;
			}

			$message_id = (int) ( $message['id'] ?? 0 );
			$sender_id  = $sender_map[ $message_id ] ?? 0;
			if ( $sender_id <= 0 || $sender_id === $user_id ) {
				continue;
			}

			$sender = get_userdata( $sender_id );
			if ( $sender && $sender->exists() ) {
				$message['sender_name'] = $sender->display_name ? $sender->display_name : $sender->user_login;
			}
		}
		unset( $message );

		return $messages;
	}
}
