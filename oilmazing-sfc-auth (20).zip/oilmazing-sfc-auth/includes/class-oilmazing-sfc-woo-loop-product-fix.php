<?php
/**
 * Keep the WooCommerce global $product in sync with the current loop post.
 *
 * Related / upsell / cross-sell templates call setup_postdata() but do not fire
 * the_post, so $product can stay stuck on the current single product. That makes
 * loop Add to Cart links point at the wrong product URL.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Woo_Loop_Product_Fix
 */
class Oilmazing_SFC_Woo_Loop_Product_Fix {

	/**
	 * Register hooks.
	 */
	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		// Run before thumbnail / title / add-to-cart callbacks.
		add_action( 'woocommerce_before_shop_loop_item', array( __CLASS__, 'sync_global_product' ), 1 );
		add_action( 'woocommerce_before_shop_loop_item_title', array( __CLASS__, 'sync_global_product' ), 1 );

		// Elementor Loop Item / Products widgets sometimes skip the shop_loop_item hooks.
		add_action( 'elementor/frontend/widget/before_render', array( __CLASS__, 'maybe_sync_for_elementor_widget' ), 5 );
	}

	/**
	 * Sync $product to the current $post product ID when they drift apart.
	 */
	public static function sync_global_product() {
		global $product, $post;

		if ( ! $post instanceof WP_Post || 'product' !== $post->post_type ) {
			return;
		}

		$post_id = (int) $post->ID;
		if ( $post_id <= 0 ) {
			return;
		}

		if ( $product instanceof WC_Product && (int) $product->get_id() === $post_id ) {
			return;
		}

		$synced = wc_get_product( $post_id );
		if ( ! $synced instanceof WC_Product ) {
			return;
		}

		$product             = $synced;
		$GLOBALS['product']  = $synced;
	}

	/**
	 * Ensure loop product context before Elementor WooCommerce widgets render.
	 *
	 * @param \Elementor\Widget_Base $widget Widget instance.
	 */
	public static function maybe_sync_for_elementor_widget( $widget ) {
		if ( ! is_object( $widget ) || ! method_exists( $widget, 'get_name' ) ) {
			return;
		}

		$name = (string) $widget->get_name();
		$woo_widgets = array(
			'woocommerce-product-add-to-cart',
			'woocommerce-product-price',
			'woocommerce-product-title',
			'woocommerce-product-images',
			'woocommerce-product-meta',
			'woocommerce-product-rating',
			'woocommerce-product-short-description',
			'wc-add-to-cart',
		);

		if ( ! in_array( $name, $woo_widgets, true ) ) {
			return;
		}

		self::sync_global_product();
	}
}
