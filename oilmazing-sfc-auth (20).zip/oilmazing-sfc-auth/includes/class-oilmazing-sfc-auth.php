<?php
/**
 * Custom login and registration for the Scent Freedom Club.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Auth
 */
class Oilmazing_SFC_Auth {

	const NONCE_ACTION = 'oilmazing_sfc_auth';

	const OPTION_KEY = 'oilmazing_sfc_auth_settings';

	const META_MEMBER_SINCE = 'oilmazing_sfc_member_since';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ), 5 );
	}

	/**
	 * Register auth assets.
	 */
	public static function register_assets() {
		wp_register_style(
			'oilmazing-sfc-my-account',
			OILMAZING_SFC_AUTH_URL . 'assets/css/my-account.css',
			array(),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_register_style(
			'oilmazing-sfc-auth-controls',
			OILMAZING_SFC_AUTH_URL . 'assets/css/auth-controls.css',
			array( 'oilmazing-sfc-my-account' ),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_register_style(
			'oilmazing-sfc-auth',
			OILMAZING_SFC_AUTH_URL . 'assets/css/auth.css',
			array( 'oilmazing-sfc-my-account', 'oilmazing-sfc-auth-controls' ),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_register_script(
			'oilmazing-sfc-auth',
			OILMAZING_SFC_AUTH_URL . 'assets/js/auth.js',
			array(),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);
	}

	/**
	 * Default auth settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_settings() {
		$defaults = array(
			'allow_registration'  => 'yes',
			'min_password_length' => 8,
		);

		$stored = get_option( self::OPTION_KEY, array() );

		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		return wp_parse_args( $stored, $defaults );
	}

	/**
	 * Whether new member registration is enabled.
	 *
	 * @return bool
	 */
	public static function registration_enabled() {
		$settings = self::get_settings();

		return 'yes' === $settings['allow_registration'];
	}

	/**
	 * Register REST routes.
	 */
	public static function register_routes() {
		if ( ! defined( 'OILMAZING_SFC_REST_NAMESPACE' ) ) {
			return;
		}

		register_rest_route(
			OILMAZING_SFC_REST_NAMESPACE,
			'/auth/login',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'login' ),
				'permission_callback' => array( __CLASS__, 'public_permission' ),
				'args'                => self::login_args(),
			)
		);

		register_rest_route(
			OILMAZING_SFC_REST_NAMESPACE,
			'/auth/register',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'register' ),
				'permission_callback' => array( __CLASS__, 'public_permission' ),
				'args'                => self::register_args(),
			)
		);
	}

	/**
	 * Login field schema.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private static function login_args() {
		return array(
			'email'    => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'password' => array(
				'required' => true,
				'type'     => 'string',
			),
			'remember' => array(
				'type'    => 'boolean',
				'default' => true,
			),
			'redirect' => array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
				'default'           => '',
			),
		);
	}

	/**
	 * Register field schema.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private static function register_args() {
		return array(
			'first_name' => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'last_name'  => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '',
			),
			'email'      => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_email',
			),
			'password'   => array(
				'required' => true,
				'type'     => 'string',
			),
			'redirect'   => array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
				'default'           => '',
			),
		);
	}

	/**
	 * Verify auth nonce for public endpoints.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return true|WP_Error
	 */
	public static function public_permission( WP_REST_Request $request ) {
		$nonce = $request->get_header( 'X-Oilmazing-Auth-Nonce' );

		if ( ! is_string( $nonce ) || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			return new WP_Error(
				'oilmazing_sfc_invalid_nonce',
				__( 'Your session expired. Please refresh the page and try again.', 'oilmazing-sfc' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Log in a member.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function login( WP_REST_Request $request ) {
		if ( is_user_logged_in() ) {
			return rest_ensure_response(
				array(
					'success'      => true,
					'message'      => __( 'You are already signed in.', 'oilmazing-sfc' ),
					'redirect_url' => self::resolve_redirect_url( $request->get_param( 'redirect' ) ),
				)
			);
		}

		$email    = sanitize_text_field( (string) $request->get_param( 'email' ) );
		$password = (string) $request->get_param( 'password' );
		$remember = (bool) $request->get_param( 'remember' );

		if ( '' === $email || '' === $password ) {
			return new WP_Error(
				'oilmazing_sfc_missing_credentials',
				__( 'Please enter your email and password.', 'oilmazing-sfc' ),
				array( 'status' => 400 )
			);
		}

		$user = wp_signon(
			array(
				'user_login'    => self::resolve_login_username( $email ),
				'user_password' => $password,
				'remember'      => $remember,
			),
			is_ssl()
		);

		if ( is_wp_error( $user ) ) {
			return new WP_Error(
				'oilmazing_sfc_login_failed',
				__( 'Incorrect email or password. Please try again.', 'oilmazing-sfc' ),
				array( 'status' => 401 )
			);
		}

		return rest_ensure_response(
			array(
				'success'      => true,
				'message'      => __( 'Welcome back.', 'oilmazing-sfc' ),
				'redirect_url' => self::resolve_redirect_url( $request->get_param( 'redirect' ) ),
				'user'         => self::get_public_user_payload( $user->ID ),
			)
		);
	}

	/**
	 * Register a new club member.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function register( WP_REST_Request $request ) {
		if ( ! self::registration_enabled() ) {
			return new WP_Error(
				'oilmazing_sfc_registration_disabled',
				__( 'New member registration is currently closed.', 'oilmazing-sfc' ),
				array( 'status' => 403 )
			);
		}

		if ( is_user_logged_in() ) {
			return rest_ensure_response(
				array(
					'success'      => true,
					'message'      => __( 'You are already signed in.', 'oilmazing-sfc' ),
					'redirect_url' => self::resolve_redirect_url( $request->get_param( 'redirect' ) ),
				)
			);
		}

		$first_name = sanitize_text_field( (string) $request->get_param( 'first_name' ) );
		$last_name  = sanitize_text_field( (string) $request->get_param( 'last_name' ) );
		$email      = sanitize_email( (string) $request->get_param( 'email' ) );
		$password   = (string) $request->get_param( 'password' );

		if ( '' === $first_name ) {
			return new WP_Error(
				'oilmazing_sfc_missing_first_name',
				__( 'Please enter your first name.', 'oilmazing-sfc' ),
				array( 'status' => 400 )
			);
		}

		if ( ! is_email( $email ) ) {
			return new WP_Error(
				'oilmazing_sfc_invalid_email',
				__( 'Please enter a valid email address.', 'oilmazing-sfc' ),
				array( 'status' => 400 )
			);
		}

		if ( email_exists( $email ) ) {
			return new WP_Error(
				'oilmazing_sfc_email_exists',
				__( 'An account with this email already exists. Try signing in instead.', 'oilmazing-sfc' ),
				array( 'status' => 409 )
			);
		}

		$password_error = self::validate_password( $password );
		if ( is_wp_error( $password_error ) ) {
			return $password_error;
		}

		$username = self::generate_username( $email, $first_name, $last_name );
		$user_id  = wp_create_user( $username, $password, $email );

		if ( is_wp_error( $user_id ) ) {
			return new WP_Error(
				'oilmazing_sfc_register_failed',
				__( 'Could not create your account. Please try again.', 'oilmazing-sfc' ),
				array( 'status' => 500 )
			);
		}

		$display_name = trim( $first_name . ' ' . $last_name );
		wp_update_user(
			array(
				'ID'           => $user_id,
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'display_name' => $display_name ? $display_name : $first_name,
				'role'         => oilmazing_sfc_get_member_role(),
			)
		);

		update_user_meta( $user_id, self::META_MEMBER_SINCE, current_time( 'mysql' ) );

		$user = wp_signon(
			array(
				'user_login'    => $username,
				'user_password' => $password,
				'remember'      => true,
			),
			is_ssl()
		);

		if ( is_wp_error( $user ) ) {
			return rest_ensure_response(
				array(
					'success'      => true,
					'message'      => __( 'Your account was created. Please sign in.', 'oilmazing-sfc' ),
					'redirect_url' => self::resolve_redirect_url( $request->get_param( 'redirect' ) ),
				)
			);
		}

		return rest_ensure_response(
			array(
				'success'      => true,
				'message'      => __( 'Welcome to Scent Freedom Club.', 'oilmazing-sfc' ),
				'redirect_url' => self::resolve_redirect_url( $request->get_param( 'redirect' ) ),
				'user'         => self::get_public_user_payload( $user->ID ),
			)
		);
	}

	/**
	 * Validate password strength.
	 *
	 * @param string $password Password.
	 * @return true|WP_Error
	 */
	private static function validate_password( $password ) {
		$settings = self::get_settings();
		$min      = max( 6, (int) $settings['min_password_length'] );

		if ( strlen( $password ) < $min ) {
			return new WP_Error(
				'oilmazing_sfc_weak_password',
				sprintf(
					/* translators: %d: minimum password length */
					__( 'Password must be at least %d characters.', 'oilmazing-sfc' ),
					$min
				),
				array( 'status' => 400 )
			);
		}

		return true;
	}

	/**
	 * Resolve login identifier from email input.
	 *
	 * @param string $email Email or username.
	 * @return string
	 */
	private static function resolve_login_username( $email ) {
		if ( is_email( $email ) ) {
			$user = get_user_by( 'email', $email );
			if ( $user ) {
				return $user->user_login;
			}
		}

		return $email;
	}

	/**
	 * Generate a unique username.
	 *
	 * @param string $email      Email address.
	 * @param string $first_name First name.
	 * @param string $last_name  Last name.
	 * @return string
	 */
	private static function generate_username( $email, $first_name, $last_name ) {
		$candidates = array();

		$base = sanitize_user( strtolower( $first_name . $last_name ), true );
		if ( $base ) {
			$candidates[] = $base;
		}

		$email_part = sanitize_user( current( explode( '@', $email ) ), true );
		if ( $email_part ) {
			$candidates[] = $email_part;
		}

		$candidates[] = 'member';

		foreach ( $candidates as $candidate ) {
			$username = $candidate;
			$counter  = 1;

			while ( username_exists( $username ) ) {
				$username = $candidate . $counter;
				++$counter;
			}

			return $username;
		}

		return 'member' . wp_rand( 1000, 9999 );
	}

	/**
	 * Resolve safe redirect URL after auth.
	 *
	 * @param string $requested Requested redirect.
	 * @return string
	 */
	public static function resolve_redirect_url( $requested = '' ) {
		$url = is_string( $requested ) ? trim( $requested ) : '';

		if ( $url && wp_validate_redirect( $url, false ) ) {
			return wp_validate_redirect( $url, home_url( '/' ) );
		}

		if ( class_exists( 'Oilmazing_SFC_Membership' ) ) {
			if ( is_user_logged_in() && ! Oilmazing_SFC_Membership::has_active_membership() ) {
				return Oilmazing_SFC_Membership::get_subscribe_url();
			}

			return Oilmazing_SFC_Membership::get_dashboard_url();
		}

		if ( is_singular() ) {
			return get_permalink();
		}

		return home_url( '/' );
	}

	/**
	 * Public user payload returned after auth.
	 *
	 * @param int $user_id User ID.
	 * @return array<string, string>
	 */
	private static function get_public_user_payload( $user_id ) {
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return array();
		}

		return array(
			'id'           => (string) $user_id,
			'display_name' => $user->display_name,
			'email'        => $user->user_email,
		);
	}

	/**
	 * Enqueue auth screen assets.
	 *
	 * @param array<string, string> $args Template args.
	 */
	public static function enqueue_assets( $args = array() ) {
		wp_enqueue_style(
			'oilmazing-sfc-auth-fonts',
			'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap',
			array(),
			null
		);

		wp_enqueue_style(
			'font-awesome-6',
			'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
			array(),
			'6.5.2'
		);

		wp_enqueue_style( 'oilmazing-sfc-my-account' );
		wp_enqueue_style( 'oilmazing-sfc-auth-controls' );
		wp_enqueue_style( 'oilmazing-sfc-auth' );
		wp_enqueue_script( 'oilmazing-sfc-auth' );

		wp_localize_script(
			'oilmazing-sfc-auth',
			'oilmazingSfcAuth',
			array(
				'restUrl'            => esc_url_raw( rest_url( OILMAZING_SFC_REST_NAMESPACE . '/' ) ),
				'nonce'              => wp_create_nonce( self::NONCE_ACTION ),
				'redirect'           => isset( $args['redirect'] ) ? esc_url_raw( $args['redirect'] ) : '',
				'registrationEnabled'=> self::registration_enabled(),
				'i18n'               => array(
					'signingIn'  => __( 'Signing in...', 'oilmazing-sfc' ),
					'creating'   => __( 'Creating account...', 'oilmazing-sfc' ),
					'error'      => __( 'Something went wrong. Please try again.', 'oilmazing-sfc' ),
				),
			)
		);
	}

	/**
	 * Render the auth screen markup.
	 *
	 * @param array<string, string> $args Template args.
	 * @return string
	 */
	public static function render_screen( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'default_tab' => 'login',
				'redirect'    => '',
				'context'     => 'dashboard',
			)
		);

		if ( is_user_logged_in() ) {
			$redirect = self::resolve_redirect_url( $args['redirect'] );
			wp_safe_redirect( $redirect );
			exit;
		}

		self::enqueue_assets( $args );

		$template = OILMAZING_SFC_AUTH_PATH . 'templates/auth.php';

		if ( is_readable( $template ) ) {
			ob_start();
			// phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- Template variable injection.
			extract( $args, EXTR_SKIP );
			include $template;
			return (string) ob_get_clean();
		}

		return oilmazing_sfc_render_template( 'auth.php', $args );
	}
}
