<?php
/**
 * Prevent dashboard assets on auth/membership gate pages; fix Tailwind CDN config order.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Assets_Guard
 */
class Oilmazing_SFC_Assets_Guard {

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'guard_dashboard_assets' ), 1000 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'fix_tailwind_config' ), 1005 );
		add_filter( 'body_class', array( __CLASS__, 'filter_body_class' ), 30 );
	}

	/**
	 * Whether the current user should load the full member dashboard bundle.
	 *
	 * @return bool
	 */
	public static function should_load_dashboard_assets() {
		if ( ! is_user_logged_in() ) {
			return false;
		}

		if ( ! class_exists( 'Oilmazing_SFC_Membership' ) ) {
			return true;
		}

		return Oilmazing_SFC_Membership::has_active_membership();
	}

	/**
	 * Dequeue dashboard scripts/styles when the shortcode renders auth or membership gate.
	 */
	public static function guard_dashboard_assets() {
		if ( ! class_exists( 'Oilmazing_SFC_Elementor_Compat' ) || ! Oilmazing_SFC_Elementor_Compat::is_club_frontend_page() ) {
			return;
		}

		if ( self::should_load_dashboard_assets() ) {
			self::enqueue_chat_enhancements();
			return;
		}

		$styles = array(
			'oilmazing-sfc-fonts',
			'font-awesome-6',
			'oilmazing-sfc-styles',
			'oilmazing-sfc-theme-isolation',
			'oilmazing-sfc-astra-compat',
			'oilmazing-sfc-dashboard-menu',
			'oilmazing-sfc-elementor-header-compat',
		);

		$scripts = array(
			'oilmazing-sfc-tailwind-config',
			'tailwindcss',
			'oilmazing-sfc-tailwind-scope',
			'oilmazing-sfc-api-client',
			'oilmazing-sfc-main',
			'oilmazing-sfc-dashboard-loader-smooth',
			'oilmazing-sfc-affiliate-dashboard',
		);

		foreach ( $styles as $handle ) {
			wp_dequeue_style( $handle );
		}

		foreach ( $scripts as $handle ) {
			wp_dequeue_script( $handle );
		}
	}

	/**
	 * Tailwind config must run after the CDN script defines `tailwind`.
	 */
	public static function fix_tailwind_config() {
		if ( ! wp_script_is( 'tailwindcss', 'enqueued' ) ) {
			return;
		}

		$wp_scripts = wp_scripts();

		if ( isset( $wp_scripts->registered['oilmazing-sfc-tailwind-config'] ) ) {
			unset( $wp_scripts->registered['oilmazing-sfc-tailwind-config']->extra['before'] );
		}

		wp_dequeue_script( 'oilmazing-sfc-tailwind-config' );

		if ( ! wp_scripts()->get_data( 'tailwindcss', 'oilmazing_sfc_config' ) ) {
			wp_add_inline_script(
				'tailwindcss',
				'if (typeof tailwind !== "undefined") { tailwind.config = { corePlugins: { preflight: false } }; }',
				'after'
			);
			wp_scripts()->add_data( 'tailwindcss', 'oilmazing_sfc_config', true );
		}
	}

	/**
	 * Drop dashboard body class on auth/membership gate screens.
	 *
	 * @param array<int,string> $classes Body classes.
	 * @return array<int,string>
	 */
	public static function filter_body_class( $classes ) {
		if ( in_array( 'oilmazing-sfc-dashboard-page', $classes, true ) && ! self::should_load_dashboard_assets() ) {
			$classes = array_values( array_diff( $classes, array( 'oilmazing-sfc-dashboard-page' ) ) );
		}

		return $classes;
	}

	/**
	 * Chat bubble layout + online/offline enhancements for member dashboard.
	 */
	public static function enqueue_chat_enhancements() {
		if ( ! class_exists( 'Oilmazing_SFC_Elementor_Compat' ) || ! Oilmazing_SFC_Elementor_Compat::is_club_frontend_page() ) {
			return;
		}

		wp_enqueue_style(
			'oilmazing-sfc-chat-enhancements',
			OILMAZING_SFC_AUTH_URL . 'assets/css/chat-enhancements.css',
			array( 'oilmazing-sfc-styles' ),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_enqueue_script(
			'oilmazing-sfc-chat-enhancements',
			OILMAZING_SFC_AUTH_URL . 'assets/js/chat-enhancements.js',
			array( 'oilmazing-sfc-main' ),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		wp_localize_script(
			'oilmazing-sfc-chat-enhancements',
			'oilmazingSfcChatEnhance',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'oilmazing_sfc_presence' ),
				'i18n'    => array(
					'you'     => __( 'You', 'oilmazing-sfc' ),
					'online'  => __( 'Online', 'oilmazing-sfc' ),
					'offline' => __( 'Offline', 'oilmazing-sfc' ),
				),
			)
		);
	}
}
