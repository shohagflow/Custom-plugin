<?php
/**
 * Suppress third-party admin notices on Scent Freedom Club admin pages.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Admin_Notices
 */
class Oilmazing_SFC_Admin_Notices {

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register_suppression' ), 4 );
		add_filter( 'admin_body_class', array( __CLASS__, 'admin_body_class' ) );
	}

	/**
	 * All plugin admin page slugs.
	 *
	 * @return array<int, string>
	 */
	public static function get_admin_slugs() {
		$slugs = array(
			'oilmazing-sfc',
			'oilmazing-sfc-members',
			'oilmazing-sfc-membership',
			'oilmazing-sfc-customer-mail',
			'oilmazing-sfc-qr-management',
			'oilmazing-sfc-cart-discount',
			'oilmazing-support',
		);

		return apply_filters( 'oilmazing_sfc_admin_page_slugs', $slugs );
	}

	/**
	 * @return bool
	 */
	public static function is_plugin_admin_screen() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		return in_array( $page, self::get_admin_slugs(), true );
	}

	/**
	 * Register notice suppression before other plugins enqueue admin assets.
	 */
	public static function register_suppression() {
		if ( ! self::is_plugin_admin_screen() ) {
			return;
		}

		add_action( 'admin_head', array( __CLASS__, 'suppress_foreign_notices' ), 0 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'suppress_foreign_notices' ), PHP_INT_MAX );
		add_action( 'in_admin_header', array( __CLASS__, 'suppress_foreign_notices' ), 0 );
	}

	/**
	 * Remove foreign admin notices.
	 */
	public static function suppress_foreign_notices() {
		if ( ! self::is_plugin_admin_screen() ) {
			return;
		}

		$hooks = array(
			'admin_notices',
			'all_admin_notices',
			'network_admin_notices',
			'user_admin_notices',
		);

		foreach ( $hooks as $hook ) {
			remove_all_actions( $hook );
		}

		add_action( 'admin_notices', array( __CLASS__, 'render_plugin_notices' ), 99 );
	}

	/**
	 * Show only this plugin's settings feedback.
	 */
	public static function render_plugin_notices() {
		settings_errors( 'oilmazing_sfc_settings' );
		settings_errors( 'oilmazing_sfc_membership_settings' );
	}

	/**
	 * @param string $classes Body classes.
	 * @return string
	 */
	public static function admin_body_class( $classes ) {
		if ( self::is_plugin_admin_screen() ) {
			$classes .= ' oilmazing-sfc-admin-screen';
		}

		return $classes;
	}
}
