<?php
/**
 * Cart subtotal percentage discount when minimum matching items are in the cart.
 *
 * Supports filtering by product categories and variable Size (pa_size) attributes.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Quantity_Discount
 */
class Oilmazing_SFC_Quantity_Discount {

	const OPTION_ENABLED = 'oilmazing_sfc_quantity_discount_enabled';

	const OPTION_PERCENT = 'oilmazing_sfc_quantity_discount_percent';

	const OPTION_RULES = 'oilmazing_sfc_quantity_discount_rules';

	const SIZE_TAXONOMY = 'pa_size';

	/**
	 * Register hooks.
	 */
	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		add_action( 'woocommerce_cart_calculate_fees', array( __CLASS__, 'apply_cart_fee' ), 25 );
	}

	/**
	 * Default rules.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_default_rules() {
		return array(
			'enabled'                      => 'yes',
			'percent'                      => 10.0,
			'min_qty'                      => 2,
			'categories'                   => array(),
			'sizes'                        => array(),
			'calendar_per_day_limit'       => 1,
			'library_collections_enabled'  => 'yes',
		);
	}

	/**
	 * Merged rules with legacy option fallback.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_rules() {
		$defaults = self::get_default_rules();
		$saved    = get_option( self::OPTION_RULES, null );

		if ( ! is_array( $saved ) ) {
			$saved = array(
				'enabled'                     => get_option( self::OPTION_ENABLED, $defaults['enabled'] ),
				'percent'                     => get_option( self::OPTION_PERCENT, $defaults['percent'] ),
				'min_qty'                     => $defaults['min_qty'],
				'categories'                  => array(),
				'sizes'                       => array(),
				'calendar_per_day_limit'      => $defaults['calendar_per_day_limit'],
				'library_collections_enabled' => $defaults['library_collections_enabled'],
			);
		}

		$rules                                 = array_merge( $defaults, $saved );
		$rules['enabled']                      = self::sanitize_yes_no( $rules['enabled'] );
		$rules['percent']                      = self::sanitize_percent( $rules['percent'] );
		$rules['min_qty']                      = self::sanitize_min_qty( $rules['min_qty'] );
		$rules['categories']                   = self::sanitize_id_list( $rules['categories'] ?? array() );
		$rules['sizes']                        = self::sanitize_size_slugs( $rules['sizes'] ?? array() );
		$rules['calendar_per_day_limit']       = self::sanitize_calendar_per_day_limit( $rules['calendar_per_day_limit'] ?? 1 );
		$rules['library_collections_enabled']  = self::sanitize_yes_no( $rules['library_collections_enabled'] ?? 'yes' );

		return $rules;
	}

	/**
	 * @param mixed $value Raw rules.
	 * @return array<string, mixed>
	 */
	public static function sanitize_rules( $value ) {
		$defaults = self::get_default_rules();
		$value    = is_array( $value ) ? $value : array();

		return array(
			'enabled'                     => self::sanitize_yes_no( $value['enabled'] ?? 'no' ),
			'percent'                     => self::sanitize_percent( $value['percent'] ?? $defaults['percent'] ),
			'min_qty'                     => self::sanitize_min_qty( $value['min_qty'] ?? $defaults['min_qty'] ),
			'categories'                  => self::sanitize_id_list( $value['categories'] ?? array() ),
			'sizes'                       => self::sanitize_size_slugs( $value['sizes'] ?? array() ),
			'calendar_per_day_limit'      => self::sanitize_calendar_per_day_limit( $value['calendar_per_day_limit'] ?? $defaults['calendar_per_day_limit'] ),
			'library_collections_enabled' => self::sanitize_yes_no( $value['library_collections_enabled'] ?? 'no' ),
		);
	}

	/**
	 * @return bool
	 */
	public static function is_enabled() {
		$rules = self::get_rules();
		return 'yes' === $rules['enabled'];
	}

	/**
	 * @return float
	 */
	public static function get_percent() {
		$rules = self::get_rules();
		return (float) $rules['percent'];
	}

	/**
	 * @return int
	 */
	public static function get_minimum_items() {
		$rules = self::get_rules();
		return (int) $rules['min_qty'];
	}

	/**
	 * Selected product category term IDs.
	 *
	 * @return int[]
	 */
	public static function get_selected_categories() {
		$rules = self::get_rules();
		return array_map( 'absint', (array) $rules['categories'] );
	}

	/**
	 * Selected pa_size term slugs.
	 *
	 * @return string[]
	 */
	public static function get_selected_sizes() {
		$rules = self::get_rules();
		return array_map( 'strval', (array) $rules['sizes'] );
	}

	/**
	 * Max products a member can schedule on one calendar day (Club dashboard).
	 *
	 * Default is 1 (new drop replaces the previous product on that day).
	 *
	 * @return int
	 */
	public static function get_calendar_per_day_limit() {
		$rules = self::get_rules();
		return self::sanitize_calendar_per_day_limit( $rules['calendar_per_day_limit'] ?? 1 );
	}

	/**
	 * Whether Library "Collections" tab is enabled in the Club dashboard.
	 *
	 * @return bool
	 */
	public static function is_library_collections_enabled() {
		$rules = self::get_rules();
		return 'yes' === self::sanitize_yes_no( $rules['library_collections_enabled'] ?? 'yes' );
	}

	/**
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_yes_no( $value ) {
		return ( 'yes' === $value || true === $value || '1' === (string) $value ) ? 'yes' : 'no';
	}

	/**
	 * @param mixed $value Raw value.
	 * @return float
	 */
	public static function sanitize_percent( $value ) {
		return max( 0.0, min( 100.0, (float) $value ) );
	}

	/**
	 * @param mixed $value Raw value.
	 * @return int
	 */
	public static function sanitize_min_qty( $value ) {
		return max( 1, min( 100, absint( $value ) ) );
	}

	/**
	 * @param mixed $value Raw value.
	 * @return int
	 */
	public static function sanitize_calendar_per_day_limit( $value ) {
		return max( 1, min( 31, absint( $value ) ) );
	}

	/**
	 * @param mixed $value Raw IDs.
	 * @return int[]
	 */
	public static function sanitize_id_list( $value ) {
		if ( ! is_array( $value ) ) {
			$value = array( $value );
		}

		$ids = array();
		foreach ( $value as $id ) {
			$id = absint( $id );
			if ( $id > 0 ) {
				$ids[] = $id;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * @param mixed $value Raw size slugs.
	 * @return string[]
	 */
	public static function sanitize_size_slugs( $value ) {
		if ( ! is_array( $value ) ) {
			$value = array( $value );
		}

		$allowed = self::get_available_size_slugs();
		$slugs   = array();

		foreach ( $value as $slug ) {
			$slug = sanitize_title( (string) $slug );
			if ( '' === $slug ) {
				continue;
			}
			if ( ! empty( $allowed ) && ! in_array( $slug, $allowed, true ) ) {
				continue;
			}
			$slugs[] = $slug;
		}

		return array_values( array_unique( $slugs ) );
	}

	/**
	 * Available Size attribute term options for admin UI.
	 *
	 * @return array<int, array{id:int,slug:string,name:string}>
	 */
	public static function get_available_sizes() {
		if ( ! taxonomy_exists( self::SIZE_TAXONOMY ) ) {
			return array();
		}

		$terms = get_terms(
			array(
				'taxonomy'   => self::SIZE_TAXONOMY,
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array();
		}

		$sizes = array();
		foreach ( $terms as $term ) {
			$sizes[] = array(
				'id'   => (int) $term->term_id,
				'slug' => (string) $term->slug,
				'name' => (string) $term->name,
			);
		}

		return $sizes;
	}

	/**
	 * @return string[]
	 */
	public static function get_available_size_slugs() {
		return array_values(
			array_map(
				static function ( $size ) {
					return (string) $size['slug'];
				},
				self::get_available_sizes()
			)
		);
	}

	/**
	 * Available product categories for admin UI.
	 *
	 * @return array<int, array{id:int,name:string,parent:int}>
	 */
	public static function get_available_categories() {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array();
		}

		$categories = array();
		foreach ( $terms as $term ) {
			$categories[] = array(
				'id'     => (int) $term->term_id,
				'name'   => (string) $term->name,
				'parent' => (int) $term->parent,
			);
		}

		return $categories;
	}

	/**
	 * Apply discount as a negative fee on matching cart lines.
	 *
	 * @param WC_Cart $cart Cart object.
	 */
	public static function apply_cart_fee( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}

		if ( ! self::is_enabled() || self::get_percent() <= 0 || ! $cart instanceof WC_Cart ) {
			return;
		}

		if ( self::has_oilmazing_bundle_items( $cart ) ) {
			return;
		}

		$savings = self::calculate_savings( $cart );
		if ( $savings <= 0 ) {
			return;
		}

		$cart->add_fee( __( 'Discount', 'oilmazing-sfc' ), -1 * $savings, false );
	}

	/**
	 * Discount amount for matching eligible cart lines.
	 *
	 * @param WC_Cart $cart Cart object.
	 * @return float
	 */
	public static function calculate_savings( $cart ) {
		if ( ! self::is_enabled() || self::get_percent() <= 0 || ! $cart instanceof WC_Cart ) {
			return 0.0;
		}

		if ( self::has_oilmazing_bundle_items( $cart ) ) {
			return 0.0;
		}

		$eligible = self::get_eligible_cart_totals( $cart );
		if ( $eligible['qty'] < self::get_minimum_items() || $eligible['subtotal'] <= 0 ) {
			return 0.0;
		}

		return max( 0.0, $eligible['subtotal'] * ( self::get_percent() / 100 ) );
	}

	/**
	 * Eligible quantity + subtotal for the configured filters.
	 *
	 * @param WC_Cart $cart Cart object.
	 * @return array{qty:int,subtotal:float}
	 */
	public static function get_eligible_cart_totals( $cart ) {
		$qty      = 0;
		$subtotal = 0.0;

		if ( ! $cart instanceof WC_Cart ) {
			return array(
				'qty'      => 0,
				'subtotal' => 0.0,
			);
		}

		foreach ( $cart->get_cart() as $cart_item ) {
			if ( ! self::cart_item_matches_rules( $cart_item ) ) {
				continue;
			}

			$line_qty = max( 0, (int) ( $cart_item['quantity'] ?? 0 ) );
			$qty     += $line_qty;

			if ( isset( $cart_item['line_subtotal'] ) && (float) $cart_item['line_subtotal'] > 0 ) {
				$subtotal += (float) $cart_item['line_subtotal'];
				continue;
			}

			if ( empty( $cart_item['data'] ) || ! is_a( $cart_item['data'], 'WC_Product' ) ) {
				continue;
			}

			$subtotal += (float) $cart_item['data']->get_price() * $line_qty;
		}

		return array(
			'qty'      => $qty,
			'subtotal' => max( 0.0, $subtotal ),
		);
	}

	/**
	 * Whether a cart line matches category/size filters.
	 *
	 * Empty category list and empty size list = all products eligible.
	 * When both lists are set, the item must match both (AND).
	 *
	 * @param array<string, mixed> $cart_item Cart item.
	 * @return bool
	 */
	public static function cart_item_matches_rules( $cart_item ) {
		$categories = self::get_selected_categories();
		$sizes      = self::get_selected_sizes();

		if ( empty( $categories ) && empty( $sizes ) ) {
			return true;
		}

		$product = isset( $cart_item['data'] ) && is_a( $cart_item['data'], 'WC_Product' )
			? $cart_item['data']
			: null;

		if ( ! $product ) {
			return false;
		}

		$parent_id = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();

		if ( ! empty( $categories ) && ! self::product_in_categories( $parent_id, $categories ) ) {
			return false;
		}

		if ( ! empty( $sizes ) && ! self::product_matches_sizes( $product, $cart_item, $sizes ) ) {
			return false;
		}

		return true;
	}

	/**
	 * @param int   $product_id Product ID (parent for variations).
	 * @param int[] $category_ids Category term IDs.
	 * @return bool
	 */
	private static function product_in_categories( $product_id, array $category_ids ) {
		$product_id    = absint( $product_id );
		$category_ids  = array_map( 'absint', $category_ids );
		$product_terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );

		if ( is_wp_error( $product_terms ) || empty( $product_terms ) ) {
			return false;
		}

		$product_terms = array_map( 'absint', $product_terms );

		foreach ( $category_ids as $category_id ) {
			if ( in_array( $category_id, $product_terms, true ) ) {
				return true;
			}

			// Include child categories of a selected parent.
			$children = get_term_children( $category_id, 'product_cat' );
			if ( ! is_wp_error( $children ) ) {
				foreach ( $children as $child_id ) {
					if ( in_array( (int) $child_id, $product_terms, true ) ) {
						return true;
					}
				}
			}
		}

		return false;
	}

	/**
	 * Match cart product against selected Size attribute slugs.
	 *
	 * @param WC_Product           $product   Product/variation.
	 * @param array<string, mixed> $cart_item Cart item.
	 * @param string[]             $sizes     Selected size slugs.
	 * @return bool
	 */
	private static function product_matches_sizes( $product, array $cart_item, array $sizes ) {
		$candidates = array();

		if ( ! empty( $cart_item['variation'] ) && is_array( $cart_item['variation'] ) ) {
			foreach ( $cart_item['variation'] as $key => $value ) {
				$key = strtolower( (string) $key );
				if ( false !== strpos( $key, 'pa_size' ) || false !== strpos( $key, 'size' ) ) {
					$candidates[] = (string) $value;
				}
			}
		}

		if ( $product instanceof WC_Product_Variation || $product->is_type( 'variation' ) ) {
			foreach ( $product->get_attributes() as $attr_key => $attr_value ) {
				$attr_key = strtolower( (string) $attr_key );
				if ( false !== strpos( $attr_key, 'pa_size' ) || 'size' === $attr_key || false !== strpos( $attr_key, 'size' ) ) {
					$candidates[] = (string) $attr_value;
				}
			}
		}

		if ( class_exists( 'Oilmazing_Bundle_Pricing' ) && method_exists( 'Oilmazing_Bundle_Pricing', 'resolve_size_key_from_attributes' ) ) {
			$attrs = array();
			if ( ! empty( $cart_item['variation'] ) && is_array( $cart_item['variation'] ) ) {
				$attrs = $cart_item['variation'];
			} elseif ( method_exists( $product, 'get_attributes' ) ) {
				$attrs = $product->get_attributes();
			}

			$size_key = Oilmazing_Bundle_Pricing::resolve_size_key_from_attributes( (array) $attrs, $product );
			$map      = array(
				'one_third_oz' => array( '1-3-oz', '1/3-oz', '1-3oz' ),
				'one_oz'       => array( '1-oz', '1oz' ),
				'one_seven_oz' => array( '1-7-oz', '1-7oz' ),
			);
			if ( isset( $map[ $size_key ] ) ) {
				$candidates = array_merge( $candidates, $map[ $size_key ] );
			}
		}

		foreach ( $candidates as $candidate ) {
			$slug = sanitize_title( (string) $candidate );
			if ( $slug && in_array( $slug, $sizes, true ) ) {
				return true;
			}

			if ( taxonomy_exists( self::SIZE_TAXONOMY ) ) {
				$term = get_term_by( 'slug', $slug, self::SIZE_TAXONOMY );
				if ( ! $term ) {
					$term = get_term_by( 'name', (string) $candidate, self::SIZE_TAXONOMY );
				}
				if ( $term && ! is_wp_error( $term ) && in_array( (string) $term->slug, $sizes, true ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Bundle products use fixed Oilmazing Bundle System pricing, not percentage discounts.
	 *
	 * @param WC_Cart $cart Cart object.
	 * @return bool
	 */
	private static function has_oilmazing_bundle_items( $cart ) {
		if ( ! class_exists( 'Oilmazing_Bundle_Cart' ) || ! $cart instanceof WC_Cart ) {
			return false;
		}

		if ( ! empty( Oilmazing_Bundle_Cart::get_eligible_cart_items( $cart ) ) ) {
			return true;
		}

		foreach ( $cart->get_cart() as $cart_item ) {
			if ( ! empty( $cart_item['oilmazing_bundle_display_unit_price'] ) ) {
				return true;
			}
		}

		$bundle_summary = Oilmazing_Bundle_Cart::get_checkout_summary( $cart );

		return ! empty( $bundle_summary['has_bundle'] ) && (float) $bundle_summary['savings'] > 0;
	}
}
