<?php
/**
 * Elementor / theme header compatibility for club pages.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Elementor_Compat
 */
class Oilmazing_SFC_Elementor_Compat {

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'wp', array( __CLASS__, 'maybe_render_elementor_locations' ) );
		add_action( 'elementor/frontend/before_enqueue_scripts', array( __CLASS__, 'ensure_elementor_sticky_assets' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'ensure_elementor_sticky_assets' ), 50 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 10001 );
	}

	/**
	 * Output Elementor Theme Builder header/footer on canvas-style templates.
	 */
	public static function maybe_render_elementor_locations() {
		if ( ! self::is_club_frontend_page() || ! function_exists( 'elementor_theme_do_location' ) ) {
			return;
		}

		// Active member dashboard stays pure Elementor canvas (no site header/footer).
		if ( self::is_dashboard_view() ) {
			return;
		}

		$template = get_page_template_slug();
		$no_theme_chrome = array(
			'elementor_canvas',
			'elementor_theme',
		);

		if ( ! in_array( $template, $no_theme_chrome, true ) ) {
			return;
		}

		add_action( 'wp_body_open', array( __CLASS__, 'render_elementor_header' ), 5 );
		add_action( 'wp_footer', array( __CLASS__, 'render_elementor_footer' ), 5 );
	}

	/**
	 * Render Elementor header location once per request.
	 */
	public static function render_elementor_header() {
		static $rendered = false;

		if ( $rendered || ! function_exists( 'elementor_theme_do_location' ) ) {
			return;
		}

		$rendered = true;

		echo '<div class="oilmazing-sfc-elementor-header">';
		elementor_theme_do_location( 'header' );
		echo '</div>';
	}

	/**
	 * Render Elementor footer location once per request.
	 */
	public static function render_elementor_footer() {
		static $rendered = false;

		if ( $rendered || ! function_exists( 'elementor_theme_do_location' ) ) {
			return;
		}

		$rendered = true;

		echo '<div class="oilmazing-sfc-elementor-footer">';
		elementor_theme_do_location( 'footer' );
		echo '</div>';
	}

	/**
	 * Elementor Pro sticky headers need jquery.sticky before frontend handlers run.
	 */
	public static function ensure_elementor_sticky_assets() {
		if ( ! self::is_club_frontend_page() || self::is_dashboard_view() || ! defined( 'ELEMENTOR_PRO_URL' ) ) {
			return;
		}

		if ( ! wp_script_is( 'oilmazing-sfc-elementor-sticky-shim', 'registered' ) ) {
			wp_register_script(
				'oilmazing-sfc-elementor-sticky-shim',
				OILMAZING_SFC_AUTH_URL . 'assets/js/elementor-sticky-shim.js',
				array( 'jquery' ),
				OILMAZING_SFC_AUTH_VERSION,
				true
			);
		}

		wp_enqueue_script( 'oilmazing-sfc-elementor-sticky-shim' );

		$pro_frontend = wp_scripts()->query( 'elementor-pro-frontend', 'registered' );
		if ( $pro_frontend instanceof _WP_Dependency && ! in_array( 'oilmazing-sfc-elementor-sticky-shim', $pro_frontend->deps, true ) ) {
			$pro_frontend->deps[] = 'oilmazing-sfc-elementor-sticky-shim';
		}

		$suffix  = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		$handles = array( 'e-sticky', 'elementor-sticky' );

		foreach ( $handles as $handle ) {
			if ( wp_script_is( $handle, 'registered' ) ) {
				wp_enqueue_script( $handle );
				return;
			}
		}

		wp_register_script(
			'elementor-sticky',
			ELEMENTOR_PRO_URL . 'assets/lib/sticky/jquery.sticky' . $suffix . '.js',
			array( 'jquery', 'oilmazing-sfc-elementor-sticky-shim' ),
			defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : '1.0.0',
			true
		);
		wp_enqueue_script( 'elementor-sticky' );
	}

	/**
	 * Enqueue header compatibility styles on club pages.
	 */
	public static function enqueue_assets() {
		if ( ! self::is_club_frontend_page() ) {
			return;
		}

		$deps = array();
		if ( wp_style_is( 'oilmazing-sfc-astra-compat', 'registered' ) ) {
			$deps[] = 'oilmazing-sfc-astra-compat';
		}

		wp_enqueue_style(
			'oilmazing-sfc-elementor-header-compat',
			OILMAZING_SFC_AUTH_URL . 'assets/css/elementor-header-compat.css',
			$deps,
			OILMAZING_SFC_AUTH_VERSION
		);

		if ( self::is_dashboard_view() ) {
			wp_enqueue_script(
				'oilmazing-sfc-dashboard-loader-smooth',
				OILMAZING_SFC_AUTH_URL . 'assets/js/dashboard-loader-smooth.js',
				array( 'oilmazing-sfc-api-client' ),
				OILMAZING_SFC_AUTH_VERSION,
				true
			);
		}
	}

	/**
	 * Whether the current front-end page renders a club shortcode.
	 *
	 * @return bool
	 */
	public static function is_club_frontend_page() {
		if ( ! is_singular() ) {
			return false;
		}

		$post = get_queried_object();
		if ( ! $post instanceof WP_Post ) {
			return false;
		}

		if (
			has_shortcode( $post->post_content, 'oilmazing_sfc_auth' )
			|| has_shortcode( $post->post_content, 'oilmazing_sfc_dashboard' )
			|| has_shortcode( $post->post_content, 'scent_freedom_club' )
		) {
			return true;
		}

		return self::post_has_club_shortcode_in_elementor( $post->ID );
	}

	/**
	 * Detect club shortcodes inside Elementor page JSON.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private static function post_has_club_shortcode_in_elementor( $post_id ) {
		$elementor_data = get_post_meta( $post_id, '_elementor_data', true );

		if ( ! is_string( $elementor_data ) || '' === $elementor_data ) {
			return false;
		}

		return false !== strpos( $elementor_data, 'oilmazing_sfc_dashboard' )
			|| false !== strpos( $elementor_data, 'scent_freedom_club' )
			|| false !== strpos( $elementor_data, 'oilmazing_sfc_auth' );
	}

	/**
	 * Whether the active member dashboard is shown (loader/flicker fixes).
	 *
	 * @return bool
	 */
	public static function is_dashboard_view() {
		if ( ! self::is_club_frontend_page() || ! is_user_logged_in() ) {
			return false;
		}

		return class_exists( 'Oilmazing_SFC_Membership' ) && Oilmazing_SFC_Membership::has_active_membership();
	}
}
