<?php
/**
 * Modern WooCommerce My Account experience.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_My_Account
 */
class Oilmazing_SFC_My_Account {

	const ENDPOINT = 'scent-club';

	/**
	 * Register hooks.
	 */
	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		add_action( 'init', array( __CLASS__, 'register_endpoint' ), 12 );
		add_filter( 'woocommerce_get_query_vars', array( __CLASS__, 'register_query_var' ) );
		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'filter_menu_items' ), 20 );
		add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( __CLASS__, 'render_club_hub' ) );
		add_filter( 'woocommerce_locate_template', array( __CLASS__, 'locate_template' ), 20, 3 );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 100000 );
		add_action( 'init', array( __CLASS__, 'maybe_flush_rewrite_rules' ), 99 );
	}

	/**
	 * Register custom account endpoint.
	 */
	public static function register_endpoint() {
		add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
	}

	/**
	 * @param array<string,string> $vars Query vars.
	 * @return array<string,string>
	 */
	public static function register_query_var( $vars ) {
		$vars[ self::ENDPOINT ] = self::ENDPOINT;
		return $vars;
	}

	/**
	 * @param array<string,string> $items Menu items.
	 * @return array<string,string>
	 */
	public static function filter_menu_items( $items ) {
		$logout = array();

		if ( isset( $items['customer-logout'] ) ) {
			$logout['customer-logout'] = $items['customer-logout'];
			unset( $items['customer-logout'] );
		}

		$new_items = array();
		foreach ( $items as $endpoint => $label ) {
			$new_items[ $endpoint ] = $label;

			if ( 'dashboard' === $endpoint ) {
				$new_items[ self::ENDPOINT ] = __( 'Scent Freedom Club', 'oilmazing-sfc' );
			}
		}

		return $new_items + $logout;
	}

	/**
	 * Club hub tab inside WooCommerce My Account.
	 */
	public static function render_club_hub() {
		if ( class_exists( 'Oilmazing_SFC_Membership' ) && ! Oilmazing_SFC_Membership::has_active_membership() ) {
			echo '<div class="oilmazing-sfc-wc-account__membership-gate">';
			echo Oilmazing_SFC_Membership::render_gate(
				array(
					'redirect' => Oilmazing_SFC_Membership::get_dashboard_url(),
				)
			);
			echo '</div>';
			return;
		}

		$dashboard_url = class_exists( 'Oilmazing_SFC_Membership' )
			? Oilmazing_SFC_Membership::get_dashboard_url()
			: home_url( '/' );
		$user           = wp_get_current_user();
		$display_name   = $user->first_name ? $user->first_name : $user->display_name;
		?>
		<div class="oilmazing-sfc-wc-account__club-hub">
			<div class="oilmazing-sfc-wc-account__club-card">
				<div class="oilmazing-sfc-wc-account__club-icon" aria-hidden="true">
					<i class="fa-solid fa-spa"></i>
				</div>
				<h3><?php esc_html_e( 'Scent Freedom Club', 'oilmazing-sfc' ); ?></h3>
				<p>
					<?php
					printf(
						/* translators: %s: member name */
						esc_html__( '%s, your member dashboard is ready with your scent calendar, deals, referrals, and community.', 'oilmazing-sfc' ),
						esc_html( $display_name )
					);
					?>
				</p>
				<a class="oilmazing-sfc-wc-account__button" href="<?php echo esc_url( $dashboard_url ); ?>">
					<?php esc_html_e( 'Open Member Dashboard', 'oilmazing-sfc' ); ?>
					<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
				</a>
			</div>
		</div>
		<?php
	}

	/**
	 * @param string $template      Template path.
	 * @param string $template_name Template name.
	 * @param string $template_path Template path.
	 * @return string
	 */
	public static function locate_template( $template, $template_name, $template_path ) {
		if ( 0 !== strpos( $template_name, 'myaccount/' ) ) {
			return $template;
		}

		$plugin_template = OILMAZING_SFC_AUTH_PATH . 'woocommerce/' . $template_name;

		if ( file_exists( $plugin_template ) ) {
			return $plugin_template;
		}

		return $template;
	}

	/**
	 * @param array<int,string> $classes Body classes.
	 * @return array<int,string>
	 */
	public static function body_class( $classes ) {
		if ( self::is_account_page() ) {
			$classes[] = 'oilmazing-sfc-my-account-page';
		}

		return $classes;
	}

	/**
	 * Enqueue account styles.
	 */
	public static function enqueue_assets() {
		if ( ! self::is_account_page() ) {
			return;
		}

		wp_enqueue_style(
			'oilmazing-sfc-google-fonts-account',
			'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap',
			array(),
			null
		);

		wp_enqueue_style(
			'font-awesome-6',
			'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
			array(),
			'6.5.2'
		);

		wp_enqueue_style(
			'oilmazing-sfc-my-account',
			OILMAZING_SFC_AUTH_URL . 'assets/css/my-account.css',
			array( 'font-awesome-6' ),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_enqueue_style(
			'oilmazing-sfc-auth-controls',
			OILMAZING_SFC_AUTH_URL . 'assets/css/auth-controls.css',
			array( 'oilmazing-sfc-my-account' ),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_add_inline_style(
			'oilmazing-sfc-my-account',
			'body.oilmazing-sfc-my-account-page .elementor-widget-woocommerce-my-account .e-my-account-tab .woocommerce .woocommerce-MyAccount-navigation ul li a{background:transparent!important;border:0!important;box-shadow:none!important;border-radius:12px!important}' .
			'body.oilmazing-sfc-my-account-page .elementor-widget-woocommerce-my-account .e-my-account-tab .woocommerce .woocommerce-MyAccount-navigation ul li.is-active a{background:#18181b!important;color:#fff!important}' .
			'body.oilmazing-sfc-my-account-page .woocommerce-MyAccount-content.oilmazing-sfc-wc-account__content{padding:32px!important}' .
			'body.oilmazing-sfc-my-account-page .oilmazing-sfc-wc-account__nav li.woocommerce-MyAccount-navigation-link,body.oilmazing-sfc-my-account-page .oilmazing-sfc-wc-account__nav .woocommerce-MyAccount-navigation-link{border:0!important;border-width:0!important;background:transparent!important}'
		);
	}

	/**
	 * @return bool
	 */
	public static function is_account_page() {
		return function_exists( 'is_account_page' ) && is_account_page();
	}

	/**
	 * @param string $endpoint Endpoint slug.
	 * @return string
	 */
	public static function get_menu_icon( $endpoint ) {
		$icons = array(
			'dashboard'       => 'fa-house',
			self::ENDPOINT    => 'fa-spa',
			'orders'          => 'fa-box',
			'subscriptions'   => 'fa-arrows-rotate',
			'downloads'       => 'fa-download',
			'edit-address'    => 'fa-location-dot',
			'payment-methods' => 'fa-credit-card',
			'edit-account'    => 'fa-user-gear',
			'customer-logout' => 'fa-right-from-bracket',
		);

		return isset( $icons[ $endpoint ] ) ? $icons[ $endpoint ] : 'fa-circle';
	}

	/**
	 * Flush rewrite rules when endpoint version changes.
	 */
	public static function maybe_flush_rewrite_rules() {
		$option = 'oilmazing_sfc_my_account_endpoint_version';

		if ( get_option( $option ) === OILMAZING_SFC_AUTH_VERSION ) {
			return;
		}

		flush_rewrite_rules( false );
		update_option( $option, OILMAZING_SFC_AUTH_VERSION );
	}
}
