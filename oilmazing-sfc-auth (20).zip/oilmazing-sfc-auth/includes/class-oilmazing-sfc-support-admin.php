<?php
/**
 * Oilmazing Support admin menu and inbox UI.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Support_Admin
 */
class Oilmazing_SFC_Support_Admin {

	const PAGE_SLUG = 'oilmazing-support';

	/**
	 * Short label used in the WP admin sidebar.
	 *
	 * @return string
	 */
	public static function get_menu_label() {
		return __( 'Support', 'oilmazing-sfc' );
	}

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_notification_assets' ), 20 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_menu_icon_styles' ), 5 );
		add_action( 'admin_menu', array( __CLASS__, 'add_menu_badge' ), 999 );
		add_action( 'admin_bar_menu', array( __CLASS__, 'add_admin_bar_node' ), 90 );
		add_action( 'admin_notices', array( __CLASS__, 'render_unread_notice' ) );
		add_action( 'wp_ajax_oilmazing_sfc_support_send_reply', array( __CLASS__, 'ajax_send_reply' ) );
		add_action( 'wp_ajax_oilmazing_sfc_support_refresh_thread', array( __CLASS__, 'ajax_refresh_thread' ) );
		add_action( 'wp_ajax_oilmazing_sfc_support_search_members', array( __CLASS__, 'ajax_search_members' ) );
		add_action( 'wp_ajax_oilmazing_sfc_support_start_conversation', array( __CLASS__, 'ajax_start_conversation' ) );
		add_action( 'wp_ajax_oilmazing_sfc_support_unread_status', array( __CLASS__, 'ajax_unread_status' ) );
	}

	/**
	 * Register top-level support menu.
	 */
	public static function register_menu() {
		add_menu_page(
			__( 'Oilmazing Support', 'oilmazing-sfc' ),
			self::get_menu_label(),
			Oilmazing_SFC_Support::get_menu_capability(),
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' ),
			self::get_menu_icon(),
			57
		);
	}

	/**
	 * Custom chat icon for the admin sidebar menu.
	 *
	 * @return string
	 */
	public static function get_menu_icon() {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M10 1.5A7.5 7.5 0 0 0 2.5 9c0 1.55.47 2.99 1.27 4.19L2 18.5l5.01-1.58A7.45 7.45 0 0 0 10 16.5a7.5 7.5 0 0 0 0-15Zm0 1.5a6 6 0 1 1 0 12 6.06 6.06 0 0 1-2.89-.73l-.41-.22-3.01.95.98-2.86-.24-.4A6 6 0 0 1 4 9a6 6 0 0 1 6-6Zm-2.6 4.25a.85.85 0 0 0-.02 1.58l.08.03c.53.2 1.08.31 1.65.31h.02a.85.85 0 0 0 0-1.7H9.1c-.34 0-.67-.06-.98-.17a.85.85 0 0 0-.72.05Zm5.2 0a.85.85 0 0 0-.72.05c-.31.11-.64.17-.98.17h-.02a.85.85 0 0 0 0 1.7c.57 0 1.12-.11 1.65-.31l.08-.03a.85.85 0 0 0-.01-1.58Z"/></svg>';

		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	/**
	 * Highlight the custom support menu icon in the admin sidebar.
	 *
	 * @param string $hook_suffix Hook suffix.
	 */
	public static function enqueue_menu_icon_styles( $hook_suffix = '' ) {
		unset( $hook_suffix );

		wp_enqueue_style(
			'oilmazing-sfc-support-menu-icon',
			OILMAZING_SFC_AUTH_URL . 'assets/css/support-menu-icon.css',
			array(),
			OILMAZING_SFC_AUTH_VERSION
		);
	}

	/**
	 * Show unread count on menu item.
	 */
	public static function add_menu_badge() {
		if ( ! Oilmazing_SFC_Support::user_can_manage() || ! Oilmazing_SFC_Support::is_available() ) {
			return;
		}

		self::apply_menu_badge( Oilmazing_SFC_Support::get_admin_unread_count() );
	}

	/**
	 * Inject or update the sidebar menu unread badge.
	 *
	 * @param int $count Unread message count.
	 */
	public static function apply_menu_badge( $count ) {
		global $menu;

		$count = max( 0, (int) $count );
		$badge = $count > 0
			? sprintf(
				' <span class="awaiting-mod count-%1$d oilmazing-sfc-support-menu-badge"><span class="pending-count">%1$d</span></span>',
				$count
			)
			: '';

		foreach ( (array) $menu as $index => $item ) {
			if ( ! isset( $item[2] ) || self::PAGE_SLUG !== $item[2] ) {
				continue;
			}

			$menu[ $index ][0] = esc_html( self::get_menu_label() ) . $badge;
			break;
		}
	}

	/**
	 * Add support inbox link to the admin bar with unread count.
	 *
	 * @param WP_Admin_Bar $admin_bar Admin bar instance.
	 */
	public static function add_admin_bar_node( $admin_bar ) {
		if ( ! is_admin() || ! Oilmazing_SFC_Support::user_can_manage() || ! Oilmazing_SFC_Support::is_available() ) {
			return;
		}

		$count = Oilmazing_SFC_Support::get_admin_unread_count();
		$title = esc_html( self::get_menu_label() );

		if ( $count > 0 ) {
			$title .= sprintf(
				' <span class="oilmazing-sfc-support-adminbar-badge awaiting-mod count-%1$d"><span class="pending-count">%1$d</span></span>',
				$count
			);
		}

		$admin_bar->add_node(
			array(
				'id'    => 'oilmazing-sfc-support-inbox',
				'title' => $title,
				'href'  => admin_url( 'admin.php?page=' . self::PAGE_SLUG ),
				'meta'  => array(
					'class' => 'oilmazing-sfc-support-adminbar-link',
					'title' => $count > 0
						? sprintf(
							/* translators: %d: unread message count */
							_n( '%d unread support message', '%d unread support messages', $count, 'oilmazing-sfc' ),
							$count
						)
						: __( 'Open the Oilmazing Support inbox', 'oilmazing-sfc' ),
				),
			)
		);
	}

	/**
	 * Show a dismissible admin notice when support messages are waiting.
	 */
	public static function render_unread_notice() {
		if ( ! Oilmazing_SFC_Support::user_can_manage() || ! Oilmazing_SFC_Support::is_available() ) {
			return;
		}

		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( self::PAGE_SLUG === $page ) {
			return;
		}

		$summary = Oilmazing_SFC_Support::get_unread_summary();
		$count   = (int) ( $summary['unread_total'] ?? 0 );
		if ( $count <= 0 ) {
			return;
		}

		$latest  = is_array( $summary['latest'] ?? null ) ? $summary['latest'] : null;
		$url     = (string) ( $summary['inbox_url'] ?? admin_url( 'admin.php?page=' . self::PAGE_SLUG ) );
		$message = sprintf(
			/* translators: %d: unread message count */
			_n(
				'You have %d unread support message from a club member.',
				'You have %d unread support messages from club members.',
				$count,
				'oilmazing-sfc'
			),
			$count
		);

		echo '<div class="notice notice-info is-dismissible oilmazing-sfc-support-unread-notice" data-oilmazing-support-notice>';
		echo '<p><strong>' . esc_html__( 'Oilmazing Support', 'oilmazing-sfc' ) . '</strong> — ';
		echo esc_html( $message );

		if ( $latest && ! empty( $latest['member_name'] ) ) {
			echo ' <span class="oilmazing-sfc-support-unread-notice__preview">';
			echo esc_html(
				sprintf(
					/* translators: 1: member name, 2: message preview */
					__( 'Latest from %1$s: %2$s', 'oilmazing-sfc' ),
					$latest['member_name'],
					$latest['preview']
				)
			);
			echo '</span>';
		}

		echo ' <a href="' . esc_url( $latest['url'] ?? $url ) . '" class="button button-primary" style="margin-left:8px;">';
		echo esc_html__( 'Open inbox', 'oilmazing-sfc' );
		echo '</a></p></div>';
	}

	/**
	 * Enqueue live notification polling on all admin screens.
	 *
	 * @param string $hook_suffix Hook suffix.
	 */
	public static function enqueue_notification_assets( $hook_suffix = '' ) {
		unset( $hook_suffix );

		if ( ! is_admin() || ! Oilmazing_SFC_Support::user_can_manage() || ! Oilmazing_SFC_Support::is_available() ) {
			return;
		}

		wp_enqueue_style(
			'oilmazing-sfc-support-notify',
			OILMAZING_SFC_AUTH_URL . 'assets/css/support-notify.css',
			array(),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_enqueue_script(
			'oilmazing-sfc-support-notify',
			OILMAZING_SFC_AUTH_URL . 'assets/js/support-admin-notify.js',
			array(),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		$summary = Oilmazing_SFC_Support::get_unread_summary();

		wp_localize_script(
			'oilmazing-sfc-support-notify',
			'oilmazingSfcSupportNotify',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'oilmazing_sfc_support' ),
				'pollMs'      => 20000,
				'unreadTotal' => (int) ( $summary['unread_total'] ?? 0 ),
				'pageSlug'    => self::PAGE_SLUG,
				'menuLabel'   => self::get_menu_label(),
				'inboxUrl'    => (string) ( $summary['inbox_url'] ?? admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ),
				'i18n'        => array(
					'newMessage'  => __( 'New support message received.', 'oilmazing-sfc' ),
					'openInbox'   => __( 'Open inbox', 'oilmazing-sfc' ),
					'unreadLabel' => __( 'unread support messages', 'oilmazing-sfc' ),
				),
			)
		);
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook_suffix Hook suffix.
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'toplevel_page_' . self::PAGE_SLUG !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'oilmazing-sfc-support-admin',
			OILMAZING_SFC_AUTH_URL . 'assets/css/support-admin.css',
			array( 'dashicons' ),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_enqueue_script(
			'oilmazing-sfc-support-admin',
			OILMAZING_SFC_AUTH_URL . 'assets/js/support-admin.js',
			array(),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		wp_localize_script(
			'oilmazing-sfc-support-admin',
			'oilmazingSfcSupport',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'oilmazing_sfc_support' ),
				'i18n'    => array(
					'sending'    => __( 'Sending…', 'oilmazing-sfc' ),
					'send'       => __( 'Send reply', 'oilmazing-sfc' ),
					'sendFailed' => __( 'Could not send reply. Please try again.', 'oilmazing-sfc' ),
					'empty'      => __( 'Please enter a reply.', 'oilmazing-sfc' ),
					'searchHint' => __( 'Search members by name or email…', 'oilmazing-sfc' ),
					'searching'  => __( 'Searching…', 'oilmazing-sfc' ),
					'noMembers'  => __( 'No members found.', 'oilmazing-sfc' ),
					'message'    => __( 'Message', 'oilmazing-sfc' ),
					'openFailed' => __( 'Could not open this conversation.', 'oilmazing-sfc' ),
					'you'        => __( 'You', 'oilmazing-sfc' ),
					'online'     => __( 'Online', 'oilmazing-sfc' ),
					'offline'    => __( 'Offline', 'oilmazing-sfc' ),
				),
				'pageUrl' => admin_url( 'admin.php?page=' . self::PAGE_SLUG ),
			)
		);
	}

	/**
	 * Render support inbox page.
	 */
	public static function render_page() {
		if ( ! Oilmazing_SFC_Support::user_can_manage() ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'oilmazing-sfc' ) );
		}

		if ( class_exists( 'Oilmazing_SFC_Presence' ) ) {
			Oilmazing_SFC_Presence::touch_last_seen();
		}

		Oilmazing_SFC_Support::maybe_install();

		$inbox               = Oilmazing_SFC_Support::get_inbox();
		$member_search       = isset( $_GET['member_q'] ) ? sanitize_text_field( wp_unslash( $_GET['member_q'] ) ) : '';
		$active_id           = isset( $_GET['conversation'] ) ? absint( wp_unslash( $_GET['conversation'] ) ) : 0;
		$active_conversation = null;
		$thread_messages     = array();

		if ( ! $active_id && ! empty( $inbox[0]['id'] ) ) {
			$active_id = (int) $inbox[0]['id'];
		}

		if ( $active_id > 0 ) {
			$active_conversation = Oilmazing_SFC_Support::get_conversation( $active_id );
			if ( $active_conversation ) {
				Oilmazing_SFC_Support::mark_read( $active_id );
				$thread_messages = Oilmazing_SFC_Support::get_thread_messages( $active_id );
			}
		}

		$active_member = null;
		if ( $active_conversation ) {
			$member = get_userdata( (int) $active_conversation['user_one_id'] );
			if ( $member ) {
				$active_member = array(
					'id'           => (int) $member->ID,
					'name'         => $member->display_name,
					'email'        => $member->user_email,
					'avatar_url'   => get_avatar_url( $member->ID, array( 'size' => 96 ) ),
					'online'       => class_exists( 'Oilmazing_SFC_Presence' ) ? Oilmazing_SFC_Presence::is_user_online( $member->ID ) : false,
					'status_label' => class_exists( 'Oilmazing_SFC_Presence' ) ? Oilmazing_SFC_Presence::get_status_label( $member->ID, false ) : __( 'Offline', 'oilmazing-sfc' ),
				);
			}
		}

		if ( function_exists( 'oilmazing_sfc_load_template' ) ) {
			oilmazing_sfc_load_template(
				'admin/support.php',
				compact( 'inbox', 'active_id', 'active_member', 'thread_messages', 'member_search' )
			);
			return;
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'Oilmazing Support', 'oilmazing-sfc' ) . '</h1></div>';
	}

	/**
	 * AJAX: send support reply.
	 */
	public static function ajax_send_reply() {
		check_ajax_referer( 'oilmazing_sfc_support', 'nonce' );

		if ( ! Oilmazing_SFC_Support::user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		if ( class_exists( 'Oilmazing_SFC_Presence' ) ) {
			Oilmazing_SFC_Presence::touch_last_seen();
		}

		$conversation_id = isset( $_POST['conversation_id'] ) ? absint( wp_unslash( $_POST['conversation_id'] ) ) : 0;
		$body            = isset( $_POST['body'] ) ? wp_unslash( $_POST['body'] ) : '';

		$result = Oilmazing_SFC_Support::send_reply( $conversation_id, $body );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
				),
				(int) ( $result->get_error_data()['status'] ?? 400 )
			);
		}

		wp_send_json_success(
			array(
				'message' => $result,
			)
		);
	}

	/**
	 * AJAX: refresh thread messages.
	 */
	public static function ajax_refresh_thread() {
		check_ajax_referer( 'oilmazing_sfc_support', 'nonce' );

		if ( ! Oilmazing_SFC_Support::user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		$conversation_id = isset( $_POST['conversation_id'] ) ? absint( wp_unslash( $_POST['conversation_id'] ) ) : 0;
		if ( $conversation_id <= 0 || ! Oilmazing_SFC_Support::get_conversation( $conversation_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Conversation not found.', 'oilmazing-sfc' ) ), 404 );
		}

		Oilmazing_SFC_Support::mark_read( $conversation_id );

		wp_send_json_success(
			array(
				'messages' => Oilmazing_SFC_Support::get_thread_messages( $conversation_id ),
			)
		);
	}

	/**
	 * AJAX: search members for support outreach.
	 */
	public static function ajax_search_members() {
		check_ajax_referer( 'oilmazing_sfc_support', 'nonce' );

		if ( ! Oilmazing_SFC_Support::user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		$query = isset( $_POST['query'] ) ? sanitize_text_field( wp_unslash( $_POST['query'] ) ) : '';

		wp_send_json_success(
			array(
				'members' => Oilmazing_SFC_Support::search_members( $query ),
			)
		);
	}

	/**
	 * AJAX: open or create a support conversation with a member.
	 */
	public static function ajax_start_conversation() {
		check_ajax_referer( 'oilmazing_sfc_support', 'nonce' );

		if ( ! Oilmazing_SFC_Support::user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		$member_id = isset( $_POST['member_id'] ) ? absint( wp_unslash( $_POST['member_id'] ) ) : 0;
		$result    = Oilmazing_SFC_Support::open_member_conversation( $member_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
				),
				(int) ( $result->get_error_data()['status'] ?? 400 )
			);
		}

		wp_send_json_success( $result );
	}

	/**
	 * AJAX: unread support status for admin notifications.
	 */
	public static function ajax_unread_status() {
		check_ajax_referer( 'oilmazing_sfc_support', 'nonce' );

		if ( ! Oilmazing_SFC_Support::user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		wp_send_json_success( Oilmazing_SFC_Support::get_unread_summary() );
	}
}
