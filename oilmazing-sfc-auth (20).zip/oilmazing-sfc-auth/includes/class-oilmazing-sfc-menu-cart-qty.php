<?php
/**
 * Quantity +/- controls for Elementor Menu Cart / WooCommerce mini cart / checkout review.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_Menu_Cart_Qty
 */
class Oilmazing_SFC_Menu_Cart_Qty {

	const AJAX_ACTION  = 'oilmazing_sfc_menu_cart_qty';
	const NONCE_ACTION = 'oilmazing_sfc_menu_cart_qty';

	/**
	 * Register hooks.
	 */
	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		add_filter( 'woocommerce_widget_cart_item_quantity', array( __CLASS__, 'render_quantity_controls' ), 20, 3 );
		add_filter( 'woocommerce_checkout_cart_item_quantity', array( __CLASS__, 'render_checkout_quantity_controls' ), 20, 3 );
		add_action( 'wp_ajax_' . self::AJAX_ACTION, array( __CLASS__, 'ajax_update_quantity' ) );
		add_action( 'wp_ajax_nopriv_' . self::AJAX_ACTION, array( __CLASS__, 'ajax_update_quantity' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 100010 );
	}

	/**
	 * Replace static "1 × $price" with interactive quantity controls (mini cart).
	 *
	 * @param string $html          Default quantity HTML.
	 * @param array  $cart_item     Cart item.
	 * @param string $cart_item_key Cart item key.
	 * @return string
	 */
	public static function render_quantity_controls( $html, $cart_item, $cart_item_key ) {
		return self::build_quantity_markup( $cart_item, $cart_item_key, 'mini', $html );
	}

	/**
	 * Replace static "× 1" with interactive quantity controls on checkout review.
	 *
	 * @param string $html          Default quantity HTML.
	 * @param array  $cart_item     Cart item.
	 * @param string $cart_item_key Cart item key.
	 * @return string
	 */
	public static function render_checkout_quantity_controls( $html, $cart_item, $cart_item_key ) {
		return self::build_quantity_markup( $cart_item, $cart_item_key, 'checkout', $html );
	}

	/**
	 * Build quantity control markup.
	 *
	 * @param array  $cart_item     Cart item.
	 * @param string $cart_item_key Cart item key.
	 * @param string $context       Context: mini|checkout.
	 * @param string $fallback      Fallback HTML.
	 * @return string
	 */
	private static function build_quantity_markup( $cart_item, $cart_item_key, $context, $fallback ) {
		$product = isset( $cart_item['data'] ) ? $cart_item['data'] : null;

		if ( ! $product instanceof WC_Product ) {
			return $fallback;
		}

		$quantity = max( 0, (int) $cart_item['quantity'] );
		$classes  = 'quantity oilmazing-sfc-menu-cart-qty oilmazing-sfc-menu-cart-qty--' . sanitize_html_class( $context );

		if ( $product->is_sold_individually() ) {
			if ( 'checkout' === $context ) {
				return sprintf(
					' <strong class="product-quantity oilmazing-sfc-menu-cart-qty oilmazing-sfc-menu-cart-qty--locked">&times;&nbsp;%s</strong>',
					esc_html( (string) $quantity )
				);
			}

			$price = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $product ), $cart_item, $cart_item_key );

			return sprintf(
				'<span class="%1$s oilmazing-sfc-menu-cart-qty--locked"><span class="product-quantity">%2$s &times;</span> %3$s</span>',
				esc_attr( $classes ),
				esc_html( (string) $quantity ),
				wp_kses_post( $price )
			);
		}

		$max = $product->get_max_purchase_quantity();
		$max = ( '' === $max || -1 === (int) $max ) ? '' : (string) max( 1, (int) $max );

		ob_start();

		if ( 'checkout' === $context ) {
			echo ' ';
		}
		?>
		<span class="<?php echo esc_attr( $classes ); ?>" data-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>" data-context="<?php echo esc_attr( $context ); ?>">
			<span class="oilmazing-sfc-menu-cart-qty__controls" role="group" aria-label="<?php esc_attr_e( 'Product quantity', 'oilmazing-sfc' ); ?>">
				<button type="button" class="oilmazing-sfc-menu-cart-qty__btn" data-action="minus" aria-label="<?php esc_attr_e( 'Decrease quantity', 'oilmazing-sfc' ); ?>">−</button>
				<input
					type="number"
					class="oilmazing-sfc-menu-cart-qty__input qty"
					value="<?php echo esc_attr( (string) $quantity ); ?>"
					min="0"
					<?php echo '' !== $max ? 'max="' . esc_attr( $max ) . '"' : ''; ?>
					step="1"
					inputmode="numeric"
					aria-label="<?php esc_attr_e( 'Quantity', 'oilmazing-sfc' ); ?>"
				/>
				<button type="button" class="oilmazing-sfc-menu-cart-qty__btn" data-action="plus" aria-label="<?php esc_attr_e( 'Increase quantity', 'oilmazing-sfc' ); ?>">+</button>
			</span>
			<?php if ( 'mini' === $context ) : ?>
				<span class="oilmazing-sfc-menu-cart-qty__price">
					<?php
					echo wp_kses_post(
						apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $product ), $cart_item, $cart_item_key )
					);
					?>
				</span>
			<?php endif; ?>
		</span>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * AJAX: update a cart line quantity.
	 */
	public static function ajax_update_quantity() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			wp_send_json_error(
				array(
					'message' => __( 'Cart is unavailable.', 'oilmazing-sfc' ),
				),
				400
			);
		}

		$cart_item_key = isset( $_POST['cart_item_key'] ) ? sanitize_text_field( wp_unslash( $_POST['cart_item_key'] ) ) : '';
		$quantity      = isset( $_POST['quantity'] ) ? (int) wp_unslash( $_POST['quantity'] ) : -1;

		if ( '' === $cart_item_key || $quantity < 0 ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid quantity request.', 'oilmazing-sfc' ),
				),
				400
			);
		}

		$cart_item = WC()->cart->get_cart_item( $cart_item_key );

		if ( empty( $cart_item ) || empty( $cart_item['data'] ) || ! $cart_item['data'] instanceof WC_Product ) {
			wp_send_json_error(
				array(
					'message' => __( 'Cart item not found.', 'oilmazing-sfc' ),
				),
				404
			);
		}

		$product = $cart_item['data'];

		if ( $product->is_sold_individually() ) {
			$quantity = min( 1, $quantity );
		}

		$max = $product->get_max_purchase_quantity();
		if ( '' !== $max && -1 !== (int) $max && $quantity > (int) $max ) {
			$quantity = (int) $max;
		}

		$updated = WC()->cart->set_quantity( $cart_item_key, $quantity, true );

		if ( false === $updated ) {
			wp_send_json_error(
				array(
					'message' => __( 'Could not update quantity.', 'oilmazing-sfc' ),
				),
				400
			);
		}

		WC()->cart->calculate_totals();

		ob_start();
		woocommerce_mini_cart();
		$mini_cart = ob_get_clean();

		$data = array(
			'fragments'  => apply_filters(
				'woocommerce_add_to_cart_fragments',
				array(
					'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
				)
			),
			'cart_hash'  => WC()->cart->get_cart_hash(),
			'quantity'   => $quantity,
			'cart_empty' => WC()->cart->is_empty(),
			'cart_url'   => wc_get_cart_url(),
		);

		wp_send_json_success( $data );
	}

	/**
	 * Enqueue menu-cart quantity assets.
	 */
	public static function enqueue_assets() {
		if ( is_admin() || ! function_exists( 'WC' ) ) {
			return;
		}

		wp_enqueue_style(
			'oilmazing-sfc-menu-cart-qty',
			OILMAZING_SFC_AUTH_URL . 'assets/css/menu-cart-qty.css',
			array(),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_enqueue_script(
			'oilmazing-sfc-menu-cart-qty',
			OILMAZING_SFC_AUTH_URL . 'assets/js/menu-cart-qty.js',
			array( 'jquery' ),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		wp_localize_script(
			'oilmazing-sfc-menu-cart-qty',
			'oilmazingSfcMenuCartQty',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action'  => self::AJAX_ACTION,
				'nonce'   => wp_create_nonce( self::NONCE_ACTION ),
			)
		);
	}
}
