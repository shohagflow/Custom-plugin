<?php
/**
 * QR image generation and storage.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_QR_Generator
 */
class Oilmazing_SFC_QR_Generator {

	/**
	 * Generate and store a QR PNG for a referral URL.
	 *
	 * @param int    $affiliate_id Affiliate ID.
	 * @param string $referral_url Referral URL to encode.
	 * @return string|\WP_Error Relative file path under uploads or error.
	 */
	public static function generate_for_affiliate( $affiliate_id, $referral_url ) {
		$affiliate_id = absint( $affiliate_id );
		$referral_url = esc_url_raw( (string) $referral_url );

		if ( $affiliate_id <= 0 || '' === $referral_url ) {
			return new WP_Error( 'invalid_qr_input', __( 'A valid affiliate and referral URL are required to generate a QR code.', 'oilmazing-sfc' ) );
		}

		$directory = self::get_storage_dir();
		if ( is_wp_error( $directory ) ) {
			return $directory;
		}

		$filename = 'affiliate-' . $affiliate_id . '.png';
		$filepath = trailingslashit( $directory ) . $filename;

		$body = self::fetch_qr_image( $referral_url );
		if ( is_wp_error( $body ) ) {
			return $body;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false === file_put_contents( $filepath, $body ) ) {
			return new WP_Error( 'qr_write_failed', __( 'The QR code image could not be saved.', 'oilmazing-sfc' ) );
		}

		return self::get_relative_path( $filepath );
	}

	/**
	 * Download a QR PNG from the first working provider.
	 *
	 * @param string $referral_url URL to encode.
	 * @return string|\WP_Error PNG binary on success.
	 */
	private static function fetch_qr_image( $referral_url ) {
		$providers = array(
			add_query_arg(
				array(
					'size'   => '400x400',
					'format' => 'png',
					'data'   => rawurlencode( $referral_url ),
				),
				'https://api.qrserver.com/v1/create-qr-code/'
			),
			add_query_arg(
				array(
					'size'   => 400,
					'margin' => 2,
					'text'   => rawurlencode( $referral_url ),
				),
				'https://quickchart.io/qr'
			),
		);

		$last_error = '';

		foreach ( $providers as $endpoint ) {
			$response = wp_remote_get(
				$endpoint,
				array(
					'timeout'   => 30,
					'sslverify' => apply_filters( 'oilmazing_sfc_qr_sslverify', true ),
				)
			);

			if ( is_wp_error( $response ) ) {
				$last_error = $response->get_error_message();
				continue;
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			$body = wp_remote_retrieve_body( $response );

			if ( 200 === $code && '' !== $body ) {
				return $body;
			}

			$last_error = sprintf( 'HTTP %d from %s', $code, wp_parse_url( $endpoint, PHP_URL_HOST ) );
		}

		return new WP_Error(
			'qr_generation_failed',
			sprintf(
				/* translators: %s: technical reason */
				__( 'The QR code image could not be generated. The server may be blocking outgoing requests. Reason: %s', 'oilmazing-sfc' ),
				$last_error ? $last_error : __( 'unknown', 'oilmazing-sfc' )
			)
		);
	}

	/**
	 * @param string $relative_path Relative uploads path.
	 * @return string
	 */
	public static function get_public_url( $relative_path ) {
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['baseurl'] ) . ltrim( (string) $relative_path, '/' );
	}

	/**
	 * @param string $relative_path Relative uploads path.
	 * @return string
	 */
	public static function get_absolute_path( $relative_path ) {
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['basedir'] ) . ltrim( (string) $relative_path, '/' );
	}

	/**
	 * @return string|\WP_Error
	 */
	private static function get_storage_dir() {
		$upload_dir = wp_upload_dir();
		if ( ! empty( $upload_dir['error'] ) ) {
			return new WP_Error( 'upload_dir_error', $upload_dir['error'] );
		}

		$directory = trailingslashit( $upload_dir['basedir'] ) . 'oilmazing-sfc-qr';
		if ( ! wp_mkdir_p( $directory ) ) {
			return new WP_Error( 'qr_dir_failed', __( 'Unable to create the QR storage directory.', 'oilmazing-sfc' ) );
		}

		return $directory;
	}

	/**
	 * @param string $absolute_path Absolute file path.
	 * @return string
	 */
	private static function get_relative_path( $absolute_path ) {
		$upload_dir = wp_upload_dir();
		$basedir    = wp_normalize_path( $upload_dir['basedir'] );
		$absolute   = wp_normalize_path( $absolute_path );

		if ( 0 === strpos( $absolute, $basedir ) ) {
			return ltrim( substr( $absolute, strlen( $basedir ) ), '/' );
		}

		return basename( $absolute_path );
	}
}
