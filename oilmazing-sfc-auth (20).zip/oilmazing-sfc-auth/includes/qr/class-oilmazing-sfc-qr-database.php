<?php
/**
 * QR module database tables.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_QR_Database
 */
class Oilmazing_SFC_QR_Database {

	const DB_VERSION = '1.1.1';

	/**
	 * Create or upgrade QR tables.
	 */
	public static function install_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$codes_table     = self::codes_table();
		$leads_table     = self::leads_table();

		$sql = "CREATE TABLE {$codes_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			affiliate_id bigint(20) unsigned NOT NULL,
			referral_url text NOT NULL,
			qr_file varchar(255) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'inactive',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY affiliate_id (affiliate_id),
			KEY status (status)
		) {$charset_collate};

		CREATE TABLE {$leads_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			affiliate_id bigint(20) unsigned NOT NULL,
			first_name varchar(100) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL,
			phone varchar(50) NOT NULL DEFAULT '',
			referral_url text NOT NULL,
			ip_address varchar(100) NOT NULL DEFAULT '',
			user_agent text NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY affiliate_email (affiliate_id, email),
			KEY affiliate_id (affiliate_id),
			KEY created_at (created_at)
		) {$charset_collate};";

		dbDelta( $sql );
		self::maybe_upgrade_leads_table();
		update_option( 'oilmazing_sfc_qr_db_version', self::DB_VERSION );
	}

	/**
	 * Ensure newer lead columns exist on older installs.
	 */
	public static function maybe_upgrade_leads_table() {
		global $wpdb;

		$table = self::leads_table();
		$cols  = $wpdb->get_col( "SHOW COLUMNS FROM {$table}", 0 );

		if ( ! is_array( $cols ) || empty( $cols ) ) {
			return;
		}

		if ( ! in_array( 'first_name', $cols, true ) ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( "ALTER TABLE {$table} ADD COLUMN first_name varchar(100) NOT NULL DEFAULT '' AFTER affiliate_id" );
		}

		if ( ! in_array( 'phone', $cols, true ) ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( "ALTER TABLE {$table} ADD COLUMN phone varchar(50) NOT NULL DEFAULT '' AFTER email" );
		}
	}

	/**
	 * Ensure tables exist.
	 */
	public static function maybe_install_tables() {
		if ( get_option( 'oilmazing_sfc_qr_db_version' ) !== self::DB_VERSION ) {
			self::install_tables();
			return;
		}

		self::maybe_upgrade_leads_table();
	}

	/**
	 * @return string
	 */
	public static function codes_table() {
		global $wpdb;
		return $wpdb->prefix . 'oilmazing_sfc_qr_codes';
	}

	/**
	 * @return string
	 */
	public static function leads_table() {
		global $wpdb;
		return $wpdb->prefix . 'oilmazing_sfc_qr_leads';
	}
}
