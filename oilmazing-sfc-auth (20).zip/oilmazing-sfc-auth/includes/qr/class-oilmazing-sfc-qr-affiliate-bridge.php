<?php
/**
 * AffiliatePress bridge for QR management.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_QR_Affiliate_Bridge
 */
class Oilmazing_SFC_QR_Affiliate_Bridge {

	/**
	 * @return bool
	 */
	public static function is_available() {
		return class_exists( 'Oilmazing_SFC_Affiliate_Integration' )
			&& Oilmazing_SFC_Affiliate_Integration::is_affiliatepress_active();
	}

	/**
	 * Get the official AffiliatePress referral URL for an affiliate.
	 *
	 * @param int $affiliate_id AffiliatePress affiliate ID.
	 * @return string
	 */
	public static function get_referral_url( $affiliate_id ) {
		$affiliate_id = absint( $affiliate_id );
		if ( $affiliate_id <= 0 || ! self::is_available() ) {
			return '';
		}

		return (string) Oilmazing_SFC_Affiliate_Integration::get_affiliate_link( $affiliate_id );
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 * @return bool
	 */
	public static function is_valid_affiliate( $affiliate_id ) {
		global $affiliatepress_affiliates;

		$affiliate_id = absint( $affiliate_id );
		if ( $affiliate_id <= 0 ) {
			return false;
		}

		if ( isset( $affiliatepress_affiliates ) && is_object( $affiliatepress_affiliates ) && method_exists( $affiliatepress_affiliates, 'affiliatepress_is_valid_affiliate' ) ) {
			return (bool) $affiliatepress_affiliates->affiliatepress_is_valid_affiliate( $affiliate_id );
		}

		return $affiliate_id > 0;
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 * @return int
	 */
	public static function get_user_id_for_affiliate( $affiliate_id ) {
		global $AffiliatePress;

		$affiliate_id = absint( $affiliate_id );
		if ( $affiliate_id <= 0 || ! isset( $AffiliatePress ) || ! method_exists( $AffiliatePress, 'affiliatepress_get_affiliate_user_id' ) ) {
			return 0;
		}

		return (int) $AffiliatePress->affiliatepress_get_affiliate_user_id( $affiliate_id );
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 * @return string
	 */
	public static function get_affiliate_name( $affiliate_id ) {
		global $wpdb, $affiliatepress_tbl_ap_affiliates;

		$affiliate_id = absint( $affiliate_id );
		if ( $affiliate_id <= 0 || empty( $affiliatepress_tbl_ap_affiliates ) ) {
			return '';
		}

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT ap_affiliates_first_name, ap_affiliates_last_name, ap_affiliates_user_id, ap_affiliates_user_email
				FROM {$affiliatepress_tbl_ap_affiliates}
				WHERE ap_affiliates_id = %d
				LIMIT 1",
				$affiliate_id
			),
			ARRAY_A
		);

		if ( ! is_array( $row ) ) {
			return '';
		}

		$name = trim( (string) ( $row['ap_affiliates_first_name'] ?? '' ) . ' ' . (string) ( $row['ap_affiliates_last_name'] ?? '' ) );
		if ( '' !== $name ) {
			return $name;
		}

		$user_id = (int) ( $row['ap_affiliates_user_id'] ?? 0 );
		if ( $user_id > 0 ) {
			$user = get_userdata( $user_id );
			if ( $user ) {
				return $user->display_name ? $user->display_name : $user->user_login;
			}
		}

		return (string) ( $row['ap_affiliates_user_email'] ?? '' );
	}

	/**
	 * @param array<string,mixed> $args Query args.
	 * @return array<int, array<string, mixed>>
	 */
	public static function query_affiliates( $args = array() ) {
		global $wpdb, $affiliatepress_tbl_ap_affiliates;

		if ( ! self::is_available() || empty( $affiliatepress_tbl_ap_affiliates ) ) {
			return array();
		}

		$defaults = array(
			'search'   => '',
			'paged'    => 1,
			'per_page' => 20,
		);
		$args     = wp_parse_args( $args, $defaults );

		$paged    = max( 1, (int) $args['paged'] );
		$per_page = max( 1, min( 100, (int) $args['per_page'] ) );
		$offset   = ( $paged - 1 ) * $per_page;
		$search   = trim( (string) $args['search'] );

		$where  = 'WHERE 1=1';
		$params = array();

		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (ap_affiliates_first_name LIKE %s OR ap_affiliates_last_name LIKE %s OR ap_affiliates_user_email LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$sql = "SELECT ap_affiliates_id, ap_affiliates_user_id, ap_affiliates_first_name, ap_affiliates_last_name, ap_affiliates_user_email, ap_affiliates_status
			FROM {$affiliatepress_tbl_ap_affiliates}
			{$where}
			ORDER BY ap_affiliates_id DESC
			LIMIT %d OFFSET %d";

		$params[] = $per_page;
		$params[] = $offset;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Dynamic WHERE with prepared params.
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );

		$affiliates = array();
		foreach ( (array) $rows as $row ) {
			$affiliate_id = (int) ( $row['ap_affiliates_id'] ?? 0 );
			if ( $affiliate_id <= 0 ) {
				continue;
			}

			$affiliates[] = array(
				'affiliate_id' => $affiliate_id,
				'user_id'      => (int) ( $row['ap_affiliates_user_id'] ?? 0 ),
				'name'         => self::get_affiliate_name( $affiliate_id ),
				'email'        => (string) ( $row['ap_affiliates_user_email'] ?? '' ),
				'status'       => (int) ( $row['ap_affiliates_status'] ?? 0 ),
				'referral_url' => self::get_referral_url( $affiliate_id ),
				'is_valid'     => self::is_valid_affiliate( $affiliate_id ),
			);
		}

		return $affiliates;
	}

	/**
	 * @param string $search Search query.
	 * @return int
	 */
	public static function count_affiliates( $search = '' ) {
		global $wpdb, $affiliatepress_tbl_ap_affiliates;

		if ( ! self::is_available() || empty( $affiliatepress_tbl_ap_affiliates ) ) {
			return 0;
		}

		$search = trim( (string) $search );
		$where  = 'WHERE 1=1';
		$params = array();

		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (ap_affiliates_first_name LIKE %s OR ap_affiliates_last_name LIKE %s OR ap_affiliates_user_email LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$sql = "SELECT COUNT(ap_affiliates_id) FROM {$affiliatepress_tbl_ap_affiliates} {$where}";

		if ( ! empty( $params ) ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( $sql );
	}
}
