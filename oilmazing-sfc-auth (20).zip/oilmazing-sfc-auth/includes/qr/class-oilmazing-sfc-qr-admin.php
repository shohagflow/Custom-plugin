<?php
/**
 * QR Management admin screen.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_QR_Admin
 */
class Oilmazing_SFC_QR_Admin {

	const PAGE_SLUG = 'oilmazing-sfc-qr-management';

	const ACTION_EXPORT_LEADS = 'oilmazing_sfc_export_qr_leads';

	const ACTION_SAVE_LEAD_POPUP_SETTINGS = 'oilmazing_sfc_qr_save_lead_popup_settings';

	/**
	 * Register hooks.
	 */
	public static function init() {
		if ( ! Oilmazing_SFC_QR_Affiliate_Bridge::is_available() ) {
			return;
		}

		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 99 );
		add_action( 'admin_post_' . self::ACTION_EXPORT_LEADS, array( __CLASS__, 'export_leads_csv' ) );
		add_action( 'admin_post_' . self::ACTION_SAVE_LEAD_POPUP_SETTINGS, array( __CLASS__, 'save_lead_popup_settings' ) );
		add_action( 'wp_ajax_oilmazing_sfc_qr_generate', array( __CLASS__, 'ajax_generate' ) );
		add_action( 'wp_ajax_oilmazing_sfc_qr_toggle_status', array( __CLASS__, 'ajax_toggle_status' ) );
		add_action( 'wp_ajax_oilmazing_sfc_qr_download', array( __CLASS__, 'ajax_download' ) );
	}

	/**
	 * Register submenu under Scent Freedom Club.
	 */
	public static function register_menu() {
		$parent = class_exists( 'Oilmazing_SFC_Admin' ) ? Oilmazing_SFC_Admin::PAGE_SLUG : 'options-general.php';

		$hook = add_submenu_page(
			$parent,
			__( 'QR Management', 'oilmazing-sfc' ),
			__( 'QR Management', 'oilmazing-sfc' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);

		if ( $hook ) {
			add_action( "load-{$hook}", array( __CLASS__, 'enqueue_assets' ) );
			add_action( "admin_enqueue_scripts-{$hook}", array( __CLASS__, 'enqueue_assets' ) );
		}
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook_suffix Hook suffix.
	 */
	public static function enqueue_assets( $hook_suffix = '' ) {
		unset( $hook_suffix );

		if ( function_exists( 'oilmazing_sfc_enqueue_admin_assets' ) ) {
			oilmazing_sfc_enqueue_admin_assets();
		}

		if ( class_exists( 'Oilmazing_SFC_Auth_Bootstrap' ) ) {
			Oilmazing_SFC_Auth_Bootstrap::enqueue_admin_menu_assets( self::PAGE_SLUG );
		}

		wp_enqueue_style( 'dashicons' );
		wp_enqueue_media();
		wp_enqueue_style(
			'oilmazing-sfc-qr-admin',
			OILMAZING_SFC_AUTH_URL . 'assets/css/qr/qr-admin.css',
			array( 'oilmazing-sfc-admin' ),
			OILMAZING_SFC_AUTH_VERSION
		);

		wp_enqueue_script(
			'oilmazing-sfc-qr-admin',
			OILMAZING_SFC_AUTH_URL . 'assets/js/qr/qr-admin.js',
			array( 'jquery', 'media-upload', 'media-views' ),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		wp_localize_script(
			'oilmazing-sfc-qr-admin',
			'oilmazingSfcQrAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'oilmazing_sfc_qr_admin' ),
				'i18n'    => array(
					'generating'  => __( 'Generating…', 'oilmazing-sfc' ),
					'generate'    => __( 'Generate QR', 'oilmazing-sfc' ),
					'activate'    => __( 'Activate', 'oilmazing-sfc' ),
					'deactivate'  => __( 'Deactivate', 'oilmazing-sfc' ),
					'download'    => __( 'Download', 'oilmazing-sfc' ),
					'success'     => __( 'QR updated successfully.', 'oilmazing-sfc' ),
					'error'       => __( 'Unable to complete this action.', 'oilmazing-sfc' ),
					'viewLeads'   => __( 'View leads', 'oilmazing-sfc' ),
					'selectImage' => __( 'Select Image', 'oilmazing-sfc' ),
					'changeImage' => __( 'Change Image', 'oilmazing-sfc' ),
					'removeImage' => __( 'Remove', 'oilmazing-sfc' ),
					'useImage'    => __( 'Use this image', 'oilmazing-sfc' ),
					'noImage'     => __( 'No image selected', 'oilmazing-sfc' ),
				),
			)
		);
	}

	/**
	 * Render admin page.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'oilmazing-sfc' ) );
		}

		$search   = isset( $_GET['qr_q'] ) ? sanitize_text_field( wp_unslash( $_GET['qr_q'] ) ) : '';
		$paged    = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1;
		$per_page = 20;

		$lead_search    = isset( $_GET['lead_q'] ) ? sanitize_text_field( wp_unslash( $_GET['lead_q'] ) ) : '';
		$lead_affiliate = isset( $_GET['lead_affiliate'] ) ? absint( wp_unslash( $_GET['lead_affiliate'] ) ) : 0;
		$leads_paged    = isset( $_GET['leads_paged'] ) ? max( 1, absint( wp_unslash( $_GET['leads_paged'] ) ) ) : 1;
		$leads_per_page = 15;

		$total    = Oilmazing_SFC_QR_Affiliate_Bridge::count_affiliates( $search );
		$rows     = Oilmazing_SFC_QR_Affiliate_Bridge::query_affiliates(
			array(
				'search'   => $search,
				'paged'    => $paged,
				'per_page' => $per_page,
			)
		);

		$affiliates = array();
		foreach ( $rows as $row ) {
			$affiliate_id = (int) ( $row['affiliate_id'] ?? 0 );
			$qr           = Oilmazing_SFC_QR_Repository::get_code_by_affiliate_id( $affiliate_id );

			$affiliates[] = array_merge(
				$row,
				array(
					'qr'              => $qr,
					'lead_count'      => $qr ? (int) ( $qr['lead_count'] ?? 0 ) : Oilmazing_SFC_QR_Repository::count_leads( $affiliate_id ),
					'leads_export_url'=> self::get_leads_export_url( '', $affiliate_id ),
				)
			);
		}

		$summary = array(
			'total_affiliates' => $total,
			'active_qr'        => self::count_codes_by_status( 'active' ),
			'total_leads'      => self::count_all_leads(),
		);

		$lead_query_args = array(
			'search'       => $lead_search,
			'affiliate_id' => $lead_affiliate,
		);

		$leads_total = Oilmazing_SFC_QR_Repository::count_leads_query( $lead_query_args );
		$leads       = Oilmazing_SFC_QR_Repository::query_leads(
			array_merge(
				$lead_query_args,
				array(
					'paged'    => $leads_paged,
					'per_page' => $leads_per_page,
				)
			)
		);

		$lead_affiliate_name = $lead_affiliate > 0
			? Oilmazing_SFC_QR_Affiliate_Bridge::get_affiliate_name( $lead_affiliate )
			: '';

		$leads_export_url      = self::get_leads_export_url( $lead_search, $lead_affiliate );
		$leads_export_all_url  = self::get_leads_export_url( $lead_search, 0 );
		$lead_popup_settings   = Oilmazing_SFC_QR_Lead_Popup::get_lead_popup_settings();
		$lead_popup_save_url   = admin_url( 'admin-post.php?action=' . self::ACTION_SAVE_LEAD_POPUP_SETTINGS );
		$lead_popup_saved      = ! empty( $_GET['lead_popup_saved'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['lead_popup_saved'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( function_exists( 'oilmazing_sfc_load_template' ) ) {
			oilmazing_sfc_load_template(
				'admin/qr-management.php',
				compact(
					'affiliates',
					'search',
					'paged',
					'per_page',
					'total',
					'summary',
					'leads',
					'lead_search',
					'lead_affiliate',
					'lead_affiliate_name',
					'leads_paged',
					'leads_per_page',
					'leads_total',
					'leads_export_url',
					'leads_export_all_url',
					'lead_popup_settings',
					'lead_popup_save_url',
					'lead_popup_saved'
				)
			);
			return;
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'QR Management', 'oilmazing-sfc' ) . '</h1></div>';
	}

	/**
	 * AJAX: generate or regenerate QR.
	 */
	public static function ajax_generate() {
		check_ajax_referer( 'oilmazing_sfc_qr_admin', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		$affiliate_id = isset( $_POST['affiliate_id'] ) ? absint( wp_unslash( $_POST['affiliate_id'] ) ) : 0;
		if ( $affiliate_id <= 0 || ! Oilmazing_SFC_QR_Affiliate_Bridge::is_valid_affiliate( $affiliate_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid affiliate selected.', 'oilmazing-sfc' ) ), 400 );
		}

		$referral_url = Oilmazing_SFC_QR_Affiliate_Bridge::get_referral_url( $affiliate_id );
		if ( '' === $referral_url ) {
			wp_send_json_error( array( 'message' => __( 'AffiliatePress referral URL could not be retrieved.', 'oilmazing-sfc' ) ), 400 );
		}

		$referral_url = Oilmazing_SFC_QR_Lead_Popup::append_qr_flag_to_url( $referral_url );

		$file = Oilmazing_SFC_QR_Generator::generate_for_affiliate( $affiliate_id, $referral_url );
		if ( is_wp_error( $file ) ) {
			wp_send_json_error( array( 'message' => $file->get_error_message() ), 500 );
		}

		$existing = Oilmazing_SFC_QR_Repository::get_code_by_affiliate_id( $affiliate_id );
		$status   = $existing ? (string) ( $existing['status'] ?? 'inactive' ) : 'inactive';

		$record = Oilmazing_SFC_QR_Repository::upsert_code( $affiliate_id, $referral_url, $file, $status );
		if ( is_wp_error( $record ) ) {
			wp_send_json_error( array( 'message' => $record->get_error_message() ), 500 );
		}

		wp_send_json_success(
			array(
				'message' => __( 'QR code generated successfully.', 'oilmazing-sfc' ),
				'qr'      => $record,
			)
		);
	}

	/**
	 * AJAX: activate or deactivate QR.
	 */
	public static function ajax_toggle_status() {
		check_ajax_referer( 'oilmazing_sfc_qr_admin', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Forbidden.', 'oilmazing-sfc' ) ), 403 );
		}

		$affiliate_id = isset( $_POST['affiliate_id'] ) ? absint( wp_unslash( $_POST['affiliate_id'] ) ) : 0;
		$status       = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';

		$result = Oilmazing_SFC_QR_Repository::update_status( $affiliate_id, $status );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
		}

		$record = Oilmazing_SFC_QR_Repository::get_code_by_affiliate_id( $affiliate_id );

		wp_send_json_success(
			array(
				'message' => 'active' === $status
					? __( 'QR code activated.', 'oilmazing-sfc' )
					: __( 'QR code deactivated.', 'oilmazing-sfc' ),
				'qr'      => $record,
			)
		);
	}

	/**
	 * AJAX: download QR PNG.
	 */
	public static function ajax_download() {
		check_ajax_referer( 'oilmazing_sfc_qr_admin', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Forbidden.', 'oilmazing-sfc' ), '', array( 'response' => 403 ) );
		}

		$affiliate_id = isset( $_GET['affiliate_id'] ) ? absint( wp_unslash( $_GET['affiliate_id'] ) ) : 0;
		$record       = Oilmazing_SFC_QR_Repository::get_code_by_affiliate_id( $affiliate_id );

		if ( ! $record || empty( $record['qr_file'] ) ) {
			wp_die( esc_html__( 'QR file not found.', 'oilmazing-sfc' ), '', array( 'response' => 404 ) );
		}

		$path = Oilmazing_SFC_QR_Generator::get_absolute_path( (string) $record['qr_file'] );
		if ( ! file_exists( $path ) ) {
			wp_die( esc_html__( 'QR file not found.', 'oilmazing-sfc' ), '', array( 'response' => 404 ) );
		}

		$name = sanitize_file_name( 'affiliate-' . $affiliate_id . '-qr.png' );

		header( 'Content-Type: image/png' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		header( 'Content-Length: ' . filesize( $path ) );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		readfile( $path );
		exit;
	}

	/**
	 * Build a nonce-protected CSV export URL.
	 *
	 * @param string $search       Lead email search.
	 * @param int    $affiliate_id Affiliate ID.
	 * @return string
	 */
	public static function get_leads_export_url( $search = '', $affiliate_id = 0 ) {
		$params = array(
			'action' => self::ACTION_EXPORT_LEADS,
		);

		$search = trim( (string) $search );
		if ( '' !== $search ) {
			$params['lead_q'] = $search;
		}

		$affiliate_id = absint( $affiliate_id );
		if ( $affiliate_id > 0 ) {
			$params['lead_affiliate'] = $affiliate_id;
		}

		return wp_nonce_url( add_query_arg( $params, admin_url( 'admin-post.php' ) ), self::ACTION_EXPORT_LEADS );
	}

	/**
	 * Export QR leads as CSV.
	 */
	public static function export_leads_csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to export leads.', 'oilmazing-sfc' ) );
		}

		check_admin_referer( self::ACTION_EXPORT_LEADS );

		$search       = isset( $_GET['lead_q'] ) ? sanitize_text_field( wp_unslash( $_GET['lead_q'] ) ) : '';
		$affiliate_id = isset( $_GET['lead_affiliate'] ) ? absint( wp_unslash( $_GET['lead_affiliate'] ) ) : 0;

		$leads = Oilmazing_SFC_QR_Repository::get_leads_for_export(
			array(
				'search'       => $search,
				'affiliate_id' => $affiliate_id,
			)
		);

		$filename = 'oilmazing-sfc-qr-leads-' . gmdate( 'Y-m-d' );
		if ( $affiliate_id > 0 ) {
			$filename .= '-affiliate-' . $affiliate_id;
		}
		$filename .= '.csv';

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=' . $filename );

		$output = fopen( 'php://output', 'w' );
		if ( false === $output ) {
			wp_die( esc_html__( 'Unable to export leads.', 'oilmazing-sfc' ) );
		}

		fputcsv(
			$output,
			array(
				'ID',
				'First Name',
				'Customer Email',
				'Phone',
				'Affiliate ID',
				'Affiliate Name',
				'Referral URL',
				'IP Address',
				'Captured At',
			)
		);

		foreach ( $leads as $lead ) {
			fputcsv(
				$output,
				array(
					(int) ( $lead['id'] ?? 0 ),
					(string) ( $lead['first_name'] ?? '' ),
					(string) ( $lead['email'] ?? '' ),
					(string) ( $lead['phone'] ?? '' ),
					(int) ( $lead['affiliate_id'] ?? 0 ),
					(string) ( $lead['affiliate_name'] ?? '' ),
					(string) ( $lead['referral_url'] ?? '' ),
					(string) ( $lead['ip_address'] ?? '' ),
					(string) ( $lead['created_label'] ?? $lead['created_at'] ?? '' ),
				)
			);
		}

		fclose( $output );
		exit;
	}

	/**
	 * Save QR lead popup form settings.
	 */
	public static function save_lead_popup_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to update popup settings.', 'oilmazing-sfc' ) );
		}

		check_admin_referer( self::ACTION_SAVE_LEAD_POPUP_SETTINGS );

		$settings = Oilmazing_SFC_QR_Lead_Popup::get_lead_popup_settings();
		$settings = array(
			'logo_id'             => (int) ( $settings['logo_id'] ?? 0 ),
			'heading'             => (string) ( $settings['heading'] ?? '' ),
			'description'         => (string) ( $settings['description'] ?? '' ),
			'first_name_label'    => (string) ( $settings['first_name_label'] ?? '' ),
			'email_label'         => (string) ( $settings['email_label'] ?? '' ),
			'phone_label'         => (string) ( $settings['phone_label'] ?? '' ),
			'button_text'         => (string) ( $settings['button_text'] ?? '' ),
			'background_image_id' => (int) ( $settings['background_image_id'] ?? 0 ),
			'button_color_start'  => (string) ( $settings['button_color_start'] ?? '' ),
			'button_color_end'    => (string) ( $settings['button_color_end'] ?? '' ),
		);

		$settings['heading']             = isset( $_POST['heading'] ) ? sanitize_text_field( wp_unslash( $_POST['heading'] ) ) : $settings['heading'];
		$settings['description']         = isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : $settings['description'];
		$settings['first_name_label']    = isset( $_POST['first_name_label'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name_label'] ) ) : $settings['first_name_label'];
		$settings['email_label']         = isset( $_POST['email_label'] ) ? sanitize_text_field( wp_unslash( $_POST['email_label'] ) ) : $settings['email_label'];
		$settings['phone_label']         = isset( $_POST['phone_label'] ) ? sanitize_text_field( wp_unslash( $_POST['phone_label'] ) ) : $settings['phone_label'];
		$settings['button_text']         = isset( $_POST['button_text'] ) ? sanitize_text_field( wp_unslash( $_POST['button_text'] ) ) : $settings['button_text'];
		$settings['button_color_start']  = self::sanitize_hex_or_default( isset( $_POST['button_color_start'] ) ? wp_unslash( $_POST['button_color_start'] ) : '', (string) $settings['button_color_start'] );
		$settings['button_color_end']    = self::sanitize_hex_or_default( isset( $_POST['button_color_end'] ) ? wp_unslash( $_POST['button_color_end'] ) : '', (string) $settings['button_color_end'] );

		if ( isset( $_POST['logo_id'] ) ) {
			$settings['logo_id'] = absint( wp_unslash( $_POST['logo_id'] ) );
		}

		if ( isset( $_POST['background_image_id'] ) ) {
			$settings['background_image_id'] = absint( wp_unslash( $_POST['background_image_id'] ) );
		}

		update_option( 'oilmazing_sfc_qr_lead_popup_settings', $settings );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'             => self::PAGE_SLUG,
					'qr_tab'           => 'leads',
					'leads_tab'        => 'form_settings',
					'lead_popup_saved' => '1',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * @param string $status QR status.
	 * @return int
	 */
	private static function count_codes_by_status( $status ) {
		global $wpdb;

		$table = Oilmazing_SFC_QR_Database::codes_table();
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(id) FROM {$table} WHERE status = %s",
				sanitize_key( (string) $status )
			)
		);
	}

	/**
	 * @return int
	 */
	private static function count_all_leads() {
		global $wpdb;

		$table = Oilmazing_SFC_QR_Database::leads_table();
		return (int) $wpdb->get_var( "SELECT COUNT(id) FROM {$table}" );
	}

	/**
	 * @param string $value   Color candidate.
	 * @param string $default Default color.
	 * @return string
	 */
	private static function sanitize_hex_or_default( $value, $default ) {
		$sanitized = sanitize_hex_color( (string) $value );
		return $sanitized ? $sanitized : $default;
	}
}
