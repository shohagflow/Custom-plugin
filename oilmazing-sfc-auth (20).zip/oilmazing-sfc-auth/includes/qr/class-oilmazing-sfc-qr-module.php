<?php
/**
 * QR module bootstrap.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

require_once OILMAZING_SFC_AUTH_PATH . 'includes/qr/class-oilmazing-sfc-qr-database.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/qr/class-oilmazing-sfc-qr-affiliate-bridge.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/qr/class-oilmazing-sfc-qr-generator.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/qr/class-oilmazing-sfc-qr-repository.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/qr/class-oilmazing-sfc-qr-lead-popup.php';
require_once OILMAZING_SFC_AUTH_PATH . 'includes/qr/class-oilmazing-sfc-qr-admin.php';

/**
 * Class Oilmazing_SFC_QR_Module
 */
class Oilmazing_SFC_QR_Module {

	/**
	 * Register QR module hooks.
	 */
	public static function init() {
		add_action( 'init', array( 'Oilmazing_SFC_QR_Database', 'maybe_install_tables' ), 5 );

		if ( ! Oilmazing_SFC_QR_Affiliate_Bridge::is_available() ) {
			return;
		}

		Oilmazing_SFC_QR_Lead_Popup::init();

		if ( is_admin() ) {
			Oilmazing_SFC_QR_Admin::init();
		}
	}
}
