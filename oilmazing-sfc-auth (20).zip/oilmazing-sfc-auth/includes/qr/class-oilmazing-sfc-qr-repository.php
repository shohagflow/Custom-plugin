<?php
/**
 * QR codes and leads repository.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_QR_Repository
 */
class Oilmazing_SFC_QR_Repository {

	/**
	 * @param int $affiliate_id Affiliate ID.
	 * @return array<string,mixed>|null
	 */
	public static function get_code_by_affiliate_id( $affiliate_id ) {
		global $wpdb;

		$affiliate_id = absint( $affiliate_id );
		if ( $affiliate_id <= 0 ) {
			return null;
		}

		$table = Oilmazing_SFC_QR_Database::codes_table();
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE affiliate_id = %d LIMIT 1",
				$affiliate_id
			),
			ARRAY_A
		);

		return is_array( $row ) ? self::format_code_row( $row ) : null;
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 * @return array<string,mixed>|null
	 */
	public static function get_active_code_by_affiliate_id( $affiliate_id ) {
		$row = self::get_code_by_affiliate_id( $affiliate_id );
		if ( ! $row || 'active' !== ( $row['status'] ?? '' ) ) {
			return null;
		}

		return $row;
	}

	/**
	 * @param int    $affiliate_id Affiliate ID.
	 * @param string $referral_url Referral URL.
	 * @param string $qr_file      Relative QR file path.
	 * @param string $status       QR status.
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function upsert_code( $affiliate_id, $referral_url, $qr_file, $status = 'inactive' ) {
		global $wpdb;

		$affiliate_id = absint( $affiliate_id );
		$referral_url = esc_url_raw( (string) $referral_url );
		$qr_file      = sanitize_text_field( (string) $qr_file );
		$status       = in_array( $status, array( 'active', 'inactive' ), true ) ? $status : 'inactive';

		if ( $affiliate_id <= 0 || '' === $referral_url ) {
			return new WP_Error( 'invalid_qr_record', __( 'Invalid QR record data.', 'oilmazing-sfc' ) );
		}

		$table = Oilmazing_SFC_QR_Database::codes_table();
		$now   = current_time( 'mysql', true );
		$existing = self::get_code_by_affiliate_id( $affiliate_id );

		if ( $existing ) {
			$updated = $wpdb->update(
				$table,
				array(
					'referral_url' => $referral_url,
					'qr_file'      => $qr_file,
					'status'       => $status,
					'updated_at'   => $now,
				),
				array( 'affiliate_id' => $affiliate_id ),
				array( '%s', '%s', '%s', '%s' ),
				array( '%d' )
			);

			if ( false === $updated ) {
				return new WP_Error( 'qr_update_failed', __( 'Unable to update the QR record.', 'oilmazing-sfc' ) );
			}
		} else {
			$inserted = $wpdb->insert(
				$table,
				array(
					'affiliate_id' => $affiliate_id,
					'referral_url' => $referral_url,
					'qr_file'      => $qr_file,
					'status'       => $status,
					'created_at'   => $now,
					'updated_at'   => $now,
				),
				array( '%d', '%s', '%s', '%s', '%s', '%s' )
			);

			if ( ! $inserted ) {
				return new WP_Error( 'qr_insert_failed', __( 'Unable to save the QR record.', 'oilmazing-sfc' ) );
			}
		}

		return self::get_code_by_affiliate_id( $affiliate_id );
	}

	/**
	 * @param int    $affiliate_id Affiliate ID.
	 * @param string $status       active|inactive.
	 * @return true|\WP_Error
	 */
	public static function update_status( $affiliate_id, $status ) {
		global $wpdb;

		$affiliate_id = absint( $affiliate_id );
		$status       = sanitize_key( (string) $status );

		if ( $affiliate_id <= 0 || ! in_array( $status, array( 'active', 'inactive' ), true ) ) {
			return new WP_Error( 'invalid_qr_status', __( 'Invalid QR status.', 'oilmazing-sfc' ) );
		}

		$row = self::get_code_by_affiliate_id( $affiliate_id );
		if ( ! $row ) {
			return new WP_Error( 'qr_not_found', __( 'Generate a QR code before changing its status.', 'oilmazing-sfc' ) );
		}

		if ( 'active' === $status && empty( $row['qr_file'] ) ) {
			return new WP_Error( 'qr_missing_file', __( 'Generate a QR image before activating it.', 'oilmazing-sfc' ) );
		}

		$table = Oilmazing_SFC_QR_Database::codes_table();
		$updated = $wpdb->update(
			$table,
			array(
				'status'     => $status,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'affiliate_id' => $affiliate_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error( 'qr_status_failed', __( 'Unable to update QR status.', 'oilmazing-sfc' ) );
		}

		return true;
	}

	/**
	 * @param int $affiliate_id Affiliate ID.
	 * @return int
	 */
	public static function count_leads( $affiliate_id ) {
		global $wpdb;

		$affiliate_id = absint( $affiliate_id );
		if ( $affiliate_id <= 0 ) {
			return 0;
		}

		$table = Oilmazing_SFC_QR_Database::leads_table();
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(id) FROM {$table} WHERE affiliate_id = %d",
				$affiliate_id
			)
		);
	}

	/**
	 * Query captured customer leads.
	 *
	 * @param array<string,mixed> $args Query args.
	 * @return array<int, array<string,mixed>>
	 */
	public static function query_leads( $args = array() ) {
		global $wpdb;

		$defaults = array(
			'search'       => '',
			'affiliate_id' => 0,
			'paged'        => 1,
			'per_page'     => 20,
		);
		$args     = wp_parse_args( $args, $defaults );

		$table        = Oilmazing_SFC_QR_Database::leads_table();
		$paged        = max( 1, (int) $args['paged'] );
		$per_page     = max( 1, min( 100, (int) $args['per_page'] ) );
		$offset       = ( $paged - 1 ) * $per_page;
		$search       = trim( (string) $args['search'] );
		$affiliate_id = absint( $args['affiliate_id'] );

		$where  = 'WHERE 1=1';
		$params = array();

		if ( $affiliate_id > 0 ) {
			$where   .= ' AND affiliate_id = %d';
			$params[] = $affiliate_id;
		}

		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (email LIKE %s OR first_name LIKE %s OR phone LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$sql = "SELECT * FROM {$table} {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d";
		$params[] = $per_page;
		$params[] = $offset;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );

		$leads = array();
		foreach ( (array) $rows as $row ) {
			$leads[] = self::format_lead_row( $row );
		}

		return $leads;
	}

	/**
	 * Count leads for listing filters.
	 *
	 * @param array<string,mixed> $args Query args.
	 * @return int
	 */
	public static function count_leads_query( $args = array() ) {
		global $wpdb;

		$defaults = array(
			'search'       => '',
			'affiliate_id' => 0,
		);
		$args     = wp_parse_args( $args, $defaults );

		$table        = Oilmazing_SFC_QR_Database::leads_table();
		$search       = trim( (string) $args['search'] );
		$affiliate_id = absint( $args['affiliate_id'] );

		$where  = 'WHERE 1=1';
		$params = array();

		if ( $affiliate_id > 0 ) {
			$where   .= ' AND affiliate_id = %d';
			$params[] = $affiliate_id;
		}

		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (email LIKE %s OR first_name LIKE %s OR phone LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$sql = "SELECT COUNT(id) FROM {$table} {$where}";

		if ( ! empty( $params ) ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( $sql );
	}

	/**
	 * Fetch leads for CSV export.
	 *
	 * @param array<string,mixed> $args Query args.
	 * @return array<int, array<string,mixed>>
	 */
	public static function get_leads_for_export( $args = array() ) {
		global $wpdb;

		$defaults = array(
			'search'       => '',
			'affiliate_id' => 0,
			'limit'        => 10000,
		);
		$args     = wp_parse_args( $args, $defaults );

		$table        = Oilmazing_SFC_QR_Database::leads_table();
		$search       = trim( (string) $args['search'] );
		$affiliate_id = absint( $args['affiliate_id'] );
		$limit        = max( 1, min( 10000, (int) $args['limit'] ) );

		$where  = 'WHERE 1=1';
		$params = array();

		if ( $affiliate_id > 0 ) {
			$where   .= ' AND affiliate_id = %d';
			$params[] = $affiliate_id;
		}

		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (email LIKE %s OR first_name LIKE %s OR phone LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$sql      = "SELECT * FROM {$table} {$where} ORDER BY created_at DESC LIMIT %d";
		$params[] = $limit;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );

		$leads = array();
		foreach ( (array) $rows as $row ) {
			$leads[] = self::format_lead_row( $row );
		}

		return $leads;
	}

	/**
	 * @param array<string,mixed> $row Raw DB row.
	 * @return array<string,mixed>
	 */
	private static function format_lead_row( $row ) {
		$affiliate_id   = (int) ( $row['affiliate_id'] ?? 0 );
		$affiliate_name = class_exists( 'Oilmazing_SFC_QR_Affiliate_Bridge' )
			? Oilmazing_SFC_QR_Affiliate_Bridge::get_affiliate_name( $affiliate_id )
			: '';

		$created_at = (string) ( $row['created_at'] ?? '' );
		$timestamp  = $created_at ? strtotime( $created_at . ' UTC' ) : false;

		return array(
			'id'             => (int) ( $row['id'] ?? 0 ),
			'affiliate_id'   => $affiliate_id,
			'affiliate_name' => $affiliate_name,
			'first_name'     => (string) ( $row['first_name'] ?? '' ),
			'email'          => (string) ( $row['email'] ?? '' ),
			'phone'          => (string) ( $row['phone'] ?? '' ),
			'referral_url'   => (string) ( $row['referral_url'] ?? '' ),
			'ip_address'     => (string) ( $row['ip_address'] ?? '' ),
			'created_at'     => $created_at,
			'created_label'  => $timestamp ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp ) : '',
		);
	}

	/**
	 * @param int                  $affiliate_id Affiliate ID.
	 * @param string               $email        Email address.
	 * @param string               $referral_url Referral URL.
	 * @param array<string,string> $extra        Optional first_name / phone.
	 * @return array<string,mixed>|true|\WP_Error
	 */
	public static function store_lead( $affiliate_id, $email, $referral_url, $extra = array() ) {
		global $wpdb;

		$affiliate_id = absint( $affiliate_id );
		$email        = sanitize_email( (string) $email );
		$referral_url = esc_url_raw( (string) $referral_url );
		$first_name   = isset( $extra['first_name'] ) ? sanitize_text_field( (string) $extra['first_name'] ) : '';
		$phone        = isset( $extra['phone'] ) ? sanitize_text_field( (string) $extra['phone'] ) : '';

		if ( $affiliate_id <= 0 || ! is_email( $email ) ) {
			return new WP_Error( 'invalid_lead', __( 'Please enter a valid email address.', 'oilmazing-sfc' ) );
		}

		$table = Oilmazing_SFC_QR_Database::leads_table();
		$exists = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE affiliate_id = %d AND email = %s LIMIT 1",
				$affiliate_id,
				$email
			)
		);

		if ( $exists > 0 ) {
			$updated = $wpdb->update(
				$table,
				array(
					'first_name'   => $first_name,
					'phone'        => $phone,
					'referral_url' => $referral_url,
					'ip_address'   => self::get_client_ip(),
					'user_agent'   => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
				),
				array( 'id' => $exists ),
				array( '%s', '%s', '%s', '%s', '%s' ),
				array( '%d' )
			);

			if ( false === $updated ) {
				return new WP_Error( 'lead_update_failed', __( 'Unable to save your details right now. Please try again.', 'oilmazing-sfc' ) );
			}

			return array(
				'id'           => $exists,
				'affiliate_id' => $affiliate_id,
				'first_name'   => $first_name,
				'email'        => $email,
				'phone'        => $phone,
			);
		}

		$inserted = $wpdb->insert(
			$table,
			array(
				'affiliate_id' => $affiliate_id,
				'first_name'   => $first_name,
				'email'        => $email,
				'phone'        => $phone,
				'referral_url' => $referral_url,
				'ip_address'   => self::get_client_ip(),
				'user_agent'   => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
				'created_at'   => current_time( 'mysql', true ),
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( ! $inserted ) {
			return new WP_Error( 'lead_insert_failed', __( 'Unable to save your email right now. Please try again.', 'oilmazing-sfc' ) );
		}

		return array(
			'id'           => (int) $wpdb->insert_id,
			'affiliate_id' => $affiliate_id,
			'first_name'   => $first_name,
			'email'        => $email,
			'phone'        => $phone,
		);
	}

	/**
	 * @return string
	 */
	private static function get_client_ip() {
		if ( class_exists( 'Oilmazing_SFC_Affiliate_Integration' ) ) {
			global $AffiliatePress;
			if ( isset( $AffiliatePress ) && method_exists( $AffiliatePress, 'affiliatepress_get_ip_address' ) ) {
				return sanitize_text_field( (string) $AffiliatePress->affiliatepress_get_ip_address() );
			}
		}

		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	}

	/**
	 * @param array<string,mixed> $row Raw DB row.
	 * @return array<string,mixed>
	 */
	private static function format_code_row( $row ) {
		$qr_file = (string) ( $row['qr_file'] ?? '' );

		return array(
			'id'           => (int) ( $row['id'] ?? 0 ),
			'affiliate_id' => (int) ( $row['affiliate_id'] ?? 0 ),
			'referral_url' => (string) ( $row['referral_url'] ?? '' ),
			'qr_file'      => $qr_file,
			'qr_url'       => $qr_file ? Oilmazing_SFC_QR_Generator::get_public_url( $qr_file ) : '',
			'status'       => (string) ( $row['status'] ?? 'inactive' ),
			'created_at'   => (string) ( $row['created_at'] ?? '' ),
			'updated_at'   => (string) ( $row['updated_at'] ?? '' ),
			'lead_count'   => self::count_leads( (int) ( $row['affiliate_id'] ?? 0 ) ),
		);
	}
}
