<?php
/**
 * Admin settings and bulk conversion for WebP images.
 *
 * @package OilmazingSFC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Oilmazing_SFC_WebP_Admin
 */
class Oilmazing_SFC_WebP_Admin {

	const PAGE_SLUG = 'oilmazing-sfc-webp-optimizer';

	const AJAX_SCAN   = 'oilmazing_sfc_webp_scan';

	const AJAX_BATCH  = 'oilmazing_sfc_webp_convert_batch';

	const BATCH_SIZE  = 8;

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 20 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'wp_ajax_' . self::AJAX_SCAN, array( __CLASS__, 'ajax_scan' ) );
		add_action( 'wp_ajax_' . self::AJAX_BATCH, array( __CLASS__, 'ajax_convert_batch' ) );
	}

	/**
	 * Register submenu under Scent Freedom Club.
	 */
	public static function register_menu() {
		$parent = class_exists( 'Oilmazing_SFC_Admin' ) ? Oilmazing_SFC_Admin::PAGE_SLUG : 'oilmazing-sfc';

		$hook = add_submenu_page(
			$parent,
			__( 'WebP Optimizer', 'oilmazing-sfc' ),
			__( 'WebP Optimizer', 'oilmazing-sfc' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);

		if ( $hook ) {
			add_action( "load-{$hook}", array( __CLASS__, 'enqueue_assets' ) );
			add_action( "admin_enqueue_scripts-{$hook}", array( __CLASS__, 'enqueue_assets' ) );
		}
	}

	/**
	 * Register settings.
	 */
	public static function register_settings() {
		register_setting(
			'oilmazing_sfc_webp_settings',
			Oilmazing_SFC_WebP_Converter::OPTION_ENABLED,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'Oilmazing_SFC_WebP_Converter', 'sanitize_yes_no' ),
				'default'           => 'yes',
			)
		);

		register_setting(
			'oilmazing_sfc_webp_settings',
			Oilmazing_SFC_WebP_Converter::OPTION_QUALITY,
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( 'Oilmazing_SFC_WebP_Converter', 'sanitize_quality' ),
				'default'           => 82,
			)
		);

		register_setting(
			'oilmazing_sfc_webp_settings',
			Oilmazing_SFC_WebP_Converter::OPTION_DELETE_ORIGINAL,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( 'Oilmazing_SFC_WebP_Converter', 'sanitize_yes_no' ),
				'default'           => 'yes',
			)
		);
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook_suffix Hook suffix.
	 */
	public static function enqueue_assets( $hook_suffix = '' ) {
		unset( $hook_suffix );

		if ( function_exists( 'oilmazing_sfc_enqueue_admin_assets' ) ) {
			oilmazing_sfc_enqueue_admin_assets();
		}

		if ( class_exists( 'Oilmazing_SFC_Auth_Bootstrap' ) ) {
			Oilmazing_SFC_Auth_Bootstrap::enqueue_admin_menu_assets( self::PAGE_SLUG );
		}

		wp_enqueue_script(
			'oilmazing-sfc-webp-admin',
			OILMAZING_SFC_AUTH_URL . 'assets/js/webp-admin.js',
			array(),
			OILMAZING_SFC_AUTH_VERSION,
			true
		);

		wp_localize_script(
			'oilmazing-sfc-webp-admin',
			'oilmazingSfcWebpAdmin',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'oilmazing_sfc_webp_admin' ),
				'batchSize' => self::BATCH_SIZE,
				'i18n'      => array(
					'starting'    => __( 'Preparing conversion…', 'oilmazing-sfc' ),
					'converting'  => __( 'Converting images to WebP…', 'oilmazing-sfc' ),
					'complete'    => __( 'All convertible images are now optimized as WebP.', 'oilmazing-sfc' ),
					'unsupported' => __( 'This server cannot create WebP images. Enable Imagick or GD with WebP support.', 'oilmazing-sfc' ),
					'failed'      => __( 'Conversion failed. Please try again.', 'oilmazing-sfc' ),
				),
			)
		);
	}

	/**
	 * Render admin page.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'oilmazing-sfc' ) );
		}

		if ( function_exists( 'oilmazing_sfc_load_template' ) ) {
			oilmazing_sfc_load_template(
				'admin/webp-optimizer.php',
				array(
					'enabled'           => Oilmazing_SFC_WebP_Converter::is_enabled(),
					'quality'           => Oilmazing_SFC_WebP_Converter::get_quality(),
					'delete_original'   => Oilmazing_SFC_WebP_Converter::should_delete_original(),
					'is_supported'      => Oilmazing_SFC_WebP_Converter::is_conversion_supported(),
					'support'           => Oilmazing_SFC_WebP_Converter::get_support_diagnostics(),
					'convertible_count' => Oilmazing_SFC_WebP_Converter::count_convertible_attachments(),
				)
			);
			return;
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'WebP Optimizer', 'oilmazing-sfc' ) . '</h1></div>';
	}

	/**
	 * AJAX: return convertible image count.
	 */
	public static function ajax_scan() {
		self::verify_ajax_request();

		wp_send_json_success(
			array(
				'total'      => Oilmazing_SFC_WebP_Converter::count_convertible_attachments(),
				'supported'  => Oilmazing_SFC_WebP_Converter::is_conversion_supported(),
				'batch_size' => self::BATCH_SIZE,
			)
		);
	}

	/**
	 * AJAX: convert the next batch of images.
	 */
	public static function ajax_convert_batch() {
		self::verify_ajax_request();

		if ( ! Oilmazing_SFC_WebP_Converter::is_conversion_supported() ) {
			wp_send_json_error(
				array(
					'message' => __( 'This server cannot create WebP images.', 'oilmazing-sfc' ),
				),
				400
			);
		}

		$offset = isset( $_POST['offset'] ) ? max( 0, (int) wp_unslash( $_POST['offset'] ) ) : 0;
		$ids    = Oilmazing_SFC_WebP_Converter::get_convertible_attachment_ids( self::BATCH_SIZE, $offset );

		$processed = 0;
		$converted = 0;
		$skipped   = 0;
		$saved     = 0;
		$errors    = array();

		foreach ( $ids as $attachment_id ) {
			++$processed;
			$result = Oilmazing_SFC_WebP_Converter::convert_attachment(
				$attachment_id,
				Oilmazing_SFC_WebP_Converter::should_delete_original()
			);

			if ( is_wp_error( $result ) ) {
				if ( 'oilmazing_sfc_webp_already_converted' === $result->get_error_code() ) {
					++$skipped;
					continue;
				}

				$errors[] = array(
					'attachment_id' => $attachment_id,
					'message'       => $result->get_error_message(),
				);
				continue;
			}

			++$converted;
			$saved += isset( $result['saved_bytes'] ) ? (int) $result['saved_bytes'] : 0;
		}

		$remaining = max( 0, Oilmazing_SFC_WebP_Converter::count_convertible_attachments() );
		$done      = 0 === $remaining || 0 === $processed;

		wp_send_json_success(
			array(
				'processed'   => $processed,
				'converted'   => $converted,
				'skipped'     => $skipped,
				'saved_bytes' => $saved,
				'remaining'   => $remaining,
				'next_offset' => 0,
				'done'        => $done,
				'errors'      => $errors,
			)
		);
	}

	/**
	 * Verify AJAX permissions and nonce.
	 */
	private static function verify_ajax_request() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Permission denied.', 'oilmazing-sfc' ),
				),
				403
			);
		}

		check_ajax_referer( 'oilmazing_sfc_webp_admin', 'nonce' );
	}
}
