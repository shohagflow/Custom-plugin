(function ($) {
    'use strict';

    const templateList = $('#cv-builder-template-list');
    const addButton = $('#cv-builder-add-template');

    function openMediaLibrary(callback) {
        const frame = wp.media({
            title: 'Select Template Image',
            button: { text: 'Use this image' },
            multiple: false
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            if (attachment && callback) {
                callback(attachment.url);
            }
        });

        frame.open();
    }

    function createTemplateRow(value) {
        const row = $('<div/>', { class: 'cv-template-row' });
        const thumbWrapper = $('<div/>', { class: 'cv-template-thumb-wrapper' }).appendTo(row);
        const thumb = $('<img/>', {
            class: 'cv-template-thumb' + (value ? '' : ' hidden'),
            src: value ? value : '',
            alt: ''
        }).appendTo(thumbWrapper);

        const fields = $('<div/>', { class: 'cv-template-fields' }).appendTo(row);
        const input = $('<input/>', {
            type: 'text',
            name: 'cv_builder_templates[]',
            class: 'cv-template-input regular-text',
            value: value ? value : '',
            placeholder: 'Template image URL'
        }).appendTo(fields);

        const actions = $('<div/>', { class: 'cv-template-actions' }).appendTo(fields);
        $('<button/>', { type: 'button', class: 'button cv-template-upload', text: 'Select Image' }).appendTo(actions);
        $('<button/>', { type: 'button', class: 'button cv-template-clear', text: 'Clear' }).appendTo(actions);
        $('<button/>', { type: 'button', class: 'button cv-template-remove', text: 'Remove' }).appendTo(actions);

        return row;
    }

    function refreshEmptyState() {
        if (!templateList.children('.cv-template-row').length) {
            templateList.append(createTemplateRow(''));
        }
    }

    $(document).ready(function () {
        refreshEmptyState();

        addButton.on('click', function (e) {
            e.preventDefault();
            templateList.append(createTemplateRow(''));
        });

        templateList.on('click', '.cv-template-upload', function (e) {
            e.preventDefault();
            const row = $(this).closest('.cv-template-row');
            openMediaLibrary(function (url) {
                row.find('.cv-template-input').val(url);
                row.find('.cv-template-thumb').attr('src', url).removeClass('hidden');
            });
        });

        templateList.on('click', '.cv-template-clear', function (e) {
            e.preventDefault();
            const row = $(this).closest('.cv-template-row');
            row.find('.cv-template-input').val('');
            row.find('.cv-template-thumb').attr('src', '').addClass('hidden');
        });

        templateList.on('click', '.cv-template-remove', function (e) {
            e.preventDefault();
            $(this).closest('.cv-template-row').remove();
            refreshEmptyState();
        });

        // Save Shortcode button handler
        $(document).on('click', '#cv-builder-save-shortcode-btn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const $button = $(this);
            const $input = $('#cv-builder-shortcode');
            const shortcode = $input.val();
            
            // Disable button and show loading
            $button.prop('disabled', true).text('Saving...');
            
            // Get nonce from localized script
            let nonce = '';
            if (typeof cvBuilderAdmin !== 'undefined' && cvBuilderAdmin.shortcodeNonce) {
                nonce = cvBuilderAdmin.shortcodeNonce;
            }
            
            if (!nonce) {
                alert('Error: Security token not found. Please refresh the page and try again.');
                $button.prop('disabled', false).text('Save Shortcode');
                return false;
            }
            
            // Use current page URL
            const formAction = window.location.href.split('?')[0] + '?page=cv-builder-templates';
            
            // Create a form to submit
            const $form = $('<form>', {
                method: 'POST',
                action: formAction,
                style: 'display: none;'
            });
            
            $form.append($('<input>', { type: 'hidden', name: 'cv_builder_shortcode_nonce', value: nonce }));
            $form.append($('<input>', { type: 'hidden', name: 'cv_builder_shortcode', value: shortcode }));
            $form.append($('<input>', { type: 'hidden', name: 'action', value: 'save_cv_builder_shortcode' }));
            
            // Submit the form
            $('body').append($form);
            $form[0].submit();
            
            return false;
        });
        
        // Save Shortcut form handler - validate before submit
        $(document).on('submit', '#cv-builder-shortcut-form', function(e) {
            const $input = $('#shortcut-input');
            const shortcut = $input.val().trim();
            
            // Validate empty input
            if (!shortcut) {
                e.preventDefault();
                alert('Please enter something.');
                return false;
            }
            
            // Button will show loading state
            const $button = $('#cv-builder-save-shortcut-btn');
            $button.prop('disabled', true).text('Saving...');
            
            // Form will submit normally and page will reload
            return true;
        });
    });
})(jQuery);

