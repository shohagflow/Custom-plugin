<?php
/**
 * Admin page template
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="cv-builder-wrapper" data-instance="admin">
    <div class="cv-builder-container">
        <!-- Header Section -->
        <div class="cv-builder-header">
            <h1 class="cv-builder-title">Start Building Marriage Biodata</h1>
            <p class="cv-builder-subtitle">Fill in the details below to create your personalized marriage biodata.</p>
        </div>

        <!-- Language Selection -->
        <div class="cv-builder-language-section">
            <label for="cv-language-select" class="cv-builder-label">Select Language</label>
            <div class="cv-builder-select-wrapper">
                <select id="cv-language-select" class="cv-builder-select">
                    <option value="en" selected>English</option>
                    <option value="hi">Hindi</option>
                    <option value="bn">Bengali</option>
                    <option value="te">Telugu</option>
                    <option value="ta">Tamil</option>
                    <option value="mr">Marathi</option>
                    <option value="gu">Gujarati</option>
                    <option value="kn">Kannada</option>
                    <option value="ml">Malayalam</option>
                </select>
            </div>
        </div>

        <!-- Form Sections -->
        <div class="cv-builder-sections">
            
            <!-- Personal Details Section -->
            <div class="cv-builder-section active" data-section="personal">
                <div class="cv-builder-section-header">
                    <h2 class="cv-builder-section-title">Personal Details</h2>
                    <span class="cv-builder-section-toggle">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-down">
                            <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-up" style="display: none;">
                            <path d="M5 12.5L10 7.5L15 12.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                </div>
                <div class="cv-builder-section-content" style="max-height: 5000px !important; padding: 20px !important; display: block !important; overflow: visible !important;">
                    <!-- Header Fields -->
                    <div class="cv-field-manager-header-fields">
                        <div class="cv-field-item" data-field-type="ganesha-image" data-field-id="header-ganesha">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M2.66667 13.3335L2.66667 13.9998C2.66667 14.1766 2.73691 14.3462 2.86193 14.4712C2.98695 14.5962 3.15652 14.6665 3.33333 14.6665L3.99967 14.6665L3.99967 13.9998L3.99967 13.3335" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <div class="cv-field-ganesha-image">
                                    <span>🕉️</span>
                                </div>
                            </div>
                        </div>
                        <div class="cv-field-item" data-field-type="text" data-field-id="header-shree-ganesh">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">|| Shree Ganesh ||</span>
                                <input type="text" class="cv-field-input" placeholder="Enter text">
                            </div>
                        </div>
                        <div class="cv-field-item" data-field-type="text" data-field-id="header-biodata">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Biodata</span>
                                <input type="text" class="cv-field-input" placeholder="Enter text">
                            </div>
                        </div>
                    </div>

                    <!-- Dynamic Fields Container -->
                    <div class="cv-field-manager-fields" data-section="personal">
                        <!-- Name Field -->
                        <div class="cv-field-item" data-field-id="name" data-field-order="0">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Name</span>
                                <input type="text" name="name" class="cv-field-input" placeholder="Enter name">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Date of Birth Field -->
                        <div class="cv-field-item" data-field-id="date_of_birth" data-field-order="1">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Date of Birth</span>
                                <div class="cv-field-input-wrapper">
                                    <input type="text" name="date_of_birth" class="cv-field-input cv-date-input" placeholder="DD/MM/YYYY">
                                    <span class="cv-calendar-icon">📅</span>
                                </div>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Place of Birth Field -->
                        <div class="cv-field-item" data-field-id="place_of_birth" data-field-order="2">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Place of Birth</span>
                                <input type="text" name="place_of_birth" class="cv-field-input" placeholder="Enter place of birth">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Time of Birth Field -->
                        <div class="cv-field-item" data-field-id="time_of_birth" data-field-order="3">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Time of Birth</span>
                                <input type="text" name="time_of_birth" class="cv-field-input" placeholder="Enter time of birth">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Rashi Field -->
                        <div class="cv-field-item" data-field-id="rashi" data-field-order="4">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Rashi</span>
                                <select name="rashi" class="cv-field-select">
                                    <option value="">Select</option>
                                    <option value="aries">Aries (Mesha)</option>
                                    <option value="taurus">Taurus (Vrishabha)</option>
                                    <option value="gemini" selected>Gemini (Mithuna)</option>
                                    <option value="cancer">Cancer (Karka)</option>
                                    <option value="leo">Leo (Simha)</option>
                                    <option value="virgo">Virgo (Kanya)</option>
                                    <option value="libra">Libra (Tula)</option>
                                    <option value="scorpio">Scorpio (Vrishchika)</option>
                                    <option value="sagittarius">Sagittarius (Dhanu)</option>
                                    <option value="capricorn">Capricorn (Makara)</option>
                                    <option value="aquarius">Aquarius (Kumbha)</option>
                                    <option value="pisces">Pisces (Meena)</option>
                                </select>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Nakshatra Field -->
                        <div class="cv-field-item" data-field-id="nakshatra" data-field-order="5">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Nakshatra</span>
                                <select name="nakshatra" class="cv-field-select">
                                    <option value="">Select</option>
                                    <option value="ashwini">Ashwini</option>
                                    <option value="bharani" selected>Bharani</option>
                                    <option value="krittika">Krittika</option>
                                    <option value="rohini">Rohini</option>
                                    <option value="mrigashira">Mrigashira</option>
                                    <option value="ardra">Ardra</option>
                                    <option value="punarvasu">Punarvasu</option>
                                    <option value="pushya">Pushya</option>
                                    <option value="ashlesha">Ashlesha</option>
                                    <option value="magha">Magha</option>
                                    <option value="purva phalguni">Purva Phalguni</option>
                                    <option value="uttara phalguni">Uttara Phalguni</option>
                                    <option value="hasta">Hasta</option>
                                    <option value="chitra">Chitra</option>
                                    <option value="swati">Swati</option>
                                    <option value="vishakha">Vishakha</option>
                                    <option value="anuradha">Anuradha</option>
                                    <option value="jyestha">Jyestha</option>
                                    <option value="mula">Mula</option>
                                    <option value="purva ashadha">Purva Ashadha</option>
                                    <option value="uttara ashadha">Uttara Ashadha</option>
                                    <option value="shravana">Shravana</option>
                                    <option value="dhanishta">Dhanishta</option>
                                    <option value="shatabhisha">Shatabhisha</option>
                                    <option value="purva bhadrapada">Purva Bhadrapada</option>
                                    <option value="uttara bhadrapada">Uttara Bhadrapada</option>
                                    <option value="revati">Revati</option>
                                </select>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Complexion Field -->
                        <div class="cv-field-item" data-field-id="complexion" data-field-order="6">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Complexion</span>
                                <select name="complexion" class="cv-field-select">
                                    <option value="">Select</option>
                                    <option value="fair">Fair</option>
                                    <option value="wheatish">Wheatish</option>
                                    <option value="medium">Medium</option>
                                    <option value="dark">Dark</option>
                                </select>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Height Field -->
                        <div class="cv-field-item" data-field-id="height" data-field-order="7">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Height</span>
                                <input type="text" name="height" class="cv-field-input" placeholder="Enter height">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Gotra Field -->
                        <div class="cv-field-item" data-field-id="gotra" data-field-order="8">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Gotra</span>
                                <input type="text" name="gotra" class="cv-field-input" placeholder="Enter gotra">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Education Field -->
                        <div class="cv-field-item" data-field-id="education" data-field-order="9">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Education</span>
                                <input type="text" name="education" class="cv-field-input" placeholder="Enter education">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Religion Field -->
                        <div class="cv-field-item" data-field-id="religion" data-field-order="10">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Religion</span>
                                <select name="religion" class="cv-field-select">
                                    <option value="">Select</option>
                                    <option value="hindu">Hindu</option>
                                    <option value="muslim" selected>Muslim</option>
                                    <option value="christian">Christian</option>
                                    <option value="sikh">Sikh</option>
                                    <option value="buddhist">Buddhist</option>
                                    <option value="jain">Jain</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Caste Field -->
                        <div class="cv-field-item" data-field-id="caste" data-field-order="11">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Caste</span>
                                <input type="text" name="caste" class="cv-field-input" placeholder="Enter caste">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>

                        <!-- Job/Occupation Field -->
                        <div class="cv-field-item" data-field-id="job_occupation" data-field-order="12">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                                <span class="cv-field-label">Job/Occupation</span>
                                <input type="text" name="job_occupation" class="cv-field-input" placeholder="Enter job/occupation">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">×</button>
                            </div>
                        </div>
                    </div>

                    <!-- Field Actions -->
                    <div class="cv-field-manager-actions">
                        <button type="button" class="cv-add-field-btn">+ Add New Field</button>
                    </div>

                    <!-- Navigation -->
                    <div class="cv-field-manager-navigation">
                        <button type="button" class="cv-nav-btn cv-nav-prev">Previous</button>
                        <button type="button" class="cv-nav-btn cv-nav-next">Next</button>
                    </div>
                </div>
            </div>

            <!-- Family Details Section -->
            <div class="cv-builder-section" data-section="family">
                <div class="cv-builder-section-header">
                    <h2 class="cv-builder-section-title">Family Details</h2>
                    <span class="cv-builder-section-toggle">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                </div>
                <div class="cv-builder-section-content">
                    <form class="cv-builder-form">
                        <div class="cv-builder-form-row">
                            <div class="cv-builder-form-group">
                                <label>Father's Name</label>
                                <input type="text" name="father_name" placeholder="Enter father's name">
                            </div>
                            <div class="cv-builder-form-group">
                                <label>Father's Occupation</label>
                                <input type="text" name="father_occupation" placeholder="Enter occupation">
                            </div>
                        </div>
                        <div class="cv-builder-form-row">
                            <div class="cv-builder-form-group">
                                <label>Mother's Name</label>
                                <input type="text" name="mother_name" placeholder="Enter mother's name">
                            </div>
                            <div class="cv-builder-form-group">
                                <label>Mother's Occupation</label>
                                <input type="text" name="mother_occupation" placeholder="Enter occupation">
                            </div>
                        </div>
                        <div class="cv-builder-form-row">
                            <div class="cv-builder-form-group">
                                <label>Number of Siblings</label>
                                <input type="number" name="siblings_count" placeholder="Number of siblings">
                            </div>
                            <div class="cv-builder-form-group">
                                <label>Family Status</label>
                                <select name="family_status">
                                    <option value="">Select Status</option>
                                    <option value="joint">Joint Family</option>
                                    <option value="nuclear">Nuclear Family</option>
                                </select>
                            </div>
                        </div>
                        <div class="cv-builder-form-row">
                            <div class="cv-builder-form-group cv-builder-form-group-full">
                                <label>About Family</label>
                                <textarea name="about_family" rows="4" placeholder="Tell us about your family"></textarea>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Contact Details Section -->
            <div class="cv-builder-section" data-section="contact">
                <div class="cv-builder-section-header">
                    <h2 class="cv-builder-section-title">Contact Details</h2>
                    <span class="cv-builder-section-toggle">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                </div>
                <div class="cv-builder-section-content">
                    <form class="cv-builder-form">
                        <div class="cv-builder-form-row">
                            <div class="cv-builder-form-group">
                                <label>Email</label>
                                <input type="email" name="email" placeholder="Enter email address">
                            </div>
                            <div class="cv-builder-form-group">
                                <label>Phone</label>
                                <input type="tel" name="phone" placeholder="Enter phone number">
                            </div>
                        </div>
                        <div class="cv-builder-form-row">
                            <div class="cv-builder-form-group">
                                <label>Address</label>
                                <input type="text" name="address" placeholder="Enter address">
                            </div>
                            <div class="cv-builder-form-group">
                                <label>City</label>
                                <input type="text" name="city" placeholder="Enter city">
                            </div>
                        </div>
                        <div class="cv-builder-form-row">
                            <div class="cv-builder-form-group">
                                <label>State</label>
                                <input type="text" name="state" placeholder="Enter state">
                            </div>
                            <div class="cv-builder-form-group">
                                <label>Pincode</label>
                                <input type="text" name="pincode" placeholder="Enter pincode">
                            </div>
                        </div>
                        <div class="cv-builder-form-row">
                            <div class="cv-builder-form-group">
                                <label>Country</label>
                                <input type="text" name="country" placeholder="Enter country">
                            </div>
                            <div class="cv-builder-form-group">
                                <label>WhatsApp Number</label>
                                <input type="tel" name="whatsapp" placeholder="Enter WhatsApp number">
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Photo Upload Section -->
            <div class="cv-builder-section" data-section="photo">
                <div class="cv-builder-section-header">
                    <h2 class="cv-builder-section-title">Photo Upload</h2>
                    <span class="cv-builder-section-toggle">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                </div>
                <div class="cv-builder-section-content">
                    <div class="cv-builder-upload-area">
                        <div class="cv-builder-upload-placeholder">
                            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M21 15V19C21 19.5304 20.7893 20.0391 20.4142 20.4142C20.0391 20.7893 19.5304 21 19 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M17 8L12 3L7 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M12 3V15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <p>Click to upload or drag and drop</p>
                            <p class="cv-builder-upload-hint">PNG, JPG, GIF up to 10MB</p>
                        </div>
                        <input type="file" id="cv-photo-upload" name="photo" accept="image/*" style="display: none;">
                        <div class="cv-builder-upload-preview" style="display: none;">
                            <img id="cv-photo-preview" src="" alt="Preview">
                            <button type="button" class="cv-builder-upload-remove">Remove</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Action Button -->
        <div class="cv-builder-actions">
            <button type="button" class="cv-builder-button cv-builder-button-primary cv-choose-template-btn" id="cv-choose-template-btn">
                Choose Template & Download
            </button>
        </div>

        <!-- Terms and Privacy -->
        <div class="cv-builder-legal">
            <p class="cv-builder-terms">
                By clicking download, you agree to our 
                <a href="#" class="cv-builder-link">Terms of Service</a> 
                and 
                <a href="#" class="cv-builder-link">Privacy Policy</a>
            </p>
        </div>

        <!-- Note -->
        <div class="cv-builder-note">
            <p><strong>Note:</strong> This tool is for generating a biodata only. It does not match or connect users.</p>
        </div>

    </div>
</div>

