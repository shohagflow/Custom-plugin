<?php
/**
 * Frontend form template for shortcode
 */

if (!defined('ABSPATH')) {
    exit;
}

// Set defaults if not provided
$title = isset($template_atts['title']) ? $template_atts['title'] : 'Start Building Marriage Biodata';
$subtitle = isset($template_atts['subtitle']) ? $template_atts['subtitle'] : 'Fill in the details below to create your personalized marriage biodata.';
$instance_id = isset($template_instance_id) ? $template_instance_id : 'cv-' . uniqid();

// Ensure plugin URL constant is available
if (!defined('CV_BUILDER_PLUGIN_URL')) {
    define('CV_BUILDER_PLUGIN_URL', plugin_dir_url(dirname(__FILE__)));
}
?>

<div class="cv-builder-wrapper" data-instance="<?php echo esc_attr($instance_id); ?>">
    <div class="cv-builder-container">
        <!-- Header Section -->
        <div class="cv-builder-header"></div>

        <!-- Language Selection -->
        <div class="cv-builder-language-section">
            <label for="cv-language-select-<?php echo esc_attr($instance_id); ?>" class="cv-builder-label">Select Language</label>
            <div class="cv-language-wrapper">
                <?php 
                // Get shortcode from admin dashboard (saved_custom_shortcode option)
                $saved_shortcode = get_option('saved_custom_shortcode', '');
                if (!empty($saved_shortcode)) : 
                    // Execute the shortcode - try multiple methods
                    $shortcode_output = '';
                    
                    // Method 1: Use do_shortcode directly
                    $shortcode_output = do_shortcode($saved_shortcode);
                    
                    // Method 2: If empty or same as input, try through content filters
                    if (empty($shortcode_output) || trim($shortcode_output) === trim($saved_shortcode)) {
                        $shortcode_output = apply_filters('the_content', $saved_shortcode);
                    }
                    
                    // Method 3: If still empty, try wpautop and shortcodes
                    if (empty($shortcode_output) || trim($shortcode_output) === trim($saved_shortcode)) {
                        $shortcode_output = do_shortcode(wpautop($saved_shortcode));
                    }
                    
                    // Display if we have output (different from input means it was executed)
                    if (!empty($shortcode_output) && trim($shortcode_output) !== trim($saved_shortcode)) : ?>
                <div class="cv-shortcode-preview">
                    <div class="cv-shortcode-output">
                        <?php echo $shortcode_output; ?>
                    </div>
                </div>
                    <?php endif; 
                endif; ?>
            </div>
        </div>

        <!-- Form Sections -->
        <div class="cv-builder-sections">
            
            <!-- Personal Details Section -->
            <div class="cv-builder-section active" data-section="personal" data-instance="<?php echo esc_attr($instance_id); ?>">
                <div class="cv-builder-section-header">
                    <h2 class="cv-builder-section-title">Personal Details</h2>
                    <span class="cv-builder-section-toggle">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-down">
                            <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-up" style="display: none;">
                            <path d="M5 12.5L10 7.5L15 12.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                </div>
                <div class="cv-builder-section-content">
                    <!-- Header Fields -->
                    <div class="cv-field-manager-header-fields">
                        <!-- Row 1: Ganesha Image -->
                        <div class="cv-field-item cv-header-field" data-field-type="ganesha-image" data-field-id="header-ganesha">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn cv-ganesha-edit-btn" title="Edit" data-field-id="header-ganesha">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <div class="cv-field-ganesha-image" data-current-icon="icon3">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon3.png'); ?>" alt="Icon" class="cv-field-icon-img">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Row 2: Shree Ganesh Text -->
                        <div class="cv-field-item cv-header-field" data-field-type="text" data-field-id="header-shree-ganesh">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <div class="cv-header-text-field">
                                    <span class="cv-header-text">|| Shree Ganesh ||</span>
                                    <span class="cv-header-underline"></span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Row 3: Biodata Text -->
                        <div class="cv-field-item cv-header-field" data-field-type="text" data-field-id="header-biodata">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <div class="cv-header-text-field">
                                    <span class="cv-header-text">Biodata</span>
                                    <span class="cv-header-underline"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Dynamic Fields Container -->
                    <div class="cv-field-manager-fields" data-section="personal">
                        <!-- Name Field -->
                        <div class="cv-field-item" data-field-id="name" data-field-order="0">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Name</span>
                                <input type="text" name="name" class="cv-field-input" placeholder="Enter name">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Date of Birth Field -->
                        <div class="cv-field-item" data-field-id="date_of_birth" data-field-order="1">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Date of Birth</span>
                                <div class="cv-field-input-wrapper">
                                    <input type="text" name="date_of_birth" class="cv-field-input cv-date-input" placeholder="DD/MM/YYYY" readonly>
                                    <span class="cv-calendar-icon" role="button" tabindex="0">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M14 3H15C15.5304 3 16.0391 3.21071 16.4142 3.58579C16.7893 3.96086 17 4.46957 17 5V15C17 15.5304 16.7893 16.0391 16.4142 16.4142C16.0391 16.7893 15.5304 17 15 17H3C2.46957 17 1.96086 16.7893 1.58579 16.4142C1.21071 16.0391 1 15.5304 1 15V5C1 4.46957 1.21071 3.96086 1.58579 3.58579C1.96086 3.21071 2.46957 3 3 3H4V2H5V3H11V2H12V3Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M1 7H17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                            <circle cx="4.5" cy="10.5" r="0.5" fill="currentColor"/>
                                            <circle cx="7.5" cy="10.5" r="0.5" fill="currentColor"/>
                                            <circle cx="10.5" cy="10.5" r="0.5" fill="currentColor"/>
                                            <circle cx="13.5" cy="10.5" r="0.5" fill="currentColor"/>
                                            <circle cx="4.5" cy="13.5" r="0.5" fill="currentColor"/>
                                            <circle cx="7.5" cy="13.5" r="0.5" fill="currentColor"/>
                                            <circle cx="10.5" cy="13.5" r="0.5" fill="currentColor"/>
                                        </svg>
                                    </span>
                                </div>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Place of Birth Field -->
                        <div class="cv-field-item" data-field-id="place_of_birth" data-field-order="2">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Place of Birth</span>
                                <input type="text" name="place_of_birth" class="cv-field-input" placeholder="Enter place of birth">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Time of Birth Field -->
                        <div class="cv-field-item" data-field-id="time_of_birth" data-field-order="3">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Time of Birth</span>
                                <input type="text" name="time_of_birth" class="cv-field-input" placeholder="Enter time of birth">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Rashi Field -->
                        <div class="cv-field-item" data-field-id="rashi" data-field-order="4">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Rashi</span>
                                <select name="rashi" class="cv-field-select">
                                    <option value="">Select</option>
                                    <option value="aries">Aries (Mesha)</option>
                                    <option value="taurus">Taurus (Vrishabha)</option>
                                    <option value="gemini" selected>Gemini (Mithuna)</option>
                                    <option value="cancer">Cancer (Karka)</option>
                                    <option value="leo">Leo (Simha)</option>
                                    <option value="virgo">Virgo (Kanya)</option>
                                    <option value="libra">Libra (Tula)</option>
                                    <option value="scorpio">Scorpio (Vrishchika)</option>
                                    <option value="sagittarius">Sagittarius (Dhanu)</option>
                                    <option value="capricorn">Capricorn (Makara)</option>
                                    <option value="aquarius">Aquarius (Kumbha)</option>
                                    <option value="pisces">Pisces (Meena)</option>
                                </select>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Nakshatra Field -->
                        <div class="cv-field-item" data-field-id="nakshatra" data-field-order="5">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Nakshatra</span>
                                <select name="nakshatra" class="cv-field-select">
                                    <option value="">Select</option>
                                    <option value="ashwini">Ashwini</option>
                                    <option value="bharani" selected>Bharani</option>
                                    <option value="krittika">Krittika</option>
                                    <option value="rohini">Rohini</option>
                                    <option value="mrigashira">Mrigashira</option>
                                    <option value="ardra">Ardra</option>
                                    <option value="punarvasu">Punarvasu</option>
                                    <option value="pushya">Pushya</option>
                                    <option value="ashlesha">Ashlesha</option>
                                    <option value="magha">Magha</option>
                                    <option value="purva phalguni">Purva Phalguni</option>
                                    <option value="uttara phalguni">Uttara Phalguni</option>
                                    <option value="hasta">Hasta</option>
                                    <option value="chitra">Chitra</option>
                                    <option value="swati">Swati</option>
                                    <option value="vishakha">Vishakha</option>
                                    <option value="anuradha">Anuradha</option>
                                    <option value="jyestha">Jyestha</option>
                                    <option value="mula">Mula</option>
                                    <option value="purva ashadha">Purva Ashadha</option>
                                    <option value="uttara ashadha">Uttara Ashadha</option>
                                    <option value="shravana">Shravana</option>
                                    <option value="dhanishta">Dhanishta</option>
                                    <option value="shatabhisha">Shatabhisha</option>
                                    <option value="purva bhadrapada">Purva Bhadrapada</option>
                                    <option value="uttara bhadrapada">Uttara Bhadrapada</option>
                                    <option value="revati">Revati</option>
                                </select>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Complexion Field -->
                        <div class="cv-field-item" data-field-id="complexion" data-field-order="6">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Complexion</span>
                                <select name="complexion" class="cv-field-select">
                                    <option value="">Select</option>
                                    <option value="fair">Fair</option>
                                    <option value="wheatish">Wheatish</option>
                                    <option value="medium">Medium</option>
                                    <option value="dark">Dark</option>
                                </select>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Height Field -->
                        <div class="cv-field-item" data-field-id="height" data-field-order="7">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Height</span>
                                <input type="text" name="height" class="cv-field-input" placeholder="Enter height">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Gotra Field -->
                        <div class="cv-field-item" data-field-id="gotra" data-field-order="8">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Gotra</span>
                                <input type="text" name="gotra" class="cv-field-input" placeholder="Enter gotra">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Education Field -->
                        <div class="cv-field-item" data-field-id="education" data-field-order="9">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Education</span>
                                <input type="text" name="education" class="cv-field-input" placeholder="Enter education">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Religion Field -->
                        <div class="cv-field-item" data-field-id="religion" data-field-order="10">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Religion</span>
                                <select name="religion" class="cv-field-select">
                                    <option value="">Select</option>
                                    <option value="hindu">Hindu</option>
                                    <option value="muslim" selected>Muslim</option>
                                    <option value="christian">Christian</option>
                                    <option value="sikh">Sikh</option>
                                    <option value="buddhist">Buddhist</option>
                                    <option value="jain">Jain</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Caste Field -->
                        <div class="cv-field-item" data-field-id="caste" data-field-order="11">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Caste</span>
                                <input type="text" name="caste" class="cv-field-input" placeholder="Enter caste">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Job/Occupation Field -->
                        <div class="cv-field-item" data-field-id="job_occupation" data-field-order="12">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Job/Occupation</span>
                                <input type="text" name="job_occupation" class="cv-field-input" placeholder="Enter job/occupation">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Field Actions -->
                    <div class="cv-field-manager-actions">
                        <button type="button" class="cv-add-field-btn">+ Add New Field</button>
                    </div>

                    <!-- Navigation -->
                    <div class="cv-field-manager-navigation">
                        <button type="button" class="cv-nav-btn cv-nav-prev">Previous</button>
                        <button type="button" class="cv-nav-btn cv-nav-next">Next</button>
                    </div>
                </div>
            </div>

            <!-- Family Details Section -->
            <div class="cv-builder-section" data-section="family" data-instance="<?php echo esc_attr($instance_id); ?>">
                <div class="cv-builder-section-header">
                    <h2 class="cv-builder-section-title">Family Details</h2>
                    <span class="cv-builder-section-toggle">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-down">
                            <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-up" style="display: none;">
                            <path d="M5 12.5L10 7.5L15 12.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                </div>
                <div class="cv-builder-section-content">
                    <!-- Dynamic Fields Container -->
                    <div class="cv-field-manager-fields" data-section="family">
                        <!-- Father's Name Field -->
                        <div class="cv-field-item" data-field-id="father_name" data-field-order="0">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Father's Name</span>
                                <input type="text" name="father_name" class="cv-field-input" placeholder="Enter father's name">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Father's Occupation Field -->
                        <div class="cv-field-item" data-field-id="father_occupation" data-field-order="1">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Father's Occupation</span>
                                <input type="text" name="father_occupation" class="cv-field-input" placeholder="Enter father's occupation">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Mother's Name Field -->
                        <div class="cv-field-item" data-field-id="mother_name" data-field-order="2">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Mother's Name</span>
                                <input type="text" name="mother_name" class="cv-field-input" placeholder="Enter mother's name">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Mother's Occupation Field -->
                        <div class="cv-field-item" data-field-id="mother_occupation" data-field-order="3">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Mother's Occupation</span>
                                <input type="text" name="mother_occupation" class="cv-field-input" placeholder="Enter mother's occupation">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Brother's Name (Elder) Field -->
                        <div class="cv-field-item" data-field-id="brother_name_elder" data-field-order="4">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Brother's Name (Elder)</span>
                                <input type="text" name="brother_name_elder" class="cv-field-input" placeholder="Enter brother's name (elder)">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Brother's Occupation (Elder) Field -->
                        <div class="cv-field-item" data-field-id="brother_occupation_elder" data-field-order="5">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Brother's Occupation (Elder)</span>
                                <input type="text" name="brother_occupation_elder" class="cv-field-input" placeholder="Enter brother's occupation (elder)">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Brother's Name (Younger) Field -->
                        <div class="cv-field-item" data-field-id="brother_name_younger" data-field-order="6">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Brother's Name (Younger)</span>
                                <input type="text" name="brother_name_younger" class="cv-field-input" placeholder="Enter brother's name (younger)">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Brother's Occupation (Younger) Field -->
                        <div class="cv-field-item" data-field-id="brother_occupation_younger" data-field-order="7">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Brother's Occupation (Younger)</span>
                                <input type="text" name="brother_occupation_younger" class="cv-field-input" placeholder="Enter brother's occupation (younger)">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Sister's Name (Elder) Field -->
                        <div class="cv-field-item" data-field-id="sister_name_elder" data-field-order="8">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Sister's Name (Elder)</span>
                                <input type="text" name="sister_name_elder" class="cv-field-input" placeholder="Enter sister's name (elder)">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Sister's Occupation (Elder) Field -->
                        <div class="cv-field-item" data-field-id="sister_occupation_elder" data-field-order="9">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Sister's Occupation (Elder)</span>
                                <input type="text" name="sister_occupation_elder" class="cv-field-input" placeholder="Enter sister's occupation (elder)">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Sister's Name (Younger) Field -->
                        <div class="cv-field-item" data-field-id="sister_name_younger" data-field-order="10">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Sister's Name (Younger)</span>
                                <input type="text" name="sister_name_younger" class="cv-field-input" placeholder="Enter sister's name (younger)">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Sister's Occupation (Younger) Field -->
                        <div class="cv-field-item" data-field-id="sister_occupation_younger" data-field-order="11">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Sister's Occupation (Younger)</span>
                                <input type="text" name="sister_occupation_younger" class="cv-field-input" placeholder="Enter sister's occupation (younger)">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Property Field -->
                        <div class="cv-field-item" data-field-id="property" data-field-order="12">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Property</span>
                                <textarea name="property" class="cv-field-input" rows="3" placeholder="Enter property"></textarea>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Field Actions -->
                    <div class="cv-field-manager-actions">
                        <button type="button" class="cv-add-field-btn">+ Add New Field</button>
                    </div>

                    <!-- Navigation -->
                    <div class="cv-field-manager-navigation">
                        <button type="button" class="cv-nav-btn cv-nav-prev">previous</button>
                        <button type="button" class="cv-nav-btn cv-nav-next">Next</button>
                    </div>
                </div>
            </div>

            <!-- Contact Details Section -->
            <div class="cv-builder-section" data-section="contact" data-instance="<?php echo esc_attr($instance_id); ?>">
                <div class="cv-builder-section-header">
                    <h2 class="cv-builder-section-title">Contact Details</h2>
                    <span class="cv-builder-section-toggle">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-down">
                            <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-up" style="display: none;">
                            <path d="M5 12.5L10 7.5L15 12.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                </div>
                <div class="cv-builder-section-content">
                    <!-- Dynamic Fields Container -->
                    <div class="cv-field-manager-fields" data-section="contact">
                        <!-- Contact Number Field -->
                        <div class="cv-field-item" data-field-id="contact_number" data-field-order="0">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Contact Number</span>
                                <input type="number" inputmode="numeric" pattern="[0-9]*" name="contact_number" class="cv-field-input" placeholder="Enter contact number">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Father's Contact Number Field -->
                        <div class="cv-field-item" data-field-id="father_contact_number" data-field-order="1">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Father's Contact Number</span>
                                <input type="number" inputmode="numeric" pattern="[0-9]*" name="father_contact_number" class="cv-field-input" placeholder="Enter father's contact number">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Email Address Field -->
                        <div class="cv-field-item" data-field-id="email_address" data-field-order="2">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Email Address</span>
                                <input type="email" name="email_address" class="cv-field-input" placeholder="Enter email address">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Address Field -->
                        <div class="cv-field-item" data-field-id="address" data-field-order="3">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Address</span>
                                <textarea name="address" class="cv-field-input" rows="3" placeholder="Enter address"></textarea>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Field Actions -->
                    <div class="cv-field-manager-actions">
                        <button type="button" class="cv-add-field-btn">+ Add New Field</button>
                    </div>

                    <!-- Navigation -->
                    <div class="cv-field-manager-navigation">
                        <button type="button" class="cv-nav-btn cv-nav-prev">previous</button>
                        <button type="button" class="cv-nav-btn cv-nav-next">Next</button>
                    </div>
                </div>
            </div>

            <!-- Professional Details Section -->
            <div class="cv-builder-section" data-section="professional" data-instance="<?php echo esc_attr($instance_id); ?>">
                <div class="cv-builder-section-header">
                    <h2 class="cv-builder-section-title">Professional Details</h2>
                    <span class="cv-builder-section-toggle">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-down">
                            <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-up" style="display: none;">
                            <path d="M5 12.5L10 7.5L15 12.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                </div>
                <div class="cv-builder-section-content">
                    <!-- Dynamic Fields Container -->
                    <div class="cv-field-manager-fields" data-section="professional">
                        <!-- Job/Occupation Field -->
                        <div class="cv-field-item" data-field-id="job_occupation" data-field-order="0">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Job/Occupation</span>
                                <input type="text" name="job_occupation" class="cv-field-input" placeholder="Enter job/occupation">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Company/Organization Field -->
                        <div class="cv-field-item" data-field-id="company_organization" data-field-order="1">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Company/Organization</span>
                                <input type="text" name="company_organization" class="cv-field-input" placeholder="Enter company/organization name">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Work Experience Field -->
                        <div class="cv-field-item" data-field-id="work_experience" data-field-order="2">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Work Experience</span>
                                <textarea name="work_experience" class="cv-field-input" rows="4" placeholder="Enter work experience details"></textarea>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Skills Field -->
                        <div class="cv-field-item" data-field-id="skills" data-field-order="3">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle" checked>
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Skills</span>
                                <textarea name="skills" class="cv-field-input" rows="3" placeholder="Enter your skills"></textarea>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Certifications Field -->
                        <div class="cv-field-item" data-field-id="certifications" data-field-order="4">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Certifications</span>
                                <textarea name="certifications" class="cv-field-input" rows="3" placeholder="Enter certifications"></textarea>
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <!-- Annual Income Field -->
                        <div class="cv-field-item" data-field-id="annual_income" data-field-order="5">
                            <div class="cv-field-controls-left">
                                <label class="cv-toggle-switch">
                                    <input type="checkbox" class="cv-field-toggle">
                                    <span class="cv-toggle-slider"></span>
                                </label>
                                <button type="button" class="cv-field-edit-btn" title="Edit">
                                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/pen (1).png'); ?>" alt="Edit" class="cv-edit-icon">
                                </button>
                                <span class="cv-field-label">Annual Income</span>
                                <input type="text" name="annual_income" class="cv-field-input" placeholder="Enter annual income">
                            </div>
                            <div class="cv-field-controls-right">
                                <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                                <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                                <button type="button" class="cv-field-delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Field Actions -->
                    <div class="cv-field-manager-actions">
                        <button type="button" class="cv-add-field-btn">+ Add New Field</button>
                    </div>

                    <!-- Navigation -->
                    <div class="cv-field-manager-navigation">
                        <button type="button" class="cv-nav-btn cv-nav-prev">previous</button>
                        <button type="button" class="cv-nav-btn cv-nav-next">Next</button>
                    </div>
                </div>
            </div>

            <!-- Photo Upload Section -->
            <div class="cv-builder-section" data-section="photo" data-instance="<?php echo esc_attr($instance_id); ?>">
                <div class="cv-builder-section-header">
                    <h2 class="cv-builder-section-title">Photo Upload</h2>
                    <span class="cv-builder-section-toggle">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-down">
                            <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="cv-arrow-up" style="display: none;">
                            <path d="M5 12.5L10 7.5L15 12.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                </div>
                <div class="cv-builder-section-content">
                    <div class="cv-builder-upload-area">
                        <input type="file" id="cv-photo-upload-<?php echo esc_attr($instance_id); ?>" name="photo" accept="image/*" style="display: none;" data-instance="<?php echo esc_attr($instance_id); ?>">
                        <button type="button" class="cv-upload-photo-btn" data-instance="<?php echo esc_attr($instance_id); ?>">
                            Upload Photo
                        </button>
                        <div class="cv-builder-upload-preview" data-instance="<?php echo esc_attr($instance_id); ?>" style="display: none;">
                            <img id="cv-photo-preview-<?php echo esc_attr($instance_id); ?>" src="" alt="Preview">
                            <button type="button" class="cv-builder-upload-remove" data-instance="<?php echo esc_attr($instance_id); ?>">Remove</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Action Button -->
        <div class="cv-builder-actions">
            <button type="button" class="cv-builder-button cv-builder-button-primary cv-choose-template-btn" data-instance="<?php echo esc_attr($instance_id); ?>" id="cv-choose-template-btn-<?php echo esc_attr($instance_id); ?>">
                Choose Template & Download
            </button>
        </div>

        <!-- Terms and Privacy -->
        <div class="cv-builder-legal">
            <p class="cv-builder-terms">
                By clicking download, you agree to our 
                <a href="#" class="cv-builder-link">Terms of Service</a> 
                and 
                <a href="#" class="cv-builder-link">Privacy Policy</a>
            </p>
        </div>

        <!-- Note -->
        <div class="cv-builder-note">
            <p><strong>Note:</strong> This tool is for generating a biodata only. It does not match or connect users.</p>
        </div>

    </div>
</div>

<!-- Crop Profile Picture Modal -->
<div class="cv-crop-modal" id="cv-crop-modal">
    <div class="cv-crop-modal-overlay"></div>
    <div class="cv-crop-modal-content">
        <div class="cv-crop-modal-header">
            <h3 class="cv-crop-modal-title">Crop Profile Picture</h3>
        </div>
        <div class="cv-crop-modal-body">
            <div class="cv-crop-area">
                <div class="cv-crop-container">
                    <img id="cv-crop-image" src="" alt="Crop Image" class="cv-crop-img">
                </div>
            </div>
            <div class="cv-crop-preview-area">
                <h4 class="cv-crop-preview-title">Preview</h4>
                <div class="cv-crop-preview-container">
                    <div class="cv-crop-preview-box">
                        <img id="cv-crop-preview" src="" alt="Preview" class="cv-crop-preview-img">
                    </div>
                </div>
            </div>
        </div>
        <div class="cv-crop-modal-footer">
            <button type="button" class="cv-crop-modal-cancel">Cancel</button>
            <button type="button" class="cv-crop-modal-save">Save</button>
        </div>
    </div>
</div>

<!-- Photo Upload Modal -->
<div class="cv-photo-modal" id="cv-photo-modal">
    <div class="cv-photo-modal-overlay"></div>
    <div class="cv-photo-modal-content">
        <div class="cv-photo-modal-header">
            <h3 class="cv-photo-modal-title">Uploaded Image</h3>
        </div>
        <div class="cv-photo-modal-body">
            <div class="cv-photo-preview-container">
                <img id="cv-photo-modal-preview" src="" alt="Uploaded Image" class="cv-photo-modal-img">
            </div>
            <div class="cv-photo-options">
                <label class="cv-photo-option">
                    <input type="radio" name="photo_option" value="profile" class="cv-photo-radio">
                    <span class="cv-photo-radio-label">Set as Profile Picture</span>
                </label>
                <label class="cv-photo-option">
                    <input type="radio" name="photo_option" value="lastpage" class="cv-photo-radio">
                    <span class="cv-photo-radio-label">Add to Last Page</span>
                </label>
            </div>
        </div>
        <div class="cv-photo-modal-footer">
            <button type="button" class="cv-photo-modal-cancel">Cancel</button>
        </div>
    </div>
</div>


<!-- Religious Symbol Selection Modal -->
<div class="cv-symbol-modal" id="cv-symbol-modal">
    <div class="cv-symbol-modal-overlay"></div>
    <div class="cv-symbol-modal-content">
        <div class="cv-symbol-modal-header">
            <h3 class="cv-symbol-modal-title">Select Religious Symbol</h3>
            <button type="button" class="cv-symbol-modal-close" aria-label="Close">&times;</button>
        </div>
        <div class="cv-symbol-modal-body">
            <div class="cv-symbol-grid">
                <!-- Row 1 -->
                <button type="button" class="cv-symbol-btn" data-icon="icon1" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon1.png'); ?>" alt="Icon 1" class="cv-symbol-img">
                </button>
                <button type="button" class="cv-symbol-btn" data-icon="icon2" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon2 (1).png'); ?>" alt="Icon 2" class="cv-symbol-img">
                </button>
                <button type="button" class="cv-symbol-btn cv-symbol-btn-active" data-icon="icon3" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon3.png'); ?>" alt="Icon 3" class="cv-symbol-img">
                </button>
                <button type="button" class="cv-symbol-btn" data-icon="icon4" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon4.png'); ?>" alt="Icon 4" class="cv-symbol-img">
                </button>
                <button type="button" class="cv-symbol-btn" data-icon="icon5" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon5.png'); ?>" alt="Icon 5" class="cv-symbol-img">
                </button>
                <button type="button" class="cv-symbol-btn" data-icon="icon6" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon6.png'); ?>" alt="Icon 6" class="cv-symbol-img">
                </button>
                <!-- Row 2 -->
                <button type="button" class="cv-symbol-btn" data-icon="icon7" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon7.png'); ?>" alt="Icon 7" class="cv-symbol-img">
                </button>
                <button type="button" class="cv-symbol-btn" data-icon="icon8" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon8.png'); ?>" alt="Icon 8" class="cv-symbol-img">
                </button>
                <button type="button" class="cv-symbol-btn" data-icon="icon9" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon9.png'); ?>" alt="Icon 9" class="cv-symbol-img">
                </button>
                <button type="button" class="cv-symbol-btn" data-icon="icon10" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon10.png'); ?>" alt="Icon 10" class="cv-symbol-img">
                </button>
                <button type="button" class="cv-symbol-btn" data-icon="icon12" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon12.png'); ?>" alt="Icon 12" class="cv-symbol-img">
                </button>
                <button type="button" class="cv-symbol-btn" data-icon="icon13" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon13.png'); ?>" alt="Icon 13" class="cv-symbol-img">
                </button>
                <!-- Row 3 -->
                <button type="button" class="cv-symbol-btn" data-icon="icon14" data-icon-type="png">
                    <img src="<?php echo esc_url(CV_BUILDER_PLUGIN_URL . 'assets/images/icon14.png'); ?>" alt="Icon 14" class="cv-symbol-img">
                </button>
            </div>
            <div class="cv-symbol-preview">
                <h4 class="cv-preview-title">PREVIEW</h4>
                <div class="cv-preview-icon-card">
                    <div class="cv-preview-icon-placeholder" id="cv-preview-icon">
                        <span>Icon</span>
                    </div>
                </div>
                <h4 class="cv-preview-biodata-title">BIODATA</h4>
                <div class="cv-preview-biodata-placeholder">
                    <div class="cv-placeholder-line" style="width: 60%;"></div>
                    <div class="cv-placeholder-line" style="width: 80%;"></div>
                    <div class="cv-placeholder-line" style="width: 70%;"></div>
                </div>
            </div>
        </div>
        <div class="cv-symbol-modal-footer">
            <button type="button" class="cv-modal-btn cv-modal-btn-cancel">Cancel</button>
            <button type="button" class="cv-modal-btn cv-modal-btn-select">Select Icon</button>
        </div>
    </div>
</div>

