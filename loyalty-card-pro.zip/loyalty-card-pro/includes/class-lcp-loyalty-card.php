<?php
/**
 * Loyalty Card model class
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Loyalty_Card {
    
    /**
     * Create loyalty card
     */
    public static function create_card($client_id, $beautician_id, $visit_limit = 10, $reward_description = '') {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_loyalty_cards';
        
        $wpdb->insert($table, array(
            'client_id' => $client_id,
            'beautician_id' => $beautician_id,
            'visit_limit' => $visit_limit,
            'current_visits' => 0,
            'reward_description' => sanitize_textarea_field($reward_description),
            'status' => 'active',
        ));
        
        return $wpdb->insert_id;
    }
    
    /**
     * Get card by ID
     */
    public static function get_card($card_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_loyalty_cards';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d",
            $card_id
        ));
    }
    
    /**
     * Get active card for client
     */
    public static function get_active_card($client_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_loyalty_cards';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE client_id = %d AND status = 'active' ORDER BY created_at DESC LIMIT 1",
            $client_id
        ));
    }
    
    /**
     * Get all cards for beautician
     */
    public static function get_beautician_cards($beautician_id, $status = 'all') {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_loyalty_cards';
        
        $where = $wpdb->prepare("WHERE beautician_id = %d", $beautician_id);
        
        if ($status !== 'all') {
            $where .= $wpdb->prepare(" AND status = %s", $status);
        }
        
        return $wpdb->get_results("SELECT * FROM $table $where ORDER BY created_at DESC");
    }
    
    /**
     * Add visit to card
     */
    public static function add_visit($card_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_loyalty_cards';
        
        $card = self::get_card($card_id);
        
        if (!$card) {
            return false;
        }
        
        $new_visits = $card->current_visits + 1;
        
        $update_data = array(
            'current_visits' => $new_visits,
        );
        
        // Check if card is completed
        if ($new_visits >= $card->visit_limit) {
            $update_data['status'] = 'completed';
            $update_data['completed_at'] = current_time('mysql');
        }
        
        return $wpdb->update($table, $update_data, array('id' => $card_id));
    }
    
    /**
     * Update card
     */
    public static function update_card($card_id, $data) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_loyalty_cards';
        
        $update_data = array();
        
        if (isset($data['visit_limit'])) {
            $update_data['visit_limit'] = intval($data['visit_limit']);
        }
        if (isset($data['reward_description'])) {
            $update_data['reward_description'] = sanitize_textarea_field($data['reward_description']);
        }
        if (isset($data['status'])) {
            $update_data['status'] = sanitize_text_field($data['status']);
        }
        
        return $wpdb->update($table, $update_data, array('id' => $card_id));
    }
    
    /**
     * Reset card
     */
    public static function reset_card($card_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_loyalty_cards';
        
        return $wpdb->update($table, array(
            'current_visits' => 0,
            'status' => 'active',
            'completed_at' => null,
        ), array('id' => $card_id));
    }
    
    /**
     * Get card statistics for beautician
     */
    public static function get_statistics($beautician_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_loyalty_cards';
        
        $stats = array(
            'total_cards' => 0,
            'active_cards' => 0,
            'completed_cards' => 0,
        );
        
        $stats['total_cards'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE beautician_id = %d",
            $beautician_id
        ));
        
        $stats['active_cards'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE beautician_id = %d AND status = 'active'",
            $beautician_id
        ));
        
        $stats['completed_cards'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE beautician_id = %d AND status = 'completed'",
            $beautician_id
        ));
        
        return $stats;
    }
}
