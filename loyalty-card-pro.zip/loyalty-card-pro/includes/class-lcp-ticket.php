<?php
/**
 * Ticket model class
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Ticket {
    
    /**
     * Create tickets bundle
     */
    public static function create_tickets($beautician_id, $count = 50, $reward_data = array()) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_tickets';
        
        $created = 0;
        
        for ($i = 0; $i < $count; $i++) {
            $ticket_code = self::generate_ticket_code();
            
            $ticket_data = array(
                'beautician_id' => $beautician_id,
                'ticket_code' => $ticket_code,
                'reward_type' => isset($reward_data['type']) ? sanitize_text_field($reward_data['type']) : 'random',
                'reward_value' => isset($reward_data['value']) ? sanitize_text_field($reward_data['value']) : '',
                'reward_description' => isset($reward_data['description']) ? sanitize_textarea_field($reward_data['description']) : '',
                'status' => 'available',
            );
            
            if ($wpdb->insert($table, $ticket_data)) {
                $created++;
            }
        }
        
        return $created;
    }
    
    /**
     * Generate unique ticket code
     */
    private static function generate_ticket_code() {
        return 'LCP-' . strtoupper(wp_generate_password(12, false));
    }
    
    /**
     * Get available tickets for beautician
     */
    public static function get_available_tickets($beautician_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_tickets';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE beautician_id = %d AND status = 'available' ORDER BY created_at DESC",
            $beautician_id
        ));
    }
    
    /**
     * Get ticket count by status
     */
    public static function get_ticket_count($beautician_id, $status = 'available') {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_tickets';
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE beautician_id = %d AND status = %s",
            $beautician_id,
            $status
        ));
    }
    
    /**
     * Assign ticket to client
     */
    public static function assign_ticket($beautician_id, $client_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_tickets';
        
        // Get a random available ticket
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE beautician_id = %d AND status = 'available' ORDER BY RAND() LIMIT 1",
            $beautician_id
        ));
        
        if (!$ticket) {
            return false;
        }
        
        // Update ticket
        $wpdb->update($table, array(
            'status' => 'assigned',
            'assigned_client_id' => $client_id,
            'assigned_at' => current_time('mysql'),
        ), array('id' => $ticket->id));
        
        return $ticket->id;
    }
    
    /**
     * Reveal ticket
     */
    public static function reveal_ticket($ticket_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_tickets';
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d",
            $ticket_id
        ));
        
        if (!$ticket || $ticket->status !== 'assigned') {
            return false;
        }
        
        // Generate random reward if needed
        if ($ticket->reward_type === 'random') {
            $rewards = self::get_random_rewards();
            $random_reward = $rewards[array_rand($rewards)];
            
            $wpdb->update($table, array(
                'reward_type' => $random_reward['type'],
                'reward_value' => $random_reward['value'],
                'reward_description' => $random_reward['description'],
            ), array('id' => $ticket_id));
            
            // Refresh ticket data
            $ticket = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table WHERE id = %d",
                $ticket_id
            ));
        }
        
        // Mark as revealed
        $wpdb->update($table, array(
            'status' => 'revealed',
            'revealed_at' => current_time('mysql'),
        ), array('id' => $ticket_id));
        
        return $ticket;
    }
    
    /**
     * Get random reward options
     */
    private static function get_random_rewards() {
        return array(
            array(
                'type' => 'discount',
                'value' => '10%',
                'description' => '10% off your next visit',
            ),
            array(
                'type' => 'discount',
                'value' => '15%',
                'description' => '15% off your next visit',
            ),
            array(
                'type' => 'discount',
                'value' => '20%',
                'description' => '20% off your next visit',
            ),
            array(
                'type' => 'discount',
                'value' => '25%',
                'description' => '25% off your next visit',
            ),
            array(
                'type' => 'free_service',
                'value' => 'manicure',
                'description' => 'Free basic manicure',
            ),
            array(
                'type' => 'free_service',
                'value' => 'pedicure',
                'description' => 'Free basic pedicure',
            ),
            array(
                'type' => 'voucher',
                'value' => '$5',
                'description' => '$5 voucher for next visit',
            ),
            array(
                'type' => 'voucher',
                'value' => '$10',
                'description' => '$10 voucher for next visit',
            ),
        );
    }
    
    /**
     * Get ticket by ID
     */
    public static function get_ticket($ticket_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_tickets';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d",
            $ticket_id
        ));
    }
    
    /**
     * Get assigned tickets for client
     */
    public static function get_client_tickets($client_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_tickets';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE assigned_client_id = %d ORDER BY assigned_at DESC",
            $client_id
        ));
    }
    
    /**
     * Get ticket statistics
     */
    public static function get_statistics($beautician_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_tickets';
        
        $stats = array(
            'available' => 0,
            'assigned' => 0,
            'revealed' => 0,
            'total' => 0,
        );
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT status, COUNT(*) as count FROM $table WHERE beautician_id = %d GROUP BY status",
            $beautician_id
        ));
        
        foreach ($results as $result) {
            $stats[$result->status] = $result->count;
            $stats['total'] += $result->count;
        }
        
        return $stats;
    }
    
    /**
     * Delete ticket
     */
    public static function delete_ticket($ticket_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_tickets';
        
        return $wpdb->delete($table, array('id' => $ticket_id));
    }
}
