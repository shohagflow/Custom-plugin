<?php
/**
 * AJAX request handler
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Ajax {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Admin AJAX
        add_action('wp_ajax_lcp_add_beautician', array($this, 'add_beautician'));
        add_action('wp_ajax_lcp_add_client', array($this, 'add_client'));
        add_action('wp_ajax_lcp_search_clients', array($this, 'search_clients'));
        add_action('wp_ajax_lcp_add_visit', array($this, 'add_visit'));
        add_action('wp_ajax_lcp_assign_ticket', array($this, 'assign_ticket'));
        add_action('wp_ajax_lcp_reveal_ticket', array($this, 'reveal_ticket'));
        add_action('wp_ajax_lcp_reset_loyalty_card', array($this, 'reset_loyalty_card'));
        add_action('wp_ajax_lcp_purchase_plan', array($this, 'purchase_plan'));
        add_action('wp_ajax_lcp_get_client_history', array($this, 'get_client_history'));
        
        // Public AJAX (if needed for non-logged in users)
        add_action('wp_ajax_nopriv_lcp_reveal_ticket', array($this, 'reveal_ticket'));
    }
    
    /**
     * Add beautician (Super Admin only)
     */
    public function add_beautician() {
        check_ajax_referer('lcp_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied.', 'loyalty-card-pro')));
        }
        
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $username = sanitize_user($_POST['username']);
        $password = $_POST['password'];
        
        // Create user
        $user_id = wp_create_user($username, $password, $email);
        
        if (is_wp_error($user_id)) {
            wp_send_json_error(array('message' => $user_id->get_error_message()));
        }
        
        // Update user meta
        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => $name,
            'first_name' => $name,
        ));
        
        // Set role
        $user = new WP_User($user_id);
        $user->set_role('lcp_beautician');
        
        wp_send_json_success(array(
            'message' => __('Beautician added successfully!', 'loyalty-card-pro'),
            'user_id' => $user_id,
        ));
    }
    
    /**
     * Add client
     */
    public function add_client() {
        check_ajax_referer('lcp_admin_nonce', 'nonce');
        
        $beautician_id = get_current_user_id();
        
        if (!LCP_Roles::can_access_dashboard($beautician_id)) {
            wp_send_json_error(array('message' => __('Permission denied.', 'loyalty-card-pro')));
        }
        
        // Check if can add more clients
        if (!LCP_Subscription::can_add_client($beautician_id)) {
            wp_send_json_error(array('message' => __('Client limit reached. Please upgrade your plan.', 'loyalty-card-pro')));
        }
        
        $data = array(
            'name' => sanitize_text_field($_POST['name']),
            'email' => sanitize_email($_POST['email']),
            'phone' => sanitize_text_field($_POST['phone']),
        );
        
        $client_id = LCP_Client::add_client($beautician_id, $data);
        
        if (!$client_id) {
            wp_send_json_error(array('message' => __('Failed to add client.', 'loyalty-card-pro')));
        }
        
        // Create loyalty card if requested
        if (isset($_POST['create_loyalty_card']) && $_POST['create_loyalty_card'] === 'true') {
            $visit_limit = isset($_POST['visit_limit']) ? intval($_POST['visit_limit']) : 10;
            $reward_description = isset($_POST['reward_description']) ? sanitize_textarea_field($_POST['reward_description']) : '';
            
            LCP_Loyalty_Card::create_card($client_id, $beautician_id, $visit_limit, $reward_description);
        }
        
        wp_send_json_success(array(
            'message' => __('Client added successfully!', 'loyalty-card-pro'),
            'client_id' => $client_id,
        ));
    }
    
    /**
     * Search clients
     */
    public function search_clients() {
        check_ajax_referer('lcp_admin_nonce', 'nonce');
        
        $beautician_id = get_current_user_id();
        
        if (!LCP_Roles::can_access_dashboard($beautician_id)) {
            wp_send_json_error(array('message' => __('Permission denied.', 'loyalty-card-pro')));
        }
        
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        $clients = LCP_Client::get_clients($beautician_id, $search, 20, 0);
        
        $results = array();
        foreach ($clients as $client) {
            $loyalty_card = LCP_Loyalty_Card::get_active_card($client->id);
            $results[] = array(
                'id' => $client->id,
                'name' => $client->name,
                'email' => $client->email,
                'phone' => $client->phone,
                'total_visits' => $client->total_visits,
                'loyalty_card' => $loyalty_card ? array(
                    'current_visits' => $loyalty_card->current_visits,
                    'visit_limit' => $loyalty_card->visit_limit,
                ) : null,
            );
        }
        
        wp_send_json_success(array('clients' => $results));
    }
    
    /**
     * Add visit to client
     */
    public function add_visit() {
        check_ajax_referer('lcp_admin_nonce', 'nonce');
        
        $beautician_id = get_current_user_id();
        
        if (!LCP_Roles::can_access_dashboard($beautician_id)) {
            wp_send_json_error(array('message' => __('Permission denied.', 'loyalty-card-pro')));
        }
        
        $client_id = intval($_POST['client_id']);
        $notes = isset($_POST['notes']) ? sanitize_textarea_field($_POST['notes']) : '';
        
        // Get active loyalty card
        $loyalty_card = LCP_Loyalty_Card::get_active_card($client_id);
        $loyalty_card_id = $loyalty_card ? $loyalty_card->id : null;
        
        $visit_id = LCP_Client::add_visit($client_id, $beautician_id, $loyalty_card_id, $notes);
        
        if (!$visit_id) {
            wp_send_json_error(array('message' => __('Failed to add visit.', 'loyalty-card-pro')));
        }
        
        // Check if loyalty card is completed
        $card_completed = false;
        if ($loyalty_card) {
            $updated_card = LCP_Loyalty_Card::get_card($loyalty_card_id);
            $card_completed = $updated_card->status === 'completed';
        }
        
        wp_send_json_success(array(
            'message' => __('Visit added successfully!', 'loyalty-card-pro'),
            'visit_id' => $visit_id,
            'card_completed' => $card_completed,
        ));
    }
    
    /**
     * Assign ticket to client
     */
    public function assign_ticket() {
        check_ajax_referer('lcp_admin_nonce', 'nonce');
        
        $beautician_id = get_current_user_id();
        
        if (!LCP_Roles::can_access_dashboard($beautician_id)) {
            wp_send_json_error(array('message' => __('Permission denied.', 'loyalty-card-pro')));
        }
        
        $client_id = intval($_POST['client_id']);
        
        // Check if tickets are available
        $available_count = LCP_Ticket::get_ticket_count($beautician_id, 'available');
        if ($available_count == 0) {
            wp_send_json_error(array('message' => __('No tickets available. Please purchase more tickets.', 'loyalty-card-pro')));
        }
        
        $ticket_id = LCP_Ticket::assign_ticket($beautician_id, $client_id);
        
        if (!$ticket_id) {
            wp_send_json_error(array('message' => __('Failed to assign ticket.', 'loyalty-card-pro')));
        }
        
        wp_send_json_success(array(
            'message' => __('Ticket assigned successfully!', 'loyalty-card-pro'),
            'ticket_id' => $ticket_id,
        ));
    }
    
    /**
     * Reveal ticket (scratch-off effect)
     */
    public function reveal_ticket() {
        check_ajax_referer('lcp_public_nonce', 'nonce');
        
        $ticket_id = intval($_POST['ticket_id']);
        $ticket = LCP_Ticket::reveal_ticket($ticket_id);
        
        if (!$ticket) {
            wp_send_json_error(array('message' => __('Failed to reveal ticket.', 'loyalty-card-pro')));
        }
        
        wp_send_json_success(array(
            'reward_type' => $ticket->reward_type,
            'reward_value' => $ticket->reward_value,
            'reward_description' => $ticket->reward_description,
        ));
    }
    
    /**
     * Reset loyalty card
     */
    public function reset_loyalty_card() {
        check_ajax_referer('lcp_admin_nonce', 'nonce');
        
        $beautician_id = get_current_user_id();
        
        if (!LCP_Roles::can_access_dashboard($beautician_id)) {
            wp_send_json_error(array('message' => __('Permission denied.', 'loyalty-card-pro')));
        }
        
        $card_id = intval($_POST['card_id']);
        $card = LCP_Loyalty_Card::get_card($card_id);
        
        if (!$card || $card->beautician_id != $beautician_id) {
            wp_send_json_error(array('message' => __('Invalid card.', 'loyalty-card-pro')));
        }
        
        LCP_Loyalty_Card::reset_card($card_id);
        
        wp_send_json_success(array('message' => __('Card reset successfully!', 'loyalty-card-pro')));
    }
    
    /**
     * Purchase plan
     */
    public function purchase_plan() {
        check_ajax_referer('lcp_admin_nonce', 'nonce');
        
        $beautician_id = get_current_user_id();
        
        if (!LCP_Roles::can_access_dashboard($beautician_id)) {
            wp_send_json_error(array('message' => __('Permission denied.', 'loyalty-card-pro')));
        }
        
        $plan_id = intval($_POST['plan_id']);
        $plan = LCP_Subscription::get_pricing_plan($plan_id);
        
        if (!$plan) {
            wp_send_json_error(array('message' => __('Invalid plan.', 'loyalty-card-pro')));
        }
        
        // Create subscription
        $subscription_id = LCP_Subscription::create_subscription($beautician_id, $plan_id);
        
        if (!$subscription_id) {
            wp_send_json_error(array('message' => __('Failed to create subscription.', 'loyalty-card-pro')));
        }
        
        // Record payment (simplified - in production, integrate with payment gateway)
        global $wpdb;
        $payments_table = $wpdb->prefix . 'lcp_payments';
        $wpdb->insert($payments_table, array(
            'user_id' => $beautician_id,
            'plan_id' => $plan_id,
            'amount' => $plan->price,
            'currency' => 'USD',
            'payment_method' => 'manual',
            'transaction_id' => 'TXN-' . time() . '-' . $beautician_id,
            'status' => 'completed',
        ));
        
        wp_send_json_success(array(
            'message' => __('Plan purchased successfully!', 'loyalty-card-pro'),
            'subscription_id' => $subscription_id,
        ));
    }
    
    /**
     * Get client history
     */
    public function get_client_history() {
        check_ajax_referer('lcp_admin_nonce', 'nonce');
        
        $beautician_id = get_current_user_id();
        
        if (!LCP_Roles::can_access_dashboard($beautician_id)) {
            wp_send_json_error(array('message' => __('Permission denied.', 'loyalty-card-pro')));
        }
        
        $client_id = intval($_POST['client_id']);
        $client = LCP_Client::get_client($client_id);
        
        if (!$client || $client->beautician_id != $beautician_id) {
            wp_send_json_error(array('message' => __('Invalid client.', 'loyalty-card-pro')));
        }
        
        $visits = LCP_Client::get_visit_history($client_id, 20);
        $tickets = LCP_Ticket::get_client_tickets($client_id);
        $loyalty_cards = LCP_Loyalty_Card::get_beautician_cards($beautician_id);
        
        // Filter loyalty cards for this client
        $client_cards = array_filter($loyalty_cards, function($card) use ($client_id) {
            return $card->client_id == $client_id;
        });
        
        wp_send_json_success(array(
            'client' => array(
                'id' => $client->id,
                'name' => $client->name,
                'email' => $client->email,
                'phone' => $client->phone,
                'total_visits' => $client->total_visits,
            ),
            'visits' => $visits,
            'tickets' => $tickets,
            'loyalty_cards' => array_values($client_cards),
        ));
    }
}
