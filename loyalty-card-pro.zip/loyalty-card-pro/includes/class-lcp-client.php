<?php
/**
 * Client model class
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Client {
    
    /**
     * Get all clients for a beautician
     */
    public static function get_clients($beautician_id, $search = '', $limit = 20, $offset = 0) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_clients';
        
        $where = $wpdb->prepare("WHERE beautician_id = %d", $beautician_id);
        
        if (!empty($search)) {
            $search_term = '%' . $wpdb->esc_like($search) . '%';
            $where .= $wpdb->prepare(" AND (name LIKE %s OR email LIKE %s OR phone LIKE %s)", $search_term, $search_term, $search_term);
        }
        
        $sql = "SELECT * FROM $table $where ORDER BY created_at DESC LIMIT %d OFFSET %d";
        $results = $wpdb->get_results($wpdb->prepare($sql, $limit, $offset));
        
        return $results;
    }
    
    /**
     * Get client count for beautician
     */
    public static function get_client_count($beautician_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_clients';
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE beautician_id = %d",
            $beautician_id
        ));
    }
    
    /**
     * Get client by ID
     */
    public static function get_client($client_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_clients';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d",
            $client_id
        ));
    }
    
    /**
     * Add new client
     */
    public static function add_client($beautician_id, $data) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_clients';
        
        $insert_data = array(
            'beautician_id' => $beautician_id,
            'name' => sanitize_text_field($data['name']),
            'email' => sanitize_email($data['email']),
            'phone' => sanitize_text_field($data['phone']),
            'total_visits' => 0,
        );
        
        $wpdb->insert($table, $insert_data);
        
        return $wpdb->insert_id;
    }
    
    /**
     * Update client
     */
    public static function update_client($client_id, $data) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_clients';
        
        $update_data = array();
        
        if (isset($data['name'])) {
            $update_data['name'] = sanitize_text_field($data['name']);
        }
        if (isset($data['email'])) {
            $update_data['email'] = sanitize_email($data['email']);
        }
        if (isset($data['phone'])) {
            $update_data['phone'] = sanitize_text_field($data['phone']);
        }
        
        return $wpdb->update($table, $update_data, array('id' => $client_id));
    }
    
    /**
     * Delete client
     */
    public static function delete_client($client_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_clients';
        
        return $wpdb->delete($table, array('id' => $client_id));
    }
    
    /**
     * Add visit for client
     */
    public static function add_visit($client_id, $beautician_id, $loyalty_card_id = null, $notes = '') {
        global $wpdb;
        $visits_table = $wpdb->prefix . 'lcp_visits';
        $clients_table = $wpdb->prefix . 'lcp_clients';
        
        // Insert visit
        $wpdb->insert($visits_table, array(
            'client_id' => $client_id,
            'beautician_id' => $beautician_id,
            'loyalty_card_id' => $loyalty_card_id,
            'notes' => sanitize_textarea_field($notes),
        ));
        
        // Update total visits
        $wpdb->query($wpdb->prepare(
            "UPDATE $clients_table SET total_visits = total_visits + 1 WHERE id = %d",
            $client_id
        ));
        
        // Update loyalty card if provided
        if ($loyalty_card_id) {
            LCP_Loyalty_Card::add_visit($loyalty_card_id);
        }
        
        return $wpdb->insert_id;
    }
    
    /**
     * Get visit history
     */
    public static function get_visit_history($client_id, $limit = 10) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_visits';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE client_id = %d ORDER BY visit_date DESC LIMIT %d",
            $client_id,
            $limit
        ));
    }
    
    /**
     * Search clients globally (for super admin)
     */
    public static function search_all_clients($search = '', $limit = 20, $offset = 0) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_clients';
        
        $where = "WHERE 1=1";
        
        if (!empty($search)) {
            $search_term = '%' . $wpdb->esc_like($search) . '%';
            $where .= $wpdb->prepare(" AND (name LIKE %s OR email LIKE %s)", $search_term, $search_term);
        }
        
        $sql = "SELECT * FROM $table $where ORDER BY created_at DESC LIMIT %d OFFSET %d";
        
        return $wpdb->get_results($wpdb->prepare($sql, $limit, $offset));
    }
}
