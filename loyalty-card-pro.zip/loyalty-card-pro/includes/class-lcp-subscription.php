<?php
/**
 * Subscription model class
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Subscription {
    
    /**
     * Create subscription
     */
    public static function create_subscription($beautician_id, $plan_id) {
        global $wpdb;
        $subscriptions_table = $wpdb->prefix . 'lcp_subscriptions';
        $plans_table = $wpdb->prefix . 'lcp_pricing_plans';
        
        // Get plan details
        $plan = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $plans_table WHERE id = %d",
            $plan_id
        ));
        
        if (!$plan) {
            return false;
        }
        
        // Create subscription
        $wpdb->insert($subscriptions_table, array(
            'beautician_id' => $beautician_id,
            'plan_type' => $plan->plan_type,
            'client_limit' => $plan->client_limit,
            'ticket_bundle_size' => $plan->ticket_count,
            'status' => 'active',
            'started_at' => current_time('mysql'),
        ));
        
        $subscription_id = $wpdb->insert_id;
        
        // Create tickets if applicable
        if ($plan->ticket_count > 0) {
            LCP_Ticket::create_tickets($beautician_id, $plan->ticket_count);
        }
        
        return $subscription_id;
    }
    
    /**
     * Get active subscription for beautician
     */
    public static function get_active_subscription($beautician_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_subscriptions';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE beautician_id = %d AND status = 'active' ORDER BY started_at DESC LIMIT 1",
            $beautician_id
        ));
    }
    
    /**
     * Get all subscriptions for beautician
     */
    public static function get_beautician_subscriptions($beautician_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_subscriptions';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE beautician_id = %d ORDER BY started_at DESC",
            $beautician_id
        ));
    }
    
    /**
     * Check if beautician can add more clients
     */
    public static function can_add_client($beautician_id) {
        $current_count = LCP_Client::get_client_count($beautician_id);
        $subscription = self::get_active_subscription($beautician_id);
        
        // Default limit is 20 if no subscription
        $limit = $subscription ? $subscription->client_limit : 20;
        
        return $current_count < $limit;
    }
    
    /**
     * Get client limit for beautician
     */
    public static function get_client_limit($beautician_id) {
        $subscription = self::get_active_subscription($beautician_id);
        
        // Start with 20 clients by default
        $base_limit = 20;
        
        if ($subscription) {
            return $base_limit + $subscription->client_limit;
        }
        
        return $base_limit;
    }
    
    /**
     * Expand client limit
     */
    public static function expand_client_limit($beautician_id, $additional_clients) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_subscriptions';
        
        $subscription = self::get_active_subscription($beautician_id);
        
        if ($subscription) {
            // Update existing subscription
            return $wpdb->update($table, array(
                'client_limit' => $subscription->client_limit + $additional_clients,
            ), array('id' => $subscription->id));
        } else {
            // Create new subscription
            return $wpdb->insert($table, array(
                'beautician_id' => $beautician_id,
                'plan_type' => 'clients',
                'client_limit' => $additional_clients,
                'ticket_bundle_size' => 0,
                'status' => 'active',
                'started_at' => current_time('mysql'),
            ));
        }
    }
    
    /**
     * Get all pricing plans
     */
    public static function get_pricing_plans() {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        return $wpdb->get_results(
            "SELECT * FROM $table WHERE is_active = 1 ORDER BY price ASC"
        );
    }
    
    /**
     * Get pricing plan by ID
     */
    public static function get_pricing_plan($plan_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d",
            $plan_id
        ));
    }
    
    /**
     * Create pricing plan
     */
    public static function create_pricing_plan($data) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        return $wpdb->insert($table, array(
            'plan_name' => sanitize_text_field($data['plan_name']),
            'plan_type' => sanitize_text_field($data['plan_type']),
            'ticket_count' => intval($data['ticket_count']),
            'client_limit' => intval($data['client_limit']),
            'price' => floatval($data['price']),
            'is_active' => isset($data['is_active']) ? intval($data['is_active']) : 1,
        ));
    }
    
    /**
     * Update pricing plan
     */
    public static function update_pricing_plan($plan_id, $data) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        $update_data = array();
        
        if (isset($data['plan_name'])) {
            $update_data['plan_name'] = sanitize_text_field($data['plan_name']);
        }
        if (isset($data['ticket_count'])) {
            $update_data['ticket_count'] = intval($data['ticket_count']);
        }
        if (isset($data['client_limit'])) {
            $update_data['client_limit'] = intval($data['client_limit']);
        }
        if (isset($data['price'])) {
            $update_data['price'] = floatval($data['price']);
        }
        if (isset($data['is_active'])) {
            $update_data['is_active'] = intval($data['is_active']);
        }
        
        return $wpdb->update($table, $update_data, array('id' => $plan_id));
    }
    
    /**
     * Delete pricing plan
     */
    public static function delete_pricing_plan($plan_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        return $wpdb->delete($table, array('id' => $plan_id));
    }
}
