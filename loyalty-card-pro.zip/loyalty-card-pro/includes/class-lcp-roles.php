<?php
/**
 * Roles and capabilities handler
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Roles {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Constructor
    }
    
    /**
     * Add custom roles
     */
    public static function add_roles() {
        // Add Beautician role
        add_role(
            'lcp_beautician',
            __('Beautician', 'loyalty-card-pro'),
            array(
                'read' => true,
                'lcp_manage_clients' => true,
                'lcp_manage_loyalty_cards' => true,
                'lcp_manage_tickets' => true,
                'lcp_view_dashboard' => true,
            )
        );
        
        // Add capabilities to administrator
        $admin = get_role('administrator');
        if ($admin) {
            $admin->add_cap('lcp_manage_all');
            $admin->add_cap('lcp_manage_beauticians');
            $admin->add_cap('lcp_manage_pricing');
            $admin->add_cap('lcp_view_payments');
            $admin->add_cap('lcp_manage_clients');
            $admin->add_cap('lcp_manage_loyalty_cards');
            $admin->add_cap('lcp_manage_tickets');
            $admin->add_cap('lcp_view_dashboard');
        }
    }
    
    /**
     * Remove custom roles
     */
    public static function remove_roles() {
        remove_role('lcp_beautician');
        
        // Remove capabilities from administrator
        $admin = get_role('administrator');
        if ($admin) {
            $admin->remove_cap('lcp_manage_all');
            $admin->remove_cap('lcp_manage_beauticians');
            $admin->remove_cap('lcp_manage_pricing');
            $admin->remove_cap('lcp_view_payments');
            $admin->remove_cap('lcp_manage_clients');
            $admin->remove_cap('lcp_manage_loyalty_cards');
            $admin->remove_cap('lcp_manage_tickets');
            $admin->remove_cap('lcp_view_dashboard');
        }
    }
    
    /**
     * Check if user is beautician
     */
    public static function is_beautician($user_id = 0) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        $user = get_userdata($user_id);
        return $user && in_array('lcp_beautician', (array) $user->roles);
    }
    
    /**
     * Check if user is super admin
     */
    public static function is_super_admin($user_id = 0) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        return user_can($user_id, 'manage_options');
    }
    
    /**
     * Check if user can access dashboard
     */
    public static function can_access_dashboard($user_id = 0) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        return user_can($user_id, 'lcp_view_dashboard') || user_can($user_id, 'manage_options');
    }
}
