/**
 * Loyalty Card Pro - Public JavaScript
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        
        // Show Add Client Modal (Frontend)
        $('.lcp-btn-add-client-frontend').on('click', function(e) {
            e.preventDefault();
            $('#lcp-add-client-modal-frontend').fadeIn();
        });
        
        // Close Modal
        $('.lcp-modal-close').on('click', function() {
            $(this).closest('.lcp-modal').fadeOut();
        });
        
        // Close modal on outside click
        $('.lcp-modal').on('click', function(e) {
            if ($(e.target).is('.lcp-modal')) {
                $(this).fadeOut();
            }
        });
        
        // Add Client Form (Frontend)
        $('#lcp-add-client-form-frontend').on('submit', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $button = $form.find('button[type="submit"]');
            const buttonText = $button.text();
            
            $button.prop('disabled', true).html('<span class="lcp-loading"></span> Adding...');
            
            $.ajax({
                url: lcpPublic.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_add_client',
                    nonce: lcpPublic.nonce,
                    name: $form.find('[name="name"]').val(),
                    email: $form.find('[name="email"]').val(),
                    phone: $form.find('[name="phone"]').val(),
                    create_loyalty_card: $form.find('[name="create_loyalty_card"]').is(':checked') ? 'true' : 'false'
                },
                success: function(response) {
                    if (response.success) {
                        showMessage(response.data.message, 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showMessage(response.data.message, 'error');
                    }
                },
                error: function() {
                    showMessage('An error occurred. Please try again.', 'error');
                },
                complete: function() {
                    $button.prop('disabled', false).text(buttonText);
                }
            });
        });
        
        // Client Search
        $('#lcp-search-btn').on('click', function() {
            const searchTerm = $('#lcp-client-search').val();
            searchClients(searchTerm);
        });
        
        $('#lcp-client-search').on('keypress', function(e) {
            if (e.which === 13) {
                e.preventDefault();
                const searchTerm = $(this).val();
                searchClients(searchTerm);
            }
        });
        
        function searchClients(searchTerm) {
            const $results = $('#lcp-search-results');
            $results.html('<p><span class="lcp-loading"></span> Searching...</p>');
            
            $.ajax({
                url: lcpPublic.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_search_clients',
                    nonce: lcpPublic.nonce,
                    search: searchTerm
                },
                success: function(response) {
                    if (response.success) {
                        displaySearchResults(response.data.clients);
                    } else {
                        $results.html('<p class="lcp-error-message">' + response.data.message + '</p>');
                    }
                },
                error: function() {
                    $results.html('<p class="lcp-error-message">An error occurred. Please try again.</p>');
                }
            });
        }
        
        function displaySearchResults(clients) {
            const $results = $('#lcp-search-results');
            
            if (clients.length === 0) {
                $results.html('<p>No clients found.</p>');
                return;
            }
            
            let html = '<div class="lcp-clients-list">';
            
            clients.forEach(function(client) {
                html += '<div class="lcp-client-item lcp-fade-in">';
                html += '<div class="lcp-client-avatar">' + client.name.charAt(0).toUpperCase() + '</div>';
                html += '<div class="lcp-client-info">';
                html += '<h4>' + client.name + '</h4>';
                html += '<p>' + (client.email || 'No email') + '</p>';
                html += '<span class="lcp-badge">' + client.total_visits + ' visits</span>';
                
                if (client.loyalty_card) {
                    html += '<span class="lcp-badge lcp-badge-success">';
                    html += client.loyalty_card.current_visits + '/' + client.loyalty_card.visit_limit + ' card progress';
                    html += '</span>';
                }
                
                html += '</div>';
                html += '<div class="lcp-client-actions">';
                html += '<button class="button lcp-btn-add-visit-frontend" data-client-id="' + client.id + '">Add Visit</button>';
                html += '<button class="button lcp-btn-assign-ticket-frontend" data-client-id="' + client.id + '">Give Ticket</button>';
                html += '</div>';
                html += '</div>';
            });
            
            html += '</div>';
            $results.html(html);
        }
        
        // Add Visit (Frontend)
        $(document).on('click', '.lcp-btn-add-visit-frontend', function() {
            const clientId = $(this).data('client-id');
            const $button = $(this);
            const buttonText = $button.text();
            
            if (!confirm('Add a visit for this client?')) {
                return;
            }
            
            $button.prop('disabled', true).html('<span class="lcp-loading"></span>');
            
            $.ajax({
                url: lcpPublic.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_add_visit',
                    nonce: lcpPublic.nonce,
                    client_id: clientId
                },
                success: function(response) {
                    if (response.success) {
                        showMessage(response.data.message, 'success');
                        
                        if (response.data.card_completed) {
                            alert('🎉 Loyalty card completed! Client earned their reward!');
                        }
                        
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showMessage(response.data.message, 'error');
                        $button.prop('disabled', false).text(buttonText);
                    }
                },
                error: function() {
                    showMessage('An error occurred. Please try again.', 'error');
                    $button.prop('disabled', false).text(buttonText);
                }
            });
        });
        
        // Assign Ticket (Frontend)
        $(document).on('click', '.lcp-btn-assign-ticket-frontend', function() {
            const clientId = $(this).data('client-id');
            const $button = $(this);
            const buttonText = $button.text();
            
            $button.prop('disabled', true).html('<span class="lcp-loading"></span>');
            
            $.ajax({
                url: lcpPublic.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_assign_ticket',
                    nonce: lcpPublic.nonce,
                    client_id: clientId
                },
                success: function(response) {
                    if (response.success) {
                        showTicketRevealModal(response.data.ticket_id);
                    } else {
                        showMessage(response.data.message, 'error');
                        $button.prop('disabled', false).text(buttonText);
                    }
                },
                error: function() {
                    showMessage('An error occurred. Please try again.', 'error');
                    $button.prop('disabled', false).text(buttonText);
                }
            });
        });
        
        // Show Ticket Reveal Modal
        function showTicketRevealModal(ticketId) {
            $('#lcp-ticket-reveal-modal').fadeIn();
            initScratchCanvas(ticketId);
        }
        
        // Initialize Scratch Canvas
        function initScratchCanvas(ticketId) {
            const canvas = document.getElementById('lcp-scratch-canvas');
            if (!canvas) return;
            
            const ctx = canvas.getContext('2d');
            const container = canvas.parentElement;
            
            // Set canvas size
            canvas.width = container.offsetWidth;
            canvas.height = 300;
            
            // Fill with scratch-off overlay
            ctx.fillStyle = lcpPublic.colors.primary;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Add text
            ctx.fillStyle = lcpPublic.colors.white;
            ctx.font = 'bold 24px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('Scratch Here!', canvas.width / 2, canvas.height / 2);
            
            let isScratching = false;
            let scratchPercentage = 0;
            
            function scratch(x, y) {
                ctx.globalCompositeOperation = 'destination-out';
                ctx.beginPath();
                ctx.arc(x, y, 30, 0, 2 * Math.PI);
                ctx.fill();
                
                checkScratchPercentage();
            }
            
            function checkScratchPercentage() {
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const pixels = imageData.data;
                let transparent = 0;
                
                for (let i = 3; i < pixels.length; i += 4) {
                    if (pixels[i] === 0) transparent++;
                }
                
                scratchPercentage = (transparent / (pixels.length / 4)) * 100;
                
                if (scratchPercentage > 50) {
                    revealTicket(ticketId);
                }
            }
            
            // Mouse events
            canvas.addEventListener('mousedown', function() {
                isScratching = true;
            });
            
            canvas.addEventListener('mouseup', function() {
                isScratching = false;
            });
            
            canvas.addEventListener('mousemove', function(e) {
                if (isScratching) {
                    const rect = canvas.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const y = e.clientY - rect.top;
                    scratch(x, y);
                }
            });
            
            // Touch events for mobile
            canvas.addEventListener('touchstart', function(e) {
                e.preventDefault();
                isScratching = true;
            });
            
            canvas.addEventListener('touchend', function() {
                isScratching = false;
            });
            
            canvas.addEventListener('touchmove', function(e) {
                e.preventDefault();
                if (isScratching) {
                    const rect = canvas.getBoundingClientRect();
                    const touch = e.touches[0];
                    const x = touch.clientX - rect.left;
                    const y = touch.clientY - rect.top;
                    scratch(x, y);
                }
            });
            
            // Click to reveal instantly
            canvas.addEventListener('click', function() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                revealTicket(ticketId);
            });
        }
        
        // Reveal Ticket
        function revealTicket(ticketId) {
            $.ajax({
                url: lcpPublic.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_reveal_ticket',
                    nonce: lcpPublic.nonce,
                    ticket_id: ticketId
                },
                success: function(response) {
                    if (response.success) {
                        $('.lcp-scratch-overlay').fadeOut();
                        $('.lcp-reward-text').text(response.data.reward_description);
                        $('.lcp-scratch-instruction').text('Share this reward with your client!');
                    }
                }
            });
        }
        
        // Show Message Helper
        function showMessage(message, type) {
            const className = type === 'success' ? 'lcp-success-message' : 'lcp-error-message';
            const $message = $('<div class="' + className + '">' + message + '</div>');
            
            $('.lcp-my-account-dashboard').prepend($message);
            
            setTimeout(function() {
                $message.fadeOut(function() {
                    $(this).remove();
                });
            }, 3000);
        }
    });

})(jQuery);
