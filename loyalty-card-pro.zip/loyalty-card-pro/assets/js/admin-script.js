/**
 * Loyalty Card Pro - Admin JavaScript
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        
        // Filter Dropdown Enhancement
        $('#lcp-filter-select').on('change', function() {
            const $select = $(this);
            $select.css('color', lcpAdmin.colors.primary);
            
            // Add loading state
            $select.prop('disabled', true);
            $select.after('<span class="lcp-loading" style="margin-left: 10px;"></span>');
        });
        
        // Highlight current filter on load
        if ($('#lcp-filter-select').length) {
            $('#lcp-filter-select').css('color', lcpAdmin.colors.primary);
        }
        
        // Add Beautician Form (Super Admin)
        $('#lcp-add-beautician-form').on('submit', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $button = $form.find('button[type="submit"]');
            const buttonText = $button.text();
            
            $button.prop('disabled', true).html('<span class="lcp-loading"></span> Adding...');
            
            $.ajax({
                url: lcpAdmin.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_add_beautician',
                    nonce: lcpAdmin.nonce,
                    name: $form.find('[name="name"]').val(),
                    email: $form.find('[name="email"]').val(),
                    username: $form.find('[name="username"]').val(),
                    password: $form.find('[name="password"]').val()
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        location.reload();
                    } else {
                        alert(response.data.message);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).text(buttonText);
                }
            });
        });
        
        // Show Add Client Modal
        $('.lcp-btn-add-client').on('click', function(e) {
            e.preventDefault();
            $('#lcp-add-client-modal').fadeIn();
        });
        
        // Close Modal
        $('.lcp-modal-close').on('click', function() {
            $(this).closest('.lcp-modal').fadeOut();
        });
        
        // Close modal on outside click
        $('.lcp-modal').on('click', function(e) {
            if ($(e.target).is('.lcp-modal')) {
                $(this).fadeOut();
            }
        });
        
        // Toggle loyalty card options
        $('input[name="create_loyalty_card"]').on('change', function() {
            if ($(this).is(':checked')) {
                $('#lcp-loyalty-card-options').slideDown();
            } else {
                $('#lcp-loyalty-card-options').slideUp();
            }
        });
        
        // Add Client Form
        $('#lcp-add-client-form').on('submit', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $button = $form.find('button[type="submit"]');
            const buttonText = $button.text();
            
            $button.prop('disabled', true).html('<span class="lcp-loading"></span> Adding...');
            
            $.ajax({
                url: lcpAdmin.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_add_client',
                    nonce: lcpAdmin.nonce,
                    name: $form.find('[name="name"]').val(),
                    email: $form.find('[name="email"]').val(),
                    phone: $form.find('[name="phone"]').val(),
                    create_loyalty_card: $form.find('[name="create_loyalty_card"]').is(':checked') ? 'true' : 'false',
                    visit_limit: $form.find('[name="visit_limit"]').val(),
                    reward_description: $form.find('[name="reward_description"]').val()
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        location.reload();
                    } else {
                        alert(response.data.message);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).text(buttonText);
                }
            });
        });
        
        // Add Visit
        $('.lcp-btn-add-visit').on('click', function() {
            const clientId = $(this).data('client-id');
            const $button = $(this);
            const buttonText = $button.text();
            
            if (!confirm('Add a visit for this client?')) {
                return;
            }
            
            $button.prop('disabled', true).html('<span class="lcp-loading"></span>');
            
            $.ajax({
                url: lcpAdmin.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_add_visit',
                    nonce: lcpAdmin.nonce,
                    client_id: clientId
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        
                        if (response.data.card_completed) {
                            alert('Loyalty card completed! Client earned their reward!');
                        }
                        
                        location.reload();
                    } else {
                        alert(response.data.message);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).text(buttonText);
                }
            });
        });
        
        // Assign Random Ticket
        $('.lcp-btn-assign-ticket, .lcp-btn-assign-random-ticket').on('click', function() {
            const clientId = $(this).data('client-id');
            const $button = $(this);
            const buttonText = $button.text();
            
            if (!confirm('Assign a surprise ticket to this client?')) {
                return;
            }
            
            $button.prop('disabled', true).html('<span class="lcp-loading"></span>');
            
            $.ajax({
                url: lcpAdmin.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_assign_ticket',
                    nonce: lcpAdmin.nonce,
                    client_id: clientId
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message + '\nTicket ID: ' + response.data.ticket_id);
                        location.reload();
                    } else {
                        alert(response.data.message);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).text(buttonText);
                }
            });
        });
        
        // Reset Loyalty Card
        $('.lcp-btn-reset-card').on('click', function() {
            const cardId = $(this).data('card-id');
            const $button = $(this);
            const buttonText = $button.text();
            
            if (!confirm('Reset this loyalty card? This will start a new card for the client.')) {
                return;
            }
            
            $button.prop('disabled', true).html('<span class="lcp-loading"></span>');
            
            $.ajax({
                url: lcpAdmin.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_reset_loyalty_card',
                    nonce: lcpAdmin.nonce,
                    card_id: cardId
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        location.reload();
                    } else {
                        alert(response.data.message);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).text(buttonText);
                }
            });
        });
        
        // Purchase Plan
        $('.lcp-btn-purchase-plan').on('click', function() {
            const planId = $(this).data('plan-id');
            const $button = $(this);
            const buttonText = $button.text();
            
            if (!confirm('Purchase this plan? You will be charged immediately.')) {
                return;
            }
            
            $button.prop('disabled', true).html('<span class="lcp-loading"></span> Processing...');
            
            $.ajax({
                url: lcpAdmin.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_purchase_plan',
                    nonce: lcpAdmin.nonce,
                    plan_id: planId
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        location.reload();
                    } else {
                        alert(response.data.message);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                },
                complete: function() {
                    $button.prop('disabled', false).text(buttonText);
                }
            });
        });
        
        // View Client History
        $('.lcp-btn-view-history').on('click', function() {
            const clientId = $(this).data('client-id');
            
            $.ajax({
                url: lcpAdmin.ajax_url,
                type: 'POST',
                data: {
                    action: 'lcp_get_client_history',
                    nonce: lcpAdmin.nonce,
                    client_id: clientId
                },
                success: function(response) {
                    if (response.success) {
                        showClientHistory(response.data);
                    } else {
                        alert(response.data.message);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                }
            });
        });
        
        // Show client history in modal
        function showClientHistory(data) {
            let html = '<div class="lcp-modal" id="lcp-history-modal">';
            html += '<div class="lcp-modal-content">';
            html += '<span class="lcp-modal-close">&times;</span>';
            html += '<h2>' + data.client.name + ' - History</h2>';
            html += '<p>Email: ' + data.client.email + '</p>';
            html += '<p>Total Visits: ' + data.client.total_visits + '</p>';
            
            html += '<h3>Recent Visits</h3>';
            if (data.visits.length > 0) {
                html += '<ul>';
                data.visits.forEach(function(visit) {
                    html += '<li>' + visit.visit_date + (visit.notes ? ' - ' + visit.notes : '') + '</li>';
                });
                html += '</ul>';
            } else {
                html += '<p>No visits yet.</p>';
            }
            
            html += '<h3>Tickets</h3>';
            if (data.tickets.length > 0) {
                html += '<ul>';
                data.tickets.forEach(function(ticket) {
                    html += '<li>' + ticket.status + ' - ' + (ticket.reward_description || 'Pending reveal') + '</li>';
                });
                html += '</ul>';
            } else {
                html += '<p>No tickets assigned.</p>';
            }
            
            html += '</div></div>';
            
            $('body').append(html);
            $('#lcp-history-modal').fadeIn();
            
            $('#lcp-history-modal .lcp-modal-close').on('click', function() {
                $('#lcp-history-modal').fadeOut(function() {
                    $(this).remove();
                });
            });
        }
        
        // Search functionality (if needed for future enhancements)
        $('#lcp-client-search-form').on('submit', function(e) {
            e.preventDefault();
            // Implement search if needed
        });
    });

})(jQuery);
