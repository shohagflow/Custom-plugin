<?php
/**
 * Super Admin Dashboard class
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Super_Admin {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', array($this, 'add_super_admin_menu'));
    }
    
    /**
     * Add super admin menu
     */
    public function add_super_admin_menu() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        add_submenu_page(
            'loyalty-card-pro',
            __('Beauticians Management', 'loyalty-card-pro'),
            __('Beauticians Management', 'loyalty-card-pro'),
            'manage_options',
            'lcp-beauticians-management',
            array($this, 'render_beauticians_management')
        );
        
        add_submenu_page(
            'loyalty-card-pro',
            __('Package Control', 'loyalty-card-pro'),
            __('Package Control', 'loyalty-card-pro'),
            'manage_options',
            'lcp-price-control',
            array($this, 'render_price_control')
        );
        
        add_submenu_page(
            'loyalty-card-pro',
            __('Payment Gateway', 'loyalty-card-pro'),
            __('Payment Gateway', 'loyalty-card-pro'),
            'manage_options',
            'lcp-payment-gateway',
            array($this, 'render_payment_gateway')
        );
    }
    
    /**
     * Render super admin dashboard (Overview)
     */
    public static function render_super_admin_dashboard() {
        global $wpdb;
        
        // Get statistics
        $beauticians_count = count(get_users(array('role' => 'lcp_beautician')));
        $clients_table = $wpdb->prefix . 'lcp_clients';
        $total_clients = $wpdb->get_var("SELECT COUNT(*) FROM $clients_table");
        
        $tickets_table = $wpdb->prefix . 'lcp_tickets';
        $total_tickets = $wpdb->get_var("SELECT COUNT(*) FROM $tickets_table");
        $available_tickets = $wpdb->get_var("SELECT COUNT(*) FROM $tickets_table WHERE status = 'available'");
        $used_tickets = $wpdb->get_var("SELECT COUNT(*) FROM $tickets_table WHERE status = 'revealed'");
        
        $loyalty_cards_table = $wpdb->prefix . 'lcp_loyalty_cards';
        $active_cards = $wpdb->get_var("SELECT COUNT(*) FROM $loyalty_cards_table WHERE status = 'active'");
        $completed_cards = $wpdb->get_var("SELECT COUNT(*) FROM $loyalty_cards_table WHERE status = 'completed'");
        
        $payments_table = $wpdb->prefix . 'lcp_payments';
        $total_revenue = $wpdb->get_var("SELECT SUM(amount) FROM $payments_table WHERE status = 'completed'");
        
        // Get recent activities
        $recent_clients = $wpdb->get_results("SELECT * FROM $clients_table ORDER BY created_at DESC LIMIT 5");
        
        // Get top beauticians by client count
        $top_beauticians = $wpdb->get_results("
            SELECT beautician_id, COUNT(*) as client_count 
            FROM $clients_table 
            GROUP BY beautician_id 
            ORDER BY client_count DESC 
            LIMIT 5
        ");
        
        ?>
        <div class="wrap lcp-super-admin-dashboard">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <div>
                    <h1 style="margin: 0; color: #FE7AC1;">
                        <span class="dashicons dashicons-chart-area" style="font-size: 32px;"></span>
                        <?php _e('Overview', 'loyalty-card-pro'); ?>
                    </h1>
                    <p style="margin: 5px 0 0 0; color: #666;"><?php _e('Welcome back! Here\'s what\'s happening with your loyalty program.', 'loyalty-card-pro'); ?></p>
                </div>
                <div>
                    <span style="background: #FFEFF7; color: #FE7AC1; padding: 8px 16px; border-radius: 20px; font-weight: 600;">
                        <?php echo date('l, F j, Y'); ?>
                    </span>
                </div>
            </div>
            
            <!-- Main Statistics Cards -->
            <div class="lcp-stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
                <div class="lcp-stat-card" style="background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%); color: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(254,122,193,0.3);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p style="margin: 0; opacity: 0.9; font-size: 14px;"><?php _e('Total Beauticians', 'loyalty-card-pro'); ?></p>
                            <h2 style="margin: 10px 0 0 0; font-size: 36px; font-weight: 700;"><?php echo number_format($beauticians_count); ?></h2>
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 12px; border-radius: 10px;">
                            <span class="dashicons dashicons-admin-users" style="font-size: 28px;"></span>
                        </div>
                    </div>
                </div>
                
                <div class="lcp-stat-card" style="background: white; border: 2px solid #FFEFF7; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p style="margin: 0; color: #666; font-size: 14px;"><?php _e('Total Clients', 'loyalty-card-pro'); ?></p>
                            <h2 style="margin: 10px 0 0 0; font-size: 36px; font-weight: 700; color: #FE7AC1;"><?php echo number_format($total_clients); ?></h2>
                        </div>
                        <div style="background: #FFEFF7; padding: 12px; border-radius: 10px;">
                            <span class="dashicons dashicons-groups" style="font-size: 28px; color: #FE7AC1;"></span>
                        </div>
                    </div>
                </div>
                
                <div class="lcp-stat-card" style="background: white; border: 2px solid #FFEFF7; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p style="margin: 0; color: #666; font-size: 14px;"><?php _e('Total Tickets', 'loyalty-card-pro'); ?></p>
                            <h2 style="margin: 10px 0 5px 0; font-size: 36px; font-weight: 700; color: #FE7AC1;"><?php echo number_format($total_tickets); ?></h2>
                            <p style="margin: 0; font-size: 12px; color: #999;">
                                <span style="color: #4CAF50;">●</span> <?php echo number_format($available_tickets); ?> <?php _e('available', 'loyalty-card-pro'); ?> 
                                <span style="margin-left: 10px; color: #999;">●</span> <?php echo number_format($used_tickets); ?> <?php _e('used', 'loyalty-card-pro'); ?>
                            </p>
                        </div>
                        <div style="background: #FFEFF7; padding: 12px; border-radius: 10px;">
                            <span class="dashicons dashicons-tickets-alt" style="font-size: 28px; color: #FE7AC1;"></span>
                        </div>
                    </div>
                </div>
                
                <div class="lcp-stat-card" style="background: linear-gradient(135deg, #4CAF50 0%, #66BB6A 100%); color: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(76,175,80,0.3);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p style="margin: 0; opacity: 0.9; font-size: 14px;"><?php _e('Total Revenue', 'loyalty-card-pro'); ?></p>
                            <h2 style="margin: 10px 0 0 0; font-size: 36px; font-weight: 700;">$<?php echo number_format($total_revenue, 2); ?></h2>
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 12px; border-radius: 10px;">
                            <span class="dashicons dashicons-money-alt" style="font-size: 28px;"></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Two Column Layout -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
                <!-- Loyalty Cards Stats -->
                <div style="background: white; padding: 25px; border-radius: 12px; border: 2px solid #FFEFF7; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <h3 style="margin: 0 0 20px 0; color: #FE7AC1; display: flex; align-items: center; gap: 10px;">
                        <span class="dashicons dashicons-awards"></span>
                        <?php _e('Loyalty Cards', 'loyalty-card-pro'); ?>
                    </h3>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div style="text-align: center; padding: 20px; background: #FFEFF7; border-radius: 8px;">
                            <h4 style="margin: 0; font-size: 32px; color: #FE7AC1; font-weight: 700;"><?php echo number_format($active_cards); ?></h4>
                            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;"><?php _e('Active Cards', 'loyalty-card-pro'); ?></p>
                        </div>
                        <div style="text-align: center; padding: 20px; background: #F0F0F1; border-radius: 8px;">
                            <h4 style="margin: 0; font-size: 32px; color: #4CAF50; font-weight: 700;"><?php echo number_format($completed_cards); ?></h4>
                            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;"><?php _e('Completed', 'loyalty-card-pro'); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div style="background: white; padding: 25px; border-radius: 12px; border: 2px solid #FFEFF7; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <h3 style="margin: 0 0 20px 0; color: #FE7AC1; display: flex; align-items: center; gap: 10px;">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <?php _e('Quick Actions', 'loyalty-card-pro'); ?>
                    </h3>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <a href="<?php echo admin_url('admin.php?page=lcp-beauticians-management'); ?>" class="button button-large" style="justify-content: flex-start; display: flex; align-items: center; gap: 10px; text-decoration: none;">
                            <span class="dashicons dashicons-admin-users"></span>
                            <?php _e('Manage Beauticians', 'loyalty-card-pro'); ?>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=lcp-price-control'); ?>" class="button button-large" style="justify-content: flex-start; display: flex; align-items: center; gap: 10px; text-decoration: none;">
                            <span class="dashicons dashicons-tag"></span>
                            <?php _e('Package Control', 'loyalty-card-pro'); ?>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=lcp-payment-gateway'); ?>" class="button button-large" style="justify-content: flex-start; display: flex; align-items: center; gap: 10px; text-decoration: none;">
                            <span class="dashicons dashicons-money-alt"></span>
                            <?php _e('Payment Settings', 'loyalty-card-pro'); ?>
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Two Column Layout -->
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
                <!-- Recent Clients -->
                <div style="background: white; padding: 25px; border-radius: 12px; border: 2px solid #FFEFF7; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <h3 style="margin: 0 0 20px 0; color: #FE7AC1; display: flex; align-items: center; gap: 10px;">
                        <span class="dashicons dashicons-groups"></span>
                        <?php _e('Recent Clients', 'loyalty-card-pro'); ?>
                    </h3>
                    <table class="wp-list-table widefat fixed striped" style="border: none;">
                        <thead>
                            <tr style="background: #FFEFF7;">
                                <th><?php _e('Name', 'loyalty-card-pro'); ?></th>
                                <th><?php _e('Email', 'loyalty-card-pro'); ?></th>
                                <th><?php _e('Beautician', 'loyalty-card-pro'); ?></th>
                                <th><?php _e('Visits', 'loyalty-card-pro'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_clients)) : ?>
                                <tr>
                                    <td colspan="4" style="text-align: center; padding: 40px; color: #999;">
                                        <span class="dashicons dashicons-groups" style="font-size: 48px; opacity: 0.3;"></span>
                                        <p><?php _e('No clients yet.', 'loyalty-card-pro'); ?></p>
                                    </td>
                                </tr>
                            <?php else : ?>
                                <?php foreach ($recent_clients as $client) : 
                                    $beautician = get_userdata($client->beautician_id);
                                ?>
                                    <tr>
                                        <td><strong><?php echo esc_html($client->name); ?></strong></td>
                                        <td><?php echo esc_html($client->email); ?></td>
                                        <td><?php echo $beautician ? esc_html($beautician->display_name) : __('N/A', 'loyalty-card-pro'); ?></td>
                                        <td><span style="background: #FE7AC1; color: white; padding: 3px 10px; border-radius: 12px; font-weight: 600;"><?php echo intval($client->total_visits); ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Top Beauticians -->
                <div style="background: white; padding: 25px; border-radius: 12px; border: 2px solid #FFEFF7; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <h3 style="margin: 0 0 20px 0; color: #FE7AC1; display: flex; align-items: center; gap: 10px;">
                        <span class="dashicons dashicons-star-filled"></span>
                        <?php _e('Top Beauticians', 'loyalty-card-pro'); ?>
                    </h3>
                    <?php if (empty($top_beauticians)) : ?>
                        <p style="text-align: center; color: #999; padding: 20px 0;"><?php _e('No data available', 'loyalty-card-pro'); ?></p>
                    <?php else : ?>
                        <div style="display: flex; flex-direction: column; gap: 12px;">
                            <?php 
                            $rank = 1;
                            foreach ($top_beauticians as $top) : 
                                $beautician = get_userdata($top->beautician_id);
                                if ($beautician) :
                            ?>
                                <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #FFEFF7; border-radius: 8px;">
                                    <div style="width: 32px; height: 32px; background: #FE7AC1; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700;">
                                        <?php echo $rank; ?>
                                    </div>
                                    <div style="flex: 1;">
                                        <strong style="display: block; color: #333;"><?php echo esc_html($beautician->display_name); ?></strong>
                                        <span style="font-size: 12px; color: #666;"><?php echo number_format($top->client_count); ?> <?php _e('clients', 'loyalty-card-pro'); ?></span>
                                    </div>
                                </div>
                            <?php 
                                $rank++;
                                endif;
                            endforeach; 
                            ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render beauticians management page
     */
    public function render_beauticians_management() {
        global $wpdb;
        
        // Get filter parameter (dummy - UI only)
        $current_filter = isset($_GET['filter']) ? sanitize_text_field($_GET['filter']) : 'all';
        
        // Get all beauticians
        $beauticians = get_users(array('role' => 'lcp_beautician'));
        
        // Add dummy beauticians if none exist
        $dummy_beauticians = array(
            array('name' => 'Sarah Johnson', 'email' => 'sarah.johnson@beautysalon.com', 'visitors' => 145, 'clients' => 32),
            array('name' => 'Emma Wilson', 'email' => 'emma.wilson@beautysalon.com', 'visitors' => 198, 'clients' => 45),
            array('name' => 'Olivia Martinez', 'email' => 'olivia.martinez@beautysalon.com', 'visitors' => 167, 'clients' => 38),
            array('name' => 'Sophia Brown', 'email' => 'sophia.brown@beautysalon.com', 'visitors' => 123, 'clients' => 28),
            array('name' => 'Isabella Garcia', 'email' => 'isabella.garcia@beautysalon.com', 'visitors' => 189, 'clients' => 41),
            array('name' => 'Mia Anderson', 'email' => 'mia.anderson@beautysalon.com', 'visitors' => 156, 'clients' => 35),
            array('name' => 'Charlotte Taylor', 'email' => 'charlotte.taylor@beautysalon.com', 'visitors' => 134, 'clients' => 30),
            array('name' => 'Amelia Thomas', 'email' => 'amelia.thomas@beautysalon.com', 'visitors' => 178, 'clients' => 40),
        );
        
        ?>
        <div class="wrap lcp-beauticians-management">
            <h1><?php _e('Beauticians Management', 'loyalty-card-pro'); ?></h1>
            
            <!-- Filter Options (UI only) -->
            <div class="lcp-filter-tabs" style="margin: 20px 0; padding: 15px; background: #fff; border: 1px solid #ddd; border-radius: 4px;">
                <strong style="margin-right: 15px;"><?php _e('Filter:', 'loyalty-card-pro'); ?></strong>
                <a href="?page=lcp-beauticians-management&filter=daily" 
                   class="button <?php echo $current_filter === 'daily' ? 'button-primary' : ''; ?>" 
                   style="margin-right: 5px;">
                    <?php _e('Daily', 'loyalty-card-pro'); ?>
                </a>
                <a href="?page=lcp-beauticians-management&filter=weekly" 
                   class="button <?php echo $current_filter === 'weekly' ? 'button-primary' : ''; ?>" 
                   style="margin-right: 5px;">
                    <?php _e('Weekly', 'loyalty-card-pro'); ?>
                </a>
                <a href="?page=lcp-beauticians-management&filter=monthly" 
                   class="button <?php echo $current_filter === 'monthly' ? 'button-primary' : ''; ?>" 
                   style="margin-right: 5px;">
                    <?php _e('Monthly', 'loyalty-card-pro'); ?>
                </a>
                <a href="?page=lcp-beauticians-management" 
                   class="button <?php echo $current_filter === 'all' ? 'button-primary' : ''; ?>">
                    <?php _e('All Time', 'loyalty-card-pro'); ?>
                </a>
                <?php if ($current_filter !== 'all') : ?>
                    <span style="margin-left: 15px; color: #666; font-style: italic;">
                        <?php printf(__('Showing %s data', 'loyalty-card-pro'), ucfirst($current_filter)); ?>
                    </span>
                <?php endif; ?>
            </div>
            
            <!-- Beauticians Table -->
            <table class="wp-list-table widefat fixed striped lcp-beauticians-table">
                <thead>
                    <tr>
                        <th><?php _e('Name', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Email', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Total Visitors', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Total Clients', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Action', 'loyalty-card-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Show real beauticians if they exist, otherwise show dummy data
                    $display_beauticians = !empty($beauticians) ? $beauticians : null;
                    
                    if (empty($beauticians)) :
                        // Display dummy beauticians
                        foreach ($dummy_beauticians as $idx => $beautician) : 
                    ?>
                            <tr>
                                <td><strong><?php echo esc_html($beautician['name']); ?></strong></td>
                                <td><?php echo esc_html($beautician['email']); ?></td>
                                <td>
                                    <span class="lcp-stat-badge" style="background: #FE7AC1; color: white; padding: 3px 10px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($beautician['visitors']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="lcp-stat-badge" style="background: #FFEFF7; color: #FE7AC1; padding: 3px 10px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($beautician['clients']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button type="button" 
                                            class="button button-small button-link-delete lcp-delete-beautician-btn" 
                                            data-user-id="<?php echo ($idx + 1); ?>"
                                            data-user-name="<?php echo esc_attr($beautician['name']); ?>"
                                            style="color: #d63638;">
                                        <?php _e('Delete', 'loyalty-card-pro'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <?php foreach ($beauticians as $beautician) : 
                            $client_count = LCP_Client::get_client_count($beautician->ID);
                            // Generate dummy visitor count based on client count
                            $visitor_count = $client_count > 0 ? rand($client_count * 2, $client_count * 5) : rand(0, 10);
                        ?>
                            <tr>
                                <td><strong><?php echo esc_html($beautician->display_name); ?></strong></td>
                                <td><?php echo esc_html($beautician->user_email); ?></td>
                                <td>
                                    <span class="lcp-stat-badge" style="background: #FE7AC1; color: white; padding: 3px 10px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($visitor_count); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="lcp-stat-badge" style="background: #FFEFF7; color: #FE7AC1; padding: 3px 10px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($client_count); ?>
                                    </span>
                                </td>
                                <td>
                                    <button type="button" 
                                            class="button button-small button-link-delete lcp-delete-beautician-btn" 
                                            data-user-id="<?php echo $beautician->ID; ?>"
                                            data-user-name="<?php echo esc_attr($beautician->display_name); ?>"
                                            style="color: #d63638;">
                                        <?php _e('Delete', 'loyalty-card-pro'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <p style="margin-top: 15px; padding: 10px; background: #f0f0f1; border-left: 4px solid #FE7AC1;">
                <strong><?php _e('Note:', 'loyalty-card-pro'); ?></strong> 
                <?php _e('Filters are currently for display purposes only. Delete action is UI-only (no backend logic).', 'loyalty-card-pro'); ?>
            </p>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // UI-only delete button (no actual deletion)
            $('.lcp-delete-beautician-btn').on('click', function() {
                var userName = $(this).data('user-name');
                var confirmed = confirm('Delete ' + userName + '? (Note: This is UI-only, no actual deletion will occur)');
                if (confirmed) {
                    $(this).closest('tr').fadeOut(300, function() {
                        $(this).remove();
                    });
                    
                    // Show success message
                    $('<div class="notice notice-success is-dismissible"><p>Beautician deleted successfully (UI-only demo).</p></div>')
                        .insertAfter('.lcp-beauticians-management h1')
                        .delay(3000)
                        .fadeOut();
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render price control page
     */
    public function render_price_control() {
        // Dummy data for display
        $loyalty_cards = array(
            array('id' => 1, 'name' => 'Basic Card - 20 Clients', 'client_limit' => 20, 'price' => 15.00),
            array('id' => 2, 'name' => 'Premium Card - 50 Clients', 'client_limit' => 50, 'price' => 35.00),
            array('id' => 3, 'name' => 'Enterprise Card - 100 Clients', 'client_limit' => 100, 'price' => 65.00),
        );
        
        $ticket_bundles = array(
            array('id' => 1, 'name' => 'Starter Bundle - 50 Tickets', 'ticket_limit' => 50, 'price' => 10.00),
            array('id' => 2, 'name' => 'Standard Bundle - 100 Tickets', 'ticket_limit' => 100, 'price' => 18.00),
            array('id' => 3, 'name' => 'Premium Bundle - 200 Tickets', 'ticket_limit' => 200, 'price' => 32.00),
        );
        
        ?>
        <div class="wrap lcp-price-control">
            <h1 style="color: #FE7AC1;">
                <span class="dashicons dashicons-tag" style="font-size: 32px;"></span>
                <?php _e('Package Control Management', 'loyalty-card-pro'); ?>
            </h1>
            <p class="description"><?php _e('Manage packages for Digital Loyalty Cards and Scratch-Off Surprise Tickets', 'loyalty-card-pro'); ?></p>
            
            <!-- Tab Navigation -->
            <div class="lcp-tab-navigation" style="margin: 25px 0 0 0; border-bottom: 2px solid #FFEFF7;">
                <button class="lcp-tab-button active" onclick="lcpSwitchTab('loyalty-cards')" data-tab="loyalty-cards" style="background: none; border: none; padding: 15px 30px; font-size: 16px; font-weight: 600; color: #666; cursor: pointer; border-bottom: 3px solid transparent; transition: all 0.3s;">
                    <span class="dashicons dashicons-awards" style="margin-right: 8px;"></span>
                    <?php _e('Digital Loyalty Card', 'loyalty-card-pro'); ?>
                </button>
                <button class="lcp-tab-button" onclick="lcpSwitchTab('scratch-tickets')" data-tab="scratch-tickets" style="background: none; border: none; padding: 15px 30px; font-size: 16px; font-weight: 600; color: #666; cursor: pointer; border-bottom: 3px solid transparent; transition: all 0.3s;">
                    <span class="dashicons dashicons-tickets-alt" style="margin-right: 8px;"></span>
                    <?php _e('Scratch-Off Surprise Tickets', 'loyalty-card-pro'); ?>
                </button>
                <button class="lcp-tab-button" onclick="lcpSwitchTab('user-purchases')" data-tab="user-purchases" style="background: none; border: none; padding: 15px 30px; font-size: 16px; font-weight: 600; color: #666; cursor: pointer; border-bottom: 3px solid transparent; transition: all 0.3s;">
                    <span class="dashicons dashicons-cart" style="margin-right: 8px;"></span>
                    <?php _e('User Purchases', 'loyalty-card-pro'); ?>
                </button>
            </div>
            
            <!-- Tab Content: Digital Loyalty Card Section -->
            <div id="lcp-tab-loyalty-cards" class="lcp-tab-content" style="display: block; padding-top: 30px;">
            <div class="lcp-price-section" style="background: white; padding: 25px; margin-bottom: 30px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h2 style="color: #FE7AC1; margin-top: 0;">
                    <span class="dashicons dashicons-awards"></span>
                    <?php _e('Digital Loyalty Card', 'loyalty-card-pro'); ?>
                </h2>
                <p style="color: #666; margin-bottom: 25px;"><?php _e('Create and manage digital loyalty card plans with client limits and pricing', 'loyalty-card-pro'); ?></p>
                
                <!-- Create/Edit Form -->
                <div class="lcp-price-form" style="background: #FFEFF7; padding: 20px; border-radius: 6px; margin-bottom: 25px;">
                    <h3 style="margin-top: 0;"><?php _e('Create/Edit Digital Loyalty Card Plan', 'loyalty-card-pro'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th><label><?php _e('Plan Name', 'loyalty-card-pro'); ?></label></th>
                            <td><input type="text" class="regular-text" placeholder="e.g., Premium Card - 50 Clients" value=""></td>
                        </tr>
                        <tr>
                            <th><label><?php _e('Client Limit', 'loyalty-card-pro'); ?></label></th>
                            <td>
                                <input type="number" class="regular-text" placeholder="20" value="" min="1" step="1">
                                <p class="description"><?php _e('Number of clients beauticians can manage with this plan', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label><?php _e('Price ($)', 'loyalty-card-pro'); ?></label></th>
                            <td>
                                <input type="number" class="regular-text" placeholder="15.00" value="" min="0" step="0.01">
                                <p class="description"><?php _e('Price in USD', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <p>
                        <button type="button" class="button button-primary button-large" style="background: #FE7AC1; border-color: #FE7AC1;" onclick="alert('UI-only demo: Plan saved successfully!')">
                            <span class="dashicons dashicons-saved" style="margin-top: 3px;"></span> 
                            <?php _e('Save Plan', 'loyalty-card-pro'); ?>
                        </button>
                        <button type="button" class="button button-large" onclick="jQuery(this).closest('.lcp-price-form').find('input').val('')">
                            <?php _e('Clear', 'loyalty-card-pro'); ?>
                        </button>
                    </p>
                </div>
                
                <!-- Existing Plans Table -->
                <h3><?php _e('Existing Plans', 'loyalty-card-pro'); ?></h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr style="background: #FFEFF7;">
                            <th style="width: 50%;"><?php _e('Plan Name', 'loyalty-card-pro'); ?></th>
                            <th style="width: 20%;"><?php _e('Client Limit', 'loyalty-card-pro'); ?></th>
                            <th style="width: 20%;"><?php _e('Price', 'loyalty-card-pro'); ?></th>
                            <th style="width: 10%;"><?php _e('Action', 'loyalty-card-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($loyalty_cards as $card) : ?>
                            <tr>
                                <td><strong><?php echo esc_html($card['name']); ?></strong></td>
                                <td>
                                    <span style="background: #FE7AC1; color: white; padding: 4px 12px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($card['client_limit']); ?> clients
                                    </span>
                                </td>
                                <td><strong style="color: #FE7AC1; font-size: 16px;">$<?php echo number_format($card['price'], 2); ?></strong></td>
                                <td>
                                    <button type="button" class="button button-small" onclick="alert('UI-only: Edit plan #<?php echo $card['id']; ?>')" style="color: #FE7AC1;">
                                        <?php _e('Edit', 'loyalty-card-pro'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            </div>
            
            <!-- Tab Content: Scratch-Off Surprise Tickets Section -->
            <div id="lcp-tab-scratch-tickets" class="lcp-tab-content" style="display: none; padding-top: 30px;">
            <div class="lcp-price-section" style="background: white; padding: 25px; margin-bottom: 30px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h2 style="color: #FE7AC1; margin-top: 0;">
                    <span class="dashicons dashicons-tickets-alt"></span>
                    <?php _e('Scratch-Off Surprise Tickets', 'loyalty-card-pro'); ?>
                </h2>
                <p style="color: #666; margin-bottom: 25px;"><?php _e('Create and manage scratch-off ticket bundles with ticket limits and pricing', 'loyalty-card-pro'); ?></p>
                
                <!-- Create/Edit Form -->
                <div class="lcp-price-form" style="background: #FFEFF7; padding: 20px; border-radius: 6px; margin-bottom: 25px;">
                    <h3 style="margin-top: 0;"><?php _e('Create/Edit Scratch-Off Ticket Bundle', 'loyalty-card-pro'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th><label><?php _e('Bundle Name', 'loyalty-card-pro'); ?></label></th>
                            <td><input type="text" class="regular-text" placeholder="e.g., Standard Bundle - 100 Tickets" value=""></td>
                        </tr>
                        <tr>
                            <th><label><?php _e('Ticket Limit', 'loyalty-card-pro'); ?></label></th>
                            <td>
                                <input type="number" class="regular-text" placeholder="50" value="" min="1" step="1">
                                <p class="description"><?php _e('Number of scratch-off tickets in this bundle', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label><?php _e('Price ($)', 'loyalty-card-pro'); ?></label></th>
                            <td>
                                <input type="number" class="regular-text" placeholder="10.00" value="" min="0" step="0.01">
                                <p class="description"><?php _e('Price in USD', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <p>
                        <button type="button" class="button button-primary button-large" style="background: #FE7AC1; border-color: #FE7AC1;" onclick="alert('UI-only demo: Bundle saved successfully!')">
                            <span class="dashicons dashicons-saved" style="margin-top: 3px;"></span> 
                            <?php _e('Save Bundle', 'loyalty-card-pro'); ?>
                        </button>
                        <button type="button" class="button button-large" onclick="jQuery(this).closest('.lcp-price-form').find('input').val('')">
                            <?php _e('Clear', 'loyalty-card-pro'); ?>
                        </button>
                    </p>
                </div>
                
                <!-- Existing Bundles Table -->
                <h3><?php _e('Existing Bundles', 'loyalty-card-pro'); ?></h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr style="background: #FFEFF7;">
                            <th style="width: 50%;"><?php _e('Bundle Name', 'loyalty-card-pro'); ?></th>
                            <th style="width: 20%;"><?php _e('Ticket Limit', 'loyalty-card-pro'); ?></th>
                            <th style="width: 20%;"><?php _e('Price', 'loyalty-card-pro'); ?></th>
                            <th style="width: 10%;"><?php _e('Action', 'loyalty-card-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ticket_bundles as $bundle) : ?>
                            <tr>
                                <td><strong><?php echo esc_html($bundle['name']); ?></strong></td>
                                <td>
                                    <span style="background: #FE7AC1; color: white; padding: 4px 12px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($bundle['ticket_limit']); ?> tickets
                                    </span>
                                </td>
                                <td><strong style="color: #FE7AC1; font-size: 16px;">$<?php echo number_format($bundle['price'], 2); ?></strong></td>
                                <td>
                                    <button type="button" class="button button-small" onclick="alert('UI-only: Edit bundle #<?php echo $bundle['id']; ?>')" style="color: #FE7AC1;">
                                        <?php _e('Edit', 'loyalty-card-pro'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            </div>
            
            <!-- Tab Content: User Purchases Section -->
            <div id="lcp-tab-user-purchases" class="lcp-tab-content" style="display: none; padding-top: 30px;">
            <div class="lcp-price-section" style="background: white; padding: 25px; margin-bottom: 30px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h2 style="color: #FE7AC1; margin-top: 0;">
                    <span class="dashicons dashicons-cart"></span>
                    <?php _e('User Purchases History', 'loyalty-card-pro'); ?>
                </h2>
                <p style="color: #666; margin-bottom: 25px;"><?php _e('View all users who purchased Digital Loyalty Cards and Scratch-Off Surprise Tickets', 'loyalty-card-pro'); ?></p>
                
                <?php
                // Dummy purchase data
                $dummy_purchases = array(
                    array(
                        'user' => 'Sarah Johnson',
                        'email' => 'sarah.johnson@beautysalon.com',
                        'loyalty_cards' => 2,
                        'loyalty_price' => 30.00,
                        'tickets' => 100,
                        'tickets_price' => 18.00,
                        'total' => 48.00,
                        'date' => '2026-01-18'
                    ),
                    array(
                        'user' => 'Emma Wilson',
                        'email' => 'emma.wilson@beautysalon.com',
                        'loyalty_cards' => 1,
                        'loyalty_price' => 35.00,
                        'tickets' => 50,
                        'tickets_price' => 10.00,
                        'total' => 45.00,
                        'date' => '2026-01-17'
                    ),
                    array(
                        'user' => 'Olivia Martinez',
                        'email' => 'olivia.martinez@beautysalon.com',
                        'loyalty_cards' => 3,
                        'loyalty_price' => 65.00,
                        'tickets' => 200,
                        'tickets_price' => 32.00,
                        'total' => 97.00,
                        'date' => '2026-01-16'
                    ),
                    array(
                        'user' => 'Sophia Brown',
                        'email' => 'sophia.brown@beautysalon.com',
                        'loyalty_cards' => 1,
                        'loyalty_price' => 15.00,
                        'tickets' => 100,
                        'tickets_price' => 18.00,
                        'total' => 33.00,
                        'date' => '2026-01-15'
                    ),
                    array(
                        'user' => 'Isabella Garcia',
                        'email' => 'isabella.garcia@beautysalon.com',
                        'loyalty_cards' => 2,
                        'loyalty_price' => 35.00,
                        'tickets' => 150,
                        'tickets_price' => 25.00,
                        'total' => 60.00,
                        'date' => '2026-01-14'
                    ),
                    array(
                        'user' => 'Mia Anderson',
                        'email' => 'mia.anderson@beautysalon.com',
                        'loyalty_cards' => 1,
                        'loyalty_price' => 15.00,
                        'tickets' => 50,
                        'tickets_price' => 10.00,
                        'total' => 25.00,
                        'date' => '2026-01-13'
                    ),
                    array(
                        'user' => 'Charlotte Taylor',
                        'email' => 'charlotte.taylor@beautysalon.com',
                        'loyalty_cards' => 2,
                        'loyalty_price' => 50.00,
                        'tickets' => 200,
                        'tickets_price' => 32.00,
                        'total' => 82.00,
                        'date' => '2026-01-12'
                    ),
                    array(
                        'user' => 'Amelia Thomas',
                        'email' => 'amelia.thomas@beautysalon.com',
                        'loyalty_cards' => 3,
                        'loyalty_price' => 65.00,
                        'tickets' => 100,
                        'tickets_price' => 18.00,
                        'total' => 83.00,
                        'date' => '2026-01-11'
                    ),
                );
                
                // Calculate totals
                $total_loyalty_revenue = 0;
                $total_tickets_revenue = 0;
                $grand_total = 0;
                foreach ($dummy_purchases as $purchase) {
                    $total_loyalty_revenue += $purchase['loyalty_price'];
                    $total_tickets_revenue += $purchase['tickets_price'];
                    $grand_total += $purchase['total'];
                }
                ?>
                
                <!-- Summary Cards -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 30px;">
                    <div style="background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%); color: white; padding: 20px; border-radius: 10px; text-align: center;">
                        <p style="margin: 0; opacity: 0.9; font-size: 14px;"><?php _e('Total Revenue', 'loyalty-card-pro'); ?></p>
                        <h3 style="margin: 10px 0 0 0; font-size: 28px; font-weight: 700;">$<?php echo number_format($grand_total, 2); ?></h3>
                    </div>
                    <div style="background: white; border: 2px solid #FFEFF7; padding: 20px; border-radius: 10px; text-align: center;">
                        <p style="margin: 0; color: #666; font-size: 14px;"><?php _e('Loyalty Cards Revenue', 'loyalty-card-pro'); ?></p>
                        <h3 style="margin: 10px 0 0 0; font-size: 28px; font-weight: 700; color: #FE7AC1;">$<?php echo number_format($total_loyalty_revenue, 2); ?></h3>
                    </div>
                    <div style="background: white; border: 2px solid #FFEFF7; padding: 20px; border-radius: 10px; text-align: center;">
                        <p style="margin: 0; color: #666; font-size: 14px;"><?php _e('Tickets Revenue', 'loyalty-card-pro'); ?></p>
                        <h3 style="margin: 10px 0 0 0; font-size: 28px; font-weight: 700; color: #FE7AC1;">$<?php echo number_format($total_tickets_revenue, 2); ?></h3>
                    </div>
                    <div style="background: white; border: 2px solid #FFEFF7; padding: 20px; border-radius: 10px; text-align: center;">
                        <p style="margin: 0; color: #666; font-size: 14px;"><?php _e('Total Purchases', 'loyalty-card-pro'); ?></p>
                        <h3 style="margin: 10px 0 0 0; font-size: 28px; font-weight: 700; color: #FE7AC1;"><?php echo count($dummy_purchases); ?></h3>
                    </div>
                </div>
                
                <!-- Purchases Table -->
                <h3><?php _e('Purchase History', 'loyalty-card-pro'); ?></h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr style="background: #FFEFF7;">
                            <th style="width: 20%;"><?php _e('User', 'loyalty-card-pro'); ?></th>
                            <th style="width: 20%;"><?php _e('Email', 'loyalty-card-pro'); ?></th>
                            <th style="width: 15%;"><?php _e('Loyalty Cards', 'loyalty-card-pro'); ?></th>
                            <th style="width: 15%;"><?php _e('Tickets', 'loyalty-card-pro'); ?></th>
                            <th style="width: 10%;"><?php _e('Total', 'loyalty-card-pro'); ?></th>
                            <th style="width: 10%;"><?php _e('Date', 'loyalty-card-pro'); ?></th>
                            <th style="width: 10%;"><?php _e('Status', 'loyalty-card-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dummy_purchases as $purchase) : ?>
                            <tr>
                                <td><strong><?php echo esc_html($purchase['user']); ?></strong></td>
                                <td><?php echo esc_html($purchase['email']); ?></td>
                                <td>
                                    <?php if ($purchase['loyalty_cards'] > 0) : ?>
                                        <span style="display: block; font-weight: 600; color: #333;">
                                            <?php echo $purchase['loyalty_cards']; ?> <?php _e('plan(s)', 'loyalty-card-pro'); ?>
                                        </span>
                                        <span style="display: block; font-size: 12px; color: #FE7AC1;">
                                            $<?php echo number_format($purchase['loyalty_price'], 2); ?>
                                        </span>
                                    <?php else : ?>
                                        <span style="color: #999;">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($purchase['tickets'] > 0) : ?>
                                        <span style="display: block; font-weight: 600; color: #333;">
                                            <?php echo number_format($purchase['tickets']); ?> <?php _e('tickets', 'loyalty-card-pro'); ?>
                                        </span>
                                        <span style="display: block; font-size: 12px; color: #FE7AC1;">
                                            $<?php echo number_format($purchase['tickets_price'], 2); ?>
                                        </span>
                                    <?php else : ?>
                                        <span style="color: #999;">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong style="color: #FE7AC1; font-size: 16px;">
                                        $<?php echo number_format($purchase['total'], 2); ?>
                                    </strong>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($purchase['date'])); ?></td>
                                <td>
                                    <span style="background: #4CAF50; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                        <?php _e('Completed', 'loyalty-card-pro'); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr style="background: #FFEFF7; font-weight: 600;">
                            <td colspan="2"><strong><?php _e('TOTAL', 'loyalty-card-pro'); ?></strong></td>
                            <td>
                                <strong style="color: #FE7AC1;">
                                    $<?php echo number_format($total_loyalty_revenue, 2); ?>
                                </strong>
                            </td>
                            <td>
                                <strong style="color: #FE7AC1;">
                                    $<?php echo number_format($total_tickets_revenue, 2); ?>
                                </strong>
                            </td>
                            <td>
                                <strong style="color: #FE7AC1; font-size: 18px;">
                                    $<?php echo number_format($grand_total, 2); ?>
                                </strong>
                            </td>
                            <td colspan="2"></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            </div>
            
            <!-- Info Notice -->
            <div class="notice notice-info" style="border-left-color: #FE7AC1; margin-top: 30px;">
                <p>
                    <strong><?php _e('Note:', 'loyalty-card-pro'); ?></strong> 
                    <?php _e('All values are editable from the UI. This is currently a dummy interface with no backend logic.', 'loyalty-card-pro'); ?>
                </p>
            </div>
        </div>
        
        <style>
        .lcp-tab-button {
            position: relative;
            background: none !important;
            box-shadow: none !important;
        }
        .lcp-tab-button:hover {
            color: #FE7AC1 !important;
        }
        .lcp-tab-button.active {
            color: #FE7AC1 !important;
            border-bottom-color: #FE7AC1 !important;
        }
        .lcp-tab-content {
            animation: fadeIn 0.3s ease-in;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        </style>
        
        <script>
        function lcpSwitchTab(tabName) {
            // Hide all tab contents
            var tabContents = document.querySelectorAll('.lcp-tab-content');
            tabContents.forEach(function(content) {
                content.style.display = 'none';
            });
            
            // Remove active class from all tab buttons
            var tabButtons = document.querySelectorAll('.lcp-tab-button');
            tabButtons.forEach(function(button) {
                button.classList.remove('active');
            });
            
            // Show selected tab content
            var selectedTab = document.getElementById('lcp-tab-' + tabName);
            if (selectedTab) {
                selectedTab.style.display = 'block';
            }
            
            // Add active class to clicked button
            var activeButton = document.querySelector('.lcp-tab-button[data-tab="' + tabName + '"]');
            if (activeButton) {
                activeButton.classList.add('active');
            }
        }
        
        // Initialize tabs on page load
        jQuery(document).ready(function($) {
            // Ensure first tab is active by default
            lcpSwitchTab('loyalty-cards');
        });
        </script>
        <?php
    }
    
    /**
     * Render payment gateway settings page
     */
    public function render_payment_gateway() {
        ?>
        <div class="wrap lcp-payment-gateway">
            <h1 style="color: #FE7AC1;">
                <span class="dashicons dashicons-money-alt" style="font-size: 32px;"></span>
                <?php _e('Payment Gateway Settings', 'loyalty-card-pro'); ?>
            </h1>
            <p class="description"><?php _e('Configure payment gateway for processing transactions', 'loyalty-card-pro'); ?></p>
            
            <hr style="margin: 25px 0; border: none; border-top: 2px solid #FFEFF7;">
            
            <!-- Stripe Payment Gateway -->
            <div class="lcp-gateway-card" style="background: white; padding: 30px; margin-bottom: 30px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 25px;">
                    <div style="display: flex; align-items: center;">
                        <div style="width: 60px; height: 60px; background: #635BFF; border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 20px;">
                            <span style="color: white; font-size: 24px; font-weight: bold;">S</span>
                        </div>
                        <div>
                            <h2 style="margin: 0; color: #635BFF; font-size: 24px;">Stripe</h2>
                            <p style="margin: 5px 0 0 0; color: #666;"><?php _e('Accept payments via Stripe payment gateway', 'loyalty-card-pro'); ?></p>
                        </div>
                    </div>
                    <div>
                        <span class="lcp-status-badge" style="background: #28a745; color: white; padding: 8px 20px; border-radius: 20px; font-weight: 600; font-size: 14px;">
                            <span class="dashicons dashicons-yes-alt" style="font-size: 16px; margin-top: 2px;"></span>
                            <?php _e('Enabled', 'loyalty-card-pro'); ?>
                        </span>
                    </div>
                </div>
                
                <hr style="margin: 25px 0; border: none; border-top: 1px solid #eee;">
                
                <!-- Gateway Details -->
                <div class="lcp-gateway-details">
                    <table class="form-table">
                        <tr>
                            <th style="width: 200px; padding-left: 0;">
                                <label><?php _e('Gateway Status', 'loyalty-card-pro'); ?></label>
                            </th>
                            <td>
                                <label class="lcp-switch" style="position: relative; display: inline-block; width: 60px; height: 30px;">
                                    <input type="checkbox" checked disabled style="opacity: 0; width: 0; height: 0;">
                                    <span style="position: absolute; cursor: not-allowed; top: 0; left: 0; right: 0; bottom: 0; background-color: #28a745; border-radius: 30px; transition: 0.4s;">
                                        <span style="position: absolute; content: ''; height: 22px; width: 22px; left: 33px; bottom: 4px; background-color: white; border-radius: 50%; transition: 0.4s;"></span>
                                    </span>
                                </label>
                                <span style="margin-left: 15px; color: #28a745; font-weight: 600;"><?php _e('Active', 'loyalty-card-pro'); ?></span>
                                <p class="description"><?php _e('Gateway is currently enabled for processing payments', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th style="padding-left: 0;">
                                <label><?php _e('Test Mode', 'loyalty-card-pro'); ?></label>
                            </th>
                            <td>
                                <label class="lcp-switch" style="position: relative; display: inline-block; width: 60px; height: 30px;">
                                    <input type="checkbox" checked disabled style="opacity: 0; width: 0; height: 0;">
                                    <span style="position: absolute; cursor: not-allowed; top: 0; left: 0; right: 0; bottom: 0; background-color: #ff9800; border-radius: 30px; transition: 0.4s;">
                                        <span style="position: absolute; content: ''; height: 22px; width: 22px; left: 33px; bottom: 4px; background-color: white; border-radius: 50%; transition: 0.4s;"></span>
                                    </span>
                                </label>
                                <span style="margin-left: 15px; color: #ff9800; font-weight: 600;"><?php _e('Test Mode Enabled', 'loyalty-card-pro'); ?></span>
                                <p class="description"><?php _e('No real charges will be made in test mode', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th style="padding-left: 0;">
                                <label><?php _e('API Keys', 'loyalty-card-pro'); ?></label>
                            </th>
                            <td>
                                <p style="margin: 0 0 10px 0;">
                                    <strong><?php _e('Publishable Key:', 'loyalty-card-pro'); ?></strong>
                                    <code style="background: #f5f5f5; padding: 5px 10px; border-radius: 4px; display: inline-block; margin-left: 10px;">
                                        pk_test_***************************
                                    </code>
                                </p>
                                <p style="margin: 0;">
                                    <strong><?php _e('Secret Key:', 'loyalty-card-pro'); ?></strong>
                                    <code style="background: #f5f5f5; padding: 5px 10px; border-radius: 4px; display: inline-block; margin-left: 10px;">
                                        sk_test_***************************
                                    </code>
                                </p>
                                <p class="description"><?php _e('API keys are configured and validated', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th style="padding-left: 0;">
                                <label><?php _e('Supported Payment Methods', 'loyalty-card-pro'); ?></label>
                            </th>
                            <td>
                                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                                    <span style="background: #FFEFF7; color: #FE7AC1; padding: 6px 14px; border-radius: 15px; font-weight: 600; border: 1px solid #FE7AC1;">
                                        <span class="dashicons dashicons-admin-site-alt3" style="font-size: 14px; margin-top: 2px;"></span>
                                        Credit Card
                                    </span>
                                    <span style="background: #FFEFF7; color: #FE7AC1; padding: 6px 14px; border-radius: 15px; font-weight: 600; border: 1px solid #FE7AC1;">
                                        <span class="dashicons dashicons-admin-site-alt3" style="font-size: 14px; margin-top: 2px;"></span>
                                        Debit Card
                                    </span>
                                    <span style="background: #FFEFF7; color: #FE7AC1; padding: 6px 14px; border-radius: 15px; font-weight: 600; border: 1px solid #FE7AC1;">
                                        <span class="dashicons dashicons-admin-site-alt3" style="font-size: 14px; margin-top: 2px;"></span>
                                        Google Pay
                                    </span>
                                    <span style="background: #FFEFF7; color: #FE7AC1; padding: 6px 14px; border-radius: 15px; font-weight: 600; border: 1px solid #FE7AC1;">
                                        <span class="dashicons dashicons-admin-site-alt3" style="font-size: 14px; margin-top: 2px;"></span>
                                        Apple Pay
                                    </span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th style="padding-left: 0;">
                                <label><?php _e('Currency', 'loyalty-card-pro'); ?></label>
                            </th>
                            <td>
                                <strong style="color: #FE7AC1; font-size: 16px;">USD ($)</strong>
                                <p class="description"><?php _e('United States Dollar', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <hr style="margin: 25px 0; border: none; border-top: 1px solid #eee;">
                
                <!-- Actions -->
                <div class="lcp-gateway-actions" style="display: flex; gap: 10px;">
                    <button type="button" class="button button-primary button-large" style="background: #635BFF; border-color: #635BFF; box-shadow: none;" onclick="alert('UI-only demo: No API integration yet')">
                        <span class="dashicons dashicons-admin-settings" style="margin-top: 3px;"></span>
                        <?php _e('Configure Settings', 'loyalty-card-pro'); ?>
                    </button>
                    <button type="button" class="button button-large" onclick="alert('UI-only demo: Test connection')">
                        <span class="dashicons dashicons-superhero" style="margin-top: 3px;"></span>
                        <?php _e('Test Connection', 'loyalty-card-pro'); ?>
                    </button>
                    <button type="button" class="button button-large" onclick="window.open('https://dashboard.stripe.com', '_blank')">
                        <span class="dashicons dashicons-external" style="margin-top: 3px;"></span>
                        <?php _e('Open Stripe Dashboard', 'loyalty-card-pro'); ?>
                    </button>
                </div>
            </div>
            
            <!-- Additional Payment Methods (Coming Soon) -->
            <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; border: 2px dashed #ddd;">
                <h3 style="margin-top: 0; color: #666;">
                    <span class="dashicons dashicons-plus-alt"></span>
                    <?php _e('Additional Payment Gateways', 'loyalty-card-pro'); ?>
                </h3>
                <p style="color: #999;"><?php _e('More payment gateways (PayPal, Square, etc.) coming soon...', 'loyalty-card-pro'); ?></p>
            </div>
            
            <!-- Info Notice -->
            <div class="notice notice-info" style="margin-top: 25px; border-left-color: #635BFF;">
                <p>
                    <strong><?php _e('Development Mode:', 'loyalty-card-pro'); ?></strong> 
                    <?php _e('This is a display-only interface. No actual API integration is active. All data shown is for demonstration purposes.', 'loyalty-card-pro'); ?>
                </p>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render payments page
     */
    public function render_payments() {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_payments';
        
        // Get payments with user details
        $payments = $wpdb->get_results("
            SELECT p.*, u.display_name, u.user_email
            FROM $table p
            LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID
            ORDER BY p.payment_date DESC
            LIMIT 100
        ");
        
        // Calculate totals
        $total_revenue = $wpdb->get_var("SELECT SUM(amount) FROM $table WHERE status = 'completed'");
        $pending_amount = $wpdb->get_var("SELECT SUM(amount) FROM $table WHERE status = 'pending'");
        
        ?>
        <div class="wrap lcp-payments">
            <h1><?php _e('Payments', 'loyalty-card-pro'); ?></h1>
            
            <div class="lcp-payment-summary">
                <div class="lcp-summary-card">
                    <h3><?php _e('Total Revenue', 'loyalty-card-pro'); ?></h3>
                    <p class="lcp-amount">$<?php echo number_format($total_revenue, 2); ?></p>
                </div>
                <div class="lcp-summary-card">
                    <h3><?php _e('Pending Payments', 'loyalty-card-pro'); ?></h3>
                    <p class="lcp-amount">$<?php echo number_format($pending_amount, 2); ?></p>
                </div>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('ID', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('User', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Email', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Amount', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Method', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Transaction ID', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Status', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Date', 'loyalty-card-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($payments)) : ?>
                        <tr>
                            <td colspan="8"><?php _e('No payments found.', 'loyalty-card-pro'); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($payments as $payment) : ?>
                            <tr>
                                <td><?php echo intval($payment->id); ?></td>
                                <td><?php echo esc_html($payment->display_name); ?></td>
                                <td><?php echo esc_html($payment->user_email); ?></td>
                                <td>$<?php echo number_format($payment->amount, 2); ?></td>
                                <td><?php echo esc_html($payment->payment_method); ?></td>
                                <td><?php echo esc_html($payment->transaction_id); ?></td>
                                <td>
                                    <?php if ($payment->status === 'completed') : ?>
                                        <span class="lcp-badge lcp-badge-success"><?php _e('Completed', 'loyalty-card-pro'); ?></span>
                                    <?php elseif ($payment->status === 'pending') : ?>
                                        <span class="lcp-badge lcp-badge-warning"><?php _e('Pending', 'loyalty-card-pro'); ?></span>
                                    <?php else : ?>
                                        <span class="lcp-badge lcp-badge-error"><?php _e('Failed', 'loyalty-card-pro'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M d, Y H:i', strtotime($payment->payment_date)); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}
