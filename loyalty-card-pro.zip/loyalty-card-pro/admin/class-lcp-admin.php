<?php
/**
 * Admin base class
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Admin {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Main menu for all users with dashboard access
        if (current_user_can('lcp_view_dashboard') || current_user_can('manage_options')) {
            add_menu_page(
                __('Loyalty Card Pro', 'loyalty-card-pro'),
                __('Loyalty Card Pro', 'loyalty-card-pro'),
                'lcp_view_dashboard',
                'loyalty-card-pro',
                array($this, 'render_dashboard'),
                'dashicons-tickets-alt',
                30
            );
            
            // Rename first submenu to "Overview"
            add_submenu_page(
                'loyalty-card-pro',
                __('Overview', 'loyalty-card-pro'),
                __('Overview', 'loyalty-card-pro'),
                'lcp_view_dashboard',
                'loyalty-card-pro',
                array($this, 'render_dashboard')
            );
        }
    }
    
    /**
     * Render dashboard (redirect based on role)
     */
    public function render_dashboard() {
        $user_id = get_current_user_id();
        
        if (LCP_Roles::is_super_admin($user_id)) {
            LCP_Super_Admin::render_super_admin_dashboard();
        } elseif (LCP_Roles::is_beautician($user_id)) {
            LCP_Beautician_Dashboard::render_beautician_dashboard();
        } else {
            echo '<div class="wrap"><h1>' . __('Access Denied', 'loyalty-card-pro') . '</h1></div>';
        }
    }
}
