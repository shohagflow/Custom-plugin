<?php
/**
 * Plugin Name: Loyalty Card Pro
 * Plugin URI: https://loyaltycardpro.com
 * Description: A comprehensive digital loyalty card and scratch-off ticket system for beauticians with client management, rewards tracking, and engagement tools.
 * Version: 1.0.0
 * Author: Loyalty Card Pro Team
 * Author URI: https://loyaltycardpro.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: loyalty-card-pro
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('LCP_VERSION', '1.0.0');
define('LCP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LCP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('LCP_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Brand Colors
define('LCP_COLOR_PRIMARY', '#FE7AC1');
define('LCP_COLOR_SECONDARY', '#FFEFF7');
define('LCP_COLOR_WHITE', '#FFFFFF');

/**
 * Main plugin class
 */
class Loyalty_Card_Pro {
    
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    /**
     * Load required files
     */
    private function load_dependencies() {
        // Core classes
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-database.php';
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-roles.php';
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-client.php';
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-loyalty-card.php';
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-ticket.php';
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-subscription.php';
        
        // Admin classes
        require_once LCP_PLUGIN_DIR . 'admin/class-lcp-admin.php';
        require_once LCP_PLUGIN_DIR . 'admin/class-lcp-super-admin.php';
        require_once LCP_PLUGIN_DIR . 'admin/class-lcp-beautician-dashboard.php';
        
        // Frontend classes
        require_once LCP_PLUGIN_DIR . 'public/class-lcp-public.php';
        require_once LCP_PLUGIN_DIR . 'public/class-lcp-my-account.php';
        
        // AJAX handlers
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-ajax.php';
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        add_action('plugins_loaded', array($this, 'init'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'public_enqueue_scripts'));
        add_action('init', array($this, 'register_customer_registration_page'));
        add_action('template_redirect', array($this, 'customer_registration_template'));
        
        // AJAX handlers for customer registration
        add_action('wp_ajax_lcp_register_customer', array($this, 'ajax_register_customer'));
        add_action('wp_ajax_nopriv_lcp_register_customer', array($this, 'ajax_register_customer'));
        
        // AJAX handler to get customers
        add_action('wp_ajax_lcp_get_customers', array($this, 'ajax_get_customers'));
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return;
        }
        
        // Initialize components
        LCP_Database::get_instance();
        LCP_Roles::get_instance();
        LCP_Admin::get_instance();
        LCP_Super_Admin::get_instance();
        LCP_Beautician_Dashboard::get_instance();
        LCP_Public::get_instance();
        LCP_My_Account::get_instance();
        LCP_Ajax::get_instance();
        
        // Load text domain
        load_plugin_textdomain('loyalty-card-pro', false, dirname(LCP_PLUGIN_BASENAME) . '/languages');
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        LCP_Database::create_tables();
        LCP_Roles::add_roles();
        
        // Register the endpoints before flushing
        add_rewrite_endpoint('beautician-dashboard', EP_ROOT | EP_PAGES);
        add_action('init', array($this, 'register_customer_registration_page'));
        
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * Register customer registration page
     */
    public function register_customer_registration_page() {
        add_rewrite_rule(
            '^customer-registration/?$',
            'index.php?lcp_customer_registration=1',
            'top'
        );
        add_filter('query_vars', function($vars) {
            $vars[] = 'lcp_customer_registration';
            return $vars;
        });
    }
    
    /**
     * Load customer registration template
     */
    public function customer_registration_template() {
        if (get_query_var('lcp_customer_registration')) {
            include LCP_PLUGIN_DIR . 'public/templates/customer-registration.php';
            exit;
        }
    }
    
    /**
     * AJAX handler for customer registration
     */
    public function ajax_register_customer() {
        // Verify nonce for security
        check_ajax_referer('lcp_public_nonce', 'nonce');
        
        // Get form data
        $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
        $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
        $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        
        // Validate required fields
        if (empty($name) || empty($phone)) {
            wp_send_json_error(array('message' => __('Name and phone number are required.', 'loyalty-card-pro')));
            return;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'lcp_clients';
        
        // Check if customer already exists by phone
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE phone = %s",
            $phone
        ));
        
        if ($existing) {
            wp_send_json_error(array('message' => __('A customer with this phone number already exists.', 'loyalty-card-pro')));
            return;
        }
        
        // Insert new customer
        $result = $wpdb->insert(
            $table_name,
            array(
                'name' => $name,
                'phone' => $phone,
                'email' => $email,
                'loyalty_cards' => 0,
                'tickets' => 0,
                'visits' => 0,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ),
            array('%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s')
        );
        
        if ($result) {
            wp_send_json_success(array(
                'message' => __('Registration successful! Welcome to our loyalty program.', 'loyalty-card-pro'),
                'customer_id' => $wpdb->insert_id
            ));
        } else {
            wp_send_json_error(array('message' => __('Registration failed. Please try again.', 'loyalty-card-pro')));
        }
    }
    
    /**
     * AJAX handler to get all customers
     */
    public function ajax_get_customers() {
        // Check nonce
        check_ajax_referer('lcp_public_nonce', 'nonce');
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'lcp_clients';
        
        // Get all customers ordered by most recent first
        $customers = $wpdb->get_results(
            "SELECT * FROM $table_name ORDER BY created_at DESC",
            ARRAY_A
        );
        
        if ($customers) {
            wp_send_json_success(array('customers' => $customers));
        } else {
            wp_send_json_success(array('customers' => array()));
        }
    }
    
    /**
     * WooCommerce missing notice
     */
    public function woocommerce_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('Loyalty Card Pro requires WooCommerce to be installed and active.', 'loyalty-card-pro'); ?></p>
        </div>
        <?php
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function admin_enqueue_scripts($hook) {
        wp_enqueue_style('lcp-admin-style', LCP_PLUGIN_URL . 'assets/css/admin-style.css', array(), LCP_VERSION);
        wp_enqueue_script('lcp-admin-script', LCP_PLUGIN_URL . 'assets/js/admin-script.js', array('jquery'), LCP_VERSION, true);
        
        // Localize script
        wp_localize_script('lcp-admin-script', 'lcpAdmin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('lcp_admin_nonce'),
            'colors' => array(
                'primary' => LCP_COLOR_PRIMARY,
                'secondary' => LCP_COLOR_SECONDARY,
                'white' => LCP_COLOR_WHITE,
            ),
        ));
    }
    
    /**
     * Enqueue public scripts and styles
     */
    public function public_enqueue_scripts() {
        wp_enqueue_style('lcp-public-style', LCP_PLUGIN_URL . 'assets/css/public-style.css', array(), LCP_VERSION);
        wp_enqueue_script('lcp-public-script', LCP_PLUGIN_URL . 'assets/js/public-script.js', array('jquery'), LCP_VERSION, true);
        
        // Localize script
        wp_localize_script('lcp-public-script', 'lcpPublic', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('lcp_public_nonce'),
            'colors' => array(
                'primary' => LCP_COLOR_PRIMARY,
                'secondary' => LCP_COLOR_SECONDARY,
                'white' => LCP_COLOR_WHITE,
            ),
        ));
    }
}

/**
 * Initialize the plugin
 */
function lcp_init() {
    return Loyalty_Card_Pro::get_instance();
}

// Start the plugin
lcp_init();
