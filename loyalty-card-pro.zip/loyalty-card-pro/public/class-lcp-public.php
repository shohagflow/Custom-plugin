<?php
/**
 * Public facing functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Public {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Add shortcodes
        add_shortcode('lcp_client_portal', array($this, 'render_client_portal'));
        add_shortcode('lcp_scratch_ticket', array($this, 'render_scratch_ticket'));
    }
    
    /**
     * Render client portal shortcode
     */
    public function render_client_portal($atts) {
        if (!is_user_logged_in()) {
            return '<p>' . __('Please log in to view your loyalty information.', 'loyalty-card-pro') . '</p>';
        }
        
        ob_start();
        ?>
        <div class="lcp-client-portal">
            <h2><?php _e('My Loyalty Information', 'loyalty-card-pro'); ?></h2>
            <p><?php _e('Your loyalty cards and rewards will appear here.', 'loyalty-card-pro'); ?></p>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render scratch ticket shortcode
     */
    public function render_scratch_ticket($atts) {
        $atts = shortcode_atts(array(
            'ticket_id' => 0,
        ), $atts);
        
        if (!$atts['ticket_id']) {
            return '';
        }
        
        $ticket = LCP_Ticket::get_ticket($atts['ticket_id']);
        
        if (!$ticket || $ticket->status !== 'assigned') {
            return '';
        }
        
        ob_start();
        ?>
        <div class="lcp-scratch-ticket" data-ticket-id="<?php echo $ticket->id; ?>">
            <div class="lcp-scratch-canvas">
                <canvas id="lcp-scratch-<?php echo $ticket->id; ?>"></canvas>
            </div>
            <div class="lcp-scratch-reward" style="display: none;">
                <h3><?php _e('Congratulations!', 'loyalty-card-pro'); ?></h3>
                <p class="lcp-reward-description"></p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
