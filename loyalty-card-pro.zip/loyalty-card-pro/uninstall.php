<?php
/**
 * Uninstall script for Loyalty Card Pro
 * 
 * This file runs when the plugin is uninstalled via WordPress admin
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Remove plugin options
delete_option('lcp_db_version');

// Optionally remove database tables (uncomment if you want to remove all data on uninstall)
// WARNING: This will delete ALL plugin data permanently!

/*
global $wpdb;

$tables = array(
    $wpdb->prefix . 'lcp_clients',
    $wpdb->prefix . 'lcp_loyalty_cards',
    $wpdb->prefix . 'lcp_visits',
    $wpdb->prefix . 'lcp_tickets',
    $wpdb->prefix . 'lcp_subscriptions',
    $wpdb->prefix . 'lcp_pricing_plans',
    $wpdb->prefix . 'lcp_payments',
);

foreach ($tables as $table) {
    $wpdb->query("DROP TABLE IF EXISTS $table");
}
*/

// Remove custom roles and capabilities
require_once plugin_dir_path(__FILE__) . 'includes/class-lcp-roles.php';
LCP_Roles::remove_roles();

// Clear any cached data
wp_cache_flush();
