# Loyalty Card Pro

A comprehensive WordPress plugin for beauticians to manage clients, digital loyalty cards, and scratch-off surprise tickets with an engaging, mobile-friendly interface.

## Features

### Super Admin Dashboard
- **User Management**: Add, edit, and delete beauticians with complete control
- **Pricing Control**: Create and manage subscription plans (tickets, client expansions, bundles)
- **Payment Tracking**: View all transactions and revenue with filtering options
- **Analytics**: Daily, weekly, and monthly reports with detailed statistics
- **Filter Options**: View data by daily, weekly, or monthly periods

### Beautician Dashboard
- **Client Management**: 
  - Add new clients manually with instant search
  - Manage up to 20 clients (expandable via purchases)
  - View client visit history and loyalty status
  - Quick client search functionality
  
- **Digital Loyalty Card System**:
  - Create custom loyalty cards for each client
  - Set visit limits (5, 10, 15, 20 visits)
  - Define custom rewards
  - Automatic progress tracking
  - Reset completed cards for new cycles
  
- **Scratch-Off Surprise Tickets**:
  - Purchase ticket bundles (50 tickets for $10)
  - Assign random tickets to clients with one click
  - Interactive scratch-off reveal (mobile-friendly)
  - Random reward generation (discounts, free services, vouchers)
  - Spin-wheel reveal option

### WooCommerce Integration
- Seamlessly integrates with WooCommerce My Account page
- Custom "Beautician Dashboard" navigation below "Control Panel"
- Full dashboard functionality on frontend
- Mobile-optimized for in-salon use on tablets and phones

## Brand Colors
- Primary: #FE7AC1 (Pink)
- Secondary: #FFEFF7 (Light Pink)
- Background: #FFFFFF (White)

## Installation

1. Upload the `loyalty-card-pro` folder to `/wp-content/plugins/`
2. Activate the plugin through the WordPress 'Plugins' menu
3. Ensure WooCommerce is installed and active
4. Navigate to "Loyalty Card Pro" in the admin menu

## Usage

### For Super Admins

1. **Add Beauticians**:
   - Go to Loyalty Card Pro > User Management
   - Fill in beautician details (name, email, username, password)
   - Click "Add Beautician"

2. **Manage Pricing**:
   - Go to Loyalty Card Pro > Pricing Control
   - Create custom plans with ticket counts and client limits
   - Set pricing for each plan
   - Activate/deactivate plans as needed

3. **View Payments**:
   - Go to Loyalty Card Pro > Payments
   - View all transactions with status tracking
   - Filter by date, payment method, or status

### For Beauticians

1. **Add Clients**:
   - Click "Add Client" button
   - Enter client information
   - Optionally create a loyalty card immediately
   - Set visit limit and reward description

2. **Manage Loyalty Cards**:
   - Go to Loyalty Cards section
   - View all active and completed cards
   - Track progress for each client
   - Reset completed cards for new rewards

3. **Use Scratch Tickets**:
   - Go to Scratch Tickets section
   - Select a client from the grid
   - Click "Assign Ticket"
   - Client receives a random surprise reward
   - Reveal with scratch-off or spin-wheel effect

4. **Purchase More**:
   - Go to Purchase Plans
   - Select a plan (tickets, client expansion, or bundle)
   - Complete purchase to expand capacity

### Frontend Usage (My Account)

1. Log in to your WordPress account
2. Go to My Account > Beautician Dashboard
3. Access all features directly from the frontend
4. Mobile-friendly interface for in-salon use
5. Quick client search and management
6. Add visits and assign tickets on the go

## Pricing Plans

### Default Plans (Customizable)

1. **Scratch Ticket Bundle**: 50 tickets for $10
2. **Client Expansion**: +20 client slots for $15
3. **Starter Package**: 50 tickets + 20 clients for $20

## Technical Details

### Database Tables
- `wp_lcp_clients`: Client information
- `wp_lcp_loyalty_cards`: Loyalty card tracking
- `wp_lcp_visits`: Visit history
- `wp_lcp_tickets`: Scratch-off tickets
- `wp_lcp_subscriptions`: User subscriptions
- `wp_lcp_pricing_plans`: Available plans
- `wp_lcp_payments`: Payment transactions

### User Roles
- **Super Admin**: Full access to all features
- **Beautician**: Access to client management, loyalty cards, and tickets

### AJAX Endpoints
- `lcp_add_beautician`: Add new beautician
- `lcp_add_client`: Add new client
- `lcp_search_clients`: Search clients
- `lcp_add_visit`: Record client visit
- `lcp_assign_ticket`: Assign surprise ticket
- `lcp_reveal_ticket`: Reveal ticket reward
- `lcp_reset_loyalty_card`: Reset completed card
- `lcp_purchase_plan`: Purchase subscription plan
- `lcp_get_client_history`: Get client history

## Requirements

- WordPress 5.8 or higher
- PHP 7.4 or higher
- WooCommerce 5.0 or higher
- MySQL 5.6 or higher

## File Structure

```
loyalty-card-pro/
├── admin/
│   ├── class-lcp-admin.php
│   ├── class-lcp-super-admin.php
│   └── class-lcp-beautician-dashboard.php
├── includes/
│   ├── class-lcp-database.php
│   ├── class-lcp-roles.php
│   ├── class-lcp-client.php
│   ├── class-lcp-loyalty-card.php
│   ├── class-lcp-ticket.php
│   ├── class-lcp-subscription.php
│   └── class-lcp-ajax.php
├── public/
│   ├── class-lcp-public.php
│   └── class-lcp-my-account.php
├── assets/
│   ├── css/
│   │   ├── admin-style.css
│   │   └── public-style.css
│   └── js/
│       ├── admin-script.js
│       └── public-script.js
├── loyalty-card-pro.php
└── README.md
```

## Customization

### Change Brand Colors
Edit the CSS variables in `assets/css/admin-style.css` and `assets/css/public-style.css`:

```css
:root {
    --lcp-primary: #FE7AC1;
    --lcp-secondary: #FFEFF7;
    --lcp-white: #FFFFFF;
}
```

### Modify Default Plans
Edit `includes/class-lcp-database.php` in the `insert_default_pricing_plans()` method.

### Add Custom Rewards
Edit `includes/class-lcp-ticket.php` in the `get_random_rewards()` method.

## Support

For support, feature requests, or bug reports, please contact the development team.

## License

GPL v2 or later

## Changelog

### Version 1.0.0
- Initial release
- Super admin dashboard with user management
- Beautician dashboard with client management
- Digital loyalty card system
- Scratch-off surprise tickets
- WooCommerce My Account integration
- Mobile-responsive design with brand colors
- AJAX-powered interactions
- Payment tracking and analytics

## Credits

Developed for beautician businesses to enhance client engagement and streamline loyalty management.
