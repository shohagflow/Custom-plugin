# Changelog

All notable changes to Dynamic Search GMap Pro will be documented in this file.

## [1.0.0] - 2024

### Added
- Initial plugin release
- Interactive Google Maps integration with custom styling
- Specialist directory management system
- Location search with Google Places autocomplete (restricted to Spain)
- Proximity-based search with Haversine formula
- Results ordered by distance (nearest to farthest across all of Spain)
- Specialist CRUD operations (Create, Read, Update, Delete)
- Specialty management system
- User authentication system (login/registration)
- Specialist profile pages
- Avatar support with fallback placeholders
- Rating system support
- Modern admin interface with card-based design
- Custom modal dialogs for delete/confirm actions
- Copy-to-clipboard functionality for shortcodes
- Statistics cards showing totals and counts
- Status badges for active/inactive items
- WordPress user sync functionality
- Automatic sync on user registration and profile updates
- Custom user role: "specialist"
- Shortcode system: [dsgmp_map], [dsgmp_auth], [dsgmp_profile]
- Responsive design for mobile, tablet, and desktop
- Admin panel with modern styling
- Settings page with Google Maps API configuration
- Search functionality with specialty and location filters
- Map markers with info windows
- Contact buttons (call, chat) in info windows
- Google Places autocomplete for addresses
- Address geocoding (address to coordinates conversion)
- Distance calculation and display
- Empty state messages
- Loading states and animations
- Smooth animations for modals and interactions
- Custom CSS with plugin brand colors (#FF6B36)
- AJAX-powered search for instant results
- Database tables with proper indexes
- Security features: nonce verification, sanitization, prepared statements
- Error handling and user feedback messages
- Filter hooks for customization
- Developer-friendly code structure

### Technical Details
- WordPress 5.0+ compatibility
- PHP 7.2+ required
- Uses Google Maps JavaScript API v3
- Google Places API integration
- Google Geocoding API integration
- Secure database operations
- Optimized SQL queries with proper indexes
- Responsive CSS with modern design patterns
- JavaScript with jQuery dependency
- Proper WordPress coding standards
- Translation-ready (text domain: dynamic-search-gmap-pro)
