<?php
/**
 * Uninstall script for Dynamic Search GMap Pro
 * 
 * This file is executed when the plugin is deleted from WordPress
 */

// Exit if accessed directly
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

// Delete database table
$table_name = $wpdb->prefix . 'dsgmp_specialists';
$wpdb->query("DROP TABLE IF EXISTS $table_name");

// Delete plugin options
delete_option('dsgmp_options');

// Delete any transients
delete_transient('dsgmp_*');

// Clear any cached data
wp_cache_flush();
