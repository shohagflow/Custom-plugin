/**
 * Specialist Authentication JavaScript
 */

(function($) {
    'use strict';
    
    // Function to ensure CSS is loaded (for popups)
    function ensureAuthCSS() {
        if (!$('#dsgmp-auth-style-inline').length && !$('link[href*="auth.css"]').length) {
            // CSS not loaded, inject it
            var cssUrl = dsgmpAuth.css_url || dsgmpAuth.plugin_url + 'assets/css/auth.css?v=' + dsgmpAuth.version;
            $('<link>')
                .attr('rel', 'stylesheet')
                .attr('type', 'text/css')
                .attr('href', cssUrl)
                .attr('id', 'dsgmp-auth-style-inline')
                .appendTo('head');
        }
    }
    
    // Check and inject CSS if needed (useful for popups)
    if (typeof dsgmpAuth !== 'undefined' && dsgmpAuth.css_url) {
        ensureAuthCSS();
    }
    
    $(document).ready(function() {
        // Ensure CSS is loaded on ready (for dynamically loaded content)
        ensureAuthCSS();
        
        // Tab switching
        $('.dsgmp-auth-tab').on('click', function() {
            var tab = $(this).data('tab');
            
            // Update tabs
            $('.dsgmp-auth-tab').removeClass('active');
            $(this).addClass('active');
            
            // Update panels
            $('.dsgmp-auth-panel').removeClass('active');
            $('#dsgmp-' + tab + '-panel').addClass('active');
            
            // Clear messages
            $('.dsgmp-form-message').removeClass('show success error').html('');
        });
        
        // Login Form
        $('#dsgmp-login-form').on('submit', function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $btn = $form.find('button[type="submit"]');
            var $message = $('#dsgmp-login-message');
            var originalText = $btn.html();
            
            // Clear previous messages
            $message.removeClass('show success error').html('');
            
            // Disable button
            $btn.prop('disabled', true).addClass('loading');
            
            $.ajax({
                url: dsgmpAuth.ajaxurl,
                type: 'POST',
                data: {
                    action: 'dsgmp_login',
                    nonce: dsgmpAuth.nonce,
                    username: $('#login_username').val(),
                    password: $('#login_password').val(),
                    rememberme: $form.find('input[name="rememberme"]').is(':checked') ? 'forever' : ''
                },
                success: function(response) {
                    $btn.prop('disabled', false).removeClass('loading').html(originalText);
                    
                    if (response.success) {
                        $message.addClass('show success').html(response.data.message);
                        
                        // Redirect after short delay
                        setTimeout(function() {
                            window.location.href = response.data.redirect_url || dsgmpAuth.redirect_url;
                        }, 1000);
                    } else {
                        $message.addClass('show error').html(response.data.message || 'Login failed. Please try again.');
                    }
                },
                error: function() {
                    $btn.prop('disabled', false).removeClass('loading').html(originalText);
                    $message.addClass('show error').html('Error connecting to server. Please try again.');
                }
            });
        });
        
        // Register Form
        $('#dsgmp-register-form').on('submit', function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $btn = $form.find('button[type="submit"]');
            var $message = $('#dsgmp-register-message');
            var originalText = $btn.html();
            
            // Validate password match
            var password = $('#register_password').val();
            var passwordConfirm = $('#register_password_confirm').val();
            
            if (password !== passwordConfirm) {
                $message.addClass('show error').html('Passwords do not match.');
                return;
            }
            
            // Clear previous messages
            $message.removeClass('show success error').html('');
            
            // Disable button
            $btn.prop('disabled', true).addClass('loading');
            
            // Get form data
            var formData = {
                action: 'dsgmp_register',
                nonce: dsgmpAuth.nonce,
                username: $('#register_username').val(),
                email: $('#register_email').val(),
                password: password,
                password_confirm: passwordConfirm,
                first_name: $('#register_first_name').val(),
                last_name: $('#register_last_name').val(),
                company: $('#register_company').val(),
                specialty: $('#register_specialty').val(),
                phone: $('#register_phone').val(),
                address: $('#register_address').val(),
                city: $('#register_city').val(),
                province: $('#register_province').val(),
                postal_code: $('#register_postal_code').val(),
                website: $('#register_website').val(),
                description: $('#register_description').val(),
                latitude: $('#register_latitude').val(),
                longitude: $('#register_longitude').val()
            };
            
            $.ajax({
                url: dsgmpAuth.ajaxurl,
                type: 'POST',
                data: formData,
                success: function(response) {
                    $btn.prop('disabled', false).removeClass('loading').html(originalText);
                    
                    if (response.success) {
                        $message.addClass('show success').html(response.data.message);
                        
                        // Redirect after short delay
                        setTimeout(function() {
                            window.location.href = response.data.redirect_url || dsgmpAuth.redirect_url;
                        }, 1500);
                    } else {
                        $message.addClass('show error').html(response.data.message || 'Registration failed. Please try again.');
                    }
                },
                error: function() {
                    $btn.prop('disabled', false).removeClass('loading').html(originalText);
                    $message.addClass('show error').html('Error connecting to server. Please try again.');
                }
            });
        });
        
        // Address Autocomplete (if Google Maps API is available)
        if (typeof google !== 'undefined' && google.maps && google.maps.places) {
            initAddressAutocomplete();
        } else {
            // Try to load Google Maps API if not already loaded
            var apiKey = '';
            if (typeof dsgmpData !== 'undefined' && dsgmpData.apiKey) {
                apiKey = dsgmpData.apiKey;
            } else if (typeof dsgmpAuth !== 'undefined' && dsgmpAuth.apiKey) {
                apiKey = dsgmpAuth.apiKey;
            }
            
            if (apiKey) {
                var script = document.createElement('script');
                script.src = 'https://maps.googleapis.com/maps/api/js?key=' + apiKey + '&libraries=places&callback=initDsgmpAuthAutocomplete';
                script.async = true;
                script.defer = true;
                window.initDsgmpAuthAutocomplete = function() {
                    initAddressAutocomplete();
                };
                document.head.appendChild(script);
            }
        }
        
        function initAddressAutocomplete() {
            if (typeof google === 'undefined' || !google.maps || !google.maps.places) {
                return;
            }
            
            var addressInput = document.getElementById('register_address');
            if (!addressInput) {
                return;
            }
            
            var autocomplete = new google.maps.places.Autocomplete(addressInput, {
                componentRestrictions: { country: 'es' }, // Restrict to Spain
                fields: ['formatted_address', 'geometry', 'address_components']
            });
            
            autocomplete.addListener('place_changed', function() {
                var place = autocomplete.getPlace();
                
                if (!place.geometry) {
                    return;
                }
                
                var address = '';
                var city = '';
                var province = '';
                var postal_code = '';
                
                // Extract address components
                for (var i = 0; i < place.address_components.length; i++) {
                    var component = place.address_components[i];
                    var types = component.types;
                    
                    if (types.indexOf('street_number') !== -1) {
                        address = component.long_name + ' ';
                    }
                    if (types.indexOf('route') !== -1) {
                        address += component.long_name;
                    }
                    if (types.indexOf('locality') !== -1) {
                        city = component.long_name;
                    }
                    if (types.indexOf('administrative_area_level_2') !== -1) {
                        province = component.long_name;
                    }
                    if (types.indexOf('postal_code') !== -1) {
                        postal_code = component.long_name;
                    }
                }
                
                // Update form fields
                if (address) {
                    $('#register_address').val(address || place.formatted_address);
                }
                if (city) {
                    $('#register_city').val(city);
                }
                if (province) {
                    $('#register_province').val(province);
                }
                if (postal_code) {
                    $('#register_postal_code').val(postal_code);
                }
                
                // Set coordinates
                $('#register_latitude').val(place.geometry.location.lat());
                $('#register_longitude').val(place.geometry.location.lng());
            });
        }
    });
    
})(jQuery);
