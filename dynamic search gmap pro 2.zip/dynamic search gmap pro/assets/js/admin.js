/**
 * Admin JavaScript for Dynamic Search GMap Pro
 */

(function($) {
    'use strict';
    
    // Custom Modal Dialog
    var DSGMPModal = {
        init: function() {
            // Create modal HTML if it doesn't exist
            if ($('#dsgmp-modal').length === 0) {
                $('body').append(this.getModalHTML());
            }
            
            // Bind events
            this.bindEvents();
        },
        
        getModalHTML: function() {
            return '<div id="dsgmp-modal" class="dsgmp-modal-overlay">' +
                '<div class="dsgmp-modal">' +
                    '<div class="dsgmp-modal-header">' +
                        '<h3 class="dsgmp-modal-title"></h3>' +
                        '<button type="button" class="dsgmp-modal-close" aria-label="Close">' +
                            '<span class="dashicons dashicons-no-alt"></span>' +
                        '</button>' +
                    '</div>' +
                    '<div class="dsgmp-modal-body">' +
                        '<p class="dsgmp-modal-message"></p>' +
                    '</div>' +
                    '<div class="dsgmp-modal-footer">' +
                        '<button type="button" class="dsgmp-modal-cancel button button-secondary">' +
                            '<span class="dashicons dashicons-dismiss"></span> ' +
                            'Cancel' +
                        '</button>' +
                        '<button type="button" class="dsgmp-modal-confirm button button-primary">' +
                            '<span class="dashicons dashicons-yes-alt"></span> ' +
                            'Confirm' +
                        '</button>' +
                    '</div>' +
                '</div>' +
            '</div>';
        },
        
        bindEvents: function() {
            var self = this;
            
            // Close modal on overlay click
            $(document).on('click', '.dsgmp-modal-overlay', function(e) {
                if ($(e.target).hasClass('dsgmp-modal-overlay')) {
                    self.close();
                }
            });
            
            // Close modal on close button
            $(document).on('click', '.dsgmp-modal-close, .dsgmp-modal-cancel', function() {
                self.close();
            });
            
            // Handle delete confirmations
            $(document).on('click', '.dsgmp-btn-delete, a[href*="action=delete"]', function(e) {
                var $link = $(this);
                var href = $link.attr('href');
                
                // Check if it's a delete link
                if (href && href.indexOf('action=delete') !== -1) {
                    e.preventDefault();
                    var itemName = $link.data('delete-name') || 'this item';
                    self.show({
                        type: 'delete',
                        title: 'Confirm Delete',
                        message: 'Are you sure you want to delete "' + itemName + '"? This action cannot be undone.',
                        confirmText: 'Delete',
                        onConfirm: function() {
                            window.location.href = href;
                        }
                    });
                }
            });
            
            // Handle edit confirmations (optional - can be customized)
            $(document).on('click', '.dsgmp-btn-edit', function(e) {
                // You can add custom logic here if needed
                // For now, edit links work normally
            });
        },
        
        show: function(options) {
            var defaults = {
                type: 'confirm',
                title: 'Confirm Action',
                message: 'Are you sure?',
                confirmText: 'Confirm',
                cancelText: 'Cancel',
                onConfirm: function() {},
                onCancel: function() {}
            };
            
            var settings = $.extend({}, defaults, options);
            var $modal = $('#dsgmp-modal');
            
            // Set content
            $modal.find('.dsgmp-modal-title').text(settings.title);
            $modal.find('.dsgmp-modal-message').text(settings.message);
            $modal.find('.dsgmp-modal-confirm').text(settings.confirmText);
            $modal.find('.dsgmp-modal-cancel').text(settings.cancelText);
            
            // Style based on type
            if (settings.type === 'delete') {
                $modal.find('.dsgmp-modal').addClass('dsgmp-modal-delete');
                $modal.find('.dsgmp-modal-confirm').addClass('dsgmp-btn-delete-modal');
            } else {
                $modal.find('.dsgmp-modal').removeClass('dsgmp-modal-delete');
                $modal.find('.dsgmp-modal-confirm').removeClass('dsgmp-btn-delete-modal');
            }
            
            // Store callbacks
            $modal.data('onConfirm', settings.onConfirm);
            $modal.data('onCancel', settings.onCancel);
            
            // Show modal with animation
            $modal.addClass('dsgmp-modal-show');
            $('body').addClass('dsgmp-modal-open');
            
            // Focus on cancel button for accessibility
            setTimeout(function() {
                $modal.find('.dsgmp-modal-cancel').focus();
            }, 100);
        },
        
        close: function() {
            var $modal = $('#dsgmp-modal');
            var onCancel = $modal.data('onCancel');
            
            $modal.removeClass('dsgmp-modal-show');
            $('body').removeClass('dsgmp-modal-open');
            
            if (typeof onCancel === 'function') {
                onCancel();
            }
        },
        
        confirm: function() {
            var $modal = $('#dsgmp-modal');
            var onConfirm = $modal.data('onConfirm');
            
            this.close();
            
            if (typeof onConfirm === 'function') {
                onConfirm();
            }
        }
    };
    
    // Initialize on document ready
    $(document).ready(function() {
        DSGMPModal.init();
        
        // Handle confirm button click
        $(document).on('click', '.dsgmp-modal-confirm', function() {
            DSGMPModal.confirm();
        });
        
        // Close on ESC key
        $(document).on('keydown', function(e) {
            if (e.keyCode === 27 && $('#dsgmp-modal').hasClass('dsgmp-modal-show')) {
                DSGMPModal.close();
            }
        });
    });
    
    // Expose modal globally for custom usage
    window.DSGMPModal = DSGMPModal;
    
})(jQuery);
