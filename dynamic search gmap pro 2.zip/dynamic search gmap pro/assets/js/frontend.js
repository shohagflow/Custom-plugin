(function($) {
    'use strict';
    
    var DSGMP = {
        map: null,
        markers: [],
        infoWindow: null,
        autocomplete: null,
        currentLocation: null,
        currentSpecialists: [],
        
        init: function() {
            if ($('#dsgmp-map').length === 0) {
                return;
            }
            
            this.initMap();
            this.initAutocomplete();
            this.initEvents();
            
            // Load all specialists on page load
            this.loadAllSpecialists();
        },
        
        initMap: function() {
            var defaultLat = dsgmpData.defaultLat || 40.4168;
            var defaultLng = dsgmpData.defaultLng || -3.7038;
            var defaultZoom = dsgmpData.defaultZoom || 6;
            
            this.map = new google.maps.Map(document.getElementById('dsgmp-map'), {
                center: { lat: defaultLat, lng: defaultLng },
                zoom: defaultZoom,
                mapTypeControl: true,
                streetViewControl: true,
                fullscreenControl: true,
                styles: [
                    {
                        featureType: 'poi',
                        elementType: 'labels',
                        stylers: [{ visibility: 'on' }]
                    }
                ]
            });
            
            this.infoWindow = new google.maps.InfoWindow();
            
            // Listen to map bounds changes for dynamic loading
            google.maps.event.addListener(this.map, 'bounds_changed', function() {
                // Could implement lazy loading here if needed
            });
        },
        
        initAutocomplete: function() {
            var input = document.getElementById('dsgmp-location-search');
            if (!input) return;
            
            var options = {
                componentRestrictions: { country: 'es' },
                types: ['geocode', 'establishment']
            };
            
            this.autocomplete = new google.maps.places.Autocomplete(input, options);
            
            this.autocomplete.addListener('place_changed', function() {
                var place = DSGMP.autocomplete.getPlace();
                
                if (!place.geometry) {
                    console.warn('No details available for input: ' + place.name);
                    return;
                }
                
                DSGMP.currentLocation = {
                    lat: place.geometry.location.lat(),
                    lng: place.geometry.location.lng(),
                    address: place.formatted_address
                };
                
                // Center map on selected location
                DSGMP.map.setCenter(DSGMP.currentLocation);
                DSGMP.map.setZoom(12);
                
                // Trigger search if specialty is entered
                var specialty = $('#dsgmp-specialty-search').val();
                if (specialty) {
                    DSGMP.searchSpecialists();
                }
            });
        },
        
        initEvents: function() {
            var self = this;
            
            // Search button
            $('#dsgmp-search-btn').on('click', function() {
                self.searchSpecialists();
            });
            
            // Enter key on location input
            $('#dsgmp-location-search').on('keypress', function(e) {
                if (e.which === 13) {
                    e.preventDefault();
                    self.searchSpecialists();
                }
            });
            
            // Specialty dropdown change (auto-search if location is set, otherwise show all)
            $('#dsgmp-specialty-search').on('change', function() {
                var $select = $(this);
                // Add/remove class for styling when value is selected
                if ($select.val()) {
                    $select.addClass('has-value');
                } else {
                    $select.removeClass('has-value');
                }
                
                // If location is set, search by proximity, otherwise show all
                if (self.currentLocation) {
                    self.searchSpecialists();
                } else {
                    self.loadAllSpecialists();
                }
            });
            
            // Check initial value on load
            if ($('#dsgmp-specialty-search').val()) {
                $('#dsgmp-specialty-search').addClass('has-value');
            }
        },
        
        loadAllSpecialists: function() {
            var self = this;
            var specialty = $('#dsgmp-specialty-search').val();
            
            $.ajax({
                url: dsgmpData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'dsgmp_get_all',
                    nonce: dsgmpData.nonce,
                    specialty: specialty
                },
                success: function(response) {
                    if (response.success && response.data.specialists.length > 0) {
                        self.currentSpecialists = response.data.specialists;
                        self.displayResults(response.data.specialists);
                        self.addMarkers(response.data.specialists);
                        self.fitMapToMarkers();
                    }
                },
                error: function() {
                    // Silently fail on initial load
                }
            });
        },
        
        searchSpecialists: function() {
            var self = this;
            
            // If no location is set, show all specialists
            if (!this.currentLocation) {
                this.loadAllSpecialists();
                return;
            }
            
            var specialty = $('#dsgmp-specialty-search').val();
            
            // Show loading state
            var $btn = $('#dsgmp-search-btn');
            var originalText = $btn.html();
            $btn.prop('disabled', true).html('<span class="dsgmp-search-icon"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path></svg></span> Buscando...');
            
            // Clear existing markers
            this.clearMarkers();
            
            $.ajax({
                url: dsgmpData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'dsgmp_search',
                    nonce: dsgmpData.nonce,
                    lat: this.currentLocation.lat,
                    lng: this.currentLocation.lng,
                    specialty: specialty
                },
                success: function(response) {
                    $btn.prop('disabled', false).html(originalText);
                    
                    if (response.success) {
                        // Results are already ordered by distance (nearest to farthest)
                        // Keep the order as returned from the server
                        self.currentSpecialists = response.data.specialists;
                        self.displayResults(response.data.specialists);
                        
                        // Add markers in the same order (nearest to farthest)
                        // This ensures map pins match the list order
                        self.addMarkers(response.data.specialists);
                        
                        // Fit map to show all markers, but center on search location
                        if (response.data.specialists.length > 0) {
                            self.fitMapToMarkers();
                        }
                    } else {
                        alert(response.data.message || 'Error al buscar especialistas.');
                    }
                },
                error: function() {
                    $btn.prop('disabled', false).html(originalText);
                    alert('Error al conectar con el servidor.');
                }
            });
        },
        
        addMarkers: function(specialists) {
            var self = this;
            
            specialists.forEach(function(specialist) {
                var marker = new google.maps.Marker({
                    position: {
                        lat: specialist.latitude,
                        lng: specialist.longitude
                    },
                    map: self.map,
                    title: specialist.name + ' - ' + specialist.specialty,
                    icon: {
                        url: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png',
                        scaledSize: new google.maps.Size(32, 32)
                    }
                });
                
                // Create info window content
                var infoContent = self.createInfoWindowContent(specialist);
                
                marker.addListener('click', function() {
                    self.infoWindow.setContent(infoContent);
                    self.infoWindow.open(self.map, marker);
                });
                
                self.markers.push(marker);
            });
        },
        
        createInfoWindowContent: function(specialist) {
            var template = $('#dsgmp-info-window-template').html();
            var content = $(template);
            
            // Avatar - always show wrapper, show avatar image or placeholder
            var $avatarWrapper = content.find('.dsgmp-info-avatar-wrapper');
            var $avatarImg = content.find('.dsgmp-info-avatar');
            var $avatarPlaceholder = content.find('.dsgmp-info-avatar-placeholder');
            
            if (specialist.avatar && specialist.avatar !== '') {
                $avatarImg.attr('src', specialist.avatar).attr('alt', specialist.name || 'Avatar').show();
                $avatarPlaceholder.hide();
            } else {
                $avatarImg.hide();
                $avatarPlaceholder.show();
            }
            $avatarWrapper.show(); // Always show the avatar wrapper
            
            content.find('.dsgmp-info-name').text(specialist.name || '');
            content.find('.dsgmp-info-company').text(specialist.company || '').toggle(specialist.company !== '');
            content.find('.dsgmp-info-specialty').html('<strong>Specialty:</strong> ' + (specialist.specialty || ''));
            content.find('.dsgmp-info-location').html('<strong>Location:</strong> ' + 
                [specialist.address, specialist.city, specialist.province].filter(Boolean).join(', '));
            
            // Rating
            var ratingHtml = '';
            if (specialist.rating > 0) {
                var starIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:middle;margin-left:3px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>';
                ratingHtml = '<strong>Rating:</strong> ' + specialist.rating.toFixed(1) + starIcon;
                if (specialist.rating_count > 0) {
                    ratingHtml += ' (' + specialist.rating_count + ' reviews)';
                }
            }
            content.find('.dsgmp-info-rating').html(ratingHtml).toggle(ratingHtml !== '');
            
            // Distance
            if (specialist.distance) {
                content.find('.dsgmp-info-distance').html('<strong>Distance:</strong> ' + specialist.distance.toFixed(2) + ' km');
            }
            
            // Call button - hide if no phone
            if (!specialist.phone || specialist.phone === '') {
                content.find('.dsgmp-btn-call').hide();
            } else {
                content.find('.dsgmp-btn-call').on('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    window.location.href = 'tel:' + specialist.phone.replace(/\s+/g, '');
                });
            }
            
            // Chat button - hide if no email or website
            if ((!specialist.email || specialist.email === '') && (!specialist.website || specialist.website === '')) {
                content.find('.dsgmp-btn-chat').hide();
            } else {
                content.find('.dsgmp-btn-chat').on('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (specialist.email) {
                        // Open email client or you can customize this to open a chat widget
                        window.location.href = 'mailto:' + specialist.email + '?subject=Consulta sobre ' + encodeURIComponent(specialist.specialty || 'servicio');
                    } else if (specialist.website) {
                        // If no email, open website
                        window.open(specialist.website, '_blank');
                    }
                });
            }
            
            // Hide actions row if both buttons are hidden
            if ((!specialist.phone || specialist.phone === '') && 
                ((!specialist.email || specialist.email === '') && (!specialist.website || specialist.website === ''))) {
                content.find('.dsgmp-info-actions-row').hide();
            }
            
            // View profile button
            content.find('.dsgmp-btn-view-profile').on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                // You can customize this to link to a profile page
                if (specialist.website) {
                    window.open(specialist.website, '_blank');
                } else {
                    // Optionally create a profile page URL
                    // window.location.href = '/specialist/' + specialist.id;
                    alert('Perfil de: ' + specialist.name);
                }
            });
            
            return content[0];
        },
        
        displayResults: function(specialists) {
            var $list = $('#dsgmp-results-list');
            $list.empty();
            
            if (specialists.length === 0) {
                $list.html(
                    '<div class="dsgmp-no-results">' +
                        '<p>No hay especialistas disponibles en este momento.</p>' +
                        '<a href="#" class="dsgmp-view-more">Ver más especialistas →</a>' +
                    '</div>'
                );
                return;
            }
            
            specialists.forEach(function(specialist) {
                var $item = $('<div class="dsgmp-result-item">');
                
                var ratingHtml = '';
                if (specialist.rating > 0) {
                    var starIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:middle;margin-left:3px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>';
                    ratingHtml = '<span class="dsgmp-rating">' + specialist.rating.toFixed(1) + starIcon + '</span>';
                }
                
                var distanceHtml = specialist.distance ? 
                    '<span class="dsgmp-distance">' + specialist.distance.toFixed(2) + ' km</span>' : '';
                
                var locationIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:middle;margin-right:6px;"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>';
                
                var phoneIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:middle;margin-right:6px;"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>';
                
                // Avatar HTML
                var avatarHtml = '';
                if (specialist.avatar && specialist.avatar !== '') {
                    avatarHtml = '<div class="dsgmp-result-avatar"><img src="' + specialist.avatar + '" alt="' + (specialist.name || 'Avatar') + '" /></div>';
                } else {
                    avatarHtml = '<div class="dsgmp-result-avatar dsgmp-result-avatar-placeholder"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></div>';
                }
                
                $item.html(
                    '<div class="dsgmp-result-item-inner">' +
                        avatarHtml +
                        '<div class="dsgmp-result-content">' +
                            '<div class="dsgmp-result-header">' +
                                '<h4>' + (specialist.name || '') + '</h4>' +
                                '<div class="dsgmp-result-meta">' + ratingHtml + distanceHtml + '</div>' +
                            '</div>' +
                            (specialist.company ? '<p class="dsgmp-result-company">' + specialist.company + '</p>' : '') +
                            '<p class="dsgmp-result-specialty"><strong>Especialidad:</strong> ' + (specialist.specialty || '') + '</p>' +
                            '<p class="dsgmp-result-location">' + locationIcon + 
                                [specialist.address, specialist.city, specialist.province].filter(Boolean).join(', ') +
                            '</p>' +
                            (specialist.phone ? '<p class="dsgmp-result-phone">' + phoneIcon + specialist.phone + '</p>' : '') +
                            '<button class="dsgmp-btn-view-on-map" data-lat="' + specialist.latitude + '" data-lng="' + specialist.longitude + '">Ver en el mapa</button>' +
                        '</div>' +
                    '</div>'
                );
                
                // Center map on marker when clicking "View on Map"
                $item.find('.dsgmp-btn-view-on-map').on('click', function(e) {
                    e.preventDefault();
                    DSGMP.map.setCenter({
                        lat: parseFloat($(this).data('lat')),
                        lng: parseFloat($(this).data('lng'))
                    });
                    DSGMP.map.setZoom(15);
                    
                    // Find and trigger marker click
                    DSGMP.markers.forEach(function(marker) {
                        if (Math.abs(marker.position.lat() - parseFloat($(this).data('lat'))) < 0.0001 && 
                            Math.abs(marker.position.lng() - parseFloat($(this).data('lng'))) < 0.0001) {
                            google.maps.event.trigger(marker, 'click');
                        }
                    }.bind(this));
                });
                
                $list.append($item);
            });
        },
        
        clearMarkers: function() {
            this.markers.forEach(function(marker) {
                marker.setMap(null);
            });
            this.markers = [];
            this.infoWindow.close();
        },
        
        fitMapToMarkers: function() {
            if (this.markers.length === 0) {
                return;
            }
            
            var bounds = new google.maps.LatLngBounds();
            
            // Include current location
            if (this.currentLocation) {
                bounds.extend(this.currentLocation);
            }
            
            // Include all markers
            this.markers.forEach(function(marker) {
                bounds.extend(marker.position);
            });
            
            this.map.fitBounds(bounds);
            
            // Ensure minimum zoom level
            google.maps.event.addListenerOnce(this.map, 'bounds_changed', function() {
                if (DSGMP.map.getZoom() > 15) {
                    DSGMP.map.setZoom(15);
                }
            });
        },
        
        resetMap: function() {
            this.clearMarkers();
            $('#dsgmp-location-search').val('');
            $('#dsgmp-specialty-search').val('').removeClass('has-value');
            
            // Reset to default "no results" message
            $('#dsgmp-results-list').html(
                '<div class="dsgmp-no-results">' +
                    '<p>No hay especialistas disponibles en este momento.</p>' +
                    '<a href="#" class="dsgmp-view-more">Ver más especialistas →</a>' +
                '</div>'
            );
            
            this.currentLocation = null;
            this.currentSpecialists = [];
            
            var defaultLat = dsgmpData.defaultLat || 40.4168;
            var defaultLng = dsgmpData.defaultLng || -3.7038;
            var defaultZoom = dsgmpData.defaultZoom || 6;
            
            this.map.setCenter({ lat: defaultLat, lng: defaultLng });
            this.map.setZoom(defaultZoom);
        }
    };
    
    $(document).ready(function() {
        // Wait for Google Maps to load
        if (typeof google !== 'undefined' && google.maps) {
            DSGMP.init();
        } else {
            // Retry after a short delay
            setTimeout(function() {
                if (typeof google !== 'undefined' && google.maps) {
                    DSGMP.init();
                }
            }, 500);
        }
    });
    
})(jQuery);
