# Dynamic Search GMap Pro

**Version:** 1.0.0  
**Author:** [Tafsin Ahmed](https://tafsinahmed.info)  
**License:** GPL v2 or later  
**Requires:** WordPress 5.0+  
**Tested up to:** WordPress 6.4+

## Description

Dynamic Search GMap Pro is an advanced WordPress plugin that provides a professional-grade map and location search functionality similar to major platforms like Idealista. It features an interactive Google Maps integration with intelligent search capabilities, proximity-based filtering, and a comprehensive specialist directory system.

### Key Features

- 🗺️ **Interactive Google Maps** - Fully responsive map with zoom, pan, and marker clustering
- 🔍 **Smart Location Search** - Autocomplete search restricted to Spain with street, city, and postal code support
- 📍 **Proximity-Based Results** - Results ordered by actual distance (nearest to farthest) across all of Spain
- 👥 **Specialist Directory** - Complete specialist management system with profiles, specialties, and ratings
- 🎯 **Advanced Search Filters** - Specialty-based filtering with instant results
- 💼 **Specialist Management** - Full CRUD operations for specialists and specialties
- 🔐 **User Authentication** - Login and registration system for specialists
- 👤 **Profile Pages** - Customizable specialist profile pages
- 🎨 **Modern Admin Interface** - Beautiful, modern admin panel with intuitive design
- 📱 **Mobile Responsive** - Works seamlessly on desktop, tablet, and mobile devices

## Installation

### Requirements

- WordPress 5.0 or higher
- PHP 7.2 or higher
- Google Maps API Key with the following APIs enabled:
  - Maps JavaScript API
  - Places API
  - Geocoding API

### Step-by-Step Installation

1. **Upload the Plugin**
   - Download the plugin ZIP file
   - Go to WordPress Admin → Plugins → Add New
   - Click "Upload Plugin" and select the ZIP file
   - Click "Install Now"

2. **Activate the Plugin**
   - After installation, click "Activate Plugin"

3. **Configure Google Maps API**
   - Go to **GMap Pro → Settings**
   - Enter your Google Maps API Key
   - Save the settings

4. **Get Google Maps API Key**
   - Visit [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project or select an existing one
   - Enable the required APIs:
     - Maps JavaScript API
     - Places API
     - Geocoding API
   - Create credentials (API Key)
   - Restrict the API key to your domain (recommended)

## Quick Start

### 1. Set Up Pages

Create three pages in WordPress:

- **Map Page** - Add shortcode: `[dsgmp_map]`
- **Login/Register Page** - Add shortcode: `[dsgmp_auth]`
- **Profile Page** - Add shortcode: `[dsgmp_profile]`

### 2. Add Specialists

- Go to **GMap Pro → Add Specialist**
- Fill in the specialist information
- Set location using the address autocomplete
- Save the specialist

### 3. Manage Specialties

- Go to **GMap Pro → Specialties**
- Add or edit specialties
- Activate/deactivate specialties as needed

### 4. View the Map

- Visit your map page
- Select a specialty from the dropdown
- Enter a location and click search
- View specialists ordered by proximity

## Shortcodes

### [dsgmp_map]

Displays the interactive map with specialist search functionality.

**Attributes:**
- `specialty` (optional) - Pre-select a specialty
- `height` (optional) - Map height in pixels (default: 600px)

**Examples:**
```
[dsgmp_map]
[dsgmp_map specialty="Electrician"]
[dsgmp_map height="800px"]
[dsgmp_map specialty="Plumber" height="600px"]
```

### [dsgmp_auth]

Displays login and registration forms for specialists.

**Attributes:**
- `default_tab` (optional) - Default tab to show: "login" or "register" (default: "login")

**Examples:**
```
[dsgmp_auth]
[dsgmp_auth default_tab="register"]
```

### [dsgmp_profile]

Displays the specialist profile page for logged-in specialists.

**Note:** This shortcode requires the user to be logged in with the "specialist" role.

**Example:**
```
[dsgmp_profile]
```

## Elementor Widgets

The plugin includes **three Elementor widgets** for easy drag-and-drop page building. These widgets provide visual controls for customization without coding.

### Requirements

- **Elementor** plugin must be installed and activated
- Elementor version 2.0.0 or higher recommended

### Available Widgets

#### 1. GMap Pro - Map Search

**Widget Name:** `dsgmp_map`

**Description:**  
Interactive map with specialist search functionality, fully customizable through Elementor's visual controls.

**Content Controls:**
- **Default Specialty** - Pre-select a specialty from dropdown
- **Map Height** - Set height in pixels or viewport height (400px - 1200px)

**Style Controls:**

**Container Style:**
- Background Color
- Border Radius (0-50px)
- Border (width, style, color)
- Box Shadow

**Search Bar Style:**
- Background Color
- Padding (top, right, bottom, left)
- Search Button Color (default: #FF6B36)
- Search Button Text Color (default: white)
- Button Typography (font, size, weight, line height)

**Results Panel Style:**
- Background Color
- Title Typography
- Title Color
- Text Color

**Usage:**
1. Open Elementor editor
2. Search for "GMap Pro" in widget panel
3. Drag "GMap Pro - Map Search" to your page
4. Configure settings in Content tab
5. Customize appearance in Style tab
6. Preview and publish

---

#### 2. GMap Pro - Login/Register

**Widget Name:** `dsgmp_auth`

**Description:**  
Login and registration forms for specialists with tabbed interface.

**Content Controls:**
- **Default Tab** - Choose "Login" or "Register" as default tab

**Style Controls:**

**Container Style:**
- Background Color
- Border Radius (0-50px)
- Border (width, style, color)
- Box Shadow

**Tabs Style:**
- Tab Background Color
- Active Tab Color (default: #FF6B36)
- Tab Typography (font, size, weight)

**Buttons Style:**
- Button Background (default: #FF6B36)
- Button Text Color (default: white)
- Button Typography
- Button Border Radius

**Form Fields Style:**
- Border Color
- Focus Border Color (default: #FF6B36)
- Field Typography

**Usage:**
1. Open Elementor editor
2. Search for "GMap Pro" in widget panel
3. Drag "GMap Pro - Login/Register" to your page
4. Set default tab in Content tab
5. Customize colors and fonts in Style tab
6. Preview and publish

---

#### 3. GMap Pro - Specialist Profile

**Widget Name:** `dsgmp_profile`

**Description:**  
Displays specialist profile page for logged-in users with the "specialist" role.

**Content Controls:**
- Info notice about login requirements

**Style Controls:**

**Container Style:**
- Background Color
- Border Radius (0-50px)
- Border (width, style, color)
- Box Shadow

**Header Style:**
- Header Background (default: #FF6B36 gradient)
- Header Text Color (default: white)
- Title Typography

**Content Style:**
- Content Typography
- Text Color
- Heading Color

**Buttons Style:**
- Button Background (default: #FF6B36)
- Button Text Color (default: white)
- Button Typography

**Usage:**
1. Open Elementor editor
2. Search for "GMap Pro" in widget panel
3. Drag "GMap Pro - Specialist Profile" to your page
4. Customize colors and fonts in Style tab
5. Preview and publish

**Note:** This widget requires users to be logged in with the "specialist" role.

---

### Elementor Widget Features

✅ **Visual Controls** - No coding required, customize everything visually  
✅ **Live Preview** - See changes instantly in Elementor editor  
✅ **Responsive** - All widgets are mobile-responsive  
✅ **Customizable Colors** - Full color control for all elements  
✅ **Typography Control** - Customize fonts, sizes, weights  
✅ **Spacing Control** - Adjust padding and margins  
✅ **Border & Shadow** - Add borders and shadows  
✅ **Per-Widget Styling** - Each widget instance can have unique styles  

### Finding Widgets in Elementor

1. Open any page/post in Elementor editor
2. Click the "+" icon to add a widget
3. Search for "GMap Pro" in the search box
4. You'll see three widgets:
   - GMap Pro - Map Search
   - GMap Pro - Login/Register
   - GMap Pro - Specialist Profile
5. Drag any widget to your page

### Customization Tips

- **Use Plugin Colors**: Default colors match the plugin brand (#FF6B36)
- **Consistent Styling**: Apply similar styles across widgets for brand consistency
- **Responsive Design**: Test on mobile devices using Elementor's responsive mode
- **Typography**: Use web-safe fonts or Elementor's font library
- **Color Harmony**: Use complementary colors for better visual appeal

### Troubleshooting Elementor Widgets

**Widgets Not Appearing:**
- Ensure Elementor plugin is installed and activated
- Check Elementor version (2.0.0+ recommended)
- Clear Elementor cache: Elementor → Tools → Regenerate CSS
- Deactivate and reactivate the GMap Pro plugin

**Styles Not Applying:**
- Regenerate Elementor CSS: Elementor → Tools → Regenerate CSS
- Clear browser cache
- Check for CSS conflicts with theme
- Ensure you're editing the correct widget instance

**Widget Preview Not Showing:**
- This is normal - widgets show preview in Elementor editor
- Actual content appears on frontend after publishing
- Preview mode shows placeholder content

**Color Changes Not Visible:**
- Use Elementor's responsive mode to check all devices
- Clear browser cache after making changes
- Ensure you're editing the correct style section

### Elementor Widget Examples

#### Example 1: Custom Colored Map Widget

1. Add "GMap Pro - Map Search" widget
2. Go to Style → Search Bar Style
3. Set Search Button Color to your brand color
4. Set Search Button Text Color to white
5. Adjust Border Radius for rounded corners

#### Example 2: Styled Login Form

1. Add "GMap Pro - Login/Register" widget
2. Go to Style → Container Style
3. Set Background Color to light gray (#f5f5f5)
4. Set Border Radius to 12px
5. Go to Buttons Style
6. Customize button colors and typography

#### Example 3: Branded Profile Page

1. Add "GMap Pro - Specialist Profile" widget
2. Go to Style → Header Style
3. Set Header Background to your brand color
4. Set Header Text Color to white
5. Customize content typography for readability

### Advanced Customization

**Using Custom CSS:**
You can add custom CSS in Elementor's Advanced tab for each widget:
- Custom CSS class
- Custom CSS code
- Responsive CSS

**Responsive Design:**
- Use Elementor's responsive mode (desktop/tablet/mobile)
- Adjust styles for each breakpoint
- Test on actual devices

**Integration with Other Widgets:**
- Combine with Elementor sections and columns
- Use Elementor's layout controls
- Add spacing and alignment controls

## Admin Panel

### Settings Page

**Location:** GMap Pro → Settings

- **Google Maps API Key** - Enter your Google Maps API key
- **Default Zoom Level** - Set the default map zoom (1-20)
- **Available Shortcodes** - View all shortcodes with copy functionality

### Specialists Management

**Location:** GMap Pro → Specialists

- View all specialists in a modern table layout
- Edit specialist information
- Delete specialists with confirmation dialog
- See specialist statistics

### Add/Edit Specialist

**Location:** GMap Pro → Add Specialist

**Fields:**
- Name* (required)
- Company
- Specialty* (required) - Select from managed specialties
- Avatar - Upload specialist profile image
- Address* (required) - With Google Places autocomplete
- City* (required)
- Province
- Postal Code
- Phone
- Email
- Website
- Description
- Active Status

### Specialties Management

**Location:** GMap Pro → Specialties

- Add new specialties
- Edit existing specialties
- Activate/deactivate specialties
- Delete specialties with confirmation
- View specialty statistics

### Sync Users

**Location:** GMap Pro → Sync Users

- Manually sync WordPress users with "specialist" role
- View sync information
- Automatic sync runs on:
  - User registration with specialist role
  - Profile updates
  - Meta field updates

## Features

### Map Functionality

- **Interactive Map** - Full Google Maps integration with custom styling
- **Location Autocomplete** - Restricted to Spain, supports streets, cities, postal codes
- **Distance Calculation** - Haversine formula for accurate proximity calculations
- **Progressive Results** - Shows all specialists in Spain, ordered by distance
- **Marker Clustering** - Smart marker display on the map
- **Info Windows** - Clickable markers with specialist details
- **Responsive Design** - Works on all screen sizes

### Search Features

- **Specialty Filter** - Dropdown with all managed specialties
- **Location Search** - Google Places autocomplete
- **Proximity Search** - Results ordered from nearest to farthest
- **All Spain Coverage** - No distance limits, shows all specialists
- **Real-time Updates** - Instant search results as you type

### Specialist Features

- **Profile Management** - Complete specialist profiles
- **Avatar Support** - Profile images with fallback placeholders
- **Rating System** - Built-in rating support
- **Contact Information** - Phone, email, website
- **Location Details** - Full address with coordinates
- **Specialty Association** - Link specialists to specialties

### User Management

- **Registration System** - Self-service specialist registration
- **Login System** - Secure authentication
- **Profile Pages** - Customizable specialist profiles
- **Auto-sync** - Automatic sync with WordPress users
- **Role Management** - Specialist role integration

## Configuration

### Google Maps API Setup

1. Create a project in [Google Cloud Console](https://console.cloud.google.com/)
2. Enable the following APIs:
   - Maps JavaScript API
   - Places API
   - Geocoding API
3. Create an API Key
4. (Recommended) Restrict the API key:
   - Application restrictions: HTTP referrers
   - Add your domain
   - API restrictions: Restrict to the three APIs listed above
5. Enter the API key in **GMap Pro → Settings**

### Default Settings

- **Default Zoom:** 6 (Spain overview)
- **Default Location:** Madrid (40.4168, -3.7038)
- **Distance Calculation:** Haversine formula
- **Search Restriction:** Spain only

## Developer Documentation

### Hooks and Filters

#### Filters

**`dsgmp_profile_page_url`**
Change the profile page redirect URL after login/registration.
```php
add_filter('dsgmp_profile_page_url', function($url) {
    return 'https://yoursite.com/custom-profile-page/';
});
```

**`dsgmp_auth_redirect`**
Customize the redirect URL after authentication.
```php
add_filter('dsgmp_auth_redirect', function($url) {
    return 'https://yoursite.com/custom-page/';
});
```

**`dsgmp_profile_page_slug`**
Change the default profile page slug.
```php
add_filter('dsgmp_profile_page_slug', function($slug) {
    return 'my-profile';
});
```

**`dsgmp_always_enqueue_auth`**
Control whether auth scripts are always enqueued.
```php
add_filter('dsgmp_always_enqueue_auth', '__return_false');
```

#### Actions

**`dsgmp_specialist_created`**
Fires after a specialist is created.
```php
add_action('dsgmp_specialist_created', function($specialist_id) {
    // Your custom code
});
```

### Database Schema

**Table: `wp_dsgmp_specialists`**
- id (bigint)
- user_id (bigint) - WordPress user ID
- name (varchar)
- company (varchar)
- specialty (varchar)
- avatar (varchar)
- address (text)
- city (varchar)
- province (varchar)
- postal_code (varchar)
- latitude (decimal)
- longitude (decimal)
- phone (varchar)
- email (varchar)
- website (varchar)
- rating (decimal)
- rating_count (int)
- description (text)
- active (tinyint)
- created_at (datetime)
- updated_at (datetime)

**Table: `wp_dsgmp_specialties`**
- id (bigint)
- name (varchar)
- slug (varchar)
- description (text)
- active (tinyint)
- created_at (datetime)
- updated_at (datetime)

### API Methods

**DSGMP_Database::get_specialists($args)**
Get all specialists with optional filtering.

**DSGMP_Database::get_specialists_by_proximity($lat, $lng, $distance_km, $args)**
Get specialists ordered by proximity.

**DSGMP_Database::insert_specialist($data)**
Insert a new specialist.

**DSGMP_Database::update_specialist($id, $data)**
Update an existing specialist.

**DSGMP_Database::delete_specialist($id)**
Delete a specialist.

## Troubleshooting

### Map Not Displaying

1. Check that Google Maps API key is entered correctly
2. Verify all required APIs are enabled
3. Check browser console for JavaScript errors
4. Ensure API key restrictions allow your domain

### Address Autocomplete Not Working

1. Verify Places API is enabled
2. Check API key has Places API access
3. Ensure API key restrictions include your domain

### Specialists Not Appearing

1. Check specialist is marked as "Active"
2. Verify specialist has valid coordinates
3. Check specialty matches search filter
4. Review database for specialist entries

### CSS Not Loading in Popups

1. Ensure CSS is enqueued (automatically done on frontend)
2. Check for plugin conflicts
3. Verify file permissions

## Support

For support, documentation, and updates, visit:
- **Author Website:** [https://tafsinahmed.info](https://tafsinahmed.info)

## Changelog

### 1.0.0
- Initial release
- Interactive Google Maps integration
- Specialist directory system
- Location search with autocomplete
- Proximity-based search
- User authentication system
- Profile pages
- Modern admin interface
- Specialty management
- User sync functionality
- Custom modal dialogs
- Responsive design

## Credits

- **Developer:** Tafsin Ahmed
- **Website:** [https://tafsinahmed.info](https://tafsinahmed.info)
- **Google Maps API:** [Google Cloud Platform](https://cloud.google.com/maps-platform)

## License

This plugin is licensed under the GPL v2 or later.

```
Copyright (C) 2024 Tafsin Ahmed

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
```

---

**Thank you for using Dynamic Search GMap Pro!**
