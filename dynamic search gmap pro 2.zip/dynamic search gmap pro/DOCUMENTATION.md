# Dynamic Search GMap Pro - Complete Documentation

## Table of Contents

1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Usage Guide](#usage-guide)
5. [Shortcodes Reference](#shortcodes-reference)
6. [Admin Panel Guide](#admin-panel-guide)
7. [Developer Guide](#developer-guide)
8. [API Reference](#api-reference)
9. [Customization](#customization)
10. [Troubleshooting](#troubleshooting)

---

## Introduction

Dynamic Search GMap Pro is a comprehensive WordPress plugin that provides advanced map and location search functionality. It's designed to create a professional specialist directory similar to major platforms like Idealista.

### Key Concepts

- **Specialists**: Professionals or businesses listed on the map
- **Specialties**: Categories or types of specialists (e.g., Electrician, Plumber)
- **Proximity Search**: Finding specialists based on distance from a location
- **User Sync**: Automatic synchronization between WordPress users and specialists

---

## Installation

### System Requirements

- WordPress 5.0 or higher
- PHP 7.2 or higher
- MySQL 5.6 or higher
- Google Maps API Key

### Installation Steps

1. **Download the Plugin**
   ```bash
   # Download from WordPress repository or provided source
   ```

2. **Install via WordPress Admin**
   - Navigate to Plugins → Add New
   - Click "Upload Plugin"
   - Select the plugin ZIP file
   - Click "Install Now"
   - Click "Activate Plugin"

3. **Install via FTP**
   - Extract the plugin ZIP file
   - Upload the `dynamic-search-gmap-pro` folder to `/wp-content/plugins/`
   - Activate via WordPress Admin → Plugins

### Post-Installation

After activation, the plugin will:
- Create necessary database tables
- Add the "specialist" user role
- Set default options
- Perform initial user sync

---

## Configuration

### Google Maps API Setup

#### Step 1: Create API Key

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing
3. Enable billing (required for Google Maps API)

#### Step 2: Enable Required APIs

Enable these APIs in your project:
- **Maps JavaScript API** - For displaying the map
- **Places API** - For address autocomplete
- **Geocoding API** - For converting addresses to coordinates

#### Step 3: Create API Key

1. Go to APIs & Services → Credentials
2. Click "Create Credentials" → "API Key"
3. Copy the API key

#### Step 4: Restrict API Key (Recommended)

1. Click on your API key to edit it
2. Under "Application restrictions":
   - Select "HTTP referrers (web sites)"
   - Add your domain: `https://yoursite.com/*`
3. Under "API restrictions":
   - Select "Restrict key"
   - Choose: Maps JavaScript API, Places API, Geocoding API

#### Step 5: Enter API Key in Plugin

1. Go to **GMap Pro → Settings**
2. Paste your API key in "Google Maps API Key" field
3. Click "Save Changes"

### Default Settings

Configure in **GMap Pro → Settings**:

- **Default Zoom Level**: Initial map zoom (1-20, default: 6)
- **Default Latitude**: Default map center latitude (default: 40.4168)
- **Default Longitude**: Default map center longitude (default: -3.7038)

---

## Usage Guide

### Setting Up Pages

#### 1. Create Map Page

1. Go to Pages → Add New
2. Title: "Find Specialists" (or your preference)
3. Add shortcode: `[dsgmp_map]`
4. Publish the page

#### 2. Create Login/Register Page

1. Go to Pages → Add New
2. Title: "Specialist Login"
3. Add shortcode: `[dsgmp_auth]`
4. Publish the page

#### 3. Create Profile Page

1. Go to Pages → Add New
2. Title: "Specialist Profile"
3. Add shortcode: `[dsgmp_profile]`
4. Publish the page

#### 4. Add to Menu

1. Go to Appearance → Menus
2. Add all three pages to your navigation menu
3. Save the menu

### Managing Specialists

#### Adding a Specialist

1. Go to **GMap Pro → Add Specialist**
2. Fill in required fields:
   - Name*
   - Specialty* (select from dropdown)
   - Address* (use autocomplete)
   - City*
3. Optional fields:
   - Company
   - Avatar (upload image)
   - Province
   - Postal Code
   - Phone
   - Email
   - Website
   - Description
4. Click "Save Specialist"

#### Editing a Specialist

1. Go to **GMap Pro → Specialists**
2. Click "Edit" next to the specialist
3. Make changes
4. Click "Save Specialist"

#### Deleting a Specialist

1. Go to **GMap Pro → Specialists**
2. Click "Delete" next to the specialist
3. Confirm deletion in the modal dialog

### Managing Specialties

#### Adding a Specialty

1. Go to **GMap Pro → Specialties**
2. Click "Add New"
3. Enter:
   - Specialty Name*
   - Description (optional)
   - Active status
4. Click "Save Specialty"

#### Using Specialties

- Specialties appear in the map search dropdown
- Specialists must select a specialty when registering
- You can activate/deactivate specialties to control visibility

### User Sync

The plugin automatically syncs WordPress users with the "specialist" role to the specialists table.

#### Automatic Sync

Sync happens automatically when:
- A user registers with the specialist role
- A specialist updates their profile
- Specialist meta fields are updated

#### Manual Sync

1. Go to **GMap Pro → Sync Users**
2. Review the information
3. Click "Sync All Specialist Users"

---

## Shortcodes Reference

### [dsgmp_map]

Displays the interactive map with search functionality.

**Attributes:**
- `specialty` (string, optional) - Pre-select a specialty
- `height` (string, optional) - Map height (default: "600px")

**Examples:**
```
[dsgmp_map]
[dsgmp_map specialty="Electrician"]
[dsgmp_map height="800px"]
[dsgmp_map specialty="Plumber" height="700px"]
```

**Output:**
- Search bar with specialty dropdown and location input
- Interactive Google Map
- Results panel showing specialists
- Markers on the map for each specialist

### [dsgmp_auth]

Displays login and registration forms.

**Attributes:**
- `default_tab` (string, optional) - Default tab: "login" or "register" (default: "login")

**Examples:**
```
[dsgmp_auth]
[dsgmp_auth default_tab="register"]
```

**Output:**
- Tabbed interface with Login and Register
- Login form (if not logged in)
- Registration form with specialist fields
- Profile link (if already logged in)

### [dsgmp_profile]

Displays the specialist profile page.

**No attributes**

**Example:**
```
[dsgmp_profile]
```

**Output:**
- Profile header with avatar and name
- Contact information
- Location details
- Profile description
- Status and rating information
- Edit Profile and Logout buttons

**Note:** Requires user to be logged in with "specialist" role.

---

## Admin Panel Guide

### Dashboard Overview

The admin panel is organized into these sections:

1. **Settings** - Configure API keys and defaults
2. **Specialists** - Manage all specialists
3. **Add Specialist** - Create or edit specialists
4. **Specialties** - Manage specialty categories
5. **Sync Users** - Sync WordPress users

### Settings Page

**Location:** GMap Pro → Settings

**Sections:**
- Google Maps API Settings
- Map Default Settings
- Available Shortcodes

### Specialists Page

**Location:** GMap Pro → Specialists

**Features:**
- List view with all specialists
- Statistics card showing total count
- Quick edit and delete actions
- Search and filter capabilities

### Add Specialist Page

**Location:** GMap Pro → Add Specialist

**Features:**
- Complete form with all fields
- Google Places autocomplete for addresses
- Avatar uploader
- Specialty dropdown
- Auto-geocoding (address → coordinates)

### Specialties Page

**Location:** GMap Pro → Specialties

**Features:**
- List of all specialties
- Statistics showing total and active counts
- Add/Edit/Delete functionality
- Status management

---

## Developer Guide

### File Structure

```
dynamic-search-gmap-pro/
├── dynamic-search-gmap-pro.php    # Main plugin file
├── uninstall.php                   # Uninstall handler
├── README.md                       # Plugin readme
├── CHANGELOG.md                    # Version history
├── DOCUMENTATION.md                # This file
├── includes/
│   ├── class-dsgmp-database.php   # Database operations
│   ├── class-dsgmp-admin.php      # Admin interface
│   ├── class-dsgmp-frontend.php   # Frontend display
│   ├── class-dsgmp-ajax.php       # AJAX handlers
│   ├── class-dsgmp-user-sync.php  # User synchronization
│   └── class-dsgmp-auth.php       # Authentication
└── assets/
    ├── css/
    │   ├── frontend.css           # Frontend styles
    │   ├── admin.css              # Admin styles
    │   ├── auth.css               # Auth styles
    │   └── profile.css            # Profile styles
    └── js/
        ├── frontend.js            # Frontend JavaScript
        ├── admin.js               # Admin JavaScript
        └── auth.js                # Auth JavaScript
```

### Database Schema

#### wp_dsgmp_specialists

```sql
CREATE TABLE wp_dsgmp_specialists (
    id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id bigint(20) UNSIGNED DEFAULT NULL,
    name varchar(255) NOT NULL,
    company varchar(255) DEFAULT '',
    specialty varchar(255) NOT NULL,
    avatar varchar(500) DEFAULT '',
    address text NOT NULL,
    city varchar(255) NOT NULL,
    province varchar(255) DEFAULT '',
    postal_code varchar(20) DEFAULT '',
    latitude decimal(10,8) NOT NULL,
    longitude decimal(11,8) NOT NULL,
    phone varchar(50) DEFAULT '',
    email varchar(255) DEFAULT '',
    website varchar(255) DEFAULT '',
    rating decimal(3,2) DEFAULT 0.00,
    rating_count int(11) DEFAULT 0,
    description text DEFAULT '',
    active tinyint(1) DEFAULT 1,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY user_id (user_id),
    KEY specialty (specialty),
    KEY active (active),
    KEY coordinates (latitude, longitude),
    KEY city (city)
);
```

#### wp_dsgmp_specialties

```sql
CREATE TABLE wp_dsgmp_specialties (
    id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    slug varchar(255) NOT NULL,
    description text DEFAULT '',
    active tinyint(1) DEFAULT 1,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY slug (slug),
    KEY active (active)
);
```

### Hooks and Filters

#### Filters

**`dsgmp_profile_page_url`**
Customize the profile page URL after login/registration.

```php
add_filter('dsgmp_profile_page_url', function($url) {
    return 'https://yoursite.com/custom-profile/';
});
```

**`dsgmp_auth_redirect`**
Change redirect URL after authentication.

```php
add_filter('dsgmp_auth_redirect', function($url) {
    return 'https://yoursite.com/dashboard/';
});
```

**`dsgmp_profile_page_slug`**
Customize the default profile page slug.

```php
add_filter('dsgmp_profile_page_slug', function($slug) {
    return 'my-profile';
});
```

**`dsgmp_always_enqueue_auth`**
Control auth script enqueueing.

```php
add_filter('dsgmp_always_enqueue_auth', '__return_false');
```

#### Actions

**`dsgmp_specialist_created`**
Fires after a specialist is created.

```php
add_action('dsgmp_specialist_created', function($specialist_id) {
    $specialist = DSGMP_Database::get_specialist($specialist_id);
    // Your custom code
});
```

**`dsgmp_specialist_updated`**
Fires after a specialist is updated.

```php
add_action('dsgmp_specialist_updated', function($specialist_id) {
    // Your custom code
});
```

---

## API Reference

### DSGMP_Database Class

#### get_specialists($args)

Get all specialists with optional filtering.

**Parameters:**
```php
$args = array(
    'active' => 1,           // Active status (1, 0, or '')
    'specialty' => '',       // Filter by specialty
    'search' => '',          // Search term
    'orderby' => 'name',     // Order by field
    'order' => 'ASC',        // Order direction
    'limit' => -1,           // Limit results (-1 = no limit)
    'offset' => 0            // Offset for pagination
);
```

**Returns:** Array of specialist objects

**Example:**
```php
$specialists = DSGMP_Database::get_specialists(array(
    'specialty' => 'Electrician',
    'active' => 1
));
```

#### get_specialists_by_proximity($lat, $lng, $distance_km, $args)

Get specialists ordered by distance from a location.

**Parameters:**
- `$lat` (float) - Latitude
- `$lng` (float) - Longitude
- `$distance_km` (float|null) - Distance limit in km (null = no limit)
- `$args` (array) - Additional filters

**Returns:** Array of specialist objects with `distance` property

**Example:**
```php
$specialists = DSGMP_Database::get_specialists_by_proximity(
    40.4168,  // Madrid latitude
    -3.7038,  // Madrid longitude
    null,     // No distance limit
    array('specialty' => 'Electrician')
);
```

#### insert_specialist($data)

Insert a new specialist.

**Parameters:**
```php
$data = array(
    'name' => 'John Doe',
    'specialty' => 'Electrician',
    'address' => '123 Main St',
    'city' => 'Madrid',
    'latitude' => 40.4168,
    'longitude' => -3.7038,
    // ... other fields
);
```

**Returns:** Insert ID on success, false on failure

#### update_specialist($id, $data)

Update an existing specialist.

**Parameters:**
- `$id` (int) - Specialist ID
- `$data` (array) - Fields to update

**Returns:** Boolean (true on success)

#### delete_specialist($id)

Delete a specialist.

**Parameters:**
- `$id` (int) - Specialist ID

**Returns:** Boolean (true on success)

#### get_specialty_names()

Get all active specialty names for dropdowns.

**Returns:** Array of specialty name strings

---

## Customization

### Styling

#### Custom CSS

Add custom CSS to your theme or via a custom CSS plugin:

```css
/* Customize map container */
.dsgmp-map-container {
    border-radius: 12px;
}

/* Customize search button */
.dsgmp-btn-search {
    background: #your-color;
}
```

#### Color Scheme

The plugin uses `#FF6B36` as the primary brand color. To change it globally:

```css
:root {
    --dsgmp-primary: #your-color;
}
```

### JavaScript Customization

#### Custom Map Styles

Modify map appearance in `frontend.js`:

```javascript
var mapStyles = [
    {
        featureType: 'all',
        stylers: [{ saturation: -50 }]
    }
];
```

### Template Overrides

While the plugin doesn't support template overrides directly, you can:

1. Use filters to modify output
2. Enqueue custom CSS/JS to override styles
3. Create custom shortcode handlers

---

## Troubleshooting

### Common Issues

#### Map Not Displaying

**Problem:** Map doesn't appear on the page.

**Solutions:**
1. Check Google Maps API key is entered correctly
2. Verify all required APIs are enabled
3. Check browser console for JavaScript errors
4. Ensure API key restrictions allow your domain
5. Verify billing is enabled on Google Cloud

#### Address Autocomplete Not Working

**Problem:** Autocomplete dropdown doesn't appear.

**Solutions:**
1. Verify Places API is enabled
2. Check API key has Places API access
3. Ensure API key restrictions include your domain
4. Check browser console for errors

#### Specialists Not Appearing on Map

**Problem:** No markers appear on the map.

**Solutions:**
1. Check specialist is marked as "Active"
2. Verify specialist has valid coordinates (not 0,0)
3. Check specialty matches the search filter
4. Review database to ensure specialists exist
5. Check browser console for JavaScript errors

#### CSS Not Loading

**Problem:** Styles not applying.

**Solutions:**
1. Clear WordPress cache
2. Clear browser cache
3. Check for plugin conflicts
4. Verify CSS files are accessible
5. Check file permissions

#### User Sync Not Working

**Problem:** WordPress users not syncing to specialists.

**Solutions:**
1. Verify user has "specialist" role
2. Check user meta fields are set
3. Manually trigger sync from Sync Users page
4. Check for JavaScript errors in browser console

### Debug Mode

Enable WordPress debug mode to see detailed error messages:

**wp-config.php:**
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

Check logs in `/wp-content/debug.log`

### Support

For additional support:
- **Author:** Tafsin Ahmed
- **Website:** [https://tafsinahmed.info](https://tafsinahmed.info)

---

## Frequently Asked Questions

### Q: Can I customize the map appearance?

A: Yes, you can add custom CSS to style the map container and related elements.

### Q: How many specialists can I add?

A: There's no hard limit. The plugin is optimized to handle thousands of specialists.

### Q: Can I use this outside of Spain?

A: Currently, the address autocomplete is restricted to Spain. You can modify the JavaScript to allow other countries.

### Q: Is the plugin translation-ready?

A: Yes, all text strings are wrapped in translation functions. Use translation plugins like WPML or Loco Translate.

### Q: Can I integrate with other plugins?

A: Yes, use the provided hooks and filters to integrate with other WordPress plugins.

---

## Credits

**Developed by:** Tafsin Ahmed  
**Website:** [https://tafsinahmed.info](https://tafsinahmed.info)  
**License:** GPL v2 or later

---

*Last Updated: Version 1.0.0*
