<?php
/**
 * Plugin Name: Dynamic Search GMap Pro
 * Plugin URI: https://example.com/dynamic-search-gmap-pro
 * Description: Advanced map and location search plugin with autocomplete, proximity filters, and specialist directory. Similar to Idealista level functionality.
 * Version: 1.0.0
 * Author: Tafsin Ahmed
 * Author URI: https://tafsinahmed.info
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: dynamic-search-gmap-pro
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('DSGMP_VERSION', '1.0.0');
define('DSGMP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DSGMP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DSGMP_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include required files
require_once DSGMP_PLUGIN_DIR . 'includes/class-dsgmp-database.php';
require_once DSGMP_PLUGIN_DIR . 'includes/class-dsgmp-user-sync.php';
require_once DSGMP_PLUGIN_DIR . 'includes/class-dsgmp-admin.php';
require_once DSGMP_PLUGIN_DIR . 'includes/class-dsgmp-frontend.php';
require_once DSGMP_PLUGIN_DIR . 'includes/class-dsgmp-ajax.php';
require_once DSGMP_PLUGIN_DIR . 'includes/class-dsgmp-auth.php';

// Include Elementor widgets if Elementor is active (safer check)
add_action('plugins_loaded', function() {
    if (did_action('elementor/loaded') || class_exists('\Elementor\Plugin')) {
        require_once DSGMP_PLUGIN_DIR . 'includes/class-dsgmp-elementor.php';
        new DSGMP_Elementor();
    }
}, 20);

/**
 * Main plugin class
 */
class Dynamic_Search_GMap_Pro {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->init_hooks();
    }
    
    private function init_hooks() {
        // Activation and deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Initialize on plugins loaded
        add_action('plugins_loaded', array($this, 'init'));
        
        // Load text domain for translations
        add_action('init', array($this, 'load_textdomain'));
    }
    
    public function init() {
        // Initialize user sync (runs on both admin and frontend)
        if (class_exists('DSGMP_User_Sync')) {
            new DSGMP_User_Sync();
            
            // Sync specialist users if flag is set (from activation)
            if (get_option('dsgmp_sync_on_activation')) {
                delete_option('dsgmp_sync_on_activation');
                // Delay sync slightly to ensure all classes are loaded
                add_action('wp_loaded', array($this, 'perform_initial_sync'), 999);
            }
        }
        
        // Initialize components
        if (is_admin()) {
            new DSGMP_Admin();
        } else {
            new DSGMP_Frontend();
        }
        
        // Initialize AJAX handlers (both admin and frontend)
        new DSGMP_Ajax();
        
        // Initialize Authentication (both admin and frontend)
        new DSGMP_Auth();
        
        // Elementor widgets are initialized via plugins_loaded hook
    }
    
    /**
     * Perform initial sync after all plugins are loaded
     */
    public function perform_initial_sync() {
        if (class_exists('DSGMP_Database')) {
            DSGMP_Database::sync_all_specialist_users();
        }
    }
    
    public function activate() {
        // Create database tables
        DSGMP_Database::create_tables();
        
        // Add specialist role
        if (!get_role('specialist')) {
            add_role(
                'specialist',
                __('Specialist', 'dynamic-search-gmap-pro'),
                array(
                    'read' => true,
                    'edit_posts' => false,
                )
            );
        }
        
        // Set default options
        $default_options = array(
            'google_maps_api_key' => '',
            'default_zoom' => 6,
            'default_lat' => 40.4168,
            'default_lng' => -3.7038, // Madrid, Spain center
            'max_distance' => 100,
            'distance_increment' => 5
        );
        
        add_option('dsgmp_options', $default_options);
        
        // Mark for sync after activation (will be handled on next page load)
        add_option('dsgmp_sync_on_activation', 1);
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    public function load_textdomain() {
        load_plugin_textdomain('dynamic-search-gmap-pro', false, dirname(DSGMP_PLUGIN_BASENAME) . '/languages');
    }
}

// Initialize the plugin
Dynamic_Search_GMap_Pro::get_instance();
