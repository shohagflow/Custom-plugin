<?php
/**
 * User Sync class - Syncs WordPress users with specialist role to specialists table
 */

if (!defined('ABSPATH')) {
    exit;
}

class DSGMP_User_Sync {
    
    public function __construct() {
        // Hook into user registration
        add_action('user_register', array($this, 'sync_user_on_register'));
        
        // Hook into profile updates
        add_action('profile_update', array($this, 'sync_user_on_update'), 10, 2);
        
        // Hook into user meta updates
        add_action('updated_user_meta', array($this, 'sync_user_on_meta_update'), 10, 4);
        
        // Add specialist fields to user profile
        add_action('show_user_profile', array($this, 'add_specialist_fields'));
        add_action('edit_user_profile', array($this, 'add_specialist_fields'));
        add_action('personal_options_update', array($this, 'save_specialist_fields'));
        add_action('edit_user_profile_update', array($this, 'save_specialist_fields'));
    }
    
    /**
     * Sync user when registered
     */
    public function sync_user_on_register($user_id) {
        $user = get_userdata($user_id);
        if ($user && in_array('specialist', (array) $user->roles)) {
            $this->sync_user_to_specialist($user_id);
        }
    }
    
    /**
     * Sync user when profile is updated
     */
    public function sync_user_on_update($user_id, $old_user_data) {
        $user = get_userdata($user_id);
        if ($user && in_array('specialist', (array) $user->roles)) {
            $this->sync_user_to_specialist($user_id);
        } elseif (!$user || !in_array('specialist', (array) $user->roles)) {
            // Remove from specialists if role was removed
            DSGMP_Database::delete_specialist_by_user_id($user_id);
        }
    }
    
    /**
     * Sync user when meta is updated
     */
    public function sync_user_on_meta_update($meta_id, $user_id, $meta_key, $meta_value) {
        // Check if any specialist meta was updated
        $specialist_meta_keys = array(
            'dsgmp_specialty', 'dsgmp_company', 'dsgmp_address', 'dsgmp_city',
            'dsgmp_province', 'dsgmp_postal_code', 'dsgmp_latitude', 'dsgmp_longitude',
            'dsgmp_phone', 'dsgmp_website', 'dsgmp_description', 'dsgmp_avatar'
        );
        
        if (in_array($meta_key, $specialist_meta_keys)) {
            $user = get_userdata($user_id);
            if ($user && in_array('specialist', (array) $user->roles)) {
                $this->sync_user_to_specialist($user_id);
            }
        }
    }
    
    /**
     * Sync user to specialist table
     */
    public function sync_user_to_specialist($user_id) {
        $user = get_userdata($user_id);
        if (!$user || !in_array('specialist', (array) $user->roles)) {
            return false;
        }
        
        // Check if specialist already exists
        $existing = DSGMP_Database::get_specialist_by_user_id($user_id);
        
        // Get user meta fields
        $specialty = get_user_meta($user_id, 'dsgmp_specialty', true);
        $company = get_user_meta($user_id, 'dsgmp_company', true);
        $address = get_user_meta($user_id, 'dsgmp_address', true);
        $city = get_user_meta($user_id, 'dsgmp_city', true);
        $province = get_user_meta($user_id, 'dsgmp_province', true);
        $postal_code = get_user_meta($user_id, 'dsgmp_postal_code', true);
        $latitude = get_user_meta($user_id, 'dsgmp_latitude', true);
        $longitude = get_user_meta($user_id, 'dsgmp_longitude', true);
        $phone = get_user_meta($user_id, 'dsgmp_phone', true);
        $website = get_user_meta($user_id, 'dsgmp_website', true);
        $description = get_user_meta($user_id, 'dsgmp_description', true);
        $avatar = get_user_meta($user_id, 'dsgmp_avatar', true);
        
        // Get avatar from WordPress avatar if not set
        if (empty($avatar)) {
            $avatar_url = get_avatar_url($user_id, array('size' => 150));
            $avatar = $avatar_url;
        }
        
        // Validate required fields
        if (empty($specialty)) {
            $specialty = 'General'; // Default specialty
        }
        
        if (empty($address)) {
            $address = '';
        }
        
        if (empty($city)) {
            $city = '';
        }
        
        // Default coordinates if not set
        if (empty($latitude) || $latitude == 0) {
            $latitude = 40.4168; // Madrid default
        }
        
        if (empty($longitude) || $longitude == 0) {
            $longitude = -3.7038;
        }
        
        // Prepare data
        $data = array(
            'user_id' => $user_id,
            'name' => $user->display_name ? $user->display_name : $user->user_login,
            'company' => $company ? $company : '',
            'specialty' => $specialty,
            'avatar' => $avatar ? $avatar : '',
            'address' => $address ? $address : '',
            'city' => $city ? $city : '',
            'province' => $province ? $province : '',
            'postal_code' => $postal_code ? $postal_code : '',
            'latitude' => floatval($latitude),
            'longitude' => floatval($longitude),
            'phone' => $phone ? $phone : '',
            'email' => $user->user_email ? $user->user_email : '',
            'website' => $website ? $website : '',
            'description' => $description ? $description : '',
            'active' => 1 // Auto-activate synced users
        );
        
        if ($existing) {
            // Update existing specialist
            DSGMP_Database::update_specialist($existing->id, $data);
            return $existing->id;
        } else {
            // Insert new specialist
            return DSGMP_Database::insert_specialist($data);
        }
    }
    
    /**
     * Add specialist fields to user profile
     */
    public function add_specialist_fields($user) {
        // Only show for specialist role
        if (!in_array('specialist', (array) $user->roles)) {
            return;
        }
        
        ?>
        <h3><?php _e('Specialist Information', 'dynamic-search-gmap-pro'); ?></h3>
        <table class="form-table">
            <tr>
                <th><label for="dsgmp_specialty"><?php _e('Specialty', 'dynamic-search-gmap-pro'); ?> *</label></th>
                <td>
                    <input type="text" name="dsgmp_specialty" id="dsgmp_specialty" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_specialty', true)); ?>" class="regular-text" />
                    <p class="description"><?php _e('Area of specialization (e.g., Cardiology, Dermatology)', 'dynamic-search-gmap-pro'); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_company"><?php _e('Company', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="text" name="dsgmp_company" id="dsgmp_company" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_company', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_location_search"><?php _e('Location Search', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="text" id="dsgmp_location_search" placeholder="<?php _e('Type address, city, or postal code...', 'dynamic-search-gmap-pro'); ?>" class="regular-text" />
                    <p class="description"><?php _e('Start typing to search for location. This will auto-fill the address fields.', 'dynamic-search-gmap-pro'); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_address"><?php _e('Address', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="text" name="dsgmp_address" id="dsgmp_address" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_address', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_city"><?php _e('City', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="text" name="dsgmp_city" id="dsgmp_city" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_city', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_province"><?php _e('Province', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="text" name="dsgmp_province" id="dsgmp_province" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_province', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_postal_code"><?php _e('Postal Code', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="text" name="dsgmp_postal_code" id="dsgmp_postal_code" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_postal_code', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_latitude"><?php _e('Latitude', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="text" name="dsgmp_latitude" id="dsgmp_latitude" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_latitude', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_longitude"><?php _e('Longitude', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="text" name="dsgmp_longitude" id="dsgmp_longitude" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_longitude', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_phone"><?php _e('Phone', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="text" name="dsgmp_phone" id="dsgmp_phone" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_phone', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_website"><?php _e('Website', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="url" name="dsgmp_website" id="dsgmp_website" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_website', true)); ?>" class="regular-text" />
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_avatar"><?php _e('Avatar URL', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <input type="url" name="dsgmp_avatar" id="dsgmp_avatar" value="<?php echo esc_attr(get_user_meta($user->ID, 'dsgmp_avatar', true)); ?>" class="regular-text" />
                    <p class="description"><?php _e('Profile image URL (or leave empty to use WordPress avatar)', 'dynamic-search-gmap-pro'); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="dsgmp_description"><?php _e('Description', 'dynamic-search-gmap-pro'); ?></label></th>
                <td>
                    <textarea name="dsgmp_description" id="dsgmp_description" rows="5" class="large-text"><?php echo esc_textarea(get_user_meta($user->ID, 'dsgmp_description', true)); ?></textarea>
                </td>
            </tr>
        </table>
        
        <?php
        $options = get_option('dsgmp_options');
        $api_key = isset($options['google_maps_api_key']) ? $options['google_maps_api_key'] : '';
        if (!empty($api_key)): ?>
            <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_js($api_key); ?>&libraries=places&language=es"></script>
            <script>
            jQuery(document).ready(function($) {
                var autocomplete = new google.maps.places.Autocomplete(document.getElementById('dsgmp_location_search'));
                autocomplete.setComponentRestrictions({country: 'es'});
                
                autocomplete.addListener('place_changed', function() {
                    var place = autocomplete.getPlace();
                    
                    if (!place.geometry) {
                        return;
                    }
                    
                    var address = '';
                    var city = '';
                    var province = '';
                    var postal_code = '';
                    
                    for (var i = 0; i < place.address_components.length; i++) {
                        var component = place.address_components[i];
                        var types = component.types;
                        
                        if (types.indexOf('street_number') !== -1) {
                            address = component.long_name + ' ';
                        }
                        if (types.indexOf('route') !== -1) {
                            address += component.long_name;
                        }
                        if (types.indexOf('locality') !== -1) {
                            city = component.long_name;
                        }
                        if (types.indexOf('administrative_area_level_2') !== -1) {
                            province = component.long_name;
                        }
                        if (types.indexOf('postal_code') !== -1) {
                            postal_code = component.long_name;
                        }
                    }
                    
                    $('#dsgmp_address').val(address || place.formatted_address);
                    $('#dsgmp_city').val(city);
                    $('#dsgmp_province').val(province);
                    $('#dsgmp_postal_code').val(postal_code);
                    $('#dsgmp_latitude').val(place.geometry.location.lat());
                    $('#dsgmp_longitude').val(place.geometry.location.lng());
                });
            });
            </script>
        <?php endif;
    }
    
    /**
     * Save specialist fields from user profile
     */
    public function save_specialist_fields($user_id) {
        if (!current_user_can('edit_user', $user_id)) {
            return false;
        }
        
        $fields = array(
            'dsgmp_specialty', 'dsgmp_company', 'dsgmp_address', 'dsgmp_city',
            'dsgmp_province', 'dsgmp_postal_code', 'dsgmp_latitude', 'dsgmp_longitude',
            'dsgmp_phone', 'dsgmp_website', 'dsgmp_description', 'dsgmp_avatar'
        );
        
        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_user_meta($user_id, $field, sanitize_text_field($_POST[$field]));
            }
        }
        
        // Auto-sync after saving
        $user = get_userdata($user_id);
        if ($user && in_array('specialist', (array) $user->roles)) {
            $this->sync_user_to_specialist($user_id);
        }
    }
}
