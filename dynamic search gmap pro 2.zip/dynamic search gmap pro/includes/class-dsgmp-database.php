<?php
/**
 * Database handling class
 */

if (!defined('ABSPATH')) {
    exit;
}

class DSGMP_Database {
    
    /**
     * Create database tables
     */
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $wpdb->prefix . 'dsgmp_specialists';
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED DEFAULT NULL,
            name varchar(255) NOT NULL,
            company varchar(255) DEFAULT '',
            specialty varchar(255) NOT NULL,
            avatar varchar(500) DEFAULT '',
            address text NOT NULL,
            city varchar(255) NOT NULL,
            province varchar(255) DEFAULT '',
            postal_code varchar(20) DEFAULT '',
            latitude decimal(10,8) NOT NULL,
            longitude decimal(11,8) NOT NULL,
            phone varchar(50) DEFAULT '',
            email varchar(255) DEFAULT '',
            website varchar(255) DEFAULT '',
            rating decimal(3,2) DEFAULT 0.00,
            rating_count int(11) DEFAULT 0,
            description text DEFAULT '',
            active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY specialty (specialty),
            KEY active (active),
            KEY coordinates (latitude, longitude),
            KEY city (city)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Add columns if they don't exist (for existing installations)
        $columns = $wpdb->get_col("DESC $table_name");
        
        if (!in_array('avatar', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN avatar varchar(500) DEFAULT '' AFTER specialty");
        }
        
        if (!in_array('user_id', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN user_id bigint(20) UNSIGNED DEFAULT NULL AFTER id");
            // Add index separately to avoid errors if it already exists
            $indexes = $wpdb->get_results("SHOW INDEX FROM $table_name WHERE Key_name = 'user_id'");
            if (empty($indexes)) {
                $wpdb->query("ALTER TABLE $table_name ADD INDEX user_id (user_id)");
            }
        }
        
        // Ensure user_id index exists
        $indexes = $wpdb->get_results("SHOW INDEX FROM $table_name WHERE Key_name = 'user_id'");
        if (empty($indexes) && in_array('user_id', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD INDEX user_id (user_id)");
        }
        
        // Create specialties table
        $specialties_table = $wpdb->prefix . 'dsgmp_specialties';
        $specialties_sql = "CREATE TABLE IF NOT EXISTS $specialties_table (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            slug varchar(255) NOT NULL,
            description text DEFAULT '',
            active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug),
            KEY active (active)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($specialties_sql);
    }
    
    /**
     * Get all active specialists
     */
    public static function get_specialists($args = array()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialists';
        
        $defaults = array(
            'active' => 1,
            'orderby' => 'name',
            'order' => 'ASC',
            'limit' => -1,
            'offset' => 0,
            'specialty' => '',
            'search' => ''
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array();
        $where_values = array();
        
        if ($args['active'] !== '') {
            $where[] = "active = %d";
            $where_values[] = $args['active'];
        }
        
        if (!empty($args['specialty'])) {
            $where[] = "specialty LIKE %s";
            $where_values[] = '%' . $wpdb->esc_like($args['specialty']) . '%';
        }
        
        if (!empty($args['search'])) {
            $where[] = "(name LIKE %s OR company LIKE %s OR specialty LIKE %s OR city LIKE %s)";
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $where_values[] = $search_term;
            $where_values[] = $search_term;
            $where_values[] = $search_term;
            $where_values[] = $search_term;
        }
        
        $where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
        $order_sql = "ORDER BY " . esc_sql($args['orderby']) . " " . esc_sql($args['order']);
        $limit_sql = $args['limit'] > 0 ? $wpdb->prepare("LIMIT %d OFFSET %d", $args['limit'], $args['offset']) : "";
        
        if (!empty($where_values)) {
            $sql = $wpdb->prepare(
                "SELECT * FROM $table_name $where_sql $order_sql $limit_sql",
                $where_values
            );
        } else {
            $sql = "SELECT * FROM $table_name $where_sql $order_sql $limit_sql";
        }
        
        return $wpdb->get_results($sql);
    }
    
    /**
     * Get specialists ordered by proximity (no distance limit - shows all in Spain)
     */
    public static function get_specialists_by_proximity($lat, $lng, $distance_km = null, $args = array()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialists';
        
        $defaults = array(
            'active' => 1,
            'specialty' => '',
            'limit' => -1
        );
        
        $args = wp_parse_args($args, $defaults);
        
        // Haversine formula for distance calculation
        // Sanitize numeric values
        $lat = floatval($lat);
        $lng = floatval($lng);
        
        $where = array();
        $where_values = array();
        
        // Build WHERE clause
        if ($args['active'] !== '') {
            $where[] = "active = %d";
            $where_values[] = $args['active'];
        }
        
        if (!empty($args['specialty'])) {
            $where[] = "specialty LIKE %s";
            $where_values[] = '%' . $wpdb->esc_like($args['specialty']) . '%';
        }
        
        $where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
        
        // Build the SQL with haversine formula (using sprintf for numeric values is safe)
        $haversine = sprintf(
            "(6371 * acos(cos(radians(%f)) * cos(radians(latitude)) * cos(radians(longitude) - radians(%f)) + sin(radians(%f)) * sin(radians(latitude)))) AS distance",
            $lat,
            $lng,
            $lat
        );
        
        // If distance_km is provided and > 0, add distance filter
        // Otherwise, show all specialists ordered by distance (covers all of Spain)
        $distance_where = "";
        if ($distance_km !== null && floatval($distance_km) > 0) {
            $distance_km = floatval($distance_km);
            $distance_where = sprintf(
                "(6371 * acos(cos(radians(%f)) * cos(radians(latitude)) * cos(radians(longitude) - radians(%f)) + sin(radians(%f)) * sin(radians(latitude)))) <= %f",
                $lat,
                $lng,
                $lat,
                $distance_km
            );
            
            if (!empty($where_sql)) {
                $distance_where = " AND " . $distance_where;
            } else {
                $distance_where = "WHERE " . $distance_where;
            }
        } else {
            // No distance limit - show all specialists in Spain ordered by proximity
            if (!empty($where_sql)) {
                $distance_where = "";
            }
        }
        
        // Build base SQL - always order by distance (nearest first)
        $sql = "SELECT *, $haversine 
                FROM $table_name 
                $where_sql $distance_where";
        
        // Add prepared statement values if needed
        if (!empty($where_values)) {
            $sql = $wpdb->prepare($sql, $where_values);
        }
        
        // Always order by distance ASC (nearest to farthest)
        $sql .= " ORDER BY distance ASC";
        
        // Apply limit if specified
        if ($args['limit'] > 0) {
            $sql .= $wpdb->prepare(" LIMIT %d", $args['limit']);
        }
        
        return $wpdb->get_results($sql);
    }
    
    /**
     * Insert specialist
     */
    public static function insert_specialist($data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialists';
        
        $defaults = array(
            'active' => 1,
            'rating' => 0,
            'rating_count' => 0
        );
        
        $data = wp_parse_args($data, $defaults);
        
        $result = $wpdb->insert($table_name, $data);
        
        if ($result) {
            return $wpdb->insert_id;
        }
        
        return false;
    }
    
    /**
     * Update specialist
     */
    public static function update_specialist($id, $data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialists';
        
        // Ensure required columns exist (migration check)
        $columns = $wpdb->get_col("DESC $table_name");
        if (!in_array('avatar', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN avatar varchar(500) DEFAULT '' AFTER specialty");
        }
        if (!in_array('user_id', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN user_id bigint(20) UNSIGNED DEFAULT NULL AFTER id");
        }
        
        // Remove any fields that don't exist in the table
        $allowed_columns = $wpdb->get_col("DESC $table_name");
        $data = array_intersect_key($data, array_flip($allowed_columns));
        
        if (empty($data)) {
            return false; // No valid fields to update
        }
        
        // Define format specifiers for each field type
        $formats = array();
        foreach ($data as $key => $value) {
            if ($key === 'user_id' || $key === 'rating_count' || $key === 'active') {
                $formats[] = '%d'; // Integer
            } elseif ($key === 'latitude' || $key === 'longitude' || $key === 'rating') {
                $formats[] = '%f'; // Float
            } else {
                $formats[] = '%s'; // String
            }
        }
        
        $result = $wpdb->update(
            $table_name,
            $data,
            array('id' => $id),
            $formats,
            array('%d')
        );
        
        // wpdb->update returns false on error, or number of rows affected (which can be 0)
        // We only return false on actual error
        if ($result === false) {
            return false;
        }
        
        return true; // Success (even if 0 rows were updated, it's still a success)
    }
    
    /**
     * Delete specialist
     */
    public static function delete_specialist($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialists';
        
        return $wpdb->delete($table_name, array('id' => $id), array('%d'));
    }
    
    /**
     * Get specialist by ID
     */
    public static function get_specialist($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialists';
        
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
    }
    
    /**
     * Get specialist by user ID
     */
    public static function get_specialist_by_user_id($user_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialists';
        
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d LIMIT 1", $user_id));
    }
    
    /**
     * Delete specialist by user ID
     */
    public static function delete_specialist_by_user_id($user_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialists';
        
        return $wpdb->delete($table_name, array('user_id' => $user_id), array('%d'));
    }
    
    /**
     * Sync all users with specialist role
     */
    public static function sync_all_specialist_users() {
        $users = get_users(array(
            'role' => 'specialist',
            'number' => -1
        ));
        
        $synced = 0;
        foreach ($users as $user) {
            if (class_exists('DSGMP_User_Sync')) {
                $sync = new DSGMP_User_Sync();
                if ($sync->sync_user_to_specialist($user->ID)) {
                    $synced++;
                }
            }
        }
        
        return $synced;
    }
    
    /**
     * Get all unique specialties (from specialists table - legacy)
     */
    public static function get_unique_specialties() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialists';
        
        $results = $wpdb->get_col("SELECT DISTINCT specialty FROM $table_name WHERE active = 1 AND specialty != '' ORDER BY specialty ASC");
        
        return $results ? $results : array();
    }
    
    /**
     * Get all specialties from specialties table
     */
    public static function get_specialties($args = array()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialties';
        
        $defaults = array(
            'active' => 1,
            'orderby' => 'name',
            'order' => 'ASC'
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array();
        if ($args['active'] !== '') {
            $where[] = $wpdb->prepare("active = %d", $args['active']);
        }
        
        $where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
        $order_sql = "ORDER BY " . esc_sql($args['orderby']) . " " . esc_sql($args['order']);
        
        return $wpdb->get_results("SELECT * FROM $table_name $where_sql $order_sql");
    }
    
    /**
     * Get specialty by ID
     */
    public static function get_specialty($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialties';
        
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
    }
    
    /**
     * Insert specialty
     */
    public static function insert_specialty($data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialties';
        
        // Generate slug if not provided
        if (empty($data['slug']) && !empty($data['name'])) {
            $data['slug'] = sanitize_title($data['name']);
        }
        
        // Ensure slug is unique
        if (!empty($data['slug'])) {
            $original_slug = $data['slug'];
            $counter = 1;
            while ($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE slug = %s", $data['slug']))) {
                $data['slug'] = $original_slug . '-' . $counter;
                $counter++;
            }
        }
        
        $defaults = array(
            'active' => 1,
            'description' => ''
        );
        
        $data = wp_parse_args($data, $defaults);
        
        $result = $wpdb->insert($table_name, $data);
        
        if ($result) {
            return $wpdb->insert_id;
        }
        
        return false;
    }
    
    /**
     * Update specialty
     */
    public static function update_specialty($id, $data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialties';
        
        // Generate slug if name changed and slug not provided
        if (!empty($data['name']) && empty($data['slug'])) {
            $data['slug'] = sanitize_title($data['name']);
        }
        
        // Ensure slug is unique (excluding current specialty)
        if (!empty($data['slug'])) {
            $original_slug = $data['slug'];
            $counter = 1;
            while ($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE slug = %s AND id != %d", $data['slug'], $id))) {
                $data['slug'] = $original_slug . '-' . $counter;
                $counter++;
            }
        }
        
        $result = $wpdb->update(
            $table_name,
            $data,
            array('id' => $id),
            null,
            array('%d')
        );
        
        if ($result === false) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Delete specialty
     */
    public static function delete_specialty($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialties';
        
        return $wpdb->delete($table_name, array('id' => $id), array('%d'));
    }
    
    /**
     * Get all specialty names for dropdowns
     */
    public static function get_specialty_names() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dsgmp_specialties';
        
        $results = $wpdb->get_col("SELECT name FROM $table_name WHERE active = 1 ORDER BY name ASC");
        
        // If no specialties in table, get from specialists table (backward compatibility)
        if (empty($results)) {
            return self::get_unique_specialties();
        }
        
        return $results ? $results : array();
    }
}
