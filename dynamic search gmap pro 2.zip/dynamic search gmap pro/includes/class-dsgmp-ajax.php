<?php
/**
 * AJAX handlers class
 */

if (!defined('ABSPATH')) {
    exit;
}

class DSGMP_Ajax {
    
    public function __construct() {
        // Frontend AJAX actions
        add_action('wp_ajax_dsgmp_search', array($this, 'search_specialists'));
        add_action('wp_ajax_nopriv_dsgmp_search', array($this, 'search_specialists'));
        add_action('wp_ajax_dsgmp_get_all', array($this, 'get_all_specialists'));
        add_action('wp_ajax_nopriv_dsgmp_get_all', array($this, 'get_all_specialists'));
        add_action('wp_ajax_dsgmp_geocode', array($this, 'geocode_address'));
        add_action('wp_ajax_nopriv_dsgmp_geocode', array($this, 'geocode_address'));
    }
    
    public function search_specialists() {
        check_ajax_referer('dsgmp_nonce', 'nonce');
        
        $lat = isset($_POST['lat']) ? floatval($_POST['lat']) : 0;
        $lng = isset($_POST['lng']) ? floatval($_POST['lng']) : 0;
        $specialty = isset($_POST['specialty']) ? sanitize_text_field($_POST['specialty']) : '';
        
        if ($lat == 0 || $lng == 0) {
            wp_send_json_error(array('message' => __('Invalid coordinates.', 'dynamic-search-gmap-pro')));
            return;
        }
        
        // Search all specialists in Spain, ordered by proximity (no distance limit)
        $args = array(
            'active' => 1,
            'specialty' => $specialty,
            'limit' => -1 // No limit - show all specialists in Spain
        );
        
        // Pass null as distance to remove distance limit and show all specialists ordered by proximity
        $specialists = DSGMP_Database::get_specialists_by_proximity($lat, $lng, null, $args);
        
        $results = array();
        foreach ($specialists as $specialist) {
            $results[] = array(
                'id' => $specialist->id,
                'name' => $specialist->name,
                'company' => $specialist->company,
                'specialty' => $specialist->specialty,
                'avatar' => isset($specialist->avatar) ? $specialist->avatar : '',
                'address' => $specialist->address,
                'city' => $specialist->city,
                'province' => $specialist->province,
                'postal_code' => $specialist->postal_code,
                'latitude' => floatval($specialist->latitude),
                'longitude' => floatval($specialist->longitude),
                'phone' => $specialist->phone,
                'email' => $specialist->email,
                'website' => $specialist->website,
                'rating' => floatval($specialist->rating),
                'rating_count' => intval($specialist->rating_count),
                'description' => $specialist->description,
                'distance' => isset($specialist->distance) ? round(floatval($specialist->distance), 2) : 0
            );
        }
        
        wp_send_json_success(array(
            'specialists' => $results,
            'count' => count($results)
        ));
    }
    
    public function get_all_specialists() {
        check_ajax_referer('dsgmp_nonce', 'nonce');
        
        $specialty = isset($_POST['specialty']) ? sanitize_text_field($_POST['specialty']) : '';
        
        $args = array(
            'active' => 1,
            'specialty' => $specialty,
            'limit' => 500 // Maximum results
        );
        
        $specialists = DSGMP_Database::get_specialists($args);
        
        $results = array();
        foreach ($specialists as $specialist) {
            $results[] = array(
                'id' => $specialist->id,
                'name' => $specialist->name,
                'company' => $specialist->company,
                'specialty' => $specialist->specialty,
                'avatar' => isset($specialist->avatar) ? $specialist->avatar : '',
                'address' => $specialist->address,
                'city' => $specialist->city,
                'province' => $specialist->province,
                'postal_code' => $specialist->postal_code,
                'latitude' => floatval($specialist->latitude),
                'longitude' => floatval($specialist->longitude),
                'phone' => $specialist->phone,
                'email' => $specialist->email,
                'website' => $specialist->website,
                'rating' => floatval($specialist->rating),
                'rating_count' => intval($specialist->rating_count),
                'description' => $specialist->description,
                'distance' => 0 // No distance when showing all
            );
        }
        
        wp_send_json_success(array(
            'specialists' => $results,
            'count' => count($results)
        ));
    }
    
    public function geocode_address() {
        check_ajax_referer('dsgmp_nonce', 'nonce');
        
        $address = isset($_POST['address']) ? sanitize_text_field($_POST['address']) : '';
        
        if (empty($address)) {
            wp_send_json_error(array('message' => __('Address is required.', 'dynamic-search-gmap-pro')));
            return;
        }
        
        $options = get_option('dsgmp_options');
        $api_key = isset($options['google_maps_api_key']) ? $options['google_maps_api_key'] : '';
        
        if (empty($api_key)) {
            wp_send_json_error(array('message' => __('Google Maps API key is not configured.', 'dynamic-search-gmap-pro')));
            return;
        }
        
        $url = 'https://maps.googleapis.com/maps/api/geocode/json?address=' . urlencode($address) . '&key=' . $api_key . '&region=es';
        
        $response = wp_remote_get($url);
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => __('Error connecting to Google Maps API.', 'dynamic-search-gmap-pro')));
            return;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data['status'] !== 'OK' || empty($data['results'])) {
            wp_send_json_error(array('message' => __('Address not found.', 'dynamic-search-gmap-pro')));
            return;
        }
        
        $result = $data['results'][0];
        $location = $result['geometry']['location'];
        
        // Extract address components
        $components = array();
        foreach ($result['address_components'] as $component) {
            $components[$component['types'][0]] = $component['long_name'];
            if (isset($component['types'][1])) {
                $components[$component['types'][1]] = $component['long_name'];
            }
        }
        
        wp_send_json_success(array(
            'lat' => floatval($location['lat']),
            'lng' => floatval($location['lng']),
            'formatted_address' => $result['formatted_address'],
            'components' => $components
        ));
    }
}
