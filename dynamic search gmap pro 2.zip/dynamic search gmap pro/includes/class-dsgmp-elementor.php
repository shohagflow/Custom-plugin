<?php
/**
 * Elementor Widget Integration for Dynamic Search GMap Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

class DSGMP_Elementor {
    
    public function __construct() {
        // Check if Elementor is installed and activated
        add_action('plugins_loaded', array($this, 'init'), 25);
    }
    
    public function init() {
        // Check if Elementor installed and activated
        if (!did_action('elementor/loaded') && !class_exists('\Elementor\Plugin')) {
            // Only show notice in admin
            if (is_admin()) {
                add_action('admin_notices', array($this, 'admin_notice_missing_elementor'));
            }
            return;
        }
        
        // Register Elementor Widget (compatible with both old and new Elementor versions)
        if (defined('ELEMENTOR_VERSION') && version_compare(ELEMENTOR_VERSION, '3.5.0', '>=')) {
            // Elementor 3.5.0+
            add_action('elementor/widgets/register', array($this, 'register_widgets'), 10);
        } else {
            // Older Elementor versions or if version constant not defined
            add_action('elementor/widgets/widgets_registered', array($this, 'register_widgets_legacy'), 10);
            // Also try new method as fallback
            add_action('elementor/widgets/register', array($this, 'register_widgets'), 10);
        }
        
        // Enqueue styles for Elementor editor
        add_action('elementor/editor/after_enqueue_styles', array($this, 'editor_styles'));
    }
    
    /**
     * Admin notice if Elementor is not installed
     */
    public function admin_notice_missing_elementor() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        
        $message = sprintf(
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'dynamic-search-gmap-pro'),
            '<strong>' . esc_html__('Dynamic Search GMap Pro - Elementor Widget', 'dynamic-search-gmap-pro') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'dynamic-search-gmap-pro') . '</strong>'
        );
        
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }
    
    /**
     * Register Elementor Widgets (Elementor 3.5.0+)
     */
    public function register_widgets($widgets_manager) {
        // Check if class exists before requiring (avoid fatal errors)
        if (!class_exists('DSGMP_Elementor_Map_Widget')) {
            require_once DSGMP_PLUGIN_DIR . 'includes/widgets/class-dsgmp-elementor-map-widget.php';
        }
        if (!class_exists('DSGMP_Elementor_Auth_Widget')) {
            require_once DSGMP_PLUGIN_DIR . 'includes/widgets/class-dsgmp-elementor-auth-widget.php';
        }
        if (!class_exists('DSGMP_Elementor_Profile_Widget')) {
            require_once DSGMP_PLUGIN_DIR . 'includes/widgets/class-dsgmp-elementor-profile-widget.php';
        }
        
        // Register widgets if they exist
        if (class_exists('DSGMP_Elementor_Map_Widget')) {
            $widgets_manager->register(new DSGMP_Elementor_Map_Widget());
        }
        if (class_exists('DSGMP_Elementor_Auth_Widget')) {
            $widgets_manager->register(new DSGMP_Elementor_Auth_Widget());
        }
        if (class_exists('DSGMP_Elementor_Profile_Widget')) {
            $widgets_manager->register(new DSGMP_Elementor_Profile_Widget());
        }
    }
    
    /**
     * Register Elementor Widgets (Legacy - Elementor < 3.5.0)
     */
    public function register_widgets_legacy($widgets_manager) {
        // Check if class exists before requiring (avoid fatal errors)
        if (!class_exists('DSGMP_Elementor_Map_Widget')) {
            require_once DSGMP_PLUGIN_DIR . 'includes/widgets/class-dsgmp-elementor-map-widget.php';
        }
        if (!class_exists('DSGMP_Elementor_Auth_Widget')) {
            require_once DSGMP_PLUGIN_DIR . 'includes/widgets/class-dsgmp-elementor-auth-widget.php';
        }
        if (!class_exists('DSGMP_Elementor_Profile_Widget')) {
            require_once DSGMP_PLUGIN_DIR . 'includes/widgets/class-dsgmp-elementor-profile-widget.php';
        }
        
        // Register widgets if they exist (legacy method)
        if (class_exists('DSGMP_Elementor_Map_Widget')) {
            $widgets_manager->register_widget_type(new DSGMP_Elementor_Map_Widget());
        }
        if (class_exists('DSGMP_Elementor_Auth_Widget')) {
            $widgets_manager->register_widget_type(new DSGMP_Elementor_Auth_Widget());
        }
        if (class_exists('DSGMP_Elementor_Profile_Widget')) {
            $widgets_manager->register_widget_type(new DSGMP_Elementor_Profile_Widget());
        }
    }
    
    /**
     * Enqueue editor styles
     */
    public function editor_styles() {
        wp_enqueue_style(
            'dsgmp-elementor-editor',
            DSGMP_PLUGIN_URL . 'assets/css/elementor-editor.css',
            array(),
            DSGMP_VERSION
        );
    }
}
