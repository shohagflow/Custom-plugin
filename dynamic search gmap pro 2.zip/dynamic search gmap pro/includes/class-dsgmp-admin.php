<?php
/**
 * Admin interface class
 */

if (!defined('ABSPATH')) {
    exit;
}

class DSGMP_Admin {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // Ensure database tables are up to date
        $this->ensure_database_structure();
    }
    
    /**
     * Ensure database structure is up to date
     */
    private function ensure_database_structure() {
        // Run create_tables which handles migrations
        DSGMP_Database::create_tables();
    }
    
    public function add_admin_menu() {
        add_menu_page(
            __('Dynamic Search GMap Pro', 'dynamic-search-gmap-pro'),
            __('GMap Pro', 'dynamic-search-gmap-pro'),
            'manage_options',
            'dsgmp-settings',
            array($this, 'settings_page'),
            'dashicons-location-alt',
            30
        );
        
        add_submenu_page(
            'dsgmp-settings',
            __('Settings', 'dynamic-search-gmap-pro'),
            __('Settings', 'dynamic-search-gmap-pro'),
            'manage_options',
            'dsgmp-settings',
            array($this, 'settings_page')
        );
        
        add_submenu_page(
            'dsgmp-settings',
            __('Specialists', 'dynamic-search-gmap-pro'),
            __('Specialists', 'dynamic-search-gmap-pro'),
            'manage_options',
            'dsgmp-specialists',
            array($this, 'specialists_page')
        );
        
        add_submenu_page(
            'dsgmp-settings',
            __('Add Specialist', 'dynamic-search-gmap-pro'),
            __('Add Specialist', 'dynamic-search-gmap-pro'),
            'manage_options',
            'dsgmp-add-specialist',
            array($this, 'add_specialist_page')
        );
        
        add_submenu_page(
            'dsgmp-settings',
            __('Specialties', 'dynamic-search-gmap-pro'),
            __('Specialties', 'dynamic-search-gmap-pro'),
            'manage_options',
            'dsgmp-specialties',
            array($this, 'specialties_page')
        );
        
        add_submenu_page(
            'dsgmp-settings',
            __('Sync Users', 'dynamic-search-gmap-pro'),
            __('Sync Users', 'dynamic-search-gmap-pro'),
            'manage_options',
            'dsgmp-sync-users',
            array($this, 'sync_users_page')
        );
    }
    
    public function register_settings() {
        register_setting('dsgmp_options_group', 'dsgmp_options');
        
        add_settings_section(
            'dsgmp_api_section',
            __('Google Maps API Settings', 'dynamic-search-gmap-pro'),
            array($this, 'api_section_callback'),
            'dsgmp-settings'
        );
        
        add_settings_field(
            'google_maps_api_key',
            __('Google Maps API Key', 'dynamic-search-gmap-pro'),
            array($this, 'api_key_field_callback'),
            'dsgmp-settings',
            'dsgmp_api_section'
        );
        
        add_settings_section(
            'dsgmp_map_section',
            __('Map Default Settings', 'dynamic-search-gmap-pro'),
            array($this, 'map_section_callback'),
            'dsgmp-settings'
        );
        
        add_settings_field(
            'default_zoom',
            __('Default Zoom Level', 'dynamic-search-gmap-pro'),
            array($this, 'default_zoom_field_callback'),
            'dsgmp-settings',
            'dsgmp_map_section'
        );
        
        add_settings_section(
            'dsgmp_shortcodes_section',
            __('Available Shortcodes', 'dynamic-search-gmap-pro'),
            array($this, 'shortcodes_section_callback'),
            'dsgmp-settings'
        );
    }
    
    public function api_section_callback() {
        echo '<p>' . __('Enter your Google Maps API key. Make sure it has the following APIs enabled:', 'dynamic-search-gmap-pro') . '</p>';
        echo '<ul>';
        echo '<li>Maps JavaScript API</li>';
        echo '<li>Places API</li>';
        echo '<li>Geocoding API</li>';
        echo '</ul>';
    }
    
    public function api_key_field_callback() {
        $options = get_option('dsgmp_options');
        $value = isset($options['google_maps_api_key']) ? $options['google_maps_api_key'] : '';
        echo '<input type="text" name="dsgmp_options[google_maps_api_key]" value="' . esc_attr($value) . '" class="regular-text" />';
    }
    
    public function map_section_callback() {
        echo '<p>' . __('Configure default map settings.', 'dynamic-search-gmap-pro') . '</p>';
    }
    
    public function default_zoom_field_callback() {
        $options = get_option('dsgmp_options');
        $value = isset($options['default_zoom']) ? $options['default_zoom'] : 6;
        echo '<input type="number" name="dsgmp_options[default_zoom]" value="' . esc_attr($value) . '" min="1" max="20" />';
    }
    
    public function shortcodes_section_callback() {
        ?>
        <div class="dsgmp-shortcodes-list">
            <p><?php _e('Use these shortcodes to display plugin features on your pages and posts:', 'dynamic-search-gmap-pro'); ?></p>
            
            <div class="dsgmp-shortcode-item">
                <div class="dsgmp-shortcode-header">
                    <h3>
                        <span class="dashicons dashicons-location-alt"></span>
                        <?php _e('Map Shortcode', 'dynamic-search-gmap-pro'); ?>
                    </h3>
                    <div class="dsgmp-shortcode-code-wrapper">
                        <code class="dsgmp-shortcode-code" data-shortcode="[dsgmp_map]">[dsgmp_map]</code>
                        <button type="button" class="dsgmp-copy-btn" data-copy="[dsgmp_map]" title="<?php _e('Copy to clipboard', 'dynamic-search-gmap-pro'); ?>">
                            <span class="dashicons dashicons-clipboard"></span>
                            <span class="dsgmp-copy-text"><?php _e('Copy', 'dynamic-search-gmap-pro'); ?></span>
                        </button>
                    </div>
                </div>
                <div class="dsgmp-shortcode-content">
                    <p><strong><?php _e('Description:', 'dynamic-search-gmap-pro'); ?></strong> <?php _e('Displays the interactive map with specialist search functionality.', 'dynamic-search-gmap-pro'); ?></p>
                    <p><strong><?php _e('Usage:', 'dynamic-search-gmap-pro'); ?></strong></p>
                    <ul>
                        <li>
                            <code data-shortcode="[dsgmp_map]">[dsgmp_map]</code> - <?php _e('Basic map display', 'dynamic-search-gmap-pro'); ?>
                            <button type="button" class="dsgmp-copy-btn-inline" data-copy="[dsgmp_map]" title="<?php _e('Copy', 'dynamic-search-gmap-pro'); ?>">
                                <span class="dashicons dashicons-clipboard"></span>
                            </button>
                        </li>
                        <li>
                            <code data-shortcode='[dsgmp_map specialty="Electrician"]'>[dsgmp_map specialty="Electrician"]</code> - <?php _e('Pre-select a specialty', 'dynamic-search-gmap-pro'); ?>
                            <button type="button" class="dsgmp-copy-btn-inline" data-copy='[dsgmp_map specialty="Electrician"]' title="<?php _e('Copy', 'dynamic-search-gmap-pro'); ?>">
                                <span class="dashicons dashicons-clipboard"></span>
                            </button>
                        </li>
                        <li>
                            <code data-shortcode='[dsgmp_map height="800px"]'>[dsgmp_map height="800px"]</code> - <?php _e('Custom map height', 'dynamic-search-gmap-pro'); ?>
                            <button type="button" class="dsgmp-copy-btn-inline" data-copy='[dsgmp_map height="800px"]' title="<?php _e('Copy', 'dynamic-search-gmap-pro'); ?>">
                                <span class="dashicons dashicons-clipboard"></span>
                            </button>
                        </li>
                        <li>
                            <code data-shortcode='[dsgmp_map specialty="Plumber" height="600px"]'>[dsgmp_map specialty="Plumber" height="600px"]</code> - <?php _e('Combine attributes', 'dynamic-search-gmap-pro'); ?>
                            <button type="button" class="dsgmp-copy-btn-inline" data-copy='[dsgmp_map specialty="Plumber" height="600px"]' title="<?php _e('Copy', 'dynamic-search-gmap-pro'); ?>">
                                <span class="dashicons dashicons-clipboard"></span>
                            </button>
                        </li>
                    </ul>
                    <p><strong><?php _e('Attributes:', 'dynamic-search-gmap-pro'); ?></strong></p>
                    <ul>
                        <li><code>specialty</code> - <?php _e('Pre-select a specialty (optional)', 'dynamic-search-gmap-pro'); ?></li>
                        <li><code>height</code> - <?php _e('Map height in pixels (default: 600px)', 'dynamic-search-gmap-pro'); ?></li>
                    </ul>
                </div>
            </div>
            
            <div class="dsgmp-shortcode-item">
                <div class="dsgmp-shortcode-header">
                    <h3>
                        <span class="dashicons dashicons-admin-users"></span>
                        <?php _e('Authentication Shortcode', 'dynamic-search-gmap-pro'); ?>
                    </h3>
                    <div class="dsgmp-shortcode-code-wrapper">
                        <code class="dsgmp-shortcode-code" data-shortcode="[dsgmp_auth]">[dsgmp_auth]</code>
                        <button type="button" class="dsgmp-copy-btn" data-copy="[dsgmp_auth]" title="<?php _e('Copy to clipboard', 'dynamic-search-gmap-pro'); ?>">
                            <span class="dashicons dashicons-clipboard"></span>
                            <span class="dsgmp-copy-text"><?php _e('Copy', 'dynamic-search-gmap-pro'); ?></span>
                        </button>
                    </div>
                </div>
                <div class="dsgmp-shortcode-content">
                    <p><strong><?php _e('Description:', 'dynamic-search-gmap-pro'); ?></strong> <?php _e('Displays login and registration forms for specialists.', 'dynamic-search-gmap-pro'); ?></p>
                    <p><strong><?php _e('Usage:', 'dynamic-search-gmap-pro'); ?></strong></p>
                    <ul>
                        <li>
                            <code data-shortcode="[dsgmp_auth]">[dsgmp_auth]</code> - <?php _e('Show login form by default', 'dynamic-search-gmap-pro'); ?>
                            <button type="button" class="dsgmp-copy-btn-inline" data-copy="[dsgmp_auth]" title="<?php _e('Copy', 'dynamic-search-gmap-pro'); ?>">
                                <span class="dashicons dashicons-clipboard"></span>
                            </button>
                        </li>
                        <li>
                            <code data-shortcode='[dsgmp_auth default_tab="register"]'>[dsgmp_auth default_tab="register"]</code> - <?php _e('Show registration form by default', 'dynamic-search-gmap-pro'); ?>
                            <button type="button" class="dsgmp-copy-btn-inline" data-copy='[dsgmp_auth default_tab="register"]' title="<?php _e('Copy', 'dynamic-search-gmap-pro'); ?>">
                                <span class="dashicons dashicons-clipboard"></span>
                            </button>
                        </li>
                    </ul>
                    <p><strong><?php _e('Attributes:', 'dynamic-search-gmap-pro'); ?></strong></p>
                    <ul>
                        <li><code>default_tab</code> - <?php _e('Default tab to show: "login" or "register" (default: "login")', 'dynamic-search-gmap-pro'); ?></li>
                    </ul>
                    <p><strong><?php _e('Note:', 'dynamic-search-gmap-pro'); ?></strong> <?php _e('If user is already logged in, shows profile link and logout button.', 'dynamic-search-gmap-pro'); ?></p>
                </div>
            </div>
            
            <div class="dsgmp-shortcode-item">
                <div class="dsgmp-shortcode-header">
                    <h3>
                        <span class="dashicons dashicons-id"></span>
                        <?php _e('Profile Shortcode', 'dynamic-search-gmap-pro'); ?>
                    </h3>
                    <div class="dsgmp-shortcode-code-wrapper">
                        <code class="dsgmp-shortcode-code" data-shortcode="[dsgmp_profile]">[dsgmp_profile]</code>
                        <button type="button" class="dsgmp-copy-btn" data-copy="[dsgmp_profile]" title="<?php _e('Copy to clipboard', 'dynamic-search-gmap-pro'); ?>">
                            <span class="dashicons dashicons-clipboard"></span>
                            <span class="dsgmp-copy-text"><?php _e('Copy', 'dynamic-search-gmap-pro'); ?></span>
                        </button>
                    </div>
                </div>
                <div class="dsgmp-shortcode-content">
                    <p><strong><?php _e('Description:', 'dynamic-search-gmap-pro'); ?></strong> <?php _e('Displays the specialist profile page for logged-in specialists.', 'dynamic-search-gmap-pro'); ?></p>
                    <p><strong><?php _e('Usage:', 'dynamic-search-gmap-pro'); ?></strong></p>
                    <ul>
                        <li>
                            <code data-shortcode="[dsgmp_profile]">[dsgmp_profile]</code> - <?php _e('Display specialist profile', 'dynamic-search-gmap-pro'); ?>
                            <button type="button" class="dsgmp-copy-btn-inline" data-copy="[dsgmp_profile]" title="<?php _e('Copy', 'dynamic-search-gmap-pro'); ?>">
                                <span class="dashicons dashicons-clipboard"></span>
                            </button>
                        </li>
                    </ul>
                    <p><strong><?php _e('Note:', 'dynamic-search-gmap-pro'); ?></strong> <?php _e('This shortcode requires the user to be logged in with the "specialist" role. After login/registration, users are automatically redirected to the page containing this shortcode.', 'dynamic-search-gmap-pro'); ?></p>
                    <p><strong><?php _e('Tip:', 'dynamic-search-gmap-pro'); ?></strong> <?php _e('Create a page called "Specialist Profile" and add this shortcode. The plugin will automatically detect and redirect users there after login.', 'dynamic-search-gmap-pro'); ?></p>
                </div>
            </div>
            
            <div class="dsgmp-shortcode-info-box">
                <h4><?php _e('Quick Setup Guide', 'dynamic-search-gmap-pro'); ?></h4>
                <ol>
                    <li><?php _e('Create a page for the map and add: <code data-shortcode="[dsgmp_map]">[dsgmp_map]</code>', 'dynamic-search-gmap-pro'); ?></li>
                    <li><?php _e('Create a page for login/register and add: <code data-shortcode="[dsgmp_auth]">[dsgmp_auth]</code>', 'dynamic-search-gmap-pro'); ?></li>
                    <li><?php _e('Create a page for specialist profile and add: <code data-shortcode="[dsgmp_profile]">[dsgmp_profile]</code>', 'dynamic-search-gmap-pro'); ?></li>
                    <li><?php _e('Add these pages to your navigation menu', 'dynamic-search-gmap-pro'); ?></li>
                </ol>
            </div>
        </div>
        <script>
        jQuery(document).ready(function($) {
            // Copy button functionality with smooth animations
            $('.dsgmp-copy-btn, .dsgmp-copy-btn-inline').on('click', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var textToCopy = $btn.data('copy');
                
                // Create temporary textarea
                var $temp = $('<textarea>');
                $('body').append($temp);
                $temp.val(textToCopy).select();
                
                try {
                    // Copy to clipboard
                    var successful = document.execCommand('copy');
                    
                    if (successful) {
                        // Animation and feedback
                        $btn.addClass('dsgmp-copied');
                        
                        // Change icon and text
                        var $icon = $btn.find('.dashicons');
                        var $text = $btn.find('.dsgmp-copy-text');
                        
                        $icon.removeClass('dashicons-clipboard').addClass('dashicons-yes-alt');
                        if ($text.length) {
                            $text.text('<?php _e('Copied!', 'dynamic-search-gmap-pro'); ?>');
                        }
                        
                        // Reset after animation
                        setTimeout(function() {
                            $btn.removeClass('dsgmp-copied');
                            $icon.removeClass('dashicons-yes-alt').addClass('dashicons-clipboard');
                            if ($text.length) {
                                $text.text('<?php _e('Copy', 'dynamic-search-gmap-pro'); ?>');
                            }
                        }, 2000);
                    } else {
                        // Fallback: Show alert
                        alert('<?php _e('Failed to copy. Please copy manually.', 'dynamic-search-gmap-pro'); ?>');
                    }
                } catch (err) {
                    // Fallback for older browsers
                    alert('<?php _e('Copy not supported. Please copy manually.', 'dynamic-search-gmap-pro'); ?>');
                }
                
                $temp.remove();
            });
        });
        </script>
        <?php
    }
    
    public function settings_page() {
        // Handle form submission
        if (isset($_POST['dsgmp_options']) && isset($_POST['_wpnonce'])) {
            // Verify nonce from settings_fields
            if (wp_verify_nonce($_POST['_wpnonce'], 'dsgmp_options_group-options')) {
                update_option('dsgmp_options', $_POST['dsgmp_options']);
                echo '<div class="notice notice-success"><p>' . __('Settings saved.', 'dynamic-search-gmap-pro') . '</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>' . __('Security check failed. Please try again.', 'dynamic-search-gmap-pro') . '</p></div>';
            }
        }
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'dynamic-search-gmap-pro'));
        }
        
        $options = get_option('dsgmp_options');
        ?>
        <div class="wrap dsgmp-admin-wrap">
            <h1>
                <span class="dashicons dashicons-admin-settings"></span>
                <?php _e('Dynamic Search GMap Pro - Settings', 'dynamic-search-gmap-pro'); ?>
            </h1>
            <div class="dsgmp-admin-card">
                <form method="post" action="" class="dsgmp-settings-form">
                    <?php settings_fields('dsgmp_options_group'); ?>
                    <?php do_settings_sections('dsgmp-settings'); ?>
                    <?php submit_button(); ?>
                </form>
            </div>
        </div>
        <?php
    }
    
    public function specialists_page() {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'dynamic-search-gmap-pro'));
        }
        
        // Handle delete action
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
            $nonce = isset($_GET['_wpnonce']) ? $_GET['_wpnonce'] : '';
            if (wp_verify_nonce($nonce, 'delete_specialist_' . $_GET['id'])) {
                $result = DSGMP_Database::delete_specialist(intval($_GET['id']));
                if ($result !== false) {
                    echo '<div class="notice notice-success"><p>' . __('Specialist deleted.', 'dynamic-search-gmap-pro') . '</p></div>';
                } else {
                    global $wpdb;
                    echo '<div class="notice notice-error"><p>' . __('Error deleting specialist: ', 'dynamic-search-gmap-pro') . $wpdb->last_error . '</p></div>';
                }
            } else {
                echo '<div class="notice notice-error"><p>' . __('Security check failed. Please try again.', 'dynamic-search-gmap-pro') . '</p></div>';
            }
        }
        
        $specialists = DSGMP_Database::get_specialists();
        $specialists_count = count($specialists);
        ?>
        <div class="wrap dsgmp-admin-wrap">
            <h1>
                <span class="dashicons dashicons-groups"></span>
                <?php _e('Specialists', 'dynamic-search-gmap-pro'); ?>
                <a href="<?php echo admin_url('admin.php?page=dsgmp-add-specialist'); ?>" class="page-title-action"><?php _e('Add New', 'dynamic-search-gmap-pro'); ?></a>
            </h1>
            
            <?php if ($specialists_count > 0): ?>
            <div class="dsgmp-stats-grid">
                <div class="dsgmp-stat-card">
                    <h3><?php _e('Total Specialists', 'dynamic-search-gmap-pro'); ?></h3>
                    <p class="stat-number"><?php echo $specialists_count; ?></p>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="dsgmp-admin-card">
                <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('ID', 'dynamic-search-gmap-pro'); ?></th>
                        <th><?php _e('Name/Company', 'dynamic-search-gmap-pro'); ?></th>
                        <th><?php _e('Specialty', 'dynamic-search-gmap-pro'); ?></th>
                        <th><?php _e('Location', 'dynamic-search-gmap-pro'); ?></th>
                        <th><?php _e('Rating', 'dynamic-search-gmap-pro'); ?></th>
                        <th><?php _e('Actions', 'dynamic-search-gmap-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($specialists)): ?>
                        <tr>
                            <td colspan="6"><?php _e('No specialists found.', 'dynamic-search-gmap-pro'); ?></td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($specialists as $specialist): ?>
                            <tr>
                                <td><?php echo esc_html($specialist->id); ?></td>
                                <td><strong><?php echo esc_html($specialist->name); ?></strong><br><?php echo esc_html($specialist->company); ?></td>
                                <td><?php echo esc_html($specialist->specialty); ?></td>
                                <td><?php echo esc_html($specialist->city . ', ' . $specialist->province); ?></td>
                                <td><?php echo esc_html(number_format($specialist->rating, 2)); ?> (<?php echo esc_html($specialist->rating_count); ?>)</td>
                                <td>
                                    <div class="dsgmp-action-buttons">
                                        <a href="<?php echo admin_url('admin.php?page=dsgmp-add-specialist&id=' . $specialist->id); ?>" class="dsgmp-btn-icon dsgmp-btn-edit"><?php _e('Edit', 'dynamic-search-gmap-pro'); ?></a>
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=dsgmp-specialists&action=delete&id=' . $specialist->id), 'delete_specialist_' . $specialist->id); ?>" class="dsgmp-btn-icon dsgmp-btn-delete" data-delete-name="<?php echo esc_attr($specialist->name); ?>"><?php _e('Delete', 'dynamic-search-gmap-pro'); ?></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            </div>
        </div>
        <?php
    }
    
    public function add_specialist_page() {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'dynamic-search-gmap-pro'));
        }
        
        $specialist_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        $specialist = null;
        
        if ($specialist_id) {
            $specialist = DSGMP_Database::get_specialist($specialist_id);
        }
        
        if (isset($_POST['save_specialist'])) {
            // Verify nonce
            if (!isset($_POST['dsgmp_save_specialist_nonce']) || !wp_verify_nonce($_POST['dsgmp_save_specialist_nonce'], 'dsgmp_save_specialist')) {
                echo '<div class="notice notice-error"><p>' . __('Security check failed. Please try again.', 'dynamic-search-gmap-pro') . '</p></div>';
            } else {
                // Validate required fields
                if (empty($_POST['name']) || empty($_POST['specialty']) || empty($_POST['address']) || empty($_POST['city'])) {
                    echo '<div class="notice notice-error"><p>' . __('Please fill in all required fields (Name, Specialty, Address, City).', 'dynamic-search-gmap-pro') . '</p></div>';
                } else {
                    $data = array(
                        'name' => sanitize_text_field($_POST['name']),
                        'company' => isset($_POST['company']) ? sanitize_text_field($_POST['company']) : '',
                        'specialty' => sanitize_text_field($_POST['specialty']),
                        'avatar' => isset($_POST['avatar']) ? esc_url_raw($_POST['avatar']) : '',
                        'address' => sanitize_text_field($_POST['address']),
                        'city' => sanitize_text_field($_POST['city']),
                        'province' => isset($_POST['province']) ? sanitize_text_field($_POST['province']) : '',
                        'postal_code' => isset($_POST['postal_code']) ? sanitize_text_field($_POST['postal_code']) : '',
                        'latitude' => isset($_POST['latitude']) && $_POST['latitude'] !== '' ? floatval($_POST['latitude']) : 40.4168,
                        'longitude' => isset($_POST['longitude']) && $_POST['longitude'] !== '' ? floatval($_POST['longitude']) : -3.7038,
                        'phone' => isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '',
                        'email' => isset($_POST['email']) ? sanitize_email($_POST['email']) : '',
                        'website' => isset($_POST['website']) ? esc_url_raw($_POST['website']) : '',
                        'rating' => isset($_POST['rating']) ? floatval($_POST['rating']) : 0,
                        'rating_count' => isset($_POST['rating_count']) ? intval($_POST['rating_count']) : 0,
                        'description' => isset($_POST['description']) ? sanitize_textarea_field($_POST['description']) : '',
                        'active' => isset($_POST['active']) ? 1 : 0
                    );
                    
                    if ($specialist_id) {
                        $result = DSGMP_Database::update_specialist($specialist_id, $data);
                        if ($result !== false) {
                            echo '<div class="notice notice-success"><p>' . __('Specialist updated.', 'dynamic-search-gmap-pro') . '</p></div>';
                            $specialist = DSGMP_Database::get_specialist($specialist_id);
                        } else {
                            global $wpdb;
                            $error_msg = $wpdb->last_error ? $wpdb->last_error : __('Database error occurred.', 'dynamic-search-gmap-pro');
                            echo '<div class="notice notice-error"><p>' . sprintf(__('Error updating specialist: %s', 'dynamic-search-gmap-pro'), esc_html($error_msg)) . '</p></div>';
                        }
                    } else {
                        $new_id = DSGMP_Database::insert_specialist($data);
                        if ($new_id) {
                            echo '<div class="notice notice-success"><p>' . __('Specialist added.', 'dynamic-search-gmap-pro') . '</p></div>';
                            $specialist_id = $new_id;
                            $specialist = DSGMP_Database::get_specialist($new_id);
                        } else {
                            global $wpdb;
                            echo '<div class="notice notice-error"><p>' . __('Error adding specialist: ', 'dynamic-search-gmap-pro') . $wpdb->last_error . '</p></div>';
                        }
                    }
                }
            }
        }
        
        $options = get_option('dsgmp_options');
        $api_key = isset($options['google_maps_api_key']) ? $options['google_maps_api_key'] : '';
        ?>
        <div class="wrap dsgmp-admin-wrap">
            <h1>
                <span class="dashicons dashicons-<?php echo $specialist_id ? 'edit' : 'plus-alt'; ?>"></span>
                <?php echo $specialist_id ? __('Edit Specialist', 'dynamic-search-gmap-pro') : __('Add Specialist', 'dynamic-search-gmap-pro'); ?>
            </h1>
            <div class="dsgmp-admin-card">
                <form method="post" id="dsgmp-specialist-form">
                <?php wp_nonce_field('dsgmp_save_specialist', 'dsgmp_save_specialist_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="name"><?php _e('Name', 'dynamic-search-gmap-pro'); ?> *</label></th>
                        <td><input type="text" id="name" name="name" value="<?php echo $specialist ? esc_attr($specialist->name) : ''; ?>" class="regular-text" required /></td>
                    </tr>
                    <tr>
                        <th><label for="company"><?php _e('Company', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td><input type="text" id="company" name="company" value="<?php echo $specialist ? esc_attr($specialist->company) : ''; ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="specialty"><?php _e('Specialty', 'dynamic-search-gmap-pro'); ?> *</label></th>
                        <td>
                            <?php 
                            $specialties = DSGMP_Database::get_specialty_names();
                            $current_specialty = $specialist ? $specialist->specialty : '';
                            ?>
                            <select id="specialty" name="specialty" class="regular-text" required style="width: 300px;">
                                <option value=""><?php _e('-- Select Specialty --', 'dynamic-search-gmap-pro'); ?></option>
                                <?php foreach ($specialties as $specialty_name): ?>
                                    <option value="<?php echo esc_attr($specialty_name); ?>" <?php selected($current_specialty, $specialty_name); ?>>
                                        <?php echo esc_html($specialty_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php _e('Or <a href="' . admin_url('admin.php?page=dsgmp-specialties') . '">add a new specialty</a>', 'dynamic-search-gmap-pro'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="avatar"><?php _e('Avatar / Profile Image', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td>
                            <input type="text" id="avatar" name="avatar" value="<?php echo $specialist ? esc_attr($specialist->avatar) : ''; ?>" class="regular-text" />
                            <button type="button" class="button dsgmp-upload-avatar-btn" id="dsgmp-upload-avatar"><?php _e('Upload Image', 'dynamic-search-gmap-pro'); ?></button>
                            <?php if ($specialist && !empty($specialist->avatar)): ?>
                                <p class="description">
                                    <img src="<?php echo esc_url($specialist->avatar); ?>" alt="Avatar" style="max-width: 100px; height: auto; margin-top: 10px; border-radius: 4px; display: block;" />
                                </p>
                            <?php endif; ?>
                            <p class="description"><?php _e('Enter image URL or upload an image for the specialist profile.', 'dynamic-search-gmap-pro'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="address"><?php _e('Address', 'dynamic-search-gmap-pro'); ?> *</label></th>
                        <td><input type="text" id="address" name="address" value="<?php echo $specialist ? esc_attr($specialist->address) : ''; ?>" class="regular-text" required /></td>
                    </tr>
                    <tr>
                        <th><label for="location_search"><?php _e('Location Search', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td>
                            <input type="text" id="location_search" placeholder="<?php _e('Type address, city, or postal code...', 'dynamic-search-gmap-pro'); ?>" class="regular-text" />
                            <p class="description"><?php _e('Start typing to search for location. This will auto-fill the address fields.', 'dynamic-search-gmap-pro'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="city"><?php _e('City', 'dynamic-search-gmap-pro'); ?> *</label></th>
                        <td><input type="text" id="city" name="city" value="<?php echo $specialist ? esc_attr($specialist->city) : ''; ?>" class="regular-text" required /></td>
                    </tr>
                    <tr>
                        <th><label for="province"><?php _e('Province', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td><input type="text" id="province" name="province" value="<?php echo $specialist ? esc_attr($specialist->province) : ''; ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="postal_code"><?php _e('Postal Code', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td><input type="text" id="postal_code" name="postal_code" value="<?php echo $specialist ? esc_attr($specialist->postal_code) : ''; ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="latitude"><?php _e('Latitude', 'dynamic-search-gmap-pro'); ?> *</label></th>
                        <td><input type="text" id="latitude" name="latitude" value="<?php echo $specialist ? esc_attr($specialist->latitude) : ''; ?>" class="regular-text" required /></td>
                    </tr>
                    <tr>
                        <th><label for="longitude"><?php _e('Longitude', 'dynamic-search-gmap-pro'); ?> *</label></th>
                        <td><input type="text" id="longitude" name="longitude" value="<?php echo $specialist ? esc_attr($specialist->longitude) : ''; ?>" class="regular-text" required /></td>
                    </tr>
                    <tr>
                        <th><label for="phone"><?php _e('Phone', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td><input type="text" id="phone" name="phone" value="<?php echo $specialist ? esc_attr($specialist->phone) : ''; ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="email"><?php _e('Email', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td><input type="email" id="email" name="email" value="<?php echo $specialist ? esc_attr($specialist->email) : ''; ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="website"><?php _e('Website', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td><input type="url" id="website" name="website" value="<?php echo $specialist ? esc_attr($specialist->website) : ''; ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="rating"><?php _e('Rating', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td><input type="number" id="rating" name="rating" value="<?php echo $specialist ? esc_attr($specialist->rating) : '0'; ?>" step="0.01" min="0" max="5" /></td>
                    </tr>
                    <tr>
                        <th><label for="rating_count"><?php _e('Rating Count', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td><input type="number" id="rating_count" name="rating_count" value="<?php echo $specialist ? esc_attr($specialist->rating_count) : '0'; ?>" min="0" /></td>
                    </tr>
                    <tr>
                        <th><label for="description"><?php _e('Description', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td><textarea id="description" name="description" rows="5" class="large-text"><?php echo $specialist ? esc_textarea($specialist->description) : ''; ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="active"><?php _e('Active', 'dynamic-search-gmap-pro'); ?></label></th>
                        <td><input type="checkbox" id="active" name="active" value="1" <?php echo ($specialist && $specialist->active) ? 'checked' : ''; ?> /></td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" name="save_specialist" class="button button-primary" value="<?php _e('Save Specialist', 'dynamic-search-gmap-pro'); ?>" />
                    <a href="<?php echo admin_url('admin.php?page=dsgmp-specialists'); ?>" class="button"><?php _e('Cancel', 'dynamic-search-gmap-pro'); ?></a>
                </p>
            </form>
            
            <?php if (!empty($api_key)): ?>
                <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_js($api_key); ?>&libraries=places&language=es"></script>
                <script>
                jQuery(document).ready(function($) {
                    var autocomplete = new google.maps.places.Autocomplete(document.getElementById('location_search'));
                    autocomplete.setComponentRestrictions({country: 'es'});
                    
                    autocomplete.addListener('place_changed', function() {
                        var place = autocomplete.getPlace();
                        
                        if (!place.geometry) {
                            return;
                        }
                        
                        // Extract address components
                        var address = '';
                        var city = '';
                        var province = '';
                        var postal_code = '';
                        
                        for (var i = 0; i < place.address_components.length; i++) {
                            var component = place.address_components[i];
                            var types = component.types;
                            
                            if (types.indexOf('street_number') !== -1) {
                                address = component.long_name + ' ';
                            }
                            if (types.indexOf('route') !== -1) {
                                address += component.long_name;
                            }
                            if (types.indexOf('locality') !== -1) {
                                city = component.long_name;
                            }
                            if (types.indexOf('administrative_area_level_2') !== -1) {
                                province = component.long_name;
                            }
                            if (types.indexOf('postal_code') !== -1) {
                                postal_code = component.long_name;
                            }
                        }
                        
                        $('#address').val(address || place.formatted_address);
                        $('#city').val(city);
                        $('#province').val(province);
                        $('#postal_code').val(postal_code);
                        $('#latitude').val(place.geometry.location.lat());
                        $('#longitude').val(place.geometry.location.lng());
                    });
                });
                </script>
            <?php endif; ?>
            </div>
        </div>
        <?php
    }
    
    public function specialties_page() {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'dynamic-search-gmap-pro'));
        }
        
        // Handle add/edit form submission
        if (isset($_POST['save_specialty'])) {
            if (isset($_POST['dsgmp_save_specialty_nonce']) && wp_verify_nonce($_POST['dsgmp_save_specialty_nonce'], 'dsgmp_save_specialty')) {
                $specialty_id = isset($_POST['specialty_id']) ? intval($_POST['specialty_id']) : 0;
                $data = array(
                    'name' => sanitize_text_field($_POST['name']),
                    'description' => sanitize_textarea_field($_POST['description']),
                    'active' => isset($_POST['active']) ? 1 : 0
                );
                
                if ($specialty_id) {
                    DSGMP_Database::update_specialty($specialty_id, $data);
                    echo '<div class="notice notice-success"><p>' . __('Specialty updated.', 'dynamic-search-gmap-pro') . '</p></div>';
                } else {
                    $new_id = DSGMP_Database::insert_specialty($data);
                    if ($new_id) {
                        echo '<div class="notice notice-success"><p>' . __('Specialty added.', 'dynamic-search-gmap-pro') . '</p></div>';
                    } else {
                        echo '<div class="notice notice-error"><p>' . __('Error adding specialty.', 'dynamic-search-gmap-pro') . '</p></div>';
                    }
                }
            }
        }
        
        // Handle delete action
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
            $nonce = isset($_GET['_wpnonce']) ? $_GET['_wpnonce'] : '';
            if (wp_verify_nonce($nonce, 'delete_specialty_' . $_GET['id'])) {
                $result = DSGMP_Database::delete_specialty(intval($_GET['id']));
                if ($result !== false) {
                    echo '<div class="notice notice-success"><p>' . __('Specialty deleted.', 'dynamic-search-gmap-pro') . '</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>' . __('Error deleting specialty.', 'dynamic-search-gmap-pro') . '</p></div>';
                }
            }
        }
        
        // Get specialty for editing
        $specialty_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        $specialty = null;
        if ($specialty_id) {
            $specialty = DSGMP_Database::get_specialty($specialty_id);
        }
        
        // Show form if editing or adding
        if (isset($_GET['action']) && ($_GET['action'] === 'add' || $_GET['action'] === 'edit')) {
            ?>
            <div class="wrap dsgmp-admin-wrap">
                <h1>
                    <span class="dashicons dashicons-<?php echo $specialty_id ? 'edit' : 'plus-alt'; ?>"></span>
                    <?php echo $specialty_id ? __('Edit Specialty', 'dynamic-search-gmap-pro') : __('Add Specialty', 'dynamic-search-gmap-pro'); ?>
                </h1>
                <a href="<?php echo admin_url('admin.php?page=dsgmp-specialties'); ?>" class="button"><?php _e('← Back to Specialties', 'dynamic-search-gmap-pro'); ?></a>
                <hr class="wp-header-end">
                
                <div class="dsgmp-admin-card">
                    <form method="post" id="dsgmp-specialty-form">
                    <?php wp_nonce_field('dsgmp_save_specialty', 'dsgmp_save_specialty_nonce'); ?>
                    <?php if ($specialty_id): ?>
                        <input type="hidden" name="specialty_id" value="<?php echo $specialty_id; ?>" />
                    <?php endif; ?>
                    <table class="form-table">
                        <tr>
                            <th><label for="name"><?php _e('Specialty Name', 'dynamic-search-gmap-pro'); ?> *</label></th>
                            <td><input type="text" id="name" name="name" value="<?php echo $specialty ? esc_attr($specialty->name) : ''; ?>" class="regular-text" required /></td>
                        </tr>
                        <tr>
                            <th><label for="description"><?php _e('Description', 'dynamic-search-gmap-pro'); ?></label></th>
                            <td><textarea id="description" name="description" rows="5" class="large-text"><?php echo $specialty ? esc_textarea($specialty->description) : ''; ?></textarea></td>
                        </tr>
                        <tr>
                            <th><label for="active"><?php _e('Active', 'dynamic-search-gmap-pro'); ?></label></th>
                            <td><input type="checkbox" id="active" name="active" value="1" <?php checked($specialty ? $specialty->active : 1, 1); ?> /></td>
                        </tr>
                    </table>
                    <p class="submit">
                        <input type="submit" name="save_specialty" class="button button-primary" value="<?php _e('Save Specialty', 'dynamic-search-gmap-pro'); ?>" />
                    </p>
                    </form>
                </div>
            </div>
            <?php
        } else {
            // Show list
            $specialties = DSGMP_Database::get_specialties();
            $specialties_count = count($specialties);
            $active_count = count(array_filter($specialties, function($s) { return $s->active; }));
            ?>
            <div class="wrap dsgmp-admin-wrap">
                <h1>
                    <span class="dashicons dashicons-category"></span>
                    <?php _e('Specialties', 'dynamic-search-gmap-pro'); ?>
                    <a href="<?php echo admin_url('admin.php?page=dsgmp-specialties&action=add'); ?>" class="page-title-action"><?php _e('Add New', 'dynamic-search-gmap-pro'); ?></a>
                </h1>
                
                <?php if ($specialties_count > 0): ?>
                <div class="dsgmp-stats-grid">
                    <div class="dsgmp-stat-card">
                        <h3><?php _e('Total Specialties', 'dynamic-search-gmap-pro'); ?></h3>
                        <p class="stat-number"><?php echo $specialties_count; ?></p>
                    </div>
                    <div class="dsgmp-stat-card success">
                        <h3><?php _e('Active', 'dynamic-search-gmap-pro'); ?></h3>
                        <p class="stat-number"><?php echo $active_count; ?></p>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="dsgmp-admin-card">
                    <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('ID', 'dynamic-search-gmap-pro'); ?></th>
                            <th><?php _e('Name', 'dynamic-search-gmap-pro'); ?></th>
                            <th><?php _e('Description', 'dynamic-search-gmap-pro'); ?></th>
                            <th><?php _e('Status', 'dynamic-search-gmap-pro'); ?></th>
                            <th><?php _e('Actions', 'dynamic-search-gmap-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($specialties)): ?>
                            <tr>
                                <td colspan="5"><?php _e('No specialties found.', 'dynamic-search-gmap-pro'); ?></td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($specialties as $spec): ?>
                                <tr>
                                    <td><?php echo esc_html($spec->id); ?></td>
                                    <td><strong><?php echo esc_html($spec->name); ?></strong></td>
                                    <td><?php echo esc_html($spec->description ?: '—'); ?></td>
                                    <td>
                                        <?php if ($spec->active): ?>
                                            <span class="dsgmp-status-active"><?php _e('Active', 'dynamic-search-gmap-pro'); ?></span>
                                        <?php else: ?>
                                            <span class="dsgmp-status-inactive"><?php _e('Inactive', 'dynamic-search-gmap-pro'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dsgmp-action-buttons">
                                            <a href="<?php echo admin_url('admin.php?page=dsgmp-specialties&action=edit&id=' . $spec->id); ?>" class="dsgmp-btn-icon dsgmp-btn-edit"><?php _e('Edit', 'dynamic-search-gmap-pro'); ?></a>
                                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=dsgmp-specialties&action=delete&id=' . $spec->id), 'delete_specialty_' . $spec->id); ?>" class="dsgmp-btn-icon dsgmp-btn-delete" data-delete-name="<?php echo esc_attr($spec->name); ?>"><?php _e('Delete', 'dynamic-search-gmap-pro'); ?></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    </table>
                </div>
            </div>
            <?php
        }
    }
    
    public function sync_users_page() {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'dynamic-search-gmap-pro'));
        }
        
        $synced = 0;
        $message = '';
        
        // Handle sync action
        if (isset($_POST['sync_users']) && isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'dsgmp_sync_users')) {
            $synced = DSGMP_Database::sync_all_specialist_users();
            $message = sprintf(__('Successfully synced %d specialist users to the map.', 'dynamic-search-gmap-pro'), $synced);
            echo '<div class="notice notice-success"><p>' . esc_html($message) . '</p></div>';
        }
        
        // Get user counts
        $specialist_users = get_users(array(
            'role' => 'specialist',
            'count_total' => true
        ));
        $total_specialists = count($specialist_users);
        
        // Check activation sync flag
        if (get_option('dsgmp_sync_on_activation')) {
            delete_option('dsgmp_sync_on_activation');
            $synced = DSGMP_Database::sync_all_specialist_users();
            $message = sprintf(__('Auto-synced %d specialist users after plugin activation.', 'dynamic-search-gmap-pro'), $synced);
            echo '<div class="notice notice-info"><p>' . esc_html($message) . '</p></div>';
        }
        ?>
        <div class="wrap dsgmp-admin-wrap">
            <h1>
                <span class="dashicons dashicons-update"></span>
                <?php _e('Sync WordPress Users', 'dynamic-search-gmap-pro'); ?>
            </h1>
            
            <div class="dsgmp-admin-card">
                <div class="dsgmp-admin-card-header">
                    <h2><?php _e('Sync Information', 'dynamic-search-gmap-pro'); ?></h2>
                </div>
                <div class="dsgmp-sync-section">
                    <p><strong><?php _e('Total Specialist Users:', 'dynamic-search-gmap-pro'); ?></strong> <span class="dsgmp-specialty-badge"><?php echo esc_html($total_specialists); ?></span></p>
                    <p><?php _e('When you click "Sync All Users", the plugin will:', 'dynamic-search-gmap-pro'); ?></p>
                    <ul>
                        <li><?php _e('Find all WordPress users with the "specialist" role', 'dynamic-search-gmap-pro'); ?></li>
                        <li><?php _e('Read their profile data (location, specialty, etc.) from user meta', 'dynamic-search-gmap-pro'); ?></li>
                        <li><?php _e('Create or update their entries in the specialists database table', 'dynamic-search-gmap-pro'); ?></li>
                        <li><?php _e('Make them appear on the map', 'dynamic-search-gmap-pro'); ?></li>
                    </ul>
                    
                    <form method="post" style="margin-top: 24px;">
                        <?php wp_nonce_field('dsgmp_sync_users'); ?>
                        <button type="submit" name="sync_users" class="button button-primary button-large">
                            <span class="dashicons dashicons-update"></span> <?php _e('Sync All Specialist Users', 'dynamic-search-gmap-pro'); ?>
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="dsgmp-admin-card">
                <div class="dsgmp-admin-card-header">
                    <h2><?php _e('Automatic Sync', 'dynamic-search-gmap-pro'); ?></h2>
                </div>
                <div class="dsgmp-sync-section">
                    <p><?php _e('The plugin automatically syncs specialists in the following situations:', 'dynamic-search-gmap-pro'); ?></p>
                    <ul>
                        <li><?php _e('When a user registers with the specialist role', 'dynamic-search-gmap-pro'); ?></li>
                        <li><?php _e('When a specialist updates their profile', 'dynamic-search-gmap-pro'); ?></li>
                        <li><?php _e('When specialist meta fields are updated', 'dynamic-search-gmap-pro'); ?></li>
                    </ul>
                    <p><em><?php _e('Manual sync is only needed if you want to force a refresh of all specialist data.', 'dynamic-search-gmap-pro'); ?></em></p>
                </div>
            </div>
            
            <div class="dsgmp-info-box">
                <h3><?php _e('How to Assign Specialist Role', 'dynamic-search-gmap-pro'); ?></h3>
                <p><?php _e('To make a WordPress user a specialist:', 'dynamic-search-gmap-pro'); ?></p>
                <ol>
                    <li><?php _e('Go to <strong>Users > All Users</strong>', 'dynamic-search-gmap-pro'); ?></li>
                    <li><?php _e('Edit a user', 'dynamic-search-gmap-pro'); ?></li>
                    <li><?php _e('In the "Role" dropdown, select <strong>Specialist</strong>', 'dynamic-search-gmap-pro'); ?></li>
                    <li><?php _e('Scroll down to "Specialist Information" section', 'dynamic-search-gmap-pro'); ?></li>
                    <li><?php _e('Fill in the specialist details (specialty, location, etc.)', 'dynamic-search-gmap-pro'); ?></li>
                    <li><?php _e('Click "Update User" - the user will be automatically synced', 'dynamic-search-gmap-pro'); ?></li>
                </ol>
            </div>
        </div>
        <?php
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'dsgmp') === false) {
            return;
        }
        
        // Enqueue modern admin styles
        wp_enqueue_style('dsgmp-admin-style', DSGMP_PLUGIN_URL . 'assets/css/admin.css', array(), DSGMP_VERSION);
        
        wp_enqueue_script('jquery');
        
        // Enqueue admin JavaScript for modals
        wp_enqueue_script('dsgmp-admin-script', DSGMP_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), DSGMP_VERSION, true);
        
        // Enqueue media uploader for avatar
        if ($hook === 'gmap-pro_page_dsgmp-add-specialist' || (isset($_GET['page']) && $_GET['page'] === 'dsgmp-add-specialist')) {
            wp_enqueue_media();
            wp_add_inline_script('jquery', '
                jQuery(document).ready(function($) {
                    $("#dsgmp-upload-avatar").on("click", function(e) {
                        e.preventDefault();
                        var image_frame;
                        if (image_frame) {
                            image_frame.open();
                        }
                        image_frame = wp.media({
                            title: "Select Avatar",
                            button: {
                                text: "Use this image"
                            },
                            multiple: false
                        });
                        image_frame.on("select", function() {
                            var selection = image_frame.state().get("selection").first();
                            var attachment = selection.toJSON();
                            $("#avatar").val(attachment.url);
                            if ($("#avatar-preview").length) {
                                $("#avatar-preview").attr("src", attachment.url).show();
                            } else {
                                $("#avatar").after(\'<p class="description"><img id="avatar-preview" src="\' + attachment.url + \'" alt="Avatar" style="max-width: 100px; height: auto; margin-top: 10px; border-radius: 4px; display: block;" /></p>\');
                            }
                        });
                        image_frame.open();
                    });
                });
            ');
        }
    }
}
