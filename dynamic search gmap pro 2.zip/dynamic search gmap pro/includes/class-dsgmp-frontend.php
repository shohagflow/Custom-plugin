<?php
/**
 * Frontend display class
 */

if (!defined('ABSPATH')) {
    exit;
}

class DSGMP_Frontend {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('dsgmp_map', array($this, 'map_shortcode'));
    }
    
    public function enqueue_scripts() {
        $options = get_option('dsgmp_options');
        $api_key = isset($options['google_maps_api_key']) ? $options['google_maps_api_key'] : '';
        
        if (empty($api_key)) {
            return;
        }
        
        // Enqueue Google Maps API
        wp_enqueue_script(
            'google-maps-api',
            'https://maps.googleapis.com/maps/api/js?key=' . esc_js($api_key) . '&libraries=places&language=es',
            array(),
            DSGMP_VERSION,
            true
        );
        
        // Enqueue plugin scripts
        wp_enqueue_script(
            'dsgmp-frontend',
            DSGMP_PLUGIN_URL . 'assets/js/frontend.js',
            array('jquery', 'google-maps-api'),
            DSGMP_VERSION,
            true
        );
        
        // Enqueue styles
        wp_enqueue_style(
            'dsgmp-frontend',
            DSGMP_PLUGIN_URL . 'assets/css/frontend.css',
            array(),
            DSGMP_VERSION
        );
        
        // Localize script with data
        wp_localize_script('dsgmp-frontend', 'dsgmpData', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('dsgmp_nonce'),
            'defaultZoom' => isset($options['default_zoom']) ? intval($options['default_zoom']) : 6,
            'defaultLat' => isset($options['default_lat']) ? floatval($options['default_lat']) : 40.4168,
            'defaultLng' => isset($options['default_lng']) ? floatval($options['default_lng']) : -3.7038,
            'distanceIncrement' => isset($options['distance_increment']) ? intval($options['distance_increment']) : 5,
            'maxDistance' => isset($options['max_distance']) ? intval($options['max_distance']) : 100
        ));
    }
    
    public function map_shortcode($atts) {
        $atts = shortcode_atts(array(
            'specialty' => '',
            'height' => '600px'
        ), $atts);
        
        // Get unique specialties for dropdown
            $specialties = DSGMP_Database::get_specialty_names();
        
        ob_start();
        ?>
        <div id="dsgmp-wrapper" class="dsgmp-wrapper">
            <!-- Top Search Bar -->
            <div class="dsgmp-search-bar">
                <div class="dsgmp-search-bar-inner">
                    <div class="dsgmp-search-field-dropdown">
                        <select id="dsgmp-specialty-search" class="dsgmp-select">
                            <option value=""><?php _e('Selecciona un especialista', 'dynamic-search-gmap-pro'); ?></option>
                            <?php foreach ($specialties as $specialty_name): ?>
                                <option value="<?php echo esc_attr($specialty_name); ?>" <?php selected($atts['specialty'], $specialty_name); ?>>
                                    <?php echo esc_html($specialty_name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="dsgmp-search-field-location">
                        <input type="text" id="dsgmp-location-search" class="dsgmp-location-input" placeholder="<?php _e('Introduce tu ubicación', 'dynamic-search-gmap-pro'); ?>" autocomplete="off" />
                        <span class="dsgmp-location-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                        </span>
                    </div>
                    
                    <button type="button" id="dsgmp-search-btn" class="dsgmp-btn-search">
                        <span class="dsgmp-search-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="11" cy="11" r="8"></circle>
                                <path d="m21 21-4.35-4.35"></path>
                            </svg>
                        </span>
                        <?php _e('Buscar', 'dynamic-search-gmap-pro'); ?>
                    </button>
                </div>
            </div>
            
            <!-- Main Container: Map (Left) + Results Panel (Right) -->
            <div id="dsgmp-map-container" class="dsgmp-map-container" style="height: <?php echo esc_attr($atts['height']); ?>;">
                <!-- Map on Left -->
                <div id="dsgmp-map" class="dsgmp-map"></div>
                
                <!-- Results Panel on Right -->
                <div class="dsgmp-results-panel-wrapper">
                    <div id="dsgmp-results-panel" class="dsgmp-results-panel">
                        <div id="dsgmp-results-list" class="dsgmp-results-list">
                            <div class="dsgmp-no-results">
                                <p><?php _e('No hay especialistas disponibles en este momento.', 'dynamic-search-gmap-pro'); ?></p>
                                <a href="#" class="dsgmp-view-more"><?php _e('Ver más especialistas →', 'dynamic-search-gmap-pro'); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="dsgmp-info-window-template" style="display: none;">
            <div class="dsgmp-info-window">
                <div class="dsgmp-info-avatar-wrapper">
                    <img class="dsgmp-info-avatar" src="" alt="" style="display: none;" />
                    <div class="dsgmp-info-avatar-placeholder" style="display: none;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                    </div>
                </div>
                <h4 class="dsgmp-info-name"></h4>
                <p class="dsgmp-info-company"></p>
                <p class="dsgmp-info-specialty"></p>
                <p class="dsgmp-info-location"></p>
                <p class="dsgmp-info-rating"></p>
                <p class="dsgmp-info-distance"></p>
                <div class="dsgmp-info-actions">
                    <div class="dsgmp-info-actions-row">
                        <button class="dsgmp-btn-call dsgmp-info-btn">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                            </svg>
                            <span><?php _e('Llamar', 'dynamic-search-gmap-pro'); ?></span>
                        </button>
                        <button class="dsgmp-btn-chat dsgmp-info-btn">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                            </svg>
                            <span><?php _e('Chat', 'dynamic-search-gmap-pro'); ?></span>
                        </button>
                    </div>
                    <button class="dsgmp-btn-view-profile dsgmp-info-btn dsgmp-btn-secondary">
                        <?php _e('Ver Perfil', 'dynamic-search-gmap-pro'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <?php
        return ob_get_clean();
    }
}
