<?php
/**
 * Elementor Profile Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

// Check if Elementor is loaded
if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class DSGMP_Elementor_Profile_Widget extends Widget_Base {
    
    public function get_name() {
        return 'dsgmp_profile';
    }
    
    public function get_title() {
        return __('GMap Pro - Specialist Profile', 'dynamic-search-gmap-pro');
    }
    
    public function get_icon() {
        return 'eicon-person';
    }
    
    public function get_categories() {
        return ['general'];
    }
    
    public function get_keywords() {
        return ['profile', 'specialist', 'user profile', 'gmap pro'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Profile Settings', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'info_notice',
            [
                'type' => Controls_Manager::RAW_HTML,
                'raw' => __('<p><strong>Note:</strong> This widget displays the profile of the currently logged-in specialist. Users must be logged in with the "specialist" role to view their profile.</p>', 'dynamic-search-gmap-pro'),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Container
        $this->start_controls_section(
            'style_container_section',
            [
                'label' => __('Container Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'container_background',
            [
                'label' => __('Background Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-profile-page' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'border_radius',
            [
                'label' => __('Border Radius', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-profile-page' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'container_border',
                'label' => __('Border', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-profile-page',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'container_shadow',
                'label' => __('Box Shadow', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-profile-page',
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Header
        $this->start_controls_section(
            'style_header_section',
            [
                'label' => __('Header Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'header_background',
            [
                'label' => __('Header Background', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FF6B36',
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-profile-header' => 'background: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'header_text_color',
            [
                'label' => __('Header Text Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-profile-header h1, {{WRAPPER}} .dsgmp-profile-header p' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'header_title_typography',
                'label' => __('Title Typography', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-profile-header h1',
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Content
        $this->start_controls_section(
            'style_content_section',
            [
                'label' => __('Content Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'label' => __('Content Typography', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-profile-content',
            ]
        );
        
        $this->add_control(
            'content_text_color',
            [
                'label' => __('Text Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-profile-content' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'heading_color',
            [
                'label' => __('Heading Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-profile-section h2' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Buttons
        $this->start_controls_section(
            'style_buttons_section',
            [
                'label' => __('Buttons Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'button_background',
            [
                'label' => __('Button Background', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FF6B36',
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-profile-actions .dsgmp-btn' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'button_text_color',
            [
                'label' => __('Button Text Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-profile-actions .dsgmp-btn' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'label' => __('Button Typography', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-profile-actions .dsgmp-btn',
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $shortcode = '[dsgmp_profile]';
        echo do_shortcode($shortcode);
    }
    
    protected function content_template() {
        ?>
        <div class="dsgmp-elementor-widget-preview">
            <div class="dsgmp-elementor-preview-icon">
                <i class="eicon-person"></i>
            </div>
            <div class="dsgmp-elementor-preview-text">
                <strong><?php _e('GMap Pro - Specialist Profile', 'dynamic-search-gmap-pro'); ?></strong>
                <p><?php _e('Displays specialist profile for logged-in users', 'dynamic-search-gmap-pro'); ?></p>
            </div>
        </div>
        <?php
    }
}
