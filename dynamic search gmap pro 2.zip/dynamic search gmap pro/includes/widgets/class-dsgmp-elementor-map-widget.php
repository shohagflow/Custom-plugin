<?php
/**
 * Elementor Map Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

// Check if Elementor is loaded
if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class DSGMP_Elementor_Map_Widget extends Widget_Base {
    
    public function get_name() {
        return 'dsgmp_map';
    }
    
    public function get_title() {
        return __('GMap Pro - Map Search', 'dynamic-search-gmap-pro');
    }
    
    public function get_icon() {
        return 'eicon-google-maps';
    }
    
    public function get_categories() {
        return ['general'];
    }
    
    public function get_keywords() {
        return ['map', 'google maps', 'location', 'search', 'specialist', 'gmap pro'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Map Settings', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'specialty',
            [
                'label' => __('Default Specialty', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::SELECT,
                'options' => $this->get_specialty_options(),
                'default' => '',
                'description' => __('Pre-select a specialty in the search dropdown', 'dynamic-search-gmap-pro'),
            ]
        );
        
        $this->add_control(
            'height',
            [
                'label' => __('Map Height', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 400,
                        'max' => 1200,
                        'step' => 50,
                    ],
                    'vh' => [
                        'min' => 40,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 600,
                ],
                'description' => __('Set the height of the map container', 'dynamic-search-gmap-pro'),
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Container
        $this->start_controls_section(
            'style_container_section',
            [
                'label' => __('Container Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'container_background',
            [
                'label' => __('Background Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-map-container' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'border_radius',
            [
                'label' => __('Border Radius', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-map-container' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'container_border',
                'label' => __('Border', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-map-container',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'container_shadow',
                'label' => __('Box Shadow', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-map-container',
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Search Bar
        $this->start_controls_section(
            'style_search_section',
            [
                'label' => __('Search Bar Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'search_bar_background',
            [
                'label' => __('Background Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-search-bar' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'search_bar_padding',
            [
                'label' => __('Padding', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-search-bar-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_control(
            'search_button_color',
            [
                'label' => __('Search Button Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FF6B36',
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-btn-search' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'search_button_text_color',
            [
                'label' => __('Search Button Text Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-btn-search' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'search_button_typography',
                'label' => __('Button Typography', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-btn-search',
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Results Panel
        $this->start_controls_section(
            'style_results_section',
            [
                'label' => __('Results Panel Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'results_background',
            [
                'label' => __('Background Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-results-panel' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'results_title_typography',
                'label' => __('Title Typography', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-result-item h4',
            ]
        );
        
        $this->add_control(
            'results_title_color',
            [
                'label' => __('Title Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-result-item h4' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'results_text_color',
            [
                'label' => __('Text Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-result-item' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    /**
     * Get specialty options for select control
     */
    private function get_specialty_options() {
        $options = ['' => __('-- Select Specialty --', 'dynamic-search-gmap-pro')];
        
        // Check if class exists to avoid fatal errors
        if (class_exists('DSGMP_Database')) {
            $specialties = DSGMP_Database::get_specialty_names();
            
            if (is_array($specialties)) {
                foreach ($specialties as $specialty) {
                    $options[$specialty] = $specialty;
                }
            }
        }
        
        return $options;
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $specialty = !empty($settings['specialty']) ? esc_attr($settings['specialty']) : '';
        $height = !empty($settings['height']['size']) ? $settings['height']['size'] . $settings['height']['unit'] : '600px';
        
        $shortcode = '[dsgmp_map';
        
        if (!empty($specialty)) {
            $shortcode .= ' specialty="' . esc_attr($specialty) . '"';
        }
        
        if (!empty($height)) {
            $shortcode .= ' height="' . esc_attr($height) . '"';
        }
        
        $shortcode .= ']';
        
        echo do_shortcode($shortcode);
    }
    
    protected function content_template() {
        ?>
        <div class="dsgmp-elementor-widget-preview">
            <div class="dsgmp-elementor-preview-icon">
                <i class="eicon-google-maps"></i>
            </div>
            <div class="dsgmp-elementor-preview-text">
                <strong><?php _e('GMap Pro - Map Search', 'dynamic-search-gmap-pro'); ?></strong>
                <p><?php _e('Interactive map with specialist search functionality', 'dynamic-search-gmap-pro'); ?></p>
            </div>
        </div>
        <?php
    }
}
