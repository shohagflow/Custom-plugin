<?php
/**
 * Elementor Auth Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

// Check if Elementor is loaded
if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class DSGMP_Elementor_Auth_Widget extends Widget_Base {
    
    public function get_name() {
        return 'dsgmp_auth';
    }
    
    public function get_title() {
        return __('GMap Pro - Login/Register', 'dynamic-search-gmap-pro');
    }
    
    public function get_icon() {
        return 'eicon-lock-user';
    }
    
    public function get_categories() {
        return ['general'];
    }
    
    public function get_keywords() {
        return ['login', 'register', 'authentication', 'specialist', 'gmap pro'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Settings', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'default_tab',
            [
                'label' => __('Default Tab', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'login' => __('Login', 'dynamic-search-gmap-pro'),
                    'register' => __('Register', 'dynamic-search-gmap-pro'),
                ],
                'default' => 'login',
                'description' => __('Which tab should be shown by default', 'dynamic-search-gmap-pro'),
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Container
        $this->start_controls_section(
            'style_container_section',
            [
                'label' => __('Container Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'container_background',
            [
                'label' => __('Background Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-auth-container' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'border_radius',
            [
                'label' => __('Border Radius', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-auth-container' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'container_border',
                'label' => __('Border', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-auth-container',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'container_shadow',
                'label' => __('Box Shadow', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-auth-container',
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Tabs
        $this->start_controls_section(
            'style_tabs_section',
            [
                'label' => __('Tabs Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'tab_background',
            [
                'label' => __('Tab Background', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-auth-tabs' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'active_tab_color',
            [
                'label' => __('Active Tab Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FF6B36',
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-auth-tab.active' => 'color: {{VALUE}}; border-bottom-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'tab_typography',
                'label' => __('Tab Typography', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-auth-tab',
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Buttons
        $this->start_controls_section(
            'style_buttons_section',
            [
                'label' => __('Buttons Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'button_background',
            [
                'label' => __('Button Background', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FF6B36',
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-btn-primary' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'button_text_color',
            [
                'label' => __('Button Text Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-btn-primary' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'label' => __('Button Typography', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-btn-primary',
            ]
        );
        
        $this->add_control(
            'button_border_radius',
            [
                'label' => __('Button Border Radius', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 6,
                ],
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-btn-primary' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section - Form Fields
        $this->start_controls_section(
            'style_fields_section',
            [
                'label' => __('Form Fields Style', 'dynamic-search-gmap-pro'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'field_border_color',
            [
                'label' => __('Border Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-auth-form input, {{WRAPPER}} .dsgmp-auth-form select, {{WRAPPER}} .dsgmp-auth-form textarea' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'field_focus_color',
            [
                'label' => __('Focus Border Color', 'dynamic-search-gmap-pro'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FF6B36',
                'selectors' => [
                    '{{WRAPPER}} .dsgmp-auth-form input:focus, {{WRAPPER}} .dsgmp-auth-form select:focus, {{WRAPPER}} .dsgmp-auth-form textarea:focus' => 'border-color: {{VALUE}}; box-shadow: 0 0 0 3px rgba({{VALUE.RGB}}, 0.1);',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'field_typography',
                'label' => __('Field Typography', 'dynamic-search-gmap-pro'),
                'selector' => '{{WRAPPER}} .dsgmp-auth-form input, {{WRAPPER}} .dsgmp-auth-form select, {{WRAPPER}} .dsgmp-auth-form textarea',
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $default_tab = !empty($settings['default_tab']) ? esc_attr($settings['default_tab']) : 'login';
        
        $shortcode = '[dsgmp_auth default_tab="' . $default_tab . '"]';
        
        echo do_shortcode($shortcode);
    }
    
    protected function content_template() {
        ?>
        <div class="dsgmp-elementor-widget-preview">
            <div class="dsgmp-elementor-preview-icon">
                <i class="eicon-lock-user"></i>
            </div>
            <div class="dsgmp-elementor-preview-text">
                <strong><?php _e('GMap Pro - Login/Register', 'dynamic-search-gmap-pro'); ?></strong>
                <p><?php _e('Specialist login and registration forms', 'dynamic-search-gmap-pro'); ?></p>
            </div>
        </div>
        <?php
    }
}
