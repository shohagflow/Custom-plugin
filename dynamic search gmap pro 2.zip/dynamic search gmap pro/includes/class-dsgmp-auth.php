<?php
/**
 * Specialist Authentication class - Login and Registration
 */

if (!defined('ABSPATH')) {
    exit;
}

class DSGMP_Auth {
    
    public function __construct() {
        // Register shortcodes
        add_shortcode('dsgmp_auth', array($this, 'auth_shortcode'));
        add_shortcode('dsgmp_profile', array($this, 'profile_shortcode'));
        
        // AJAX handlers
        add_action('wp_ajax_dsgmp_register', array($this, 'handle_registration'));
        add_action('wp_ajax_nopriv_dsgmp_register', array($this, 'handle_registration'));
        
        add_action('wp_ajax_dsgmp_login', array($this, 'handle_login'));
        add_action('wp_ajax_nopriv_dsgmp_login', array($this, 'handle_login'));
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_auth_scripts'));
        
        // AJAX handler to load auth form (for popups)
        add_action('wp_ajax_dsgmp_load_auth_form', array($this, 'ajax_load_auth_form'));
        add_action('wp_ajax_nopriv_dsgmp_load_auth_form', array($this, 'ajax_load_auth_form'));
        
        // Filter to force enqueue scripts when needed
        add_filter('dsgmp_force_enqueue_auth', array($this, 'force_enqueue_auth_scripts'));
    }
    
    /**
     * Enqueue authentication scripts and styles
     */
    public function enqueue_auth_scripts() {
        // Only enqueue on frontend (not in admin)
        if (is_admin()) {
            return;
        }
        
        global $post;
        
        // Check if shortcode is present in page content
        $has_auth_shortcode = false;
        $has_profile_shortcode = false;
        if (is_a($post, 'WP_Post')) {
            $has_auth_shortcode = has_shortcode($post->post_content, 'dsgmp_auth');
            $has_profile_shortcode = has_shortcode($post->post_content, 'dsgmp_profile');
        }
        
        // Also check if it's in widget areas or other locations
        if (!$has_auth_shortcode && is_active_widget(false, false, 'text', true)) {
            $widget_text = get_option('widget_text');
            if (is_array($widget_text)) {
                foreach ($widget_text as $widget) {
                    if (isset($widget['text'])) {
                        if (has_shortcode($widget['text'], 'dsgmp_auth')) {
                            $has_auth_shortcode = true;
                        }
                        if (has_shortcode($widget['text'], 'dsgmp_profile')) {
                            $has_profile_shortcode = true;
                        }
                    }
                }
            }
        }
        
        // Enqueue auth styles/scripts if auth shortcode is present OR always on frontend (for popup usage)
        if ($has_auth_shortcode || apply_filters('dsgmp_always_enqueue_auth', true)) {
            wp_enqueue_style('dsgmp-auth-style', DSGMP_PLUGIN_URL . 'assets/css/auth.css', array(), DSGMP_VERSION);
            wp_enqueue_script('dsgmp-auth-script', DSGMP_PLUGIN_URL . 'assets/js/auth.js', array('jquery'), DSGMP_VERSION, true);
            
            // Get Google Maps API key if available
            $options = get_option('dsgmp_options');
            $api_key = isset($options['google_maps_api_key']) ? $options['google_maps_api_key'] : '';
            
            wp_localize_script('dsgmp-auth-script', 'dsgmpAuth', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('dsgmp_auth_nonce'),
                'redirect_url' => $this->get_profile_page_url(),
                'apiKey' => $api_key,
                'css_url' => DSGMP_PLUGIN_URL . 'assets/css/auth.css?v=' . DSGMP_VERSION,
                'plugin_url' => DSGMP_PLUGIN_URL,
                'version' => DSGMP_VERSION
            ));
        }
    }
    
    /**
     * Force enqueue auth scripts (useful for popups)
     * Can be called manually or via filter
     */
    public function force_enqueue_auth_scripts() {
        if (!wp_style_is('dsgmp-auth-style', 'enqueued')) {
            wp_enqueue_style('dsgmp-auth-style', DSGMP_PLUGIN_URL . 'assets/css/auth.css', array(), DSGMP_VERSION);
        }
        if (!wp_script_is('dsgmp-auth-script', 'enqueued')) {
            wp_enqueue_script('dsgmp-auth-script', DSGMP_PLUGIN_URL . 'assets/js/auth.js', array('jquery'), DSGMP_VERSION, true);
            
            // Get Google Maps API key if available
            $options = get_option('dsgmp_options');
            $api_key = isset($options['google_maps_api_key']) ? $options['google_maps_api_key'] : '';
            
            wp_localize_script('dsgmp-auth-script', 'dsgmpAuth', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('dsgmp_auth_nonce'),
                'redirect_url' => $this->get_profile_page_url(),
                'apiKey' => $api_key,
                'css_url' => DSGMP_PLUGIN_URL . 'assets/css/auth.css?v=' . DSGMP_VERSION,
                'plugin_url' => DSGMP_PLUGIN_URL,
                'version' => DSGMP_VERSION
            ));
        }
    }
    
    /**
     * Authentication shortcode
     */
    public function auth_shortcode($atts) {
        // If user is already logged in, show profile link
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            $redirect_url = $this->get_profile_page_url();
            
            return '<div class="dsgmp-auth-container">
                <div class="dsgmp-auth-logged-in">
                    <p>' . sprintf(__('You are logged in as <strong>%s</strong>.', 'dynamic-search-gmap-pro'), esc_html($user->display_name)) . '</p>
                    <p><a href="' . esc_url($redirect_url) . '" class="dsgmp-btn">' . __('Edit Profile', 'dynamic-search-gmap-pro') . '</a></p>
                    <p><a href="' . esc_url(wp_logout_url(home_url())) . '" class="dsgmp-btn-secondary">' . __('Logout', 'dynamic-search-gmap-pro') . '</a></p>
                </div>
            </div>';
        }
        
        $atts = shortcode_atts(array(
            'default_tab' => 'login' // 'login' or 'register'
        ), $atts);
        
        ob_start();
        ?>
        <div class="dsgmp-auth-container">
            <div class="dsgmp-auth-tabs">
                <button class="dsgmp-auth-tab <?php echo $atts['default_tab'] === 'login' ? 'active' : ''; ?>" data-tab="login">
                    <?php _e('Login', 'dynamic-search-gmap-pro'); ?>
                </button>
                <button class="dsgmp-auth-tab <?php echo $atts['default_tab'] === 'register' ? 'active' : ''; ?>" data-tab="register">
                    <?php _e('Register', 'dynamic-search-gmap-pro'); ?>
                </button>
            </div>
            
            <div class="dsgmp-auth-content">
                <!-- Login Form -->
                <div class="dsgmp-auth-panel <?php echo $atts['default_tab'] === 'login' ? 'active' : ''; ?>" id="dsgmp-login-panel">
                    <form id="dsgmp-login-form" class="dsgmp-auth-form">
                        <div class="dsgmp-form-message" id="dsgmp-login-message"></div>
                        
                        <div class="dsgmp-form-group">
                            <label for="login_username"><?php _e('Username or Email', 'dynamic-search-gmap-pro'); ?> *</label>
                            <input type="text" id="login_username" name="username" required />
                        </div>
                        
                        <div class="dsgmp-form-group">
                            <label for="login_password"><?php _e('Password', 'dynamic-search-gmap-pro'); ?> *</label>
                            <input type="password" id="login_password" name="password" required />
                        </div>
                        
                        <div class="dsgmp-form-group">
                            <label>
                                <input type="checkbox" name="rememberme" value="forever" />
                                <?php _e('Remember me', 'dynamic-search-gmap-pro'); ?>
                            </label>
                        </div>
                        
                        <div class="dsgmp-form-group">
                            <button type="submit" class="dsgmp-btn dsgmp-btn-primary">
                                <?php _e('Login', 'dynamic-search-gmap-pro'); ?>
                            </button>
                        </div>
                        
                        <div class="dsgmp-form-footer">
                            <a href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php _e('Lost your password?', 'dynamic-search-gmap-pro'); ?></a>
                        </div>
                    </form>
                </div>
                
                <!-- Register Form -->
                <div class="dsgmp-auth-panel <?php echo $atts['default_tab'] === 'register' ? 'active' : ''; ?>" id="dsgmp-register-panel">
                    <form id="dsgmp-register-form" class="dsgmp-auth-form">
                        <div class="dsgmp-form-message" id="dsgmp-register-message"></div>
                        
                        <div class="dsgmp-form-row">
                            <div class="dsgmp-form-group">
                                <label for="register_username"><?php _e('Username', 'dynamic-search-gmap-pro'); ?> *</label>
                                <input type="text" id="register_username" name="username" required />
                            </div>
                            
                            <div class="dsgmp-form-group">
                                <label for="register_email"><?php _e('Email', 'dynamic-search-gmap-pro'); ?> *</label>
                                <input type="email" id="register_email" name="email" required />
                            </div>
                        </div>
                        
                        <div class="dsgmp-form-row">
                            <div class="dsgmp-form-group">
                                <label for="register_password"><?php _e('Password', 'dynamic-search-gmap-pro'); ?> *</label>
                                <input type="password" id="register_password" name="password" required />
                            </div>
                            
                            <div class="dsgmp-form-group">
                                <label for="register_password_confirm"><?php _e('Confirm Password', 'dynamic-search-gmap-pro'); ?> *</label>
                                <input type="password" id="register_password_confirm" name="password_confirm" required />
                            </div>
                        </div>
                        
                        <div class="dsgmp-form-group">
                            <label for="register_first_name"><?php _e('First Name', 'dynamic-search-gmap-pro'); ?> *</label>
                            <input type="text" id="register_first_name" name="first_name" required />
                        </div>
                        
                        <div class="dsgmp-form-group">
                            <label for="register_last_name"><?php _e('Last Name', 'dynamic-search-gmap-pro'); ?> *</label>
                            <input type="text" id="register_last_name" name="last_name" required />
                        </div>
                        
                        <div class="dsgmp-form-group">
                            <label for="register_company"><?php _e('Company Name', 'dynamic-search-gmap-pro'); ?></label>
                            <input type="text" id="register_company" name="company" />
                        </div>
                        
                        <div class="dsgmp-form-group">
                            <label for="register_specialty"><?php _e('Specialty', 'dynamic-search-gmap-pro'); ?> *</label>
                            <select id="register_specialty" name="specialty" required>
                                <option value=""><?php _e('-- Select Specialty --', 'dynamic-search-gmap-pro'); ?></option>
                                <?php 
                                $specialties = DSGMP_Database::get_specialty_names();
                                foreach ($specialties as $specialty_name): 
                                ?>
                                    <option value="<?php echo esc_attr($specialty_name); ?>">
                                        <?php echo esc_html($specialty_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="dsgmp-form-group">
                            <label for="register_phone"><?php _e('Phone', 'dynamic-search-gmap-pro'); ?></label>
                            <input type="tel" id="register_phone" name="phone" />
                        </div>
                        
                        <div class="dsgmp-form-group">
                            <label for="register_address"><?php _e('Address', 'dynamic-search-gmap-pro'); ?> *</label>
                            <input type="text" id="register_address" name="address" required />
                            <p class="description"><?php _e('Start typing your address and select from suggestions', 'dynamic-search-gmap-pro'); ?></p>
                        </div>
                        
                        <div class="dsgmp-form-row">
                            <div class="dsgmp-form-group">
                                <label for="register_city"><?php _e('City', 'dynamic-search-gmap-pro'); ?> *</label>
                                <input type="text" id="register_city" name="city" required />
                            </div>
                            
                            <div class="dsgmp-form-group">
                                <label for="register_province"><?php _e('Province', 'dynamic-search-gmap-pro'); ?></label>
                                <input type="text" id="register_province" name="province" />
                            </div>
                        </div>
                        
                        <div class="dsgmp-form-row">
                            <div class="dsgmp-form-group">
                                <label for="register_postal_code"><?php _e('Postal Code', 'dynamic-search-gmap-pro'); ?></label>
                                <input type="text" id="register_postal_code" name="postal_code" />
                            </div>
                            
                            <div class="dsgmp-form-group">
                                <label for="register_website"><?php _e('Website', 'dynamic-search-gmap-pro'); ?></label>
                                <input type="url" id="register_website" name="website" placeholder="https://" />
                            </div>
                        </div>
                        
                        <div class="dsgmp-form-group">
                            <label for="register_description"><?php _e('Description', 'dynamic-search-gmap-pro'); ?></label>
                            <textarea id="register_description" name="description" rows="4"></textarea>
                        </div>
                        
                        <!-- Hidden fields for coordinates (filled by autocomplete) -->
                        <input type="hidden" id="register_latitude" name="latitude" />
                        <input type="hidden" id="register_longitude" name="longitude" />
                        
                        <?php if (function_exists('wp_nonce_field')) {
                            wp_nonce_field('dsgmp_register_nonce', 'dsgmp_register_nonce');
                        } ?>
                        
                        <div class="dsgmp-form-group">
                            <button type="submit" class="dsgmp-btn dsgmp-btn-primary">
                                <?php _e('Register', 'dynamic-search-gmap-pro'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Handle registration AJAX request
     */
    public function handle_registration() {
        check_ajax_referer('dsgmp_auth_nonce', 'nonce');
        
        $username = isset($_POST['username']) ? sanitize_user($_POST['username']) : '';
        $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $password_confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
        $first_name = isset($_POST['first_name']) ? sanitize_text_field($_POST['first_name']) : '';
        $last_name = isset($_POST['last_name']) ? sanitize_text_field($_POST['last_name']) : '';
        $company = isset($_POST['company']) ? sanitize_text_field($_POST['company']) : '';
        $specialty = isset($_POST['specialty']) ? sanitize_text_field($_POST['specialty']) : '';
        $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
        $address = isset($_POST['address']) ? sanitize_text_field($_POST['address']) : '';
        $city = isset($_POST['city']) ? sanitize_text_field($_POST['city']) : '';
        $province = isset($_POST['province']) ? sanitize_text_field($_POST['province']) : '';
        $postal_code = isset($_POST['postal_code']) ? sanitize_text_field($_POST['postal_code']) : '';
        $website = isset($_POST['website']) ? esc_url_raw($_POST['website']) : '';
        $description = isset($_POST['description']) ? sanitize_textarea_field($_POST['description']) : '';
        $latitude = isset($_POST['latitude']) ? floatval($_POST['latitude']) : 0;
        $longitude = isset($_POST['longitude']) ? floatval($_POST['longitude']) : 0;
        
        // Validation
        if (empty($username)) {
            wp_send_json_error(array('message' => __('Username is required.', 'dynamic-search-gmap-pro')));
        }
        
        if (empty($email) || !is_email($email)) {
            wp_send_json_error(array('message' => __('Valid email is required.', 'dynamic-search-gmap-pro')));
        }
        
        if (empty($password) || strlen($password) < 6) {
            wp_send_json_error(array('message' => __('Password must be at least 6 characters.', 'dynamic-search-gmap-pro')));
        }
        
        if ($password !== $password_confirm) {
            wp_send_json_error(array('message' => __('Passwords do not match.', 'dynamic-search-gmap-pro')));
        }
        
        if (empty($first_name) || empty($last_name)) {
            wp_send_json_error(array('message' => __('First name and last name are required.', 'dynamic-search-gmap-pro')));
        }
        
        if (empty($specialty)) {
            wp_send_json_error(array('message' => __('Specialty is required.', 'dynamic-search-gmap-pro')));
        }
        
        if (empty($address) || empty($city)) {
            wp_send_json_error(array('message' => __('Address and city are required.', 'dynamic-search-gmap-pro')));
        }
        
        // Default coordinates to Madrid if not provided
        if ($latitude == 0 || $longitude == 0) {
            $latitude = 40.4168;
            $longitude = -3.7038;
        }
        
        // Check if username or email already exists
        if (username_exists($username)) {
            wp_send_json_error(array('message' => __('Username already exists.', 'dynamic-search-gmap-pro')));
        }
        
        if (email_exists($email)) {
            wp_send_json_error(array('message' => __('Email already registered.', 'dynamic-search-gmap-pro')));
        }
        
        // Create user
        $user_id = wp_create_user($username, $password, $email);
        
        if (is_wp_error($user_id)) {
            wp_send_json_error(array('message' => $user_id->get_error_message()));
        }
        
        // Set user role to specialist
        $user = new WP_User($user_id);
        $user->set_role('specialist');
        
        // Update user meta
        update_user_meta($user_id, 'first_name', $first_name);
        update_user_meta($user_id, 'last_name', $last_name);
        
        // Set specialist-specific meta
        update_user_meta($user_id, 'dsgmp_company', $company);
        update_user_meta($user_id, 'dsgmp_specialty', $specialty);
        update_user_meta($user_id, 'dsgmp_phone', $phone);
        update_user_meta($user_id, 'dsgmp_address', $address);
        update_user_meta($user_id, 'dsgmp_city', $city);
        update_user_meta($user_id, 'dsgmp_province', $province);
        update_user_meta($user_id, 'dsgmp_postal_code', $postal_code);
        update_user_meta($user_id, 'dsgmp_latitude', $latitude);
        update_user_meta($user_id, 'dsgmp_longitude', $longitude);
        update_user_meta($user_id, 'dsgmp_website', $website);
        update_user_meta($user_id, 'dsgmp_description', $description);
        
        // Auto-login the user
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id, true);
        
        // Sync user to specialist table (via User_Sync class)
        if (class_exists('DSGMP_User_Sync')) {
            $sync = new DSGMP_User_Sync();
            $sync->sync_user_to_specialist($user_id);
        }
        
        $redirect_url = $this->get_profile_page_url();
        
        wp_send_json_success(array(
            'message' => __('Registration successful! Redirecting...', 'dynamic-search-gmap-pro'),
            'redirect_url' => $redirect_url
        ));
    }
    
    /**
     * Handle login AJAX request
     */
    public function handle_login() {
        check_ajax_referer('dsgmp_auth_nonce', 'nonce');
        
        $username = isset($_POST['username']) ? sanitize_user($_POST['username']) : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $remember = isset($_POST['rememberme']) && $_POST['rememberme'] === 'forever';
        
        if (empty($username) || empty($password)) {
            wp_send_json_error(array('message' => __('Username and password are required.', 'dynamic-search-gmap-pro')));
        }
        
        // Try to authenticate
        $user = wp_authenticate($username, $password);
        
        if (is_wp_error($user)) {
            wp_send_json_error(array('message' => $user->get_error_message()));
        }
        
        // Check if user has specialist role
        if (!in_array('specialist', (array) $user->roles)) {
            wp_send_json_error(array('message' => __('This login is for specialists only.', 'dynamic-search-gmap-pro')));
        }
        
        // Log the user in
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, $remember);
        
        $redirect_url = $this->get_profile_page_url();
        
        wp_send_json_success(array(
            'message' => __('Login successful! Redirecting...', 'dynamic-search-gmap-pro'),
            'redirect_url' => $redirect_url
        ));
    }
    
    /**
     * AJAX handler to load auth form (for popups)
     */
    public function ajax_load_auth_form() {
        check_ajax_referer('dsgmp_auth_nonce', 'nonce');
        
        $default_tab = isset($_POST['default_tab']) ? sanitize_text_field($_POST['default_tab']) : 'login';
        
        // Force enqueue scripts/styles for this request
        $this->force_enqueue_auth_scripts();
        
        // Get the shortcode output
        $form_html = do_shortcode('[dsgmp_auth default_tab="' . esc_attr($default_tab) . '"]');
        
        // Get URLs for CSS and JS (in case they need to be loaded manually in popup)
        $css_url = DSGMP_PLUGIN_URL . 'assets/css/auth.css?v=' . DSGMP_VERSION;
        $js_url = DSGMP_PLUGIN_URL . 'assets/js/auth.js?v=' . DSGMP_VERSION;
        
        // Get CSS content for inline injection if needed
        $css_file = DSGMP_PLUGIN_DIR . 'assets/css/auth.css';
        $css_content = '';
        if (file_exists($css_file)) {
            $css_content = file_get_contents($css_file);
        }
        
        wp_send_json_success(array(
            'html' => $form_html,
            'css_url' => $css_url,
            'js_url' => $js_url,
            'css_content' => $css_content, // For inline injection in popups
            'message' => __('If CSS is not loading in popup, ensure the CSS file is included or inject the css_content inline.', 'dynamic-search-gmap-pro')
        ));
    }
    
    /**
     * Get specialist profile page URL
     */
    private function get_profile_page_url() {
        // First, check if there's a filter to customize the URL
        $profile_url = apply_filters('dsgmp_profile_page_url', '');
        
        if (!empty($profile_url)) {
            return $profile_url;
        }
        
        // Try to find a page with the [dsgmp_profile] shortcode
        $pages = get_pages(array(
            'post_status' => 'publish',
            'number' => 1,
            'meta_key' => '_wp_page_template',
            'hierarchical' => 0
        ));
        
        // Search for pages with the shortcode
        $profile_page = null;
        $all_pages = get_pages(array('post_status' => 'publish'));
        
        foreach ($all_pages as $page) {
            if (has_shortcode($page->post_content, 'dsgmp_profile')) {
                $profile_page = $page;
                break;
            }
        }
        
        if ($profile_page) {
            return get_permalink($profile_page->ID);
        }
        
        // Default to a common profile page slug (you can change this)
        $default_slug = apply_filters('dsgmp_profile_page_slug', 'specialist-profile');
        $page = get_page_by_path($default_slug);
        
        if ($page) {
            return get_permalink($page->ID);
        }
        
        // Fallback: try to get current page if it has the shortcode
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'dsgmp_profile')) {
            return get_permalink($post->ID);
        }
        
        // Last resort: return home URL with profile slug
        return home_url('/' . $default_slug . '/');
    }
    
    /**
     * Profile shortcode - Display specialist profile page
     */
    public function profile_shortcode($atts) {
        // Check if user is logged in
        if (!is_user_logged_in()) {
            return '<div class="dsgmp-profile-login-required">
                <p>' . __('Please log in to view your profile.', 'dynamic-search-gmap-pro') . '</p>
                <p><a href="#" class="dsgmp-btn" onclick="alert(\'' . __('Use [dsgmp_auth] shortcode to login', 'dynamic-search-gmap-pro') . '\'); return false;">' . __('Login', 'dynamic-search-gmap-pro') . '</a></p>
            </div>';
        }
        
        $user_id = get_current_user_id();
        $user = wp_get_current_user();
        
        // Check if user has specialist role
        if (!in_array('specialist', (array) $user->roles)) {
            return '<div class="dsgmp-profile-error">
                <p>' . __('This profile page is for specialists only.', 'dynamic-search-gmap-pro') . '</p>
            </div>';
        }
        
        // Get specialist data
        $specialist = DSGMP_Database::get_specialist_by_user_id($user_id);
        
        // If no specialist entry exists, sync it
        if (!$specialist && class_exists('DSGMP_User_Sync')) {
            $sync = new DSGMP_User_Sync();
            $sync->sync_user_to_specialist($user_id);
            $specialist = DSGMP_Database::get_specialist_by_user_id($user_id);
        }
        
        // Get user meta
        $first_name = get_user_meta($user_id, 'first_name', true);
        $last_name = get_user_meta($user_id, 'last_name', true);
        $company = get_user_meta($user_id, 'dsgmp_company', true);
        $specialty = get_user_meta($user_id, 'dsgmp_specialty', true);
        $phone = get_user_meta($user_id, 'dsgmp_phone', true);
        $address = get_user_meta($user_id, 'dsgmp_address', true);
        $city = get_user_meta($user_id, 'dsgmp_city', true);
        $province = get_user_meta($user_id, 'dsgmp_province', true);
        $postal_code = get_user_meta($user_id, 'dsgmp_postal_code', true);
        $website = get_user_meta($user_id, 'dsgmp_website', true);
        $description = get_user_meta($user_id, 'dsgmp_description', true);
        $avatar = get_user_meta($user_id, 'dsgmp_avatar', true);
        
        if (!$avatar) {
            $avatar = get_avatar_url($user_id, array('size' => 200));
        }
        
        ob_start();
        ?>
        <div class="dsgmp-profile-page">
            <div class="dsgmp-profile-header">
                <div class="dsgmp-profile-avatar">
                    <img src="<?php echo esc_url($avatar); ?>" alt="<?php echo esc_attr($first_name . ' ' . $last_name); ?>" />
                </div>
                <div class="dsgmp-profile-info">
                    <h1><?php echo esc_html($first_name . ' ' . $last_name); ?></h1>
                    <?php if ($company): ?>
                        <p class="dsgmp-profile-company"><?php echo esc_html($company); ?></p>
                    <?php endif; ?>
                    <?php if ($specialty): ?>
                        <p class="dsgmp-profile-specialty"><?php echo esc_html($specialty); ?></p>
                    <?php endif; ?>
                </div>
                <div class="dsgmp-profile-actions">
                    <a href="<?php echo admin_url('profile.php'); ?>" class="dsgmp-btn"><?php _e('Edit Profile', 'dynamic-search-gmap-pro'); ?></a>
                    <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="dsgmp-btn-secondary"><?php _e('Logout', 'dynamic-search-gmap-pro'); ?></a>
                </div>
            </div>
            
            <div class="dsgmp-profile-content">
                <div class="dsgmp-profile-section">
                    <h2><?php _e('Contact Information', 'dynamic-search-gmap-pro'); ?></h2>
                    <div class="dsgmp-profile-details">
                        <?php if ($phone): ?>
                            <p><strong><?php _e('Phone:', 'dynamic-search-gmap-pro'); ?></strong> <a href="tel:<?php echo esc_attr($phone); ?>"><?php echo esc_html($phone); ?></a></p>
                        <?php endif; ?>
                        <p><strong><?php _e('Email:', 'dynamic-search-gmap-pro'); ?></strong> <a href="mailto:<?php echo esc_attr($user->user_email); ?>"><?php echo esc_html($user->user_email); ?></a></p>
                        <?php if ($website): ?>
                            <p><strong><?php _e('Website:', 'dynamic-search-gmap-pro'); ?></strong> <a href="<?php echo esc_url($website); ?>" target="_blank"><?php echo esc_html($website); ?></a></p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="dsgmp-profile-section">
                    <h2><?php _e('Location', 'dynamic-search-gmap-pro'); ?></h2>
                    <div class="dsgmp-profile-details">
                        <?php if ($address): ?>
                            <p><strong><?php _e('Address:', 'dynamic-search-gmap-pro'); ?></strong> <?php echo esc_html($address); ?></p>
                        <?php endif; ?>
                        <?php if ($city): ?>
                            <p><strong><?php _e('City:', 'dynamic-search-gmap-pro'); ?></strong> <?php echo esc_html($city); ?><?php echo $province ? ', ' . esc_html($province) : ''; ?><?php echo $postal_code ? ' ' . esc_html($postal_code) : ''; ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if ($description): ?>
                <div class="dsgmp-profile-section">
                    <h2><?php _e('About', 'dynamic-search-gmap-pro'); ?></h2>
                    <div class="dsgmp-profile-description">
                        <?php echo wpautop(esc_html($description)); ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($specialist): ?>
                <div class="dsgmp-profile-section">
                    <h2><?php _e('Profile Status', 'dynamic-search-gmap-pro'); ?></h2>
                    <div class="dsgmp-profile-details">
                        <p><strong><?php _e('Status:', 'dynamic-search-gmap-pro'); ?></strong> 
                            <?php echo $specialist->active ? '<span class="dsgmp-status-active">' . __('Active', 'dynamic-search-gmap-pro') . '</span>' : '<span class="dsgmp-status-inactive">' . __('Inactive', 'dynamic-search-gmap-pro') . '</span>'; ?>
                        </p>
                        <?php if ($specialist->rating > 0): ?>
                            <p><strong><?php _e('Rating:', 'dynamic-search-gmap-pro'); ?></strong> 
                                <?php echo number_format($specialist->rating, 1); ?> 
                                <?php if ($specialist->rating_count > 0): ?>
                                    (<?php echo $specialist->rating_count; ?> <?php _e('reviews', 'dynamic-search-gmap-pro'); ?>)
                                <?php endif; ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
