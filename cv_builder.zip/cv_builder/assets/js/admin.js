/**
 * CV Builder Admin JavaScript
 */

(function($) {
    'use strict';

    const settings = window.cvBuilderSettings || {};

    if (settings.templates && Array.isArray(settings.templates)) {
        try {
            sessionStorage.setItem('cvBuilderTemplates', JSON.stringify(settings.templates));
        } catch (error) {
            console.warn('CV Builder: Unable to persist template list in sessionStorage.', error);
        }
    }

    function resolvePreviewUrl() {
        if (settings.previewUrl && typeof settings.previewUrl === 'string') {
            return settings.previewUrl;
        }

        try {
            const scripts = document.getElementsByTagName('script');
            for (let i = scripts.length - 1; i >= 0; i--) {
                const script = scripts[i];
                const src = script.getAttribute('src');
                if (!src) {
                    continue;
                }
                if (src.includes('assets/js/admin.js')) {
                    const url = new URL(src, window.location.href);
                    const path = url.pathname.replace(/assets\/js\/admin\.js.*$/, 'templete-preview/index.html');
                    url.pathname = path;
                    url.search = '';
                    url.hash = '';
                    return url.toString();
                }
            }
        } catch (error) {
            console.error('CV Builder: Failed to derive preview URL from script tag.', error);
        }

        return null;
    }

    const requiredFieldIds = [
        'name',
        'date_of_birth',
        'place_of_birth',
        'time_of_birth',
        'height',
        'education',
        'contact_number',
        'email_address'
    ];

    $(document).ready(function() {
        
        // Initialize each CV builder instance
        $('.cv-builder-wrapper').each(function() {
            const $wrapper = $(this);
            const instanceId = $wrapper.data('instance') || 'default';
            
            // Initialize sections for this instance
            initializeSections($wrapper);
            
            // Initialize photo upload for this instance
            initializePhotoUpload($wrapper, instanceId);
            
            // Initialize form data collection for this instance
            initializeFormData($wrapper, instanceId);
            
            // Initialize field manager
            initializeFieldManager($wrapper);
            
            // Initialize symbol modal
            initializeSymbolModal($wrapper);
            
            // Initialize date pickers
            initializeDatePickers($wrapper);
            
            // Initialize navigation
            initializeNavigation($wrapper);
            
            // Enforce numeric-only inputs where required
            enforceNumericInput($wrapper);

            // Enforce client-side email validation feedback
            enforceEmailValidation($wrapper);
        });
    });

    /**
     * Initialize collapsible sections
     */
    const SECTION_ANIMATION_DURATION = 280;

    function initializeSections($wrapper) {
        const $sections = $wrapper.find('.cv-builder-section');

        $sections.each(function() {
            const $section = $(this);
            if ($section.hasClass('active')) {
                openSection($section, 0, { focusFirst: false });
            } else {
                closeSection($section, 0);
            }
        });

        $wrapper.find('.cv-builder-section-header').on('click', function() {
            const $section = $(this).closest('.cv-builder-section');
            const isActive = $section.hasClass('active');

            if (isActive) {
                closeSection($section, 0);
                return;
            }

            $sections.not($section).each(function() {
                closeSection($(this), 0);
            });

            openSection($section, 0, { focusFirst: true });
        });
    }

    /**
     * Initialize photo upload functionality
     */
    function initializePhotoUpload($wrapper, instanceId) {
        const $uploadBtn = $wrapper.find('.cv-upload-photo-btn[data-instance="' + instanceId + '"]');
        const $uploadPlaceholder = $wrapper.find('.cv-builder-upload-placeholder[data-instance="' + instanceId + '"]');
        const $fileInput = $wrapper.find('#cv-photo-upload-' + instanceId);
        const $preview = $wrapper.find('.cv-builder-upload-preview[data-instance="' + instanceId + '"]');
        const $previewImg = $wrapper.find('#cv-photo-preview-' + instanceId);
        const $removeBtn = $wrapper.find('.cv-builder-upload-remove[data-instance="' + instanceId + '"]');

        // Click on button to trigger file input
        $uploadBtn.on('click', function() {
            $fileInput.click();
        });
        
        // Click on placeholder to trigger file input (if exists)
        $uploadPlaceholder.on('click', function() {
            $fileInput.click();
        });

        // Handle file selection
        $fileInput.on('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        // Show the photo upload modal
                        showPhotoUploadModal(e.target.result, instanceId);
                    };
                    reader.readAsDataURL(file);
                } else {
                    alert('Please select an image file.');
                    $fileInput.val('');
                }
            }
        });

        // Remove uploaded image
        $removeBtn.on('click', function(e) {
            e.stopPropagation();
            $fileInput.val('');
            $preview.hide();
            $uploadBtn.show();
        });

        // Drag and drop functionality
        const $uploadArea = $wrapper.find('.cv-builder-upload-area');
        
        $uploadArea.on('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).find('.cv-builder-upload-placeholder').css({
                'border-color': '#8B1538',
                'background': '#fff'
            });
        });

        $uploadArea.on('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).find('.cv-builder-upload-placeholder').css({
                'border-color': '#e0e0e0',
                'background': '#fafafa'
            });
        });

        $uploadArea.on('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).find('.cv-builder-upload-placeholder').css({
                'border-color': '#e0e0e0',
                'background': '#fafafa'
            });

            const files = e.originalEvent.dataTransfer.files;
            if (files.length > 0) {
                const file = files[0];
                if (file.type.startsWith('image/')) {
                    // Update file input
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    $fileInput[0].files = dataTransfer.files;

                    // Show preview in modal
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        // Show the photo upload modal
                        showPhotoUploadModal(e.target.result, instanceId);
                    };
                    reader.readAsDataURL(file);
                } else {
                    alert('Please select an image file.');
                }
            }
        });
    }

    /**
     * Initialize form data collection
     */
    function initializeFormData($wrapper, instanceId) {
        // Store wrapper reference for later use
        const $formWrapper = $wrapper;
        
        // Support both admin page and shortcode instances
        $wrapper.find('#cv-choose-template-btn-' + instanceId + ', #cv-choose-template-btn, .cv-choose-template-btn').on('click', function(e) {
            e.preventDefault();

            if (!validateContactFields($wrapper)) {
                return;
            }

            if (!validateRequiredFields($wrapper)) {
                return;
            }
            
            // Collect all form data for this instance
            const formData = {
                instance: instanceId,
                language: $wrapper.find('#cv-language-select-' + instanceId + ', #cv-language-select').val(),
                personal: {},
                family: {},
                contact: {},
                professional: {},
                photo: null
            };

            // Collect personal details - only active (checked) fields
            $wrapper.find('.cv-builder-section[data-section="personal"]').find('.cv-field-item').each(function() {
                const $fieldItem = $(this);
                const $toggle = $fieldItem.find('.cv-field-toggle');
                
                // Only collect if toggle is checked
                if ($toggle.length && $toggle.is(':checked')) {
                    const $input = findFieldValueInput($fieldItem);
                    if ($input.length) {
                        const fieldKey = $fieldItem.data('field-id') || $input.attr('name');
                        const value = getFieldValue($input);
                        if (fieldKey && value !== null && value !== undefined && String(value).trim() !== '') {
                            formData.personal[fieldKey] = {
                                label: getFieldLabel($fieldItem, fieldKey),
                                value: String(value).trim()
                            };
                        }
                    }
                }
            });

            // Collect family details - only active (checked) fields
            $wrapper.find('.cv-builder-section[data-section="family"]').find('.cv-field-item').each(function() {
                const $fieldItem = $(this);
                const $toggle = $fieldItem.find('.cv-field-toggle');
                
                // Only collect if toggle is checked
                if ($toggle.length && $toggle.is(':checked')) {
                    const $input = findFieldValueInput($fieldItem);
                    if ($input.length) {
                        const fieldKey = $fieldItem.data('field-id') || $input.attr('name');
                        const value = getFieldValue($input);
                        if (fieldKey && value !== null && value !== undefined && String(value).trim() !== '') {
                            formData.family[fieldKey] = {
                                label: getFieldLabel($fieldItem, fieldKey),
                                value: String(value).trim()
                            };
                        }
                    }
                }
            });

            // Collect contact details - only active (checked) fields
            $wrapper.find('.cv-builder-section[data-section="contact"]').find('.cv-field-item').each(function() {
                const $fieldItem = $(this);
                const $toggle = $fieldItem.find('.cv-field-toggle');
                
                // Only collect if toggle is checked
                if ($toggle.length && $toggle.is(':checked')) {
                    const $input = findFieldValueInput($fieldItem);
                    if ($input.length) {
                        const fieldKey = $fieldItem.data('field-id') || $input.attr('name');
                        const value = getFieldValue($input);
                        if (fieldKey && value !== null && value !== undefined && String(value).trim() !== '') {
                            formData.contact[fieldKey] = {
                                label: getFieldLabel($fieldItem, fieldKey),
                                value: String(value).trim()
                            };
                        }
                    }
                }
            });

            // Collect professional details - only active (checked) fields
            $wrapper.find('.cv-builder-section[data-section="professional"]').find('.cv-field-item').each(function() {
                const $fieldItem = $(this);
                const $toggle = $fieldItem.find('.cv-field-toggle');
                
                // Only collect if toggle is checked
                if ($toggle.length && $toggle.is(':checked')) {
                    const $input = findFieldValueInput($fieldItem);
                    if ($input.length) {
                        const fieldKey = $fieldItem.data('field-id') || $input.attr('name');
                        const value = getFieldValue($input);
                        if (fieldKey && value !== null && value !== undefined && String(value).trim() !== '') {
                            formData.professional[fieldKey] = {
                                label: getFieldLabel($fieldItem, fieldKey),
                                value: String(value).trim()
                            };
                        }
                    }
                }
            });

            // Collect photo
            const $photoPreview = $('#cv-photo-preview-' + instanceId);
            if ($photoPreview.length && $photoPreview.attr('src')) {
                formData.photo = $photoPreview.attr('src');
            }

            // Get Ganesha icon
            const $ganeshaImg = $wrapper.find('.cv-field-ganesha-image img');
            if ($ganeshaImg.length && $ganeshaImg.attr('src')) {
                formData.ganesha_icon = $ganeshaImg.attr('src');
            }

            const selectedTemplate = sessionStorage.getItem('cvBuilderSelectedTemplate');
            if (selectedTemplate) {
                formData.template_image = selectedTemplate;
            }

            // Get header text fields
            $wrapper.find('.cv-header-text').each(function() {
                const text = $(this).text().trim();
                if (text.includes('Shree Ganesh') || text.includes('गणेश') || text.includes('Ganesh')) {
                    formData.shree_ganesh_text = text;
                } else if (text === 'Biodata' || text.includes('Biodata')) {
                    formData.biodata_text = text;
                }
            });

            // Persist data for template preview step
            try {
                sessionStorage.setItem('cvBuilderFormData', JSON.stringify(formData));
            } catch (error) {
                console.error('CV Builder: Failed to cache form data for preview.', error);
            }

            // Navigate to preview template step
            const previewUrl = resolvePreviewUrl();

            if (previewUrl) {
                const url = previewUrl + (previewUrl.includes('?') ? '&' : '?') + 'instance=' + encodeURIComponent(instanceId);
                window.location.href = url;
            } else {
                console.warn('CV Builder: Preview URL not configured.');
            }
        });
    }

    function validateRequiredFields($wrapper) {
        for (let i = 0; i < requiredFieldIds.length; i++) {
            const fieldId = requiredFieldIds[i];
            const $fieldItem = $wrapper.find('.cv-field-item[data-field-id="' + fieldId + '"]');
            if (!$fieldItem.length) {
                continue;
            }

            const $toggle = $fieldItem.find('.cv-field-toggle');
            if ($toggle.length && !$toggle.is(':checked')) {
                $toggle.prop('checked', true);
            }

            const $input = findFieldValueInput($fieldItem);
            if (!$input.length) {
                continue;
            }

            const value = getFieldValue($input);
            if (value === null || value === undefined || String(value).trim() === '') {
                const label = getFieldLabel($fieldItem, fieldId) || formatLabelFromKey(fieldId);
                showPopupAlert('Please fill the ' + label + ' field before continuing.');
                if ($input.length && typeof $input.focus === 'function') {
                    $input.focus();
                }
                return false;
            }

            if (fieldId === 'email_address') {
                const emailValue = String(value).trim();
                if (emailValue && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue)) {
                    showPopupAlert('Please enter a valid Email Address.');
                    if ($input.length && typeof $input.focus === 'function') {
                        $input.focus();
                    }
                    return false;
                }
            }

            if (fieldId === 'contact_number') {
                const numberValue = String(value).trim();
                if (numberValue && !/^\d+$/.test(numberValue)) {
                    showPopupAlert('Contact Number should contain digits only.');
                    if ($input.length) {
                        $input.val(numberValue.replace(/\D/g, ''));
                        if (typeof $input.focus === 'function') {
                            $input.focus();
                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }

    function validateContactFields($wrapper) {
        const validations = [
            {
                selector: 'input[name="contact_number"]',
                type: 'number',
                label: 'Contact Number'
            },
            {
                selector: 'input[name="father_contact_number"]',
                type: 'number',
                label: 'Father Contact Number'
            },
            {
                selector: 'input[name="email_address"]',
                type: 'email',
                label: 'Email Address'
            }
        ];

        for (let i = 0; i < validations.length; i++) {
            const { selector, type, label } = validations[i];
            const $input = $wrapper.find(selector);
            if (!$input.length) {
                continue;
            }

            const value = ($input.val() || '').trim();
            if (!value) {
                continue;
            }

            if (type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                showPopupAlert('Please enter a valid ' + label + '.');
                if (typeof $input.focus === 'function') {
                    $input.focus();
                }
                return false;
            }

            if (type === 'number' && !/^\d+$/.test(value)) {
                const sanitized = value.replace(/\D/g, '');
                showPopupAlert(label + ' should contain digits only.');
                $input.val(sanitized);
                if (typeof $input.focus === 'function') {
                    $input.focus();
                }
                return false;
            }
        }

        return true;
    }

    function enforceNumericInput($wrapper) {
        const selectors = [
            'input[name="contact_number"]',
            'input[name="father_contact_number"]'
        ];

        selectors.forEach(function(selector) {
            $wrapper.on('input', selector, function() {
                const sanitized = this.value.replace(/\D/g, '');
                if (this.value !== sanitized) {
                    this.value = sanitized;
                }
            });
        });
    }

    function enforceEmailValidation($wrapper) {
        const selector = 'input[name="email_address"]';
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        $wrapper.on('input', selector, function() {
            this.setCustomValidity('');
            const value = this.value.trim();
            if (!value) {
                return;
            }
            if (!emailPattern.test(value)) {
                this.setCustomValidity('Please enter a valid Email Address.');
            }
        });

        $wrapper.on('blur', selector, function() {
            const value = this.value.trim();
            if (!value) {
                return;
            }
            if (!emailPattern.test(value)) {
                showPopupAlert('Please enter a valid Email Address.');
                const input = this;
                setTimeout(function() {
                    input.focus();
                }, 0);
            }
        });
    }

    function showPopupAlert(message) {
        const $existingModal = $('#cv-builder-alert-modal');
        let $modal = $existingModal;

        if (!$existingModal.length) {
            $modal = $('<div>', {
                class: 'cv-builder-modal',
                id: 'cv-builder-alert-modal',
                role: 'dialog',
                'aria-modal': 'true',
                'aria-live': 'assertive'
            });

            const $overlay = $('<div>', { class: 'cv-builder-modal__overlay' });
            const $content = $('<div>', { class: 'cv-builder-modal__content' });
            const $body = $('<div>', { class: 'cv-builder-modal__body' });
            const $message = $('<p>', { class: 'cv-builder-modal__message', text: '' });
            const $footer = $('<div>', { class: 'cv-builder-modal__footer' });
            const $button = $('<button>', {
                type: 'button',
                class: 'cv-builder-modal__button',
                text: 'OK'
            });

            $body.append($message);
            $footer.append($button);
            $content.append($body, $footer);
            $modal.append($overlay, $content);

            $('body').append($modal);
            $modal.on('click', '.cv-builder-modal__overlay, .cv-builder-modal__button', function() {
                $modal.removeClass('is-visible');
            });
        }

        $modal.off('keydown.cvBuilderModal').on('keydown.cvBuilderModal', function(event) {
            if (event.key === 'Escape') {
                event.preventDefault();
                $modal.removeClass('is-visible');
            }
        });

        $modal.find('.cv-builder-modal__message').text(message);
        $modal.addClass('is-visible');
        const $button = $modal.find('.cv-builder-modal__button');
        if ($button.length) {
            $button.trigger('focus');
        }
    }

    function getFieldLabel($fieldItem, fallbackKey) {
        let label = '';

        const $editableLabel = $fieldItem.find('.cv-field-label-edit');
        if ($editableLabel.length) {
            label = $editableLabel.val();
        }

        if (!label) {
            const $labelInput = $fieldItem.find('.cv-field-label-input');
            if ($labelInput.length) {
                label = $labelInput.val();
            }
        }

        if (!label) {
            const $labelSpan = $fieldItem.find('.cv-field-label').first();
            if ($labelSpan.length) {
                label = $labelSpan.text();
            }
        }

        if (!label) {
            const $headerText = $fieldItem.find('.cv-header-text').first();
            if ($headerText.length) {
                label = $headerText.text();
            }
        }

        label = (label || '').trim();

        if (!label && fallbackKey) {
            label = formatLabelFromKey(fallbackKey);
        }

        return label;
    }

    function formatLabelFromKey(key) {
        if (!key) {
            return '';
        }
        const formatted = key
            .toString()
            .replace(/[_-]+/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
        return formatted.charAt(0).toUpperCase() + formatted.slice(1);
    }

    function findFieldValueInput($fieldItem) {
        return $fieldItem.find('.cv-field-input, .cv-field-select').filter(function() {
            const $el = $(this);
            if ($el.hasClass('cv-field-toggle')) {
                return false;
            }
            if ($el.is('input') && $el.attr('type') === 'checkbox' && $el.hasClass('cv-field-toggle')) {
                return false;
            }
            return true;
        }).first();
    }

    function getFieldValue($input) {
        if (!$input || !$input.length) {
            return null;
        }

        if ($input.is('select') || $input.hasClass('cv-field-select')) {
            const selectedOption = $input.find('option:selected');
            if (selectedOption.length) {
                const text = selectedOption.text();
                return text !== undefined ? text : $input.val();
            }
            return $input.val();
        }

        if ($input.is('textarea')) {
            return $input.val();
        }

        if ($input.is('input[type="checkbox"]')) {
            if ($input.hasClass('cv-field-toggle')) {
                return '';
            }
            return $input.is(':checked') ? ($input.val() || 'Yes') : '';
        }

        if ($input.is('input[type="radio"]')) {
            const name = $input.attr('name');
            if (!name) {
                return $input.is(':checked') ? $input.val() : '';
            }
            const $checked = $('input[name="' + name + '"]:checked', $input.closest('form'));
            return $checked.length ? $checked.val() : '';
        }

        return $input.val();
    }


    /**
     * Initialize field manager functionality
     */
    function initializeFieldManager($wrapper) {
        const fieldCounters = new WeakMap();

        $wrapper.find('.cv-field-manager-fields').each(function() {
            fieldCounters.set(this, $(this).find('.cv-field-item').length);
        });

        // Toggle field visibility
        $wrapper.on('change', '.cv-field-toggle', function() {
            const $field = $(this).closest('.cv-field-item');
            if ($(this).is(':checked')) {
                $field.removeClass('disabled');
            } else {
                $field.addClass('disabled');
            }
        });

        // Move field up
        $wrapper.on('click', '.cv-field-move-up', function() {
            const $field = $(this).closest('.cv-field-item');
            const $container = $field.closest('.cv-field-manager-fields');
            const $prev = $field.prev('.cv-field-item');
            if ($prev.length) {
                $field.insertBefore($prev);
                updateFieldOrders($container);
            }
        });

        // Move field down
        $wrapper.on('click', '.cv-field-move-down', function() {
            const $field = $(this).closest('.cv-field-item');
            const $container = $field.closest('.cv-field-manager-fields');
            const $next = $field.next('.cv-field-item');
            if ($next.length) {
                $field.insertAfter($next);
                updateFieldOrders($container);
            }
        });

        // Delete field
        $wrapper.on('click', '.cv-field-delete', function() {
            if (confirm('Are you sure you want to delete this field?')) {
                const $container = $(this).closest('.cv-field-manager-fields');
                $(this).closest('.cv-field-item').remove();
                updateFieldOrders($container);
                const containerEl = $container.get(0);
                if (containerEl) {
                    fieldCounters.set(containerEl, $container.find('.cv-field-item').length);
                }
            }
        });

        // Add new field
        $wrapper.on('click', '.cv-add-field-btn', function() {
            const $button = $(this);
            const $section = $button.closest('.cv-builder-section');
            const $container = $section.find('.cv-field-manager-fields').first();

            if (!$container.length) {
                return;
            }

            const containerEl = $container.get(0);
            let fieldCounter = fieldCounters.get(containerEl);
            if (typeof fieldCounter !== 'number') {
                fieldCounter = $container.find('.cv-field-item').length;
            }

            fieldCounter += 1;
            fieldCounters.set(containerEl, fieldCounter);

            const sectionKey = ($container.data('section') || 'custom').toString();
            const fieldId = sectionKey + '_custom_field_' + fieldCounter;
            const fieldHtml = `
                <div class="cv-field-item" data-field-id="${fieldId}" data-field-order="${fieldCounter}">
                    <div class="cv-field-controls-left">
                        <label class="cv-toggle-switch">
                            <input type="checkbox" class="cv-field-toggle" checked>
                            <span class="cv-toggle-slider"></span>
                        </label>
                        <button type="button" class="cv-field-edit-btn" title="Edit">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                <path d="M11.333 2.00012C11.5084 1.82475 11.7163 1.68587 11.9439 1.59215C12.1715 1.49843 12.4144 1.45166 12.6597 1.45462C12.905 1.45758 13.1477 1.51021 13.3731 1.60931C13.5985 1.70841 13.8023 1.85191 13.9733 2.02292C14.1444 2.19394 14.2879 2.39772 14.387 2.62314C14.4861 2.84856 14.5387 3.09127 14.5417 3.33657C14.5447 3.58187 14.4979 3.82481 14.4042 4.0524C14.3105 4.27998 14.1716 4.48792 13.9963 4.66329L13.333 5.32662L10.6733 2.66695L11.333 2.00012Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M9.33333 4.00012L11.9997 6.66646" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <input type="text" class="cv-field-label-input" placeholder="Field Label" style="min-width: 120px; padding: 4px 8px; border: 1px solid #e0e0e0; border-radius: 4px;">
                        <input type="text" name="${fieldId}" class="cv-field-input" placeholder="Enter value">
                    </div>
                    <div class="cv-field-controls-right">
                        <button type="button" class="cv-field-move-up" title="Move up">↑</button>
                        <button type="button" class="cv-field-move-down" title="Move down">↓</button>
                        <button type="button" class="cv-field-delete" title="Delete">×</button>
                    </div>
                </div>
            `;
            $container.append(fieldHtml);
            updateFieldOrders($container);
        });

        // Edit field label (double click to edit)
        $wrapper.on('dblclick', '.cv-field-label', function() {
            editFieldLabel($(this));
        });

        // Edit button click - make field editable
        $wrapper.on('click', '.cv-field-edit-btn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const $editBtn = $(this);
            const $field = $editBtn.closest('.cv-field-item');
            
            // Skip if it's the Ganesha edit button (has special modal functionality)
            if ($editBtn.hasClass('cv-ganesha-edit-btn')) {
                return; // Let the symbol modal handle this
            }
            
            // Check if it's a header field with text (Shree Ganesh, Biodata)
            const $headerTextField = $field.find('.cv-header-text-field');
            if ($headerTextField.length) {
                const $label = $headerTextField.find('.cv-header-text');
                if ($label.length && !$label.is('input')) {
                    editFieldLabel($label);
                    return;
                }
            }
            
            // For regular fields, focus the input
            const $input = $field.find('.cv-field-input');
            const $select = $field.find('.cv-field-select');
            const $textarea = $field.find('textarea.cv-field-input');
            
            if ($input.length && !$select.length && !$textarea.length) {
                // Regular text input
                $input.focus().select();
            } else if ($select.length) {
                // Select dropdown
                $select.focus();
                // Try to open dropdown (this works in some browsers)
                if ($select[0].options.length > 0) {
                    $select[0].size = Math.min($select[0].options.length, 10);
                    setTimeout(function() {
                        $(document).on('click.selectEdit', function(e) {
                            if (!$(e.target).closest($select).length) {
                                $select[0].size = 1;
                                $(document).off('click.selectEdit');
                            }
                        });
                    }, 100);
                }
            } else if ($textarea.length) {
                // Textarea
                $textarea.focus();
                // Move cursor to end
                const textLength = $textarea.val().length;
                $textarea[0].setSelectionRange(textLength, textLength);
            }
        });
    }
    
    /**
     * Edit field label inline
     */
    function editFieldLabel($label) {
        if ($label.is('input')) {
            return; // Already editing
        }
        
        const currentText = $label.text();
        const $input = $('<input>', {
            type: 'text',
            class: 'cv-field-label-edit',
            val: currentText,
            css: {
                minWidth: '120px',
                padding: '4px 8px',
                border: '1px solid #8B1538',
                borderRadius: '4px',
                fontSize: '14px',
                fontWeight: '500'
            }
        });
        $label.replaceWith($input);
        $input.focus().select();

        $input.on('blur', function() {
            const newText = $(this).val().trim() || $label.text() || 'Field Label';
            const $newLabel = $('<span>', {
                class: $label.attr('class') || 'cv-field-label',
                text: newText
            });
            $(this).replaceWith($newLabel);
        });

        $input.on('keypress', function(e) {
            if (e.which === 13) {
                $(this).blur();
            }
        });
    }

    /**
     * Update field order attributes
     */
    function updateFieldOrders($container) {
        $container.find('.cv-field-item').each(function(index) {
            $(this).attr('data-field-order', index);
        });
    }

    function openSection($section, duration, options) {
        if (!$section || !$section.length) {
            return;
        }

        const opts = options || {};
        const shouldFocus = opts.focusFirst !== false;

        const $content = $section.find('.cv-builder-section-content').first();
        const $arrowDown = $section.find('.cv-arrow-down');
        const $arrowUp = $section.find('.cv-arrow-up');

        // Remove any inline styles
        $content.removeAttr('style');
        
        // Add active class - CSS will handle the display
        $section.addClass('active');
        
        if ($arrowDown.length) {
            $arrowDown.hide();
        }
        if ($arrowUp.length) {
            $arrowUp.show();
        }

        // Focus first field if needed
        if (shouldFocus) {
            setTimeout(function() {
                focusFirstEditableField($section);
            }, 10);
        }
    }

    function closeSection($section, duration) {
        if (!$section || !$section.length) {
            return;
        }

        const $content = $section.find('.cv-builder-section-content').first();
        const $arrowDown = $section.find('.cv-arrow-down');
        const $arrowUp = $section.find('.cv-arrow-up');

        // Remove active class - CSS will handle hiding
        $section.removeClass('active');
        
        if ($arrowDown.length) {
            $arrowDown.show();
        }
        if ($arrowUp.length) {
            $arrowUp.hide();
        }

        // Remove any inline styles and ensure it's hidden
        $content.removeAttr('style');
    }

    function focusFirstEditableField($section) {
        if (!$section || !$section.length) {
            return;
        }

        const $firstField = $section.find('.cv-field-item').not('.cv-header-field').filter(function() {
            const $fieldItem = $(this);
            const $input = findFieldValueInput($fieldItem);
            return $input.length > 0;
        }).first();

        if (!$firstField.length) {
            return;
        }

        const $input = findFieldValueInput($firstField);
        if ($input.length && typeof $input.focus === 'function') {
            setTimeout(function() {
                $input.trigger('focus');
            }, 30);
        }
    }

    /**
     * Initialize symbol selection modal
     */
    function initializeSymbolModal($wrapper) {
        const $modal = $('#cv-symbol-modal');
        const $overlay = $modal.find('.cv-symbol-modal-overlay');
        const $closeBtn = $modal.find('.cv-symbol-modal-close');
        const $cancelBtn = $modal.find('.cv-modal-btn-cancel');
        const $selectBtn = $modal.find('.cv-modal-btn-select');
        const $symbolBtns = $modal.find('.cv-symbol-btn');
        const $previewIcon = $modal.find('#cv-preview-icon');
        let selectedIcon = null;
        let targetField = null;

        // Open modal when Ganesha edit button is clicked
        $wrapper.on('click', '.cv-ganesha-edit-btn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            targetField = $(this).closest('.cv-header-field').find('.cv-field-ganesha-image');
            const currentIcon = targetField.data('current-icon') || 'icon3';
            
            // Set active button
            $symbolBtns.removeClass('cv-symbol-btn-active');
            $symbolBtns.filter('[data-icon="' + currentIcon + '"]').addClass('cv-symbol-btn-active');
            selectedIcon = currentIcon;
            
            // Update preview
            updatePreview(currentIcon);
            
            $modal.addClass('active');
            $('body').css('overflow', 'hidden');
        });

        // Close modal
        function closeModal() {
            $modal.removeClass('active');
            $('body').css('overflow', '');
            selectedIcon = null;
            targetField = null;
        }

        $closeBtn.on('click', closeModal);
        $cancelBtn.on('click', closeModal);
        $overlay.on('click', closeModal);

        // Select symbol
        $symbolBtns.on('click', function() {
            $symbolBtns.removeClass('cv-symbol-btn-active');
            $(this).addClass('cv-symbol-btn-active');
            selectedIcon = $(this).data('icon');
            updatePreview(selectedIcon);
        });

        // Update preview
        function updatePreview(iconId) {
            const $btn = $symbolBtns.filter('[data-icon="' + iconId + '"]');
            const iconType = $btn.data('icon-type');
            
            $previewIcon.empty();
            
            if (iconType === 'png') {
                const $img = $btn.find('img').clone();
                $img.css({ width: '60px', height: '60px', objectFit: 'contain' });
                $previewIcon.append($img);
            } else if (iconType === 'svg') {
                const $svg = $btn.find('svg').clone();
                $svg.css({ width: '60px', height: '60px' });
                $previewIcon.append($svg);
            } else {
                const $content = $btn.children().first().clone();
                if ($content.is('span')) {
                    $content.css({ fontSize: '32px' });
                }
                $previewIcon.append($content);
            }
        }

        // Select icon button
        $selectBtn.on('click', function() {
            if (selectedIcon && targetField) {
                const $selectedBtn = $symbolBtns.filter('[data-icon="' + selectedIcon + '"]');
                const iconType = $selectedBtn.data('icon-type');
                
                // Update the Ganesha image field
                targetField.empty();
                targetField.data('current-icon', selectedIcon);
                
                if (iconType === 'png') {
                    const $img = $selectedBtn.find('img').clone();
                    $img.addClass('cv-field-icon-img').attr('width', '48').attr('height', '48');
                    targetField.append($img);
                } else if (iconType === 'svg') {
                    const $svg = $selectedBtn.find('svg').clone();
                    $svg.attr('width', '48').attr('height', '48');
                    targetField.append($svg);
                } else {
                    const $content = $selectedBtn.children().first().clone();
                    targetField.append($content);
                }
                
                closeModal();
            }
        });

        // Close on Escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && $modal.hasClass('active')) {
                closeModal();
            }
        });
    }

    /**
     * Initialize date pickers
     */
    function initializeDatePickers($wrapper) {
        // Use event delegation for navigation to avoid multiple handlers
        if (!$wrapper.data('date-picker-initialized')) {
            // Navigation - Previous month (Up arrow)
            $wrapper.on('click', '.cv-date-picker-prev', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const $picker = $(this).closest('.cv-date-picker');
                const $input = $picker.closest('.cv-field-input-wrapper').find('.cv-date-input');
                let currentYear = parseInt($picker.data('current-year')) || new Date().getFullYear();
                let currentMonth = parseInt($picker.data('current-month')) || new Date().getMonth();
                
                currentMonth--;
                if (currentMonth < 0) {
                    currentMonth = 11;
                    currentYear--;
                }
                
                $picker.data('current-year', currentYear);
                $picker.data('current-month', currentMonth);
                
                // Return to monthly view if in year/month selection view
                if ($picker.data('view-mode') === 'year-month') {
                    showMonthlyView($picker, $input, currentYear, currentMonth, false);
                } else {
                    renderCalendarForPicker($picker, $input, currentYear, currentMonth);
                    // Update month-year display
                    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
                    $picker.find('.cv-date-picker-month').text(monthNames[currentMonth]);
                    $picker.find('.cv-date-picker-year').text(currentYear);
                }
            });

            // Navigation - Next month (Down arrow)
            $wrapper.on('click', '.cv-date-picker-next', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const $picker = $(this).closest('.cv-date-picker');
                const $input = $picker.closest('.cv-field-input-wrapper').find('.cv-date-input');
                let currentYear = parseInt($picker.data('current-year')) || new Date().getFullYear();
                let currentMonth = parseInt($picker.data('current-month')) || new Date().getMonth();
                
                currentMonth++;
                if (currentMonth > 11) {
                    currentMonth = 0;
                    currentYear++;
                }
                
                $picker.data('current-year', currentYear);
                $picker.data('current-month', currentMonth);
                
                // Return to monthly view if in year/month selection view
                if ($picker.data('view-mode') === 'year-month') {
                    showMonthlyView($picker, $input, currentYear, currentMonth, false);
                } else {
                    renderCalendarForPicker($picker, $input, currentYear, currentMonth);
                    // Update month-year display
                    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
                    $picker.find('.cv-date-picker-month').text(monthNames[currentMonth]);
                    $picker.find('.cv-date-picker-year').text(currentYear);
                }
            });

            // Month-Year click - Toggle year-month selection view
            $wrapper.on('click', '.cv-date-picker-month-year', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const $picker = $(this).closest('.cv-date-picker');
                const $input = $picker.closest('.cv-field-input-wrapper').find('.cv-date-input');
                toggleYearMonthView($picker, $input);
            });

            // Date selection - Click on a day to select it
            $wrapper.on('click', '.cv-date-picker-day-current', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const $picker = $(this).closest('.cv-date-picker');
                const $input = $picker.closest('.cv-field-input-wrapper').find('.cv-date-input');
                const selectedDay = parseInt($(this).data('day'));
                const currentYear = parseInt($picker.data('current-year')) || new Date().getFullYear();
                const currentMonth = parseInt($picker.data('current-month')) || new Date().getMonth();
                
                // Format date as DD/MM/YYYY
                const formattedDate = String(selectedDay).padStart(2, '0') + '/' + 
                                     String(currentMonth + 1).padStart(2, '0') + '/' + 
                                     String(currentYear);
                
                // Update input field
                $input.val(formattedDate);
                
                // Update selected date highlight
                $picker.find('.cv-date-picker-day').removeClass('cv-date-picker-day-selected');
                $(this).addClass('cv-date-picker-day-selected');
                
                // Close the date picker
                $picker.fadeOut(200, function() {
                    $picker.hide();
                    $picker.data('view-mode', null);
                });
            });

            // Year item click - Select year, update header (without affecting month)
            $wrapper.on('click', '.cv-date-picker-year-item', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const $picker = $(this).closest('.cv-date-picker');
                const $yearColumn = $picker.find('.cv-date-picker-year-column');
                const selectedYear = parseInt($(this).data('year'));
                const currentMonth = parseInt($picker.data('current-month')) || new Date().getMonth();
                
                // Update picker data - only year, keep month unchanged
                $picker.data('current-year', selectedYear);
                
                // Update the month-year header display
                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                                   'July', 'August', 'September', 'October', 'November', 'December'];
                $picker.find('.cv-date-picker-month').text(monthNames[currentMonth]);
                $picker.find('.cv-date-picker-year').text(selectedYear);
                
                // Update only the year column - do NOT rebuild month column
                // Remove all selected classes from year items
                $yearColumn.find('.cv-date-picker-year-item').removeClass('cv-date-picker-year-selected');
                
                // Add selected class to clicked year
                const $selectedYear = $yearColumn.find('.cv-date-picker-year-item[data-year="' + selectedYear + '"]');
                if ($selectedYear.length) {
                    $selectedYear.addClass('cv-date-picker-year-selected');
                    
                    // Scroll selected year to center - same approach as month
                    setTimeout(function() {
                        const yearIndex = $yearColumn.find('.cv-date-picker-year-item').index($selectedYear);
                        const itemHeight = $selectedYear.outerHeight();
                        const containerHeight = $yearColumn.height();
                        
                        // Use the exact same formula as month scrolling
                        const scrollTop = (yearIndex * itemHeight) - (containerHeight / 2) + (itemHeight / 2);
                        
                        // Scroll to center the selected year
                        $yearColumn.scrollTop(Math.max(0, scrollTop));
                        
                        // Wait a bit for scroll to complete
                        setTimeout(function() {
                            // Ensure selected class is applied
                            $selectedYear.addClass('cv-date-picker-year-selected');
                            
                            // Initialize center item highlighting
                            updateCenterItems($yearColumn, 'year');
                            
                            // Re-apply selected class to ensure it's highlighted
                            $yearColumn.find('.cv-date-picker-year-item[data-year="' + selectedYear + '"]').addClass('cv-date-picker-year-selected');
                        }, 100);
                    }, 10);
                }
            });

            // Month item click - Select month, update header - Same approach as year
            $wrapper.on('click', '.cv-date-picker-month-item', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const $picker = $(this).closest('.cv-date-picker');
                const $monthColumn = $picker.find('.cv-date-picker-month-column');
                const selectedMonth = parseInt($(this).data('month'));
                const currentYear = parseInt($picker.data('current-year')) || new Date().getFullYear();
                
                // Validate selected month
                if (isNaN(selectedMonth) || selectedMonth < 0 || selectedMonth > 11) {
                    return;
                }
                
                // Update picker data
                $picker.data('current-month', selectedMonth);
                
                // Update the month-year header display
                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                                   'July', 'August', 'September', 'October', 'November', 'December'];
                $picker.find('.cv-date-picker-month').text(monthNames[selectedMonth]);
                $picker.find('.cv-date-picker-year').text(currentYear);
                
                // Remove all selected classes from month items
                $monthColumn.find('.cv-date-picker-month-item').removeClass('cv-date-picker-month-selected');
                
                // Add selected class to clicked month
                const $selectedMonth = $monthColumn.find('.cv-date-picker-month-item[data-month="' + selectedMonth + '"]');
                if ($selectedMonth.length) {
                    $selectedMonth.addClass('cv-date-picker-month-selected');
                    
                    // Scroll selected month to center - same as year approach
                    setTimeout(function() {
                        const monthIndex = $monthColumn.find('.cv-date-picker-month-item').index($selectedMonth);
                        const itemHeight = $selectedMonth.outerHeight();
                        const containerHeight = $monthColumn.height();
                        
                        // Use the exact same formula as year scrolling
                        const scrollTop = (monthIndex * itemHeight) - (containerHeight / 2) + (itemHeight / 2);
                        
                        // Scroll to center the selected month
                        $monthColumn.scrollTop(Math.max(0, scrollTop));
                        
                        // Wait a bit for scroll to complete
                        setTimeout(function() {
                            // Ensure selected class is applied
                            $selectedMonth.addClass('cv-date-picker-month-selected');
                            
                            // Initialize center item highlighting
                            updateCenterItems($monthColumn, 'month');
                            
                            // Re-apply selected class to ensure it's highlighted
                            $monthColumn.find('.cv-date-picker-month-item[data-month="' + selectedMonth + '"]').addClass('cv-date-picker-month-selected');
                        }, 100);
                    }, 10);
                }
            });

            // Month-Year item click - Select month and year together (new format)
            $wrapper.on('click', '.cv-date-picker-month-year-item', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const $picker = $(this).closest('.cv-date-picker');
                const selectedMonth = parseInt($(this).data('month'));
                const selectedYear = parseInt($(this).data('year'));
                
                $picker.data('current-month', selectedMonth);
                $picker.data('current-year', selectedYear);
                
                // Update the month-year header display
                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                                   'July', 'August', 'September', 'October', 'November', 'December'];
                $picker.find('.cv-date-picker-month').text(monthNames[selectedMonth]);
                $picker.find('.cv-date-picker-year').text(selectedYear);
                
                // Update the view to reflect selection
                updateYearMonthView($picker, null);
            });

            // Reset button
            $wrapper.on('click', '.cv-date-picker-reset-btn', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const $picker = $(this).closest('.cv-date-picker');
                const originalYear = parseInt($picker.data('original-year')) || new Date().getFullYear();
                const originalMonth = parseInt($picker.data('original-month')) || new Date().getMonth();
                
                $picker.data('current-year', originalYear);
                $picker.data('current-month', originalMonth);
                
                // Update header
                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                                   'July', 'August', 'September', 'October', 'November', 'December'];
                $picker.find('.cv-date-picker-month').text(monthNames[originalMonth]);
                $picker.find('.cv-date-picker-year').text(originalYear);
                
                // Update the view
                updateYearMonthView($picker, null);
            });

            // Done button
            $wrapper.on('click', '.cv-date-picker-done-btn', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const $picker = $(this).closest('.cv-date-picker');
                const $input = $picker.closest('.cv-field-input-wrapper').find('.cv-date-input');
                const selectedYear = parseInt($picker.data('current-year')) || new Date().getFullYear();
                const selectedMonth = parseInt($picker.data('current-month')) || new Date().getMonth();
                
                // Get the selected day if any, otherwise use 1
                const currentValue = $input.val();
                let selectedDay = 1;
                if (currentValue) {
                    const parts = currentValue.split('/');
                    if (parts.length === 3) {
                        const day = parseInt(parts[0]);
                        const month = parseInt(parts[1]);
                        const year = parseInt(parts[2]);
                        
                        if (!isNaN(day) && !isNaN(month) && !isNaN(year) && 
                            month === selectedMonth + 1 && year === selectedYear) {
                            selectedDay = day;
                        }
                    }
                }
                
                // Update the input field
                const formattedDate = String(selectedDay).padStart(2, '0') + '/' + 
                                     String(selectedMonth + 1).padStart(2, '0') + '/' + 
                                     String(selectedYear);
                
                $input.val(formattedDate);
                
                // Store as original values for next reset
                $picker.data('original-year', selectedYear);
                $picker.data('original-month', selectedMonth);
                
                // Close the year-month view and show calendar
                const $yearMonthView = $picker.find('.cv-date-picker-year-month-view');
                const $calendar = $picker.find('.cv-date-picker-calendar');
                const $dropdownIcon = $picker.find('.cv-date-picker-dropdown-icon');
                
                $dropdownIcon.removeClass('cv-date-picker-dropdown-open');
                // Reset the flag so original values can be stored again when reopened
                $picker.data('original-year-stored', false);
                $yearMonthView.removeClass('cv-year-month-visible');
                setTimeout(function() {
                    $yearMonthView.css('display', 'none');
                    showMonthlyView($picker, $input, selectedYear, selectedMonth, false);
                }, 300);
            });

            // Year item click - Select year, update header (without affecting month)
            $wrapper.on('click', '.cv-date-picker-year-item', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const $picker = $(this).closest('.cv-date-picker');
                const $yearColumn = $picker.find('.cv-date-picker-year-column');
                const selectedYear = parseInt($(this).data('year'));
                const currentMonth = parseInt($picker.data('current-month')) || new Date().getMonth();
                
                // Update picker data - only year, keep month unchanged
                $picker.data('current-year', selectedYear);
                
                // Update the month-year header display
                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                                   'July', 'August', 'September', 'October', 'November', 'December'];
                $picker.find('.cv-date-picker-month').text(monthNames[currentMonth]);
                $picker.find('.cv-date-picker-year').text(selectedYear);
                
                // Update only the year column - do NOT rebuild month column
                // Remove all selected classes from year items
                $yearColumn.find('.cv-date-picker-year-item').removeClass('cv-date-picker-year-selected');
                
                // Add selected class to clicked year
                const $selectedYear = $yearColumn.find('.cv-date-picker-year-item[data-year="' + selectedYear + '"]');
                if ($selectedYear.length) {
                    $selectedYear.addClass('cv-date-picker-year-selected');
                    
                    // Scroll selected year to center - same approach as month
                    setTimeout(function() {
                        const yearIndex = $yearColumn.find('.cv-date-picker-year-item').index($selectedYear);
                        const itemHeight = $selectedYear.outerHeight();
                        const containerHeight = $yearColumn.height();
                        
                        // Use the exact same formula as month scrolling
                        const scrollTop = (yearIndex * itemHeight) - (containerHeight / 2) + (itemHeight / 2);
                        
                        // Scroll to center the selected year
                        $yearColumn.scrollTop(Math.max(0, scrollTop));
                        
                        // Wait a bit for scroll to complete
                        setTimeout(function() {
                            // Ensure selected class is applied
                            $selectedYear.addClass('cv-date-picker-year-selected');
                            
                            // Initialize center item highlighting
                            updateCenterItems($yearColumn, 'year');
                            
                            // Re-apply selected class to ensure it's highlighted
                            $yearColumn.find('.cv-date-picker-year-item[data-year="' + selectedYear + '"]').addClass('cv-date-picker-year-selected');
                        }, 100);
                    }, 10);
                }
            });

            // Month item click - Select month, update header - Same approach as year
            $wrapper.on('click', '.cv-date-picker-month-item', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const $picker = $(this).closest('.cv-date-picker');
                const $monthColumn = $picker.find('.cv-date-picker-month-column');
                const selectedMonth = parseInt($(this).data('month'));
                const currentYear = parseInt($picker.data('current-year')) || new Date().getFullYear();
                
                // Validate selected month
                if (isNaN(selectedMonth) || selectedMonth < 0 || selectedMonth > 11) {
                    return;
                }
                
                // Update picker data
                $picker.data('current-month', selectedMonth);
                
                // Update the month-year header display
                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                                   'July', 'August', 'September', 'October', 'November', 'December'];
                $picker.find('.cv-date-picker-month').text(monthNames[selectedMonth]);
                $picker.find('.cv-date-picker-year').text(currentYear);
                
                // Remove all selected classes from month items
                $monthColumn.find('.cv-date-picker-month-item').removeClass('cv-date-picker-month-selected');
                
                // Add selected class to clicked month
                const $selectedMonth = $monthColumn.find('.cv-date-picker-month-item[data-month="' + selectedMonth + '"]');
                if ($selectedMonth.length) {
                    $selectedMonth.addClass('cv-date-picker-month-selected');
                    
                    // Scroll selected month to center - same as year approach
                    setTimeout(function() {
                        const monthIndex = $monthColumn.find('.cv-date-picker-month-item').index($selectedMonth);
                        const itemHeight = $selectedMonth.outerHeight();
                        const containerHeight = $monthColumn.height();
                        
                        // Use the exact same formula as year scrolling
                        const scrollTop = (monthIndex * itemHeight) - (containerHeight / 2) + (itemHeight / 2);
                        
                        // Scroll to center the selected month
                        $monthColumn.scrollTop(Math.max(0, scrollTop));
                        
                        // Wait a bit for scroll to complete
                        setTimeout(function() {
                            // Ensure selected class is applied
                            $selectedMonth.addClass('cv-date-picker-month-selected');
                            
                            // Initialize center item highlighting
                            updateCenterItems($monthColumn, 'month');
                            
                            // Re-apply selected class to ensure it's highlighted
                            $monthColumn.find('.cv-date-picker-month-item[data-month="' + selectedMonth + '"]').addClass('cv-date-picker-month-selected');
                        }, 100);
                    }, 10);
                }
            });

            // Reset button
            $wrapper.on('click', '.cv-date-picker-reset-btn', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const $picker = $(this).closest('.cv-date-picker');
                const originalYear = parseInt($picker.data('original-year')) || new Date().getFullYear();
                const originalMonth = parseInt($picker.data('original-month')) || new Date().getMonth();
                
                $picker.data('current-year', originalYear);
                $picker.data('current-month', originalMonth);
                
                // Update header
                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                                   'July', 'August', 'September', 'October', 'November', 'December'];
                $picker.find('.cv-date-picker-month').text(monthNames[originalMonth]);
                $picker.find('.cv-date-picker-year').text(originalYear);
                
                // Update the view
                updateYearMonthView($picker, null);
            });

            // Close on outside click
            $wrapper.on('click', function(e) {
                const $target = $(e.target);
                // Don't close if clicking inside date picker or input wrapper
                if (!$target.closest('.cv-field-input-wrapper').length && 
                    !$target.closest('.cv-date-picker').length) {
                    $wrapper.find('.cv-date-picker:visible').hide();
                    $wrapper.find('.cv-date-picker').data('view-mode', null);
                }
            });

            $wrapper.data('date-picker-initialized', true);
        }

        // Initialize each date input
        $wrapper.find('.cv-date-input').each(function() {
            const $input = $(this);
            const $wrapperEl = $input.closest('.cv-field-input-wrapper');
            const $calendarIcon = $wrapperEl.find('.cv-calendar-icon');
            let $datePicker = $wrapperEl.find('.cv-date-picker');

            // Create date picker HTML if it doesn't exist
            function createDatePicker() {
                if ($datePicker.length) {
                    return $datePicker;
                }

                const $picker = $('<div class="cv-date-picker"></div>');
                const $header = $('<div class="cv-date-picker-header"></div>');
                const $monthYear = $('<div class="cv-date-picker-month-year"></div>');
                const $monthDisplay = $('<span class="cv-date-picker-month"></span>');
                const $yearDisplay = $('<span class="cv-date-picker-year"></span>');
                const $prevBtn = $('<button type="button" class="cv-date-picker-nav cv-date-picker-prev" aria-label="Previous month">↑</button>');
                const $nextBtn = $('<button type="button" class="cv-date-picker-nav cv-date-picker-next" aria-label="Next month">↓</button>');
                const $calendar = $('<div class="cv-date-picker-calendar"></div>');
                const $daysHeader = $('<div class="cv-date-picker-days-header"></div>');
                const $daysGrid = $('<div class="cv-date-picker-days"></div>');
                
                // Year-month selection view - Two scrollable columns with buttons
                const $yearMonthView = $('<div class="cv-date-picker-year-month-view"></div>');
                const $content = $('<div class="cv-date-picker-year-month-content"></div>');
                const $monthColumn = $('<div class="cv-date-picker-month-column"></div>');
                const $yearColumn = $('<div class="cv-date-picker-year-column"></div>');
                const $footer = $('<div class="cv-date-picker-year-month-footer"></div>');
                const $resetBtn = $('<button type="button" class="cv-date-picker-reset-btn">Reset</button>');
                const $doneBtn = $('<button type="button" class="cv-date-picker-done-btn">Done</button>');
                
                $content.append($monthColumn);
                $content.append($yearColumn);
                $footer.append($resetBtn);
                $footer.append($doneBtn);
                $yearMonthView.append($content);
                $yearMonthView.append($footer);
                $yearMonthView.hide();

                const $dropdownIcon = $('<span class="cv-date-picker-dropdown-icon">▼</span>');
                $monthYear.append($monthDisplay);
                $monthYear.append(' ');
                $monthYear.append($yearDisplay);
                $monthYear.append($dropdownIcon);
                $header.append($monthYear);
                $header.append($prevBtn);
                $header.append($nextBtn);
                $picker.append($header);
                $picker.append($calendar);
                $picker.append($yearMonthView);
                $calendar.append($daysHeader);
                $calendar.append($daysGrid);

                const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                days.forEach(day => {
                    $daysHeader.append($('<div class="cv-date-picker-day-name">' + day + '</div>'));
                });

                $picker.hide().appendTo($wrapperEl);
                $datePicker = $picker;
                return $picker;
            }

            // Show calendar on icon click
            $calendarIcon.on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();

                if (!$datePicker.length) {
                    $datePicker = createDatePicker();
                }

                // Initialize year/month from current value or today's date
                let currentYear = new Date().getFullYear();
                let currentMonth = new Date().getMonth();

                // Try to parse current value
                const currentValue = $input.val();
                if (currentValue) {
                    const parts = currentValue.split('/');
                    if (parts.length === 3) {
                        const day = parseInt(parts[0]);
                        const month = parseInt(parts[1]);
                        const year = parseInt(parts[2]);
                        
                        // Validate the parsed date
                        if (!isNaN(day) && !isNaN(month) && !isNaN(year) && 
                            day >= 1 && day <= 31 && month >= 1 && month <= 12 && 
                            year >= 1900 && year <= 2100) {
                            currentYear = year;
                            currentMonth = month - 1;
                        }
                    }
                }

                // Store state on the picker element
                $datePicker.data('current-year', currentYear);
                $datePicker.data('current-month', currentMonth);
                
                if ($datePicker.is(':visible')) {
                    $datePicker.hide();
                    $datePicker.data('view-mode', null);
                } else {
                    $datePicker.show();
                    // Hide all views first
                    $datePicker.find('.cv-date-picker-year-view').hide();
                    $datePicker.find('.cv-date-picker-month-view').hide();
                    // Show monthly view
                    showMonthlyView($datePicker, $input, currentYear, currentMonth, true);
                }
            });
        });

        // Toggle year-month selection view
        function toggleYearMonthView($picker, $input) {
            const $calendar = $picker.find('.cv-date-picker-calendar');
            const $yearMonthView = $picker.find('.cv-date-picker-year-month-view');
            const $dropdownIcon = $picker.find('.cv-date-picker-dropdown-icon');
            
            // Check if year-month view is currently visible
            const isYearMonthVisible = $yearMonthView.hasClass('cv-year-month-visible');
            
            // Toggle: if already visible, collapse it
            if (isYearMonthVisible) {
                $dropdownIcon.removeClass('cv-date-picker-dropdown-open');
                $yearMonthView.removeClass('cv-year-month-visible');
                
                // After animation completes, hide it and show calendar
                setTimeout(function() {
                    $yearMonthView.css('display', 'none');
                    // Reset the flag so original values can be stored again when reopened
                    $picker.data('original-year-stored', false);
                    showMonthlyView($picker, $input, 
                        parseInt($picker.data('current-year')) || new Date().getFullYear(),
                        parseInt($picker.data('current-month')) || new Date().getMonth()
                    );
                }, 300);
                return;
            }
            
            // Hide calendar first
            $calendar.slideUp(200, function() {
                // Get current year and month from header text (what user sees) to ensure accuracy
                const headerYearText = $picker.find('.cv-date-picker-year').text().trim();
                const headerYear = parseInt(headerYearText);
                
                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                                   'July', 'August', 'September', 'October', 'November', 'December'];
                const headerMonthText = $picker.find('.cv-date-picker-month').text().trim();
                const headerMonth = monthNames.indexOf(headerMonthText);
                
                // Use header values if valid, otherwise fallback to picker data, then today's date
                const currentYear = (!isNaN(headerYear) && headerYear > 1900 && headerYear < 2100) 
                    ? headerYear 
                    : (parseInt($picker.data('current-year')) || new Date().getFullYear());
                const currentMonth = (headerMonth >= 0 && headerMonth <= 11) 
                    ? headerMonth 
                    : (parseInt($picker.data('current-month')) || new Date().getMonth());
                
                // Update picker data to match header
                $picker.data('current-year', currentYear);
                $picker.data('current-month', currentMonth);
                
                // Store original values for reset (only if not already stored)
                if (!$picker.data('original-year-stored')) {
                    $picker.data('original-year', currentYear);
                    $picker.data('original-month', currentMonth);
                    $picker.data('original-year-stored', true);
                }
                
                // Build and show the combined view
                updateYearMonthView($picker, $input);
                
                // Rotate dropdown icon
                $dropdownIcon.addClass('cv-date-picker-dropdown-open');
                
                // Show year-month view with smooth transition
                $yearMonthView.css('display', 'flex');
                // Use setTimeout to ensure display is set before adding class
                setTimeout(function() {
                    $yearMonthView.addClass('cv-year-month-visible');
                }, 10);
                
                $picker.data('view-mode', 'year-month');
            });
        }

        // Update year-month view content - Two scrollable columns
        function updateYearMonthView($picker, $input) {
            const $monthColumn = $picker.find('.cv-date-picker-month-column');
            const $yearColumn = $picker.find('.cv-date-picker-year-column');
            
            const currentYear = parseInt($picker.data('current-year')) || new Date().getFullYear();
            const currentMonth = parseInt($picker.data('current-month')) || new Date().getMonth();
            
            // Store original values for reset
            if (!$picker.data('original-year-stored')) {
                $picker.data('original-year', currentYear);
                $picker.data('original-month', currentMonth);
                $picker.data('original-year-stored', true);
            }
            
            // Build month column - Left side with all 12 months (full names)
            $monthColumn.empty();
            const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                               'July', 'August', 'September', 'October', 'November', 'December'];
            monthNames.forEach(function(monthName, index) {
                const $monthItem = $('<div class="cv-date-picker-month-item" data-month="' + index + '">' + monthName + '</div>');
                $monthColumn.append($monthItem);
            });
            
            // Ensure selected month class is visible (remove any conflicting classes first)
            $monthColumn.find('.cv-date-picker-month-item').removeClass('cv-date-picker-month-selected');
            const $selectedMonthItem = $monthColumn.find('.cv-date-picker-month-item[data-month="' + currentMonth + '"]');
            if ($selectedMonthItem.length) {
                $selectedMonthItem.addClass('cv-date-picker-month-selected');
            }
            
            // Scroll to selected month and center it - same approach as year
            setTimeout(function() {
                const $activeMonth = $monthColumn.find('.cv-date-picker-month-item[data-month="' + currentMonth + '"]');
                if ($activeMonth.length) {
                    // Get the index of the selected month item
                    const monthIndex = $monthColumn.find('.cv-date-picker-month-item').index($activeMonth);
                    const itemHeight = $activeMonth.outerHeight();
                    const containerHeight = $monthColumn.height();
                    
                    // Calculate scroll position: 
                    // Each item is 50px tall, and we have 50px padding at top
                    // To center: scroll to (monthIndex * itemHeight) - (containerHeight / 2) + (itemHeight / 2)
                    const scrollTop = (monthIndex * itemHeight) - (containerHeight / 2) + (itemHeight / 2);
                    
                    // Scroll to center the selected month
                    $monthColumn.scrollTop(Math.max(0, scrollTop));
                    
                    // Wait a bit for scroll to complete, then ensure selected month is centered
                    setTimeout(function() {
                        // Ensure selected class is applied
                        $activeMonth.addClass('cv-date-picker-month-selected');
                        
                        // Initialize center item highlighting - this should now find the selected month in center
                        updateCenterItems($monthColumn, 'month');
                        
                        // Re-apply selected class to ensure it's highlighted
                        $monthColumn.find('.cv-date-picker-month-item[data-month="' + currentMonth + '"]').addClass('cv-date-picker-month-selected');
                    }, 100);
                } else {
                    // If month not found, still initialize center items
                    updateCenterItems($monthColumn, 'month');
                }
            }, 150);
            
            // Add scroll listener for month column
            $monthColumn.off('scroll.wheelpicker').on('scroll.wheelpicker', function() {
                updateCenterItems($(this), 'month');
                // Ensure selected month class is maintained after scroll
                const currentMonth = parseInt($picker.data('current-month')) || new Date().getMonth();
                $(this).find('.cv-date-picker-month-item[data-month="' + currentMonth + '"]').addClass('cv-date-picker-month-selected');
            });
            
            // Build year column - Right side with all years (1950 to current + 20)
            $yearColumn.empty();
            const startYear = 1950;
            const endYear = new Date().getFullYear() + 20;
            for (let year = startYear; year <= endYear; year++) {
                const $yearItem = $('<div class="cv-date-picker-year-item" data-year="' + year + '">' + year + '</div>');
                // Mark selected year - use the stored current-year from picker data (selected year)
                if (year === currentYear) {
                    $yearItem.addClass('cv-date-picker-year-selected');
                }
                $yearColumn.append($yearItem);
            }
            
            // Ensure selected year class is visible (remove any conflicting classes first)
            $yearColumn.find('.cv-date-picker-year-item').removeClass('cv-date-picker-year-selected');
            const $selectedYearItem = $yearColumn.find('.cv-date-picker-year-item[data-year="' + currentYear + '"]');
            if ($selectedYearItem.length) {
                $selectedYearItem.addClass('cv-date-picker-year-selected');
            }
            
            // Scroll to selected year and center it
            setTimeout(function() {
                const $activeYear = $yearColumn.find('.cv-date-picker-year-item[data-year="' + currentYear + '"]');
                if ($activeYear.length) {
                    // Get the index of the selected year item
                    const yearIndex = $yearColumn.find('.cv-date-picker-year-item').index($activeYear);
                    const itemHeight = $activeYear.outerHeight();
                    const containerHeight = $yearColumn.height();
                    
                    // Calculate scroll position: 
                    // Each item is 50px tall, and we have 50px padding at top
                    // To center: scroll to (yearIndex * itemHeight) - (containerHeight / 2) + (itemHeight / 2)
                    const scrollTop = (yearIndex * itemHeight) - (containerHeight / 2) + (itemHeight / 2);
                    
                    // Scroll to center the selected year
                    $yearColumn.scrollTop(Math.max(0, scrollTop));
                    
                    // Wait a bit for scroll to complete, then ensure selected year is centered
                    setTimeout(function() {
                        // Ensure selected class is applied
                        $activeYear.addClass('cv-date-picker-year-selected');
                        
                        // Initialize center item highlighting - this should now find the selected year in center
                        updateCenterItems($yearColumn, 'year');
                        
                        // Re-apply selected class to ensure it's highlighted
                        $yearColumn.find('.cv-date-picker-year-item[data-year="' + currentYear + '"]').addClass('cv-date-picker-year-selected');
                    }, 100);
                } else {
                    // If year not found, still initialize center items
                    updateCenterItems($yearColumn, 'year');
                }
            }, 150);
            
            // Add scroll listener for year column
            $yearColumn.off('scroll.wheelpicker').on('scroll.wheelpicker', function() {
                updateCenterItems($(this), 'year');
                // Ensure selected year class is maintained after scroll
                const currentYear = parseInt($picker.data('current-year')) || new Date().getFullYear();
                $(this).find('.cv-date-picker-year-item[data-year="' + currentYear + '"]').addClass('cv-date-picker-year-selected');
            });
        }

        // Scroll month to center position (middle row) - Same as year scrolling
        function scrollMonthToCenter($monthColumn, monthIndex, callback) {
            if (!$monthColumn || !$monthColumn.length) {
                if (callback) callback();
                return;
            }
            
            const $selectedMonth = $monthColumn.find('.cv-date-picker-month-item[data-month="' + monthIndex + '"]');
            
            if (!$selectedMonth.length) {
                if (callback) callback();
                return;
            }
            
            // Wait for DOM to be ready - same timing as year
            setTimeout(function() {
                const monthIndex_pos = $monthColumn.find('.cv-date-picker-month-item').index($selectedMonth);
                
                // Validate item index
                if (monthIndex_pos < 0) {
                    if (callback) callback();
                    return;
                }
                
                const itemHeight = $selectedMonth.outerHeight() || 50;
                const containerHeight = $monthColumn.height() || 150;
                
                // Use the exact same formula as year scrolling
                // Calculate scroll position: 
                // Each item is 50px tall, and we have 50px padding at top
                // To center: scroll to (monthIndex * itemHeight) - (containerHeight / 2) + (itemHeight / 2)
                const scrollTop = (monthIndex_pos * itemHeight) - (containerHeight / 2) + (itemHeight / 2);
                
                // Scroll to center the selected month - same as year (direct scroll, no animation)
                $monthColumn.scrollTop(Math.max(0, scrollTop));
                
                // Wait a bit for scroll to complete, then ensure selected month is centered
                setTimeout(function() {
                    // Ensure selected class is applied
                    $selectedMonth.addClass('cv-date-picker-month-selected');
                    
                    // Initialize center item highlighting - this should now find the selected month in center
                    updateCenterItems($monthColumn, 'month');
                    
                    // Re-apply selected class to ensure it's highlighted
                    $monthColumn.find('.cv-date-picker-month-item[data-month="' + monthIndex + '"]').addClass('cv-date-picker-month-selected');
                    
                    if (callback) callback();
                }, 100);
            }, 150);
        }

        // Update center items based on scroll position
        function updateCenterItems($column, type) {
            if (!$column || !$column.length) {
                return;
            }
            
            const containerHeight = $column.height();
            const scrollTop = $column.scrollTop();
            const centerY = scrollTop + (containerHeight / 2);
            
            // Get the picker to check selected year/month
            const $picker = $column.closest('.cv-date-picker');
            if (!$picker || !$picker.length) {
                return;
            }
            
            const selectedValue = type === 'month' 
                ? parseInt($picker.data('current-month'))
                : parseInt($picker.data('current-year'));
            
            // Validate selected value
            if (isNaN(selectedValue)) {
                return;
            }
            
            // Remove center class from all items
            $column.find('.cv-item-center').removeClass('cv-item-center');
            
            // Find the item closest to center
            let closestItem = null;
            let closestDistance = Infinity;
            
            $column.find(type === 'month' ? '.cv-date-picker-month-item' : '.cv-date-picker-year-item').each(function() {
                const $item = $(this);
                const itemTop = $item.position().top;
                const itemHeight = $item.outerHeight();
                const itemCenter = itemTop + (itemHeight / 2);
                const distance = Math.abs(centerY - itemCenter);
                
                if (distance < closestDistance) {
                    closestDistance = distance;
                    closestItem = $item;
                }
            });
            
            // Add center class to closest item
            if (closestItem && closestItem.length) {
                closestItem.addClass('cv-item-center');
                
                // If the closest item is also the selected item, ensure selected class is maintained
                const itemValue = type === 'month' 
                    ? parseInt(closestItem.data('month'))
                    : parseInt(closestItem.data('year'));
                
                if (!isNaN(itemValue) && itemValue === selectedValue) {
                    closestItem.addClass(type === 'month' ? 'cv-date-picker-month-selected' : 'cv-date-picker-year-selected');
                }
            }
            
            // Always ensure the selected item has the selected class
            // Remove selected class from all items first, then add to selected
            if (type === 'month') {
                $column.find('.cv-date-picker-month-item').removeClass('cv-date-picker-month-selected');
                const $selectedMonth = $column.find('.cv-date-picker-month-item[data-month="' + selectedValue + '"]');
                if ($selectedMonth.length) {
                    $selectedMonth.addClass('cv-date-picker-month-selected');
                    // If selected month is in center, ensure it has center class too
                    if ($selectedMonth.hasClass('cv-item-center')) {
                        $selectedMonth.addClass('cv-date-picker-month-selected cv-item-center');
                    }
                }
            } else {
                $column.find('.cv-date-picker-year-item').removeClass('cv-date-picker-year-selected');
                const $selectedYear = $column.find('.cv-date-picker-year-item[data-year="' + selectedValue + '"]');
                if ($selectedYear.length) {
                    $selectedYear.addClass('cv-date-picker-year-selected');
                    // If selected year is in center, ensure it has center class too
                    if ($selectedYear.hasClass('cv-item-center')) {
                        $selectedYear.addClass('cv-date-picker-year-selected cv-item-center');
                    }
                }
            }
        }

        // Show monthly calendar view
        function showMonthlyView($picker, $input, year, month, skipAnimation) {
            const $calendar = $picker.find('.cv-date-picker-calendar');
            const $yearMonthView = $picker.find('.cv-date-picker-year-month-view');
            const $dropdownIcon = $picker.find('.cv-date-picker-dropdown-icon');
            
            // Hide year-month view
            if (skipAnimation) {
                $yearMonthView.removeClass('cv-year-month-visible');
                $yearMonthView.css('display', 'none');
            } else {
                $yearMonthView.removeClass('cv-year-month-visible');
                setTimeout(function() {
                    $yearMonthView.css('display', 'none');
                }, 300);
            }
            
            // Reset dropdown icon rotation
            $dropdownIcon.removeClass('cv-date-picker-dropdown-open');
            
            // Update month-year display
            const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            $picker.find('.cv-date-picker-month').text(monthNames[month]);
            $picker.find('.cv-date-picker-year').text(year);
            
            // Render calendar
            renderCalendarForPicker($picker, $input, year, month);
            
            // Show calendar with smooth transition
            if (skipAnimation) {
                $calendar.show();
            } else {
                $calendar.slideDown(200);
            }
            $picker.data('view-mode', 'monthly');
        }

        // Render calendar function (shared)
        function renderCalendarForPicker($picker, $input, year, month) {
            if (!$picker.length) {
                return;
            }

            const $daysGrid = $picker.find('.cv-date-picker-days');
            
            // Update selected year in year list if it exists
            const $yearList = $picker.find('.cv-date-picker-year-list');
            if ($yearList.length) {
                $yearList.find('.cv-date-picker-year-item').removeClass('cv-date-picker-year-selected');
                $yearList.find('[data-year="' + year + '"]').addClass('cv-date-picker-year-selected');
            }

            // Get first day of month and number of days
            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const prevMonthDays = new Date(year, month, 0).getDate();

            $daysGrid.empty();

            // Previous month days
            for (let i = firstDay - 1; i >= 0; i--) {
                const day = prevMonthDays - i;
                const $day = $('<div class="cv-date-picker-day cv-date-picker-day-other">' + day + '</div>');
                $daysGrid.append($day);
            }

            // Current month days
            for (let day = 1; day <= daysInMonth; day++) {
                const $day = $('<div class="cv-date-picker-day cv-date-picker-day-current" data-day="' + day + '">' + day + '</div>');
                $daysGrid.append($day);
            }

            // Fill remaining cells
            const totalCells = $daysGrid.children().length;
            const remaining = 42 - totalCells; // 6 rows * 7 days
            for (let day = 1; day <= remaining; day++) {
                const $day = $('<div class="cv-date-picker-day cv-date-picker-day-other">' + day + '</div>');
                $daysGrid.append($day);
            }

            // Highlight selected date
            const currentValue = $input.val();
            if (currentValue) {
                const parts = currentValue.split('/');
                if (parts.length === 3) {
                    const day = parseInt(parts[0]);
                    const monthVal = parseInt(parts[1]);
                    const yearVal = parseInt(parts[2]);
                    
                    if (!isNaN(day) && !isNaN(monthVal) && !isNaN(yearVal) && 
                        monthVal === month + 1 && yearVal === year) {
                        $daysGrid.find('[data-day="' + day + '"]').addClass('cv-date-picker-day-selected');
                    }
                }
            }
        }
    }

    /**
     * Show photo upload modal after image is selected
     */
    function showPhotoUploadModal(imageSrc, instanceId) {
        const $modal = $('#cv-photo-modal');
        const $overlay = $modal.find('.cv-photo-modal-overlay');
        const $cancelBtn = $modal.find('.cv-photo-modal-cancel');
        const $previewImg = $modal.find('#cv-photo-modal-preview');
        const $radioButtons = $modal.find('.cv-photo-radio');
        const $fileInput = $('#cv-photo-upload-' + instanceId);
        const $preview = $('.cv-builder-upload-preview[data-instance="' + instanceId + '"]');
        const $previewImgMain = $('#cv-photo-preview-' + instanceId);
        const $uploadBtn = $('.cv-upload-photo-btn[data-instance="' + instanceId + '"]');

        // Set the image in modal
        $previewImg.attr('src', imageSrc);
        
        // Reset radio buttons
        $radioButtons.prop('checked', false);

        // Remove existing event listeners to avoid duplicates
        $cancelBtn.off('click.photoModal');
        $overlay.off('click.photoModal');
        $radioButtons.off('change.photoModal');
        $(document).off('keydown.photoModal');

        // Show modal
        $modal.addClass('active');
        $('body').css('overflow', 'hidden');

        // Close modal functions
        function closeModal() {
            $modal.removeClass('active');
            $('body').css('overflow', '');
            // Reset file input if cancelled
            $fileInput.val('');
        }

        $cancelBtn.on('click.photoModal', closeModal);
        $overlay.on('click.photoModal', closeModal);

        // Handle radio button selection
        $radioButtons.on('change.photoModal', function() {
            const selectedOption = $(this).val();
            
            if (selectedOption === 'profile') {
                // Close upload modal and open crop modal
                closeModal();
                showCropModal(imageSrc, instanceId);
            } else if (selectedOption === 'lastpage') {
                // Add to last page (you can implement this functionality later)
                $previewImgMain.attr('src', imageSrc);
                $uploadBtn.hide();
                $preview.show();
                closeModal();
            }
        });

        // Close on Escape key
        $(document).on('keydown.photoModal', function(e) {
            if (e.key === 'Escape' && $modal.hasClass('active')) {
                closeModal();
            }
        });
    }

    /**
     * Initialize navigation between sections
     */
    function initializeNavigation($wrapper) {
        const sections = ['personal', 'family', 'contact', 'professional', 'photo'];
        
        // Get all sections in order
        const $sections = $wrapper.find('.cv-builder-section');
        
        // Handle Next button
        $wrapper.on('click', '.cv-nav-next', function(e) {
            e.preventDefault();
            const $currentSection = $(this).closest('.cv-builder-section');
            const currentSectionId = $currentSection.data('section');
            const currentIndex = sections.indexOf(currentSectionId);
            
            // Check if all active fields are filled
            if (!validateActiveFields($currentSection)) {
                alert('Please fill all active fields before proceeding.');
                return;
            }
            
            // Move to next section
            if (currentIndex < sections.length - 1) {
                const nextSectionId = sections[currentIndex + 1];
                navigateToSection($wrapper, currentSectionId, nextSectionId);
            }
        });
        
        // Handle Previous button
        $wrapper.on('click', '.cv-nav-prev, .cv-nav-prev:contains("previous"), .cv-nav-prev:contains("Previous")', function(e) {
            e.preventDefault();
            const $currentSection = $(this).closest('.cv-builder-section');
            const currentSectionId = $currentSection.data('section');
            const currentIndex = sections.indexOf(currentSectionId);
            
            // Move to previous section
            if (currentIndex > 0) {
                const prevSectionId = sections[currentIndex - 1];
                navigateToSection($wrapper, currentSectionId, prevSectionId);
            }
        });
        
        // Update Previous button visibility on load
        updateNavigationButtons($wrapper);
    }
    
    /**
     * Validate that all active fields have values
     */
    function validateActiveFields($section) {
        let allFilled = true;
        const $activeFields = $section.find('.cv-field-toggle:checked').closest('.cv-field-item');
        
        $activeFields.each(function() {
            const $field = $(this);
            const $input = $field.find('.cv-field-input');
            const $textarea = $field.find('textarea.cv-field-input');
            const $select = $field.find('.cv-field-select');
            const $ganeshaImage = $field.find('.cv-field-ganesha-image');
            
            // Skip header fields (Ganesha, Shree Ganesh, Biodata)
            if ($field.hasClass('cv-header-field')) {
                return; // Skip validation for header fields
            }
            
            let hasValue = false;
            
            if ($textarea.length) {
                hasValue = $textarea.val().trim() !== '';
            } else if ($select.length) {
                hasValue = $select.val() !== '';
            } else if ($input.length) {
                hasValue = $input.val().trim() !== '';
            }
            
            if (!hasValue) {
                allFilled = false;
                // Highlight empty field
                $field.addClass('validation-error');
                setTimeout(function() {
                    $field.removeClass('validation-error');
                }, 2000);
            }
        });
        
        return allFilled;
    }
    
    /**
     * Navigate to a specific section
     */
    function navigateToSection($wrapper, fromSection, toSection) {
        const $from = $wrapper.find('[data-section="' + fromSection + '"]');
        const $to = $wrapper.find('[data-section="' + toSection + '"]');

        closeSection($from, SECTION_ANIMATION_DURATION);
        openSection($to, SECTION_ANIMATION_DURATION, { focusFirst: true });

        // Scroll to section
        $('html, body').animate({
            scrollTop: $to.offset().top - 50
        }, 300);
        
        // Update navigation buttons
        updateNavigationButtons($wrapper);
    }
    
    /**
     * Update navigation button visibility
     */
    function updateNavigationButtons($wrapper) {
        const sections = ['personal', 'family', 'contact', 'professional', 'photo'];
        const $allSections = $wrapper.find('.cv-builder-section');
        
        $allSections.each(function() {
            const $section = $(this);
            const sectionId = $section.data('section');
            const currentIndex = sections.indexOf(sectionId);
            const $nav = $section.find('.cv-field-manager-navigation');
            const $prevBtn = $nav.find('.cv-nav-prev');
            const $nextBtn = $nav.find('.cv-nav-next');
            
            // Hide Previous on first section
            if (currentIndex === 0) {
                $prevBtn.hide();
            } else {
                $prevBtn.show();
            }
            
            // Hide Next on last section
            if (currentIndex === sections.length - 1) {
                $nextBtn.hide();
            } else {
                $nextBtn.show();
            }
        });
    }

    /**
     * Show crop profile picture modal
     */
    function showCropModal(imageSrc, instanceId) {
        const $modal = $('#cv-crop-modal');
        const $overlay = $modal.find('.cv-crop-modal-overlay');
        const $cancelBtn = $modal.find('.cv-crop-modal-cancel');
        const $saveBtn = $modal.find('.cv-crop-modal-save');
        const $cropImg = $modal.find('#cv-crop-image');
        const $previewImg = $modal.find('#cv-crop-preview');
        const $previewImgMain = $('#cv-photo-preview-' + instanceId);
        const $preview = $('.cv-builder-upload-preview[data-instance="' + instanceId + '"]');
        const $uploadBtn = $('.cv-upload-photo-btn[data-instance="' + instanceId + '"]');
        
        let cropper = null;

        // Set the image source
        $cropImg.attr('src', imageSrc);
        $previewImg.attr('src', imageSrc);

        // Remove existing event listeners
        $cancelBtn.off('click.cropModal');
        $saveBtn.off('click.cropModal');
        $overlay.off('click.cropModal');
        $(document).off('keydown.cropModal');

        // Show modal
        $modal.addClass('active');
        $('body').css('overflow', 'hidden');

        // Initialize Cropper.js after image loads
        $cropImg.on('load.cropInit', function() {
            // Destroy existing cropper if any
            if (cropper) {
                cropper.destroy();
            }

            // Initialize cropper with square crop (1:1 aspect ratio)
            cropper = new Cropper($cropImg[0], {
                aspectRatio: 1,
                viewMode: 1,
                dragMode: 'move',
                autoCropArea: 0.8,
                restore: false,
                guides: true,
                center: true,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: true,
                toggleDragModeOnDblclick: false,
                background: true,
                modal: true,
                ready: function() {
                    // Update preview on initial load
                    updatePreview();
                },
                crop: function() {
                    // Update preview on crop change
                    updatePreview();
                }
            });
            
            // Function to update preview
            function updatePreview() {
                if (cropper) {
                    const canvas = cropper.getCroppedCanvas({
                        width: 200,
                        height: 200,
                        imageSmoothingEnabled: true,
                        imageSmoothingQuality: 'high'
                    });
                    
                    if (canvas) {
                        const dataUrl = canvas.toDataURL('image/png');
                        $previewImg.attr('src', dataUrl);
                    }
                }
            }
        });

        // Trigger load if image already loaded
        if ($cropImg[0].complete) {
            $cropImg.trigger('load.cropInit');
        }

        // Close modal functions
        function closeCropModal() {
            if (cropper) {
                cropper.destroy();
                cropper = null;
            }
            $modal.removeClass('active');
            $('body').css('overflow', '');
            $cropImg.off('load.cropInit');
        }

        $cancelBtn.on('click.cropModal', closeCropModal);
        $overlay.on('click.cropModal', closeCropModal);

        // Save cropped image
        $saveBtn.on('click.cropModal', function() {
            if (cropper) {
                const canvas = cropper.getCroppedCanvas({
                    width: 400,
                    height: 400,
                    imageSmoothingEnabled: true,
                    imageSmoothingQuality: 'high'
                });
                
                if (canvas) {
                    const dataUrl = canvas.toDataURL('image/png');
                    
                    // Update preview
                    $previewImgMain.attr('src', dataUrl);
                    $uploadBtn.hide();
                    $preview.show();
                    
                    closeCropModal();
                }
            }
        });

        // Close on Escape key
        $(document).on('keydown.cropModal', function(e) {
            if (e.key === 'Escape' && $modal.hasClass('active')) {
                closeCropModal();
            }
        });
    }

    /**
     * Initialize translator widget if present
     */
    function initializeTranslatorWidget() {
        // Check if GT Translate or other translator widgets are present
        const $translatorWidget = $('.cv-shortcode-output');
        if ($translatorWidget.length > 0) {
            // Trigger any translator plugin initialization
            // This ensures dropdown functionality works
            $(document).trigger('gt_init');
            $(document).trigger('gtranslate_init');
            
            // Re-initialize any dropdown widgets
            if (typeof window.gtranslateSettings !== 'undefined') {
                // GT Translate initialization
                if (window.gtranslateSettings && typeof window.gtranslateSettings.init === 'function') {
                    window.gtranslateSettings.init();
                }
            }
            
            // Generic translator widget initialization
            $translatorWidget.find('select, .gt-selector, .gtranslate-wrapper').each(function() {
                const $widget = $(this);
                if ($widget.hasClass('initialized')) {
                    return;
                }
                $widget.addClass('initialized');
                
                // Ensure click events work
                $widget.off('click.translator').on('click.translator', function(e) {
                    e.stopPropagation();
                });
            });
        }
    }

    // Initialize on document ready
    $(document).ready(function() {
        initializeTranslatorWidget();
    });

    // Re-initialize after AJAX or dynamic content load
    $(document).on('cvBuilderFormLoaded', function() {
        setTimeout(initializeTranslatorWidget, 100);
    });

})(jQuery);

