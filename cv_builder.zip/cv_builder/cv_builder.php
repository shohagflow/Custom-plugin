<?php
/**
 * Plugin Name: CV Builder
 * Plugin URI: https://example.com/cv-builder
 * Description: Create personalized marriage biodata/CV with customizable templates
 * Version: 1.0.0
 * Author: Shohag rana
 * Author URI: https://github.com/shohagflow
 * License: GPL v2 or later
 * Text Domain: cv-builder
 * Requires Plugins:  gtranslate
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('CV_BUILDER_VERSION', '1.0.1');
define('CV_BUILDER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CV_BUILDER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CV_BUILDER_PLUGIN_PATH', CV_BUILDER_PLUGIN_DIR);

class CV_Builder {

    private static $shortcode_used = false;
    private $default_templates = array();
    private $localized_settings = null;

    public function __construct() {
        $this->default_templates = array(
            array(
                'label' => __('Template 1', 'cv-builder'),
                'image' => CV_BUILDER_PLUGIN_URL . 'templete-preview/images/10.png',
            ),
            array(
                'label' => __('Template 2', 'cv-builder'),
                'image' => CV_BUILDER_PLUGIN_URL . 'templete-preview/images/13.png',
            ),
            array(
                'label' => __('Template 3', 'cv-builder'),
                'image' => CV_BUILDER_PLUGIN_URL . 'templete-preview/images/image.png',
            ),
        );

        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'maybe_save_templates'));
        add_action('admin_init', array($this, 'maybe_save_shortcode'));
        add_action('admin_init', array($this, 'maybe_save_shortcut'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_action('wp_footer', array($this, 'enqueue_footer_scripts'));
        add_shortcode('cv_builder', array($this, 'render_shortcode'));
    }
    
    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_frontend_scripts() {
        global $post;
        
        // Check if shortcode exists in current post/page content
        $has_shortcode = false;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'cv_builder')) {
            $has_shortcode = true;
        }
        
        // Enqueue if shortcode is found or if we're on a page that might have it
        if ($has_shortcode || self::$shortcode_used) {
            wp_enqueue_style(
                'cv-builder-frontend',
                CV_BUILDER_PLUGIN_URL . 'assets/css/admin.css',
                array(),
                CV_BUILDER_VERSION . '.' . time() // Cache busting
            );
            
            wp_enqueue_script(
                'cv-builder-frontend',
                CV_BUILDER_PLUGIN_URL . 'assets/js/admin.js',
                array('jquery', 'jquery-ui-datepicker', 'cropper-js'),
                CV_BUILDER_VERSION . '.' . time(), // Cache busting
                true
            );

            wp_localize_script(
                'cv-builder-frontend',
                'cvBuilderSettings',
                $this->get_frontend_settings()
            );
            
            // Enqueue Cropper.js for image cropping (must load before our script)
            wp_enqueue_style('cropper-css', 'https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.css');
            wp_enqueue_script('cropper-js', 'https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.js', array('jquery'), '1.5.13', false);
            
            // Enqueue jQuery UI CSS for datepicker
            wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.12.1/themes/ui-lightness/jquery-ui.css');
            
            // Ensure translator plugin scripts are loaded if shortcode is present
            $saved_shortcode = get_option('cv_builder_shortcode', '');
            if (!empty($saved_shortcode)) {
                // Trigger action to let other plugins know to enqueue their assets
                do_action('cv_builder_translator_shortcode_loaded');
                
                // Try to enqueue GT Translate scripts if available
                if (function_exists('gtranslate_enqueue_scripts')) {
                    gtranslate_enqueue_scripts();
                }
                if (function_exists('gt_enqueue_scripts')) {
                    gt_enqueue_scripts();
                }
            }
        }
    }
    
    /**
     * Enqueue scripts in footer (after shortcode processing)
     * This ensures scripts load even if shortcode is in widgets or dynamically added
     */
    public function enqueue_footer_scripts() {
        // If shortcode was used but assets weren't enqueued, add them inline
        if (self::$shortcode_used && !wp_style_is('cv-builder-frontend', 'enqueued')) {
            // Add CSS link in footer as fallback
            $css_url = CV_BUILDER_PLUGIN_URL . 'assets/css/admin.css?ver=' . CV_BUILDER_VERSION . '.' . time();
            echo '<link rel="stylesheet" href="' . esc_url($css_url) . '" type="text/css" media="all">';
            
            // Enqueue Cropper.js for image cropping (must load before our script)
            wp_enqueue_style('cropper-css', 'https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.css');
            wp_enqueue_script('cropper-js', 'https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.js', array('jquery'), '1.5.13', false);
            
            // Enqueue script normally (scripts can go in footer)
            wp_enqueue_script(
                'cv-builder-frontend',
                CV_BUILDER_PLUGIN_URL . 'assets/js/admin.js',
                array('jquery', 'cropper-js'),
                CV_BUILDER_VERSION . '.' . time(),
                true
            );

            wp_localize_script(
                'cv-builder-frontend',
                'cvBuilderSettings',
                $this->get_frontend_settings()
            );
        }
    }
    
    /**
     * Shortcode handler
     */
    public function render_shortcode($atts = array(), $content = null, $tag = 'cv_builder') {
        // Mark that shortcode is used
        self::$shortcode_used = true;
        
        // Parse shortcode attributes
        $atts = shortcode_atts(array(
            'title' => 'Start Building Marriage Biodata',
            'subtitle' => 'Fill in the details below to create your personalized marriage biodata.',
        ), $atts, $tag);
        
        // Generate unique instance ID
        $instance_id = 'cv-' . uniqid();
        
        // Start output buffering
        ob_start();
        
        // Make variables available to template
        $template_atts = $atts;
        $template_instance_id = $instance_id;
        
        // Include the frontend template
        include CV_BUILDER_PLUGIN_DIR . 'templates/frontend-form.php';
        
        // Get the output
        return ob_get_clean();
    }

    public function add_admin_menu() {
        add_menu_page(
            __('CV Builder Templates', 'cv-builder'),
            __('CV Templates', 'cv-builder'),
            'manage_options',
            'cv-builder-templates',
            array($this, 'render_admin_page'),
            'dashicons-media-default',
            81
        );
    }

    public function enqueue_admin_assets($hook) {
        if ($hook !== 'toplevel_page_cv-builder-templates') {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style(
            'cv-builder-admin-settings',
            CV_BUILDER_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            CV_BUILDER_VERSION
        );
        wp_enqueue_script(
            'cv-builder-admin-settings',
            CV_BUILDER_PLUGIN_URL . 'assets/js/admin-settings.js',
            array('jquery'),
            CV_BUILDER_VERSION,
            true
        );
        
        // Localize script with nonce for shortcode save
        wp_localize_script(
            'cv-builder-admin-settings',
            'cvBuilderAdmin',
            array(
                'shortcodeNonce' => wp_create_nonce('cv_builder_save_shortcode'),
                'shortcutNonce' => wp_create_nonce('cv_builder_save_shortcut'),
                'ajaxUrl' => admin_url('admin-ajax.php')
            )
        );
    }
    
    /**
     * Save shortcut handler (form submission)
     */
    public function maybe_save_shortcut() {
        // Check if this is a shortcut save request
        if (!isset($_POST['cv_builder_shortcut_nonce']) || !isset($_POST['action']) || $_POST['action'] !== 'save_shortcut') {
            return;
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['cv_builder_shortcut_nonce'], 'cv_builder_save_shortcut')) {
            add_settings_error(
                'cv-builder-shortcut',
                'cvBuilderShortcutError',
                __('Security check failed. Please try again.', 'cv-builder'),
                'error'
            );
            wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcut-saved' => '1'), admin_url('admin.php')));
            exit;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            add_settings_error(
                'cv-builder-shortcut',
                'cvBuilderShortcutError',
                __('You do not have permission.', 'cv-builder'),
                'error'
            );
            wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcut-saved' => '1'), admin_url('admin.php')));
            exit;
        }
        
        // Get and validate input
        $shortcut = isset($_POST['shortcut_input']) ? trim($_POST['shortcut_input']) : '';
        
        if (empty($shortcut)) {
            add_settings_error(
                'cv-builder-shortcut',
                'cvBuilderShortcutError',
                __('Please enter something.', 'cv-builder'),
                'error'
            );
            wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcut-saved' => '1'), admin_url('admin.php')));
            exit;
        }
        
        // Sanitize input
        $shortcut = wp_unslash($shortcut);
        $shortcut = sanitize_text_field($shortcut);
        
        // Save to WordPress options
        $saved = update_option('saved_custom_shortcode', $shortcut);
        
        if ($saved === false) {
            // Try add_option if update_option failed
            delete_option('saved_custom_shortcode');
            $saved = add_option('saved_custom_shortcode', $shortcut, '', 'no');
        }
        
        if ($saved !== false) {
            add_settings_error(
                'cv-builder-shortcut',
                'cvBuilderShortcutSaved',
                __('Shortcut successfully saved.', 'cv-builder'),
                'updated'
            );
        } else {
            add_settings_error(
                'cv-builder-shortcut',
                'cvBuilderShortcutError',
                __('Failed to save shortcut.', 'cv-builder'),
                'error'
            );
        }
        
        // Store errors in transient for display after redirect
        $settings_errors = get_settings_errors('cv-builder-shortcut');
        if (!empty($settings_errors)) {
            set_transient('cv_builder_shortcut_settings_errors', $settings_errors, 30);
        }
        
        // Redirect to prevent resubmission
        wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcut-saved' => '1'), admin_url('admin.php')));
        exit;
    }

    public function maybe_save_templates() {
        if (!isset($_POST['cv_builder_templates_nonce'])) {
            return;
        }

        if (!current_user_can('manage_options')) {
            return;
        }

        if (!wp_verify_nonce($_POST['cv_builder_templates_nonce'], 'cv_builder_save_templates')) {
            return;
        }

        $templates = array();
        if (!empty($_POST['cv_builder_templates']) && is_array($_POST['cv_builder_templates'])) {
            foreach ($_POST['cv_builder_templates'] as $url) {
                $url = esc_url_raw(trim($url));
                if (!empty($url)) {
                    $templates[] = $url;
                }
            }
        }

        update_option('cv_builder_templates', $templates);

        // Save custom shortcode (always save, even if empty)
        $shortcode = '';
        if (isset($_POST['cv_builder_shortcode'])) {
            // Get the shortcode value
            $shortcode = isset($_POST['cv_builder_shortcode']) ? $_POST['cv_builder_shortcode'] : '';
            $shortcode = wp_unslash($shortcode);
            $shortcode = trim($shortcode);
            
            // Preserve shortcode format - remove only dangerous content
            // Remove script and style tags
            $shortcode = preg_replace('/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi', '', $shortcode);
            $shortcode = preg_replace('/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi', '', $shortcode);
        }
        
        // Always save the shortcode (even if empty to clear it)
        $shortcode_saved = update_option('cv_builder_shortcode', $shortcode);
        
        // Debug: Log shortcode save (remove in production if needed)
        // error_log('CV Builder: Shortcode save attempt. Value: ' . $shortcode . ', Saved: ' . ($shortcode_saved ? 'true' : 'false'));

        $message = __('Templates updated successfully.', 'cv-builder');
        if (!empty($shortcode)) {
            $message .= ' ' . __('Shortcode saved.', 'cv-builder');
        }
        
        add_settings_error(
            'cv-builder-templates',
            'cvBuilderTemplatesSaved',
            $message,
            'updated'
        );

        wp_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'settings-updated' => 'true'), admin_url('admin.php')));
        exit;
    }

    /**
     * Save shortcode separately
     */
    public function maybe_save_shortcode() {
        // Check if this is a shortcode save request
        if (!isset($_POST['action']) || $_POST['action'] !== 'save_cv_builder_shortcode') {
            return;
        }
        
        // Verify nonce - required for security
        if (!isset($_POST['cv_builder_shortcode_nonce']) || !wp_verify_nonce($_POST['cv_builder_shortcode_nonce'], 'cv_builder_save_shortcode')) {
            add_settings_error(
                'cv-builder-shortcode',
                'cvBuilderShortcodeError',
                __('Security check failed. Please try again.', 'cv-builder'),
                'error'
            );
            // Still redirect to show error
            wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcode-saved' => '1'), admin_url('admin.php')));
            exit;
        }

        // Check permissions
        if (!current_user_can('manage_options')) {
            add_settings_error(
                'cv-builder-shortcode',
                'cvBuilderShortcodeError',
                __('You do not have permission to perform this action.', 'cv-builder'),
                'error'
            );
            return;
        }

        // Get the shortcode value
        $shortcode = isset($_POST['cv_builder_shortcode']) ? $_POST['cv_builder_shortcode'] : '';
        $shortcode = wp_unslash($shortcode);
        $shortcode = trim($shortcode);
        
        // Remove only dangerous content, preserve shortcode format
        if (!empty($shortcode)) {
            $shortcode = preg_replace('/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi', '', $shortcode);
            $shortcode = preg_replace('/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi', '', $shortcode);
        }
        
        // Save the shortcode - always save (even if empty)
        $saved = update_option('cv_builder_shortcode', $shortcode);
        
        // If update_option returns false, the option might not exist yet
        if ($saved === false) {
            // Try to add it as a new option
            $saved = add_option('cv_builder_shortcode', $shortcode, '', 'no');
        }

        // Set success message
        if ($saved !== false) {
            add_settings_error(
                'cv-builder-shortcode',
                'cvBuilderShortcodeSaved',
                __('Shortcode saved successfully!', 'cv-builder'),
                'updated'
            );
        } else {
            add_settings_error(
                'cv-builder-shortcode',
                'cvBuilderShortcodeError',
                __('Failed to save shortcode. Please try again.', 'cv-builder'),
                'error'
            );
        }

        // Store settings errors in transient before redirect (WordPress clears them on redirect)
        $settings_errors = get_settings_errors('cv-builder-shortcode');
        if (!empty($settings_errors)) {
            set_transient('cv_builder_shortcode_settings_errors', $settings_errors, 30);
        }

        // Redirect to prevent resubmission and show message
        wp_safe_redirect(add_query_arg(array('page' => 'cv-builder-templates', 'shortcode-saved' => '1'), admin_url('admin.php')));
        exit;
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $templates = $this->get_templates();
        $saved_shortcode = get_option('cv_builder_shortcode', '');
        ?>
        <div class="wrap cv-builder-settings">
            <h1><?php esc_html_e('CV Builder Templates', 'cv-builder'); ?></h1>
            <?php 
            // Display all settings errors
            settings_errors('cv-builder-templates');
            
            // Check for shortcode-saved parameter and show message
            if (isset($_GET['shortcode-saved']) && $_GET['shortcode-saved'] == '1') {
                // Get stored errors from transient
                $stored_errors = get_transient('cv_builder_shortcode_settings_errors');
                if ($stored_errors) {
                    // Restore the errors
                    foreach ($stored_errors as $error) {
                        add_settings_error(
                            $error['setting'],
                            $error['code'],
                            $error['message'],
                            $error['type']
                        );
                    }
                    delete_transient('cv_builder_shortcode_settings_errors');
                } else {
                    // Default success message if no errors stored
                    add_settings_error(
                        'cv-builder-shortcode',
                        'cvBuilderShortcodeSaved',
                        __('Shortcode saved successfully!', 'cv-builder'),
                        'updated'
                    );
                }
            }
            
            // Display shortcode errors
            settings_errors('cv-builder-shortcode');
            ?>
            
            <!-- Shortcut Input Section -->
            <div class="cv-shortcut-input-section" style="margin-bottom: 30px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <h2 style="margin-top: 0;"><?php esc_html_e('Shortcut Input', 'cv-builder'); ?></h2>
                <form method="post" id="cv-builder-shortcut-form">
                    <?php wp_nonce_field('cv_builder_save_shortcut', 'cv_builder_shortcut_nonce'); ?>
                    <input type="hidden" name="action" value="save_shortcut">
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">
                                <label for="shortcut-input"><?php esc_html_e('Shortcode', 'cv-builder'); ?></label>
                            </th>
                            <td>
                                <?php $saved_shortcut = get_option('saved_custom_shortcode', ''); ?>
                                <input type="text" id="shortcut-input" name="shortcut_input" class="regular-text" value="<?php echo esc_attr($saved_shortcut); ?>" placeholder="<?php esc_attr_e('Paste your shortcode here...', 'cv-builder'); ?>">
                                <p class="description">
                                    <?php esc_html_e('Enter any shortcode you want to save.', 'cv-builder'); ?>
                                </p>
                                <p>
                                    <button type="submit" class="button button-primary" id="cv-builder-save-shortcut-btn"><?php esc_html_e('Save Shortcut', 'cv-builder'); ?></button>
                                </p>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            
            <?php 
            // Display shortcut save messages
            if (isset($_GET['shortcut-saved']) && $_GET['shortcut-saved'] == '1') {
                $stored_errors = get_transient('cv_builder_shortcut_settings_errors');
                if ($stored_errors) {
                    foreach ($stored_errors as $error) {
                        add_settings_error(
                            $error['setting'],
                            $error['code'],
                            $error['message'],
                            $error['type']
                        );
                    }
                    delete_transient('cv_builder_shortcut_settings_errors');
                }
            }
            settings_errors('cv-builder-shortcut');
            ?>
            
            <!-- Templates Form -->
            <form method="post">
                <?php wp_nonce_field('cv_builder_save_templates', 'cv_builder_templates_nonce'); ?>
                <p class="description">
                    <?php esc_html_e('Upload the template preview images you want to offer in the Customize tab. The first template will be used by default.', 'cv-builder'); ?>
                </p>

                <div id="cv-builder-template-list" class="cv-template-list">
                    <?php foreach ($templates as $template) : ?>
                        <div class="cv-template-row">
                            <div class="cv-template-thumb-wrapper">
                                <?php if (!empty($template['image'])) : ?>
                                    <img src="<?php echo esc_url($template['image']); ?>" alt="" class="cv-template-thumb" />
                                <?php else : ?>
                                    <img src="" alt="" class="cv-template-thumb hidden" />
                                <?php endif; ?>
                            </div>
                            <div class="cv-template-fields">
                                <input type="text" name="cv_builder_templates[]" class="cv-template-input regular-text"
                                    value="<?php echo esc_url($template['image']); ?>" placeholder="<?php esc_attr_e('Template image URL', 'cv-builder'); ?>" />
                                <div class="cv-template-actions">
                                    <button type="button" class="button cv-template-upload"><?php esc_html_e('Select Image', 'cv-builder'); ?></button>
                                    <button type="button" class="button cv-template-clear"><?php esc_html_e('Clear', 'cv-builder'); ?></button>
                                    <button type="button" class="button cv-template-remove"><?php esc_html_e('Remove', 'cv-builder'); ?></button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <p>
                    <button type="button" class="button button-secondary" id="cv-builder-add-template"><?php esc_html_e('Add Template', 'cv-builder'); ?></button>
                </p>

                <p>
                    <button type="submit" class="button button-primary"><?php esc_html_e('Save Templates', 'cv-builder'); ?></button>
                </p>
            </form>
        </div>
        <?php
    }

    private function get_frontend_settings() {
        if ($this->localized_settings !== null) {
            return $this->localized_settings;
        }

        $this->localized_settings = array(
            'previewUrl' => CV_BUILDER_PLUGIN_URL . 'templete-preview/index.html',
            'templates'  => $this->get_templates(),
        );

        return $this->localized_settings;
    }

    private function get_templates() {
        $saved = get_option('cv_builder_templates', array());
        $templates = array();

        if (is_array($saved) && !empty($saved)) {
            $index = 1;
            foreach ($saved as $url) {
                $url = esc_url_raw($url);
                if (empty($url)) {
                    continue;
                }

                $templates[] = array(
                    'label' => sprintf(__('Template %d', 'cv-builder'), $index),
                    'image' => $url,
                    'thumb' => $url,
                );
                $index++;
            }
        }

        if (empty($templates)) {
            foreach ($this->default_templates as $index => $template) {
                $templates[] = array(
                    'label' => $template['label'],
                    'image' => $template['image'],
                    'thumb' => $template['image'],
                );
            }
        }

        return $templates;
    }
}

// Initialize the plugin
new CV_Builder();

