<?php
/**
 * WooCommerce My Account integration
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_My_Account {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Add custom endpoint
        add_action('init', array($this, 'add_endpoints'));
        add_filter('query_vars', array($this, 'add_query_vars'));
        
        // Add menu items
        add_filter('woocommerce_account_menu_items', array($this, 'add_menu_items'), 40);
        
        // Add content
        add_action('woocommerce_account_beautician-dashboard_endpoint', array($this, 'render_beautician_dashboard'));
        
        // Add styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        
        // AJAX handlers
        add_action('wp_ajax_lcp_add_to_cart_checkout', array($this, 'ajax_add_to_cart_checkout'));
        add_action('wp_ajax_nopriv_lcp_add_to_cart_checkout', array($this, 'ajax_add_to_cart_checkout'));
        
        // Fix billing fields for checkout compatibility (optimized: only on checkout)
        // Run EARLY to prevent other plugins from accessing undefined keys
        add_action('template_redirect', array($this, 'ensure_checkout_billing_fields'), 1);
        // CRITICAL: Use woocommerce_checkout_posted_data FILTER (not action) - this is the CORRECT hook
        // This hook directly filters the data from checkout form submission
        // Runs with priority 1 to ensure billing_company exists BEFORE invoicing plugin accesses it
        add_filter('woocommerce_checkout_posted_data', array($this, 'ensure_posted_data_fields'), 1);
        add_filter('woocommerce_checkout_get_value', array($this, 'ensure_billing_fields'), 1, 2);
        add_action('woocommerce_checkout_init', array($this, 'initialize_billing_fields'), 1);
        add_action('woocommerce_before_checkout_process', array($this, 'initialize_billing_fields'), 1);
        // CRITICAL: Run with priority 1 to ensure billing_company exists BEFORE invoicing plugin accesses it
        add_filter('woocommerce_checkout_fields', array($this, 'ensure_checkout_fields_early'), 1);
    }
    
    /**
     * Add custom endpoints
     */
    public function add_endpoints() {
        add_rewrite_endpoint('beautician-dashboard', EP_ROOT | EP_PAGES);
    }
    
    /**
     * Add query vars
     */
    public function add_query_vars($vars) {
        $vars[] = 'beautician-dashboard';
        return $vars;
    }
    
    /**
     * Add menu items to My Account
     */
    public function add_menu_items($items) {
        // Check if user is beautician or super admin
        if (LCP_Roles::can_access_dashboard()) {
            // Insert after "Dashboard"
            $new_items = array();
            foreach ($items as $key => $value) {
                $new_items[$key] = $value;
                
                // Insert after dashboard
                if ($key === 'dashboard') {
                    $new_items['beautician-dashboard'] = __('Beautician Dashboard', 'loyalty-card-pro');
                }
            }
            return $new_items;
        }
        
        return $items;
    }
    
    /**
     * Render beautician dashboard in My Account
     */
    public function render_beautician_dashboard() {
        $user_id = get_current_user_id();
        
        if (!LCP_Roles::can_access_dashboard($user_id)) {
            echo '<p>' . __('Access denied.', 'loyalty-card-pro') . '</p>';
            return;
        }
        
        // Redirect to admin dashboard if not on frontend
        if (is_admin()) {
            wp_redirect(admin_url('admin.php?page=loyalty-card-pro'));
            exit;
        }
        
        $beautician_name = wp_get_current_user()->display_name;
        
        // Dummy customer data
        $dummy_customers = array(
            array('id' => 1, 'name' => 'Emma Rodriguez', 'phone' => '+1 555-0123', 'loyalty_cards' => 2, 'tickets' => 3, 'date' => '2026-01-15'),
            array('id' => 2, 'name' => 'Sophia Chen', 'phone' => '+1 555-0456', 'loyalty_cards' => 1, 'tickets' => 5, 'date' => '2026-01-14'),
            array('id' => 3, 'name' => 'Olivia Martinez', 'phone' => '+1 555-0789', 'loyalty_cards' => 3, 'tickets' => 2, 'date' => '2026-01-13'),
            array('id' => 4, 'name' => 'Isabella Taylor', 'phone' => '+1 555-0321', 'loyalty_cards' => 1, 'tickets' => 4, 'date' => '2026-01-12'),
            array('id' => 5, 'name' => 'Mia Anderson', 'phone' => '+1 555-0654', 'loyalty_cards' => 0, 'tickets' => 6, 'date' => '2026-01-11'),
        );
        
        ?>
        <style>
        /* Modern Dashboard Styles */
        .lcp-frontend-dashboard {
            max-width: 1200px;
            margin: 0 auto;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
        }
        
        /* Header */
        .lcp-dashboard-header {
            background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%);
            color: white;
            padding: 30px 25px;
            border-radius: 15px;
            margin-bottom: 25px;
            box-shadow: 0 4px 20px rgba(254, 122, 193, 0.3);
        }
        
        .lcp-dashboard-header h1 {
            margin: 0 0 5px 0;
            font-size: 28px;
            font-weight: 700;
            color: white !important;
        }
        
        .lcp-dashboard-header p {
            margin: 0;
            opacity: 0.9;
            font-size: 16px;
            color: white !important;
        }
        
        /* Tab Navigation */
        .lcp-tab-nav {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            flex-wrap: wrap;
            background: white;
            padding: 15px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }
        
        .lcp-tab-btn {
            flex: 1;
            min-width: 140px;
            padding: 15px 20px;
            border: 2px solid #FFEFF7;
            background: white;
            color: #666;
            font-weight: 600;
            font-size: 14px;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .lcp-tab-btn:hover {
            border-color: #FE7AC1;
            color: #FE7AC1;
            transform: translateY(-2px);
        }
        
        .lcp-tab-btn.active {
            background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%);
            border-color: #FE7AC1;
            color: white;
            box-shadow: 0 4px 15px rgba(254, 122, 193, 0.4);
        }
        
        .lcp-tab-btn.play-game {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
            border-color: #FFD700;
            color: white;
            font-weight: 700;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        /* Tab Content */
        .lcp-tab-content {
            display: none;
            animation: fadeIn 0.4s;
        }
        
        .lcp-tab-content.active {
            display: block;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Cards */
        .lcp-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        
        .lcp-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .lcp-card-header h3 {
            margin: 0;
            color: #FE7AC1;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        /* Search */
        .lcp-search-box {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .lcp-search-box input {
            flex: 1;
            padding: 12px 15px;
            border: 2px solid #FFEFF7;
            border-radius: 10px;
            font-size: 14px;
        }
        
        .lcp-search-box input:focus {
            border-color: #FE7AC1;
            outline: none;
        }
        
        /* Search Suggestions Dropdown */
        .lcp-search-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 2px solid #FE7AC1;
            border-radius: 10px;
            margin-top: 5px;
            max-height: 300px;
            overflow-y: auto;
            box-shadow: 0 4px 20px rgba(254, 122, 193, 0.2);
            z-index: 1000;
        }
        
        .lcp-suggestion-item {
            padding: 12px 15px;
            cursor: pointer;
            border-bottom: 1px solid #FFEFF7;
            transition: background 0.2s;
        }
        
        .lcp-suggestion-item:last-child {
            border-bottom: none;
        }
        
        .lcp-suggestion-item:hover {
            background: #FFF5FB;
        }
        
        .lcp-suggestion-name {
            font-weight: 600;
            color: #333;
            display: block;
            margin-bottom: 4px;
        }
        
        .lcp-suggestion-phone {
            font-size: 13px;
            color: #FE7AC1;
        }
        
        .lcp-no-results {
            padding: 15px;
            text-align: center;
            color: #999;
        }
        
        /* Buttons */
        .lcp-btn {
            padding: 12px 24px;
            border-radius: 10px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .lcp-btn-primary {
            background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%);
            color: white;
        }
        
        .lcp-btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(254, 122, 193, 0.4);
        }
        
        .lcp-btn-secondary {
            background: #FFEFF7;
            color: #FE7AC1;
        }
        
        .lcp-btn-secondary:hover {
            background: #FE7AC1;
            color: white;
        }
        
        .lcp-btn-icon {
            padding: 8px 12px;
            font-size: 18px;
        }
        
        /* Table */
        .lcp-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            overflow: hidden;
            border-radius: 10px;
        }
        
        .lcp-table thead {
            background: #FFEFF7;
        }
        
        .lcp-table th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #FE7AC1;
            font-size: 14px;
        }
        
        .lcp-table td {
            padding: 15px;
            border-top: 1px solid #f5f5f5;
        }
        
        .lcp-table tbody tr {
            transition: background 0.2s;
        }
        
        .lcp-table tbody tr:hover {
            background: #FFEFF7;
        }
        
        /* Stats */
        .lcp-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .lcp-stat-box {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            text-align: center;
        }
        
        .lcp-stat-box h4 {
            margin: 0 0 5px 0;
            font-size: 32px;
            color: #FE7AC1;
            font-weight: 700;
        }
        
        .lcp-stat-box p {
            margin: 0;
            color: #666;
            font-size: 14px;
        }
        
        /* Badge */
        .lcp-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .lcp-badge-yes {
            background: #4CAF50;
            color: white;
        }
        
        .lcp-badge-no {
            background: #f5f5f5;
            color: #999;
        }
        
        .lcp-badge-count {
            background: #FE7AC1;
            color: white;
        }
        
        /* Modal */
        .lcp-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.7);
            z-index: 99999;
            align-items: center;
            justify-content: center;
        }
        
        .lcp-modal.active {
            display: flex !important;
        }
        
        .lcp-modal-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            position: relative;
        }
        
        .lcp-modal-close {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }
        
        .lcp-modal-close:hover {
            color: #FE7AC1;
        }
        
        /* Form */
        .lcp-form-group {
            margin-bottom: 20px;
        }
        
        .lcp-form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .lcp-form-group input,
        .lcp-form-group select,
        .lcp-form-group textarea {
            width: 100%;
            padding: 0px 15px;
            border: 2px solid #FFEFF7;
            border-radius: 10px;
            font-size: 14px;
        }
        
        .lcp-form-group input:focus,
        .lcp-form-group select:focus,
        .lcp-form-group textarea:focus {
            border-color: #FE7AC1;
            outline: none;
        }
        
        /* QR Code */
        .lcp-qr-container {
            text-align: center;
            padding: 30px;
        }
        
        .lcp-qr-code {
            background: white;
            padding: 20px;
            border-radius: 15px;
            display: inline-block;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        /* Customer Info Card */
        .lcp-customer-info-card {
            background: linear-gradient(135deg, #FFF5FB 0%, #FFEFF7 100%);
            border: 2px solid #FE7AC1;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .lcp-info-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(254, 122, 193, 0.2);
        }
        
        .lcp-info-row:last-child {
            border-bottom: none;
        }
        
        .lcp-info-label {
            font-weight: 600;
            color: #FE7AC1;
        }
        
        .lcp-info-value {
            font-weight: 600;
            color: #333;
        }
        
        /* Game */
        .lcp-game-container {
            text-align: center;
            padding: 30px;
        }
        
        .lcp-game-option {
            display: inline-block;
            margin: 15px;
            padding: 40px 30px;
            background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%);
            color: white;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s;
            min-width: 200px;
        }
        
        .lcp-game-option:hover {
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 8px 25px rgba(254, 122, 193, 0.5);
        }
        
        .lcp-game-option h3 {
            margin: 0 0 10px 0;
            font-size: 24px;
        }
        
        .lcp-scratch-game,
        .lcp-spin-wheel {
            padding: 40px;
            text-align: center;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .lcp-tab-nav {
                flex-direction: column;
            }
            
            .lcp-tab-btn {
                width: 100%;
            }
            
            .lcp-dashboard-header h1 {
                font-size: 24px;
            }
            
            .lcp-table {
                font-size: 12px;
            }
            
            .lcp-table th,
            .lcp-table td {
                padding: 10px 8px;
            }
        }
        
        /* Icons */
        .dashicons {
            font-size: 20px;
            width: 20px;
            height: 20px;
        }
        </style>
        
        <div class="lcp-frontend-dashboard">
            <!-- Header -->
            <div class="lcp-dashboard-header">
                <h1>👋 <?php _e('Welcome', 'loyalty-card-pro'); ?>, <?php echo esc_html($beautician_name); ?>!</h1>
                <p><?php _e('Manage your salon clients, loyalty cards, and surprise tickets', 'loyalty-card-pro'); ?></p>
            </div>
            
            <!-- Tab Navigation -->
            <div class="lcp-tab-nav">
                <button class="lcp-tab-btn active" onclick="lcpSwitchFrontendTab('customers')">
                        <span class="dashicons dashicons-groups"></span>
                    <?php _e('Customers', 'loyalty-card-pro'); ?>
                </button>
                <button class="lcp-tab-btn" onclick="lcpSwitchFrontendTab('loyalty-cards')">
                    <span class="dashicons dashicons-awards"></span>
                    <?php _e('Loyalty Cards', 'loyalty-card-pro'); ?>
                </button>
                <button class="lcp-tab-btn" onclick="lcpSwitchFrontendTab('tickets')">
                    <span class="dashicons dashicons-tickets-alt"></span>
                    <?php _e('Scratch Tickets', 'loyalty-card-pro'); ?>
                </button>
                <button class="lcp-tab-btn" onclick="lcpSwitchFrontendTab('visit-tracking')">
                    <span class="dashicons dashicons-clipboard"></span>
                    <?php _e('Create Surprise & QR', 'loyalty-card-pro'); ?>
                </button>
                <button class="lcp-tab-btn play-game" onclick="lcpOpenGame()">
                    <span class="dashicons dashicons-games"></span>
                    <?php _e('Play Game', 'loyalty-card-pro'); ?>
                </button>
                    </div>
            
            <!-- Tab 1: Customer Management -->
            <div id="lcp-tab-customers" class="lcp-tab-content active">
                <div class="lcp-card">
                    <div class="lcp-card-header">
                        <h3>
                            <span class="dashicons dashicons-groups"></span>
                            <?php _e('Customer Management', 'loyalty-card-pro'); ?>
                        </h3>
                        <button class="lcp-btn lcp-btn-primary" onclick="lcpOpenAddCustomer()">
                            <span class="dashicons dashicons-plus-alt"></span>
                            <?php _e('Add Customer', 'loyalty-card-pro'); ?>
                        </button>
                        </div>
                    
                    <!-- Search -->
                    <div class="lcp-search-box">
                        <input type="text" id="lcp-customer-search" placeholder="<?php _e('Search by name or phone number...', 'loyalty-card-pro'); ?>" onkeyup="lcpSearchCustomers()">
                    </div>
                    
                    <!-- Customer Table -->
                    <div style="overflow-x: auto;">
                        <table class="lcp-table" id="lcp-customers-table">
                            <thead>
                                <tr>
                                    <th><?php _e('Name', 'loyalty-card-pro'); ?></th>
                                    <th><?php _e('Phone Number', 'loyalty-card-pro'); ?></th>
                                    <th><?php _e('Loyalty Cards', 'loyalty-card-pro'); ?></th>
                                    <th><?php _e('Visit Salon', 'loyalty-card-pro'); ?></th>
                                    <th><?php _e('Date Added', 'loyalty-card-pro'); ?></th>
                                    <th><?php _e('Actions', 'loyalty-card-pro'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($dummy_customers as $customer) : ?>
                                    <tr data-name="<?php echo esc_attr(strtolower($customer['name'])); ?>" data-phone="<?php echo esc_attr($customer['phone']); ?>">
                                        <td><strong><?php echo esc_html($customer['name']); ?></strong></td>
                                        <td><?php echo esc_html($customer['phone']); ?></td>
                                        <td>
                                            <?php if ($customer['loyalty_cards'] > 0) : ?>
                                                <span class="lcp-badge lcp-badge-yes">
                                                    <?php echo $customer['loyalty_cards']; ?> <?php _e('Cards', 'loyalty-card-pro'); ?>
                                                </span>
                                            <?php else : ?>
                                                <span class="lcp-badge lcp-badge-no"><?php _e('No Cards', 'loyalty-card-pro'); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="lcp-badge lcp-badge-count"><?php echo $customer['tickets']; ?></span>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($customer['date'])); ?></td>
                                        <td>
                                            <button class="lcp-btn lcp-btn-secondary lcp-btn-icon" onclick="alert('Delete customer: <?php echo esc_js($customer['name']); ?>')" title="<?php _e('Delete', 'loyalty-card-pro'); ?>">
                                                <span class="dashicons dashicons-trash"></span>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
                
            <!-- Tab 2: Manage Loyalty Cards -->
            <div id="lcp-tab-loyalty-cards" class="lcp-tab-content">
                <!-- Stats -->
                <div class="lcp-stats-grid">
                    <div class="lcp-stat-box">
                        <h4>15</h4>
                        <p><?php _e('Available Loyalty Cards', 'loyalty-card-pro'); ?></p>
                    </div>
                    <div class="lcp-stat-box">
                        <h4>23</h4>
                        <p><?php _e('Active Cards', 'loyalty-card-pro'); ?></p>
                    </div>
                    <div class="lcp-stat-box">
                        <h4>8</h4>
                        <p><?php _e('Completed Cards', 'loyalty-card-pro'); ?></p>
                    </div>
                </div>
                
                <div class="lcp-card">
                    <div class="lcp-card-header">
                        <h3>
                        <span class="dashicons dashicons-awards"></span>
                            <?php _e('Manage Loyalty Cards', 'loyalty-card-pro'); ?>
                        </h3>
                        <button class="lcp-btn lcp-btn-primary" onclick="lcpOpenPackageModal('loyalty')">
                            <span class="dashicons dashicons-cart"></span>
                            <?php _e('Purchase More', 'loyalty-card-pro'); ?>
                        </button>
                    </div>
                    
                    <!-- Assign Card -->
                    <div class="lcp-form-group" style="position: relative;">
                        <label><?php _e('Assign Loyalty Card to Customer', 'loyalty-card-pro'); ?></label>
                        <div class="lcp-search-box">
                            <input type="text" 
                                   id="lcp-assign-card-search" 
                                   placeholder="<?php _e('Search customer by name or phone...', 'loyalty-card-pro'); ?>"
                                   onkeyup="lcpSearchForCardAssignment()"
                                   onfocus="lcpShowCardAssignSuggestions()"
                                   autocomplete="off">
                    </div>
                        <!-- Live Search Suggestions -->
                        <div id="lcp-assign-card-suggestions" class="lcp-search-suggestions" style="display: none;"></div>
                        <input type="hidden" id="lcp-selected-customer-id" value="">
                </div>
                
                    <!-- Selected Customer Details Panel -->
                    <div id="lcp-assign-customer-details" style="display: none; margin-top: 20px; margin-bottom: 20px;">
                        <h4 style="color: #FE7AC1; margin-bottom: 15px;"><?php _e('Customer Details', 'loyalty-card-pro'); ?></h4>
                        <div class="lcp-customer-info-card">
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Name:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="assign-customer-name">-</span>
                    </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Phone Number:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="assign-customer-phone">-</span>
                            </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Loyalty Cards:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="assign-customer-cards">-</span>
                            </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Total Salon Visits:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="assign-customer-visits">-</span>
                            </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Date Added:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="assign-customer-date">-</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Assign Card Action -->
                    <div style="margin-top: 20px;">
                        <div style="display: flex; gap: 15px; align-items: flex-end;">
                            <div class="lcp-form-group" style="flex: 1; margin-bottom: 0;">
                                <label><?php _e('Number of Cards', 'loyalty-card-pro'); ?></label>
                                <input type="number" id="card-count-input" placeholder="<?php _e('Enter card count', 'loyalty-card-pro'); ?>" value="1" min="1">
                            </div>
                            <button class="lcp-btn lcp-btn-primary" onclick="lcpAssignCard()" id="lcp-assign-card-btn">
                                <span class="dashicons dashicons-awards"></span>
                                <?php _e('Assign Card', 'loyalty-card-pro'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Tab 3: Manage Scratch Tickets -->
            <div id="lcp-tab-tickets" class="lcp-tab-content">
                <!-- Stats -->
                <div class="lcp-stats-grid">
                    <div class="lcp-stat-box">
                        <h4>50</h4>
                        <p><?php _e('Available Tickets', 'loyalty-card-pro'); ?></p>
                    </div>
                    <div class="lcp-stat-box">
                        <h4>12</h4>
                        <p><?php _e('Assigned Tickets', 'loyalty-card-pro'); ?></p>
                    </div>
                    <div class="lcp-stat-box">
                        <h4>8</h4>
                        <p><?php _e('Revealed Tickets', 'loyalty-card-pro'); ?></p>
                    </div>
                </div>
                
                <div class="lcp-card">
                    <div class="lcp-card-header">
                        <h3>
                            <span class="dashicons dashicons-tickets-alt"></span>
                            <?php _e('Manage Scratch-Off Tickets', 'loyalty-card-pro'); ?>
                        </h3>
                        <button class="lcp-btn lcp-btn-primary" onclick="lcpOpenPackageModal('tickets')">
                            <span class="dashicons dashicons-cart"></span>
                            <?php _e('Purchase More', 'loyalty-card-pro'); ?>
                        </button>
                    </div>
                    
                    <!-- Assign Ticket -->
                    <h4 style="color: #FE7AC1; margin-bottom: 15px;"><?php _e('Assign Ticket to Customer', 'loyalty-card-pro'); ?></h4>
                    <div class="lcp-form-group" style="position: relative;">
                        <label><?php _e('Search Customer', 'loyalty-card-pro'); ?></label>
                        <div class="lcp-search-box">
                            <input type="text" 
                                   id="lcp-assign-ticket-search" 
                                   placeholder="<?php _e('Search customer by name or phone...', 'loyalty-card-pro'); ?>"
                                   onkeyup="lcpSearchForTicketAssignment()"
                                   onfocus="lcpShowTicketAssignSuggestions()"
                                   autocomplete="off">
                </div>
                        <!-- Live Search Suggestions -->
                        <div id="lcp-assign-ticket-suggestions" class="lcp-search-suggestions" style="display: none;"></div>
                        <input type="hidden" id="lcp-selected-ticket-customer-id" value="">
            </div>
            
                    <!-- Selected Customer Details Panel -->
                    <div id="lcp-assign-ticket-details" style="display: none; margin-top: 20px; margin-bottom: 20px;">
                        <h4 style="color: #FE7AC1; margin-bottom: 15px;"><?php _e('Customer Details', 'loyalty-card-pro'); ?></h4>
                        <div class="lcp-customer-info-card">
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Name:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="assign-ticket-name">-</span>
                            </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Phone Number:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="assign-ticket-phone">-</span>
                            </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Loyalty Cards:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="assign-ticket-cards">-</span>
                            </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Available Tickets:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="assign-ticket-count">-</span>
                            </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Date Added:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="assign-ticket-date">-</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Assign Ticket Action -->
                    <div style="margin-top: 20px;">
                        <div style="display: flex; gap: 15px; align-items: flex-end;">
                            <div class="lcp-form-group" style="flex: 1; margin-bottom: 0;">
                                <label><?php _e('Number of Tickets', 'loyalty-card-pro'); ?></label>
                                <input type="number" id="ticket-count-input" placeholder="<?php _e('Enter ticket count', 'loyalty-card-pro'); ?>" value="1" min="1">
                            </div>
                            <button class="lcp-btn lcp-btn-primary" onclick="lcpAssignTicket()">
                                <span class="dashicons dashicons-tickets-alt"></span>
                                <?php _e('Give Ticket', 'loyalty-card-pro'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tab 4: Create Surprise & QR -->
        <div id="lcp-tab-visit-tracking" class="lcp-tab-content">
            <div class="lcp-card">
                <div class="lcp-card-header">
                    <h3>
                        <span class="dashicons dashicons-clipboard"></span>
                        <?php _e('Create Surprise & QR', 'loyalty-card-pro'); ?>
                    </h3>
                    <p><?php _e('Create custom surprises and register customers using QR code', 'loyalty-card-pro'); ?></p>
                </div>
                
                <!-- Customer Registration Section -->
                <div style="margin-bottom: 30px;">
                    <h4 style="color: #FE7AC1; margin-bottom: 15px;"><?php _e('Customer Registration', 'loyalty-card-pro'); ?></h4>
                    <p style="color: #666; margin-bottom: 20px;">
                        <?php _e('Generate a QR code for customers to scan and register themselves', 'loyalty-card-pro'); ?>
                    </p>
                    <button class="lcp-btn lcp-btn-primary" onclick="lcpShowVisitQRCode()" style="width: 100%;">
                        <span class="dashicons dashicons-smartphone"></span>
                        <?php _e('Generate QR Code', 'loyalty-card-pro'); ?>
                    </button>
                </div>
                
                <!-- Create Custom Surprise Section -->
                <div style="margin-top: 30px; padding-top: 30px; border-top: 2px solid #FFEFF7;">
                    <h4 style="color: #FE7AC1; margin-bottom: 15px;"><?php _e('Create Custom Surprise', 'loyalty-card-pro'); ?></h4>
                    
                    <!-- Search Customer -->
                    <div class="lcp-form-group" style="position: relative;">
                        <label><?php _e('Search Customer', 'loyalty-card-pro'); ?></label>
                <div class="lcp-search-box">
                            <input type="text" 
                                   id="lcp-surprise-search" 
                                   placeholder="<?php _e('Search by name or phone number...', 'loyalty-card-pro'); ?>"
                                   onkeyup="lcpSearchForSurprise()"
                                   onfocus="lcpShowSurpriseSuggestions()"
                                   autocomplete="off">
                </div>
                        <!-- Live Search Suggestions -->
                        <div id="lcp-surprise-suggestions" class="lcp-search-suggestions" style="display: none;"></div>
                        <input type="hidden" id="lcp-selected-surprise-customer-id" value="">
            </div>
            
                    <!-- Selected Customer Details Panel -->
                    <div id="lcp-surprise-customer-details" style="display: none; margin-bottom: 25px;">
                        <h4 style="color: #FE7AC1; margin-bottom: 15px;"><?php _e('Customer Details', 'loyalty-card-pro'); ?></h4>
                        <div class="lcp-customer-info-card">
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Name:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="surprise-customer-name">-</span>
                    </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Phone Number:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="surprise-customer-phone">-</span>
                                </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Loyalty Cards:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="surprise-customer-cards">-</span>
                                </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Available Tickets:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="surprise-customer-tickets">-</span>
                                </div>
                            <div class="lcp-info-row">
                                <span class="lcp-info-label"><?php _e('Date Added:', 'loyalty-card-pro'); ?></span>
                                <span class="lcp-info-value" id="surprise-customer-date">-</span>
                            </div>
                    </div>
            </div>
            
                    <div class="lcp-form-group">
                        <label><?php _e('Surprise Type', 'loyalty-card-pro'); ?></label>
                        <select id="surprise-type">
                            <option value="discount"><?php _e('Discount', 'loyalty-card-pro'); ?></option>
                            <option value="free_service"><?php _e('Free Service', 'loyalty-card-pro'); ?></option>
                            <option value="free_item"><?php _e('Free Item', 'loyalty-card-pro'); ?></option>
                            <option value="voucher" selected><?php _e('Voucher', 'loyalty-card-pro'); ?></option>
                        </select>
            </div>
                    
                    <div class="lcp-form-group">
                        <label><?php _e('Surprise Value', 'loyalty-card-pro'); ?></label>
                        <input type="text" id="surprise-value" placeholder="<?php _e('e.g., 20% Off or Free Manicure', 'loyalty-card-pro'); ?>">
        </div>
        
                    <div class="lcp-form-group">
                        <label><?php _e('Loyalty Cards Required per Surprise', 'loyalty-card-pro'); ?></label>
                        <input type="number" id="cards-required" placeholder="<?php _e('How many loyalty cards will be cut?', 'loyalty-card-pro'); ?>" value="0" min="0">
                    </div>
                    
                    <div class="lcp-form-group">
                        <label><?php _e('Tickets Required per Surprise', 'loyalty-card-pro'); ?></label>
                        <input type="number" id="tickets-required" placeholder="<?php _e('How many tickets will be cut?', 'loyalty-card-pro'); ?>" value="0" min="0">
                    </div>
                    
                    <div class="lcp-form-group">
                        <label><?php _e('Quantity', 'loyalty-card-pro'); ?></label>
                        <input type="number" id="surprise-quantity" placeholder="<?php _e('How many surprises?', 'loyalty-card-pro'); ?>" value="0" min="0">
                    </div>
                    
                    <button class="lcp-btn lcp-btn-primary" onclick="lcpSaveSurprise()">
                        <span class="dashicons dashicons-saved"></span>
                        <?php _e('Save Surprise', 'loyalty-card-pro'); ?>
                    </button>
                    
                    <!-- Saved Surprises List -->
                    <div id="saved-surprises-section" style="margin-top: 40px; display: none;">
                        <h4 style="color: #FE7AC1; margin-bottom: 15px;"><?php _e('Saved Surprises', 'loyalty-card-pro'); ?></h4>
                        <div style="overflow-x: auto;">
                            <table class="lcp-table" id="saved-surprises-table">
                                <thead>
                                    <tr>
                                        <th><?php _e('Customer Name', 'loyalty-card-pro'); ?></th>
                                        <th><?php _e('Surprise Name', 'loyalty-card-pro'); ?></th>
                                        <th><?php _e('Select Customer', 'loyalty-card-pro'); ?></th>
                                        <th><?php _e('Cards Used', 'loyalty-card-pro'); ?></th>
                                        <th><?php _e('Tickets Used', 'loyalty-card-pro'); ?></th>
                                        <th><?php _e('Remaining', 'loyalty-card-pro'); ?></th>
                                        <th><?php _e('Date Created', 'loyalty-card-pro'); ?></th>
                                        <th><?php _e('Action', 'loyalty-card-pro'); ?></th>
                                    </tr>
                                </thead>
                                <tbody id="saved-surprises-tbody">
                                    <!-- Surprises will be added here dynamically -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Add Customer Modal -->
        <div id="lcp-add-customer-modal" class="lcp-modal">
            <div class="lcp-modal-content">
                <span class="lcp-modal-close" onclick="lcpCloseModal('lcp-add-customer-modal')">&times;</span>
                <h2 style="color: #FE7AC1; margin-bottom: 20px;"><?php _e('Add New Customer', 'loyalty-card-pro'); ?></h2>
                <form id="lcp-add-customer-form" onsubmit="lcpAddCustomer(event)">
                    <div class="lcp-form-group">
                        <label for="customer-name"><?php _e('Full Name', 'loyalty-card-pro'); ?> *</label>
                        <input type="text" id="customer-name" name="customer_name" required placeholder="<?php _e('Enter customer name', 'loyalty-card-pro'); ?>">
                    </div>
                    <div class="lcp-form-group">
                        <label for="customer-phone"><?php _e('Phone Number', 'loyalty-card-pro'); ?> *</label>
                        <input type="tel" id="customer-phone" name="customer_phone" required placeholder="+1 555-0000">
                    </div>
                    <button type="submit" class="lcp-btn lcp-btn-primary" style="width: 100%;">
                        <?php _e('Add Customer', 'loyalty-card-pro'); ?>
                    </button>
                </form>
            </div>
        </div>
        
        <!-- QR Code Modal -->
        <div id="lcp-qr-code-modal" class="lcp-modal">
            <div class="lcp-modal-content" style="max-width: 500px;">
                <span class="lcp-modal-close" onclick="lcpCloseModal('lcp-qr-code-modal')">&times;</span>
                <h2 style="color: #FE7AC1; margin-bottom: 10px; text-align: center;"><?php _e('Customer Registration QR Code', 'loyalty-card-pro'); ?></h2>
                <p style="text-align: center; color: #666; margin-bottom: 30px; font-size: 14px;">
                    <?php _e('Scan this code to register and join our loyalty program', 'loyalty-card-pro'); ?>
                </p>
                <div class="lcp-qr-container" style="text-align: center;">
                    <!-- QR Code Container -->
                    <div id="lcp-qr-code-display" style="display: inline-block; padding: 20px; background: white; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); margin-bottom: 20px;"></div>
                    
                    <!-- Registration URL Display (Hidden) -->
                    <div style="display: none;">
                        <p id="lcp-registration-url">
                            <?php echo esc_url(home_url('/customer-registration')); ?>
                        </p>
                    </div>
                    
                    <!-- Download Button -->
                    <button class="lcp-btn lcp-btn-primary" onclick="lcpDownloadQRCode()" style="width: 100%; margin-bottom: 10px;">
                        <span class="dashicons dashicons-download"></span>
                        <?php _e('Download QR Code', 'loyalty-card-pro'); ?>
                    </button>
                    
                    <!-- Print Button -->
                    <button class="lcp-btn lcp-btn-secondary" onclick="lcpPrintQRCode()" style="width: 100%;">
                        <span class="dashicons dashicons-printer"></span>
                        <?php _e('Print QR Code', 'loyalty-card-pro'); ?>
                    </button>
                    </div>
                </div>
            </div>
        
        <!-- Game Modal -->
        <div id="lcp-game-modal" class="lcp-modal">
            <div class="lcp-modal-content" style="max-width: 600px;">
                <span class="lcp-modal-close" onclick="lcpCloseModal('lcp-game-modal')">&times;</span>
                
                <!-- Game Selection -->
                <div id="lcp-game-selection" class="lcp-game-container">
                    <h2 style="color: #FE7AC1; margin-bottom: 30px;"><?php _e('Choose Your Game', 'loyalty-card-pro'); ?></h2>
                    <div class="lcp-game-option" onclick="lcpPlaySpinWheel()">
                        <div style="margin-bottom: 10px; display: flex; justify-content: center;">
                            <svg width="80" height="80" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                                <!-- Wheel segments -->
                                <g transform="translate(50,50)">
                                    <!-- Segment 1 - Pink -->
                                    <path d="M 0,-35 A 35,35 0 0,1 24.75,-24.75 L 0,0 Z" fill="#FE7AC1"/>
                                    <!-- Segment 2 - Yellow -->
                                    <path d="M 24.75,-24.75 A 35,35 0 0,1 35,0 L 0,0 Z" fill="#FFD700"/>
                                    <!-- Segment 3 - Green -->
                                    <path d="M 35,0 A 35,35 0 0,1 24.75,24.75 L 0,0 Z" fill="#4CAF50"/>
                                    <!-- Segment 4 - Blue -->
                                    <path d="M 24.75,24.75 A 35,35 0 0,1 0,35 L 0,0 Z" fill="#2196F3"/>
                                    <!-- Segment 5 - Orange -->
                                    <path d="M 0,35 A 35,35 0 0,1 -24.75,24.75 L 0,0 Z" fill="#FF9800"/>
                                    <!-- Segment 6 - Red -->
                                    <path d="M -24.75,24.75 A 35,35 0 0,1 -35,0 L 0,0 Z" fill="#F44336"/>
                                    <!-- Segment 7 - Purple -->
                                    <path d="M -35,0 A 35,35 0 0,1 -24.75,-24.75 L 0,0 Z" fill="#9C27B0"/>
                                    <!-- Segment 8 - Cyan -->
                                    <path d="M -24.75,-24.75 A 35,35 0 0,1 0,-35 L 0,0 Z" fill="#00BCD4"/>
                                </g>
                                
                                <!-- Red border with golden studs -->
                                <circle cx="50" cy="50" r="36" fill="none" stroke="#D32F2F" stroke-width="3"/>
                                
                                <!-- Golden decorative studs around the border -->
                                <circle cx="50" cy="12" r="2" fill="#FFD700"/>
                                <circle cx="68" cy="18" r="2" fill="#FFD700"/>
                                <circle cx="82" cy="32" r="2" fill="#FFD700"/>
                                <circle cx="88" cy="50" r="2" fill="#FFD700"/>
                                <circle cx="82" cy="68" r="2" fill="#FFD700"/>
                                <circle cx="68" cy="82" r="2" fill="#FFD700"/>
                                <circle cx="50" cy="88" r="2" fill="#FFD700"/>
                                <circle cx="32" cy="82" r="2" fill="#FFD700"/>
                                <circle cx="18" cy="68" r="2" fill="#FFD700"/>
                                <circle cx="12" cy="50" r="2" fill="#FFD700"/>
                                <circle cx="18" cy="32" r="2" fill="#FFD700"/>
                                <circle cx="32" cy="18" r="2" fill="#FFD700"/>
                                
                                <!-- Golden center hub -->
                                <circle cx="50" cy="50" r="8" fill="url(#goldGradient)"/>
                                <circle cx="50" cy="50" r="8" fill="none" stroke="#B8860B" stroke-width="1"/>
                                
                                <!-- Pointer at top -->
                                <path d="M 50,5 L 45,12 L 55,12 Z" fill="#FFD700" stroke="#B8860B" stroke-width="0.5"/>
                                
                                <!-- Gradient definitions -->
                                <defs>
                                    <radialGradient id="goldGradient" cx="50%" cy="50%">
                                        <stop offset="0%" style="stop-color:#FFD700;stop-opacity:1" />
                                        <stop offset="100%" style="stop-color:#B8860B;stop-opacity:1" />
                                    </radialGradient>
                                </defs>
                            </svg>
        </div>
                        <h3 style="color: white;"><?php _e('Spin Wheel', 'loyalty-card-pro'); ?></h3>
                        <p style="margin: 0; opacity: 0.9; color: white;"><?php _e('Spin for a prize', 'loyalty-card-pro'); ?></p>
                    </div>
                </div>
                
                <!-- Scratch Card Game -->
                <div id="lcp-scratch-card-game" class="lcp-scratch-game" style="display: none;">
                    <h2 style="color: #FE7AC1; margin-bottom: 20px;"><?php _e('Scratch Card', 'loyalty-card-pro'); ?></h2>
                    <div style="position: relative; width: 300px; height: 300px; margin: 0 auto; background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%); border-radius: 20px; display: flex; align-items: center; justify-content: center; cursor: pointer;" onclick="lcpRevealScratch(this)">
                        <div style="font-size: 64px;">🎁</div>
                        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 20px; color: white; font-weight: 700;"><?php _e('Click to Reveal!', 'loyalty-card-pro'); ?></div>
                    </div>
                    <button class="lcp-btn lcp-btn-secondary" onclick="lcpBackToGameSelection()" style="margin-top: 20px;">
                        <?php _e('Back', 'loyalty-card-pro'); ?>
                    </button>
                </div>
                
                <!-- Spin Wheel Game -->
                <div id="lcp-spin-wheel-game" class="lcp-spin-wheel" style="display: none;">
                    <h2 style="color: #FE7AC1; margin-bottom: 25px; font-size: 32px; font-weight: 700; text-align: center; text-shadow: 0 2px 10px rgba(254, 122, 193, 0.3);">
                        <?php _e(' Spin the Wheel ', 'loyalty-card-pro'); ?>
                    </h2>
                    
                    <!-- Wheel Container -->
                    <div style="position: relative; width: 400px; height: 400px; margin: 0 auto 30px;">
                        <!-- Pointer/Arrow at top -->
                        <div id="lcp-wheel-pointer" style="position: absolute; top: -5px; left: 50%; transform: translateX(-50%); z-index: 10; width: 0; height: 0; border-left: 15px solid transparent; border-right: 15px solid transparent; border-top: 30px solid #FF6B6B; filter: drop-shadow(0 3px 8px rgba(0,0,0,0.3));"></div>
                        
                        <!-- Canvas Wheel -->
                        <canvas id="lcp-wheel-canvas" width="400" height="400" style="display: block;"></canvas>
                        
                        <!-- Center Button -->
                        <div id="lcp-spin-center-btn" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 100px; height: 100px; background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 700; color: white; cursor: pointer; box-shadow: 0 6px 20px rgba(254, 122, 193, 0.5), inset 0 -3px 8px rgba(0,0,0,0.2); transition: all 0.3s ease; border: 5px solid white; z-index: 5;" onclick="lcpSpinTheWheel()">
                            <span style="text-align: center; line-height: 1.2;">SPIN<br><span style="font-size: 24px;"></span></span>
                        </div>
                    </div>
                    
                    <!-- Result Display -->
                    <div id="lcp-wheel-result" style="display: none; text-align: center; margin-bottom: 20px; padding: 20px; background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%); border-radius: 15px; box-shadow: 0 4px 15px rgba(254, 122, 193, 0.4); animation: resultPulse 0.5s ease;">
                        <p style="color: white; font-size: 18px; font-weight: 600; margin: 0;">
                            <?php _e('🎉 Congratulations! 🎉', 'loyalty-card-pro'); ?>
                        </p>
                        <p id="lcp-wheel-prize" style="color: white; font-size: 24px; font-weight: 700; margin: 10px 0 0 0;"></p>
                    </div>
                    
                    <p id="lcp-wheel-status" style="margin-top: 20px; color: #666; font-weight: 600; text-align: center; font-size: 16px;">
                        <?php _e('Click the SPIN button to try your luck!', 'loyalty-card-pro'); ?>
                    </p>
                    
                    <button class="lcp-btn lcp-btn-secondary" onclick="lcpBackToGameSelection()" style="margin-top: 20px; width: 100%;">
                        <span class="dashicons dashicons-arrow-left-alt2"></span>
                        <?php _e('Back to Games', 'loyalty-card-pro'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- QR Code Generator Library -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
        
        <!-- Canvas Confetti Library -->
        <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
        
        <style>
        @keyframes resultPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        #lcp-spin-center-btn:hover {
            transform: translate(-50%, -50%) scale(1.1);
            box-shadow: 0 8px 25px rgba(254, 122, 193, 0.6), inset 0 -3px 8px rgba(0,0,0,0.2);
        }
        
        #lcp-spin-center-btn:active {
            transform: translate(-50%, -50%) scale(0.95);
        }
        
        #lcp-spin-center-btn.spinning {
            cursor: not-allowed;
            opacity: 0.7;
        }
        </style>
        
        <script>
        // Customer Data (from PHP)
        const lcpCustomerData = <?php echo json_encode($dummy_customers); ?>;
        
        // QR Code instance
        let lcpQRCodeInstance = null;
        
        // LocalStorage Helper Functions for Surprises
        function lcpGetSavedSurprises() {
            const saved = localStorage.getItem('lcp_saved_surprises');
            return saved ? JSON.parse(saved) : [];
        }
        
        function lcpSaveSurpriseToStorage(surprise) {
            const surprises = lcpGetSavedSurprises();
            surprises.unshift(surprise); // Add at the beginning
            localStorage.setItem('lcp_saved_surprises', JSON.stringify(surprises));
        }
        
        function lcpRemoveSurpriseFromStorage(surpriseId) {
            let surprises = lcpGetSavedSurprises();
            surprises = surprises.filter(s => s.id !== surpriseId);
            localStorage.setItem('lcp_saved_surprises', JSON.stringify(surprises));
        }
        
        function lcpUpdateCustomerBalanceInStorage(customerId, cardsChange, ticketsChange) {
            // Store customer balance changes for persistence
            const balanceKey = 'lcp_customer_balance_' + customerId;
            const current = localStorage.getItem(balanceKey);
            const balance = current ? JSON.parse(current) : { cards: 0, tickets: 0 };
            
            balance.cards += cardsChange;
            balance.tickets += ticketsChange;
            
            localStorage.setItem(balanceKey, JSON.stringify(balance));
        }
        
        function lcpGetCustomerBalanceFromStorage(customerId) {
            const balanceKey = 'lcp_customer_balance_' + customerId;
            const balance = localStorage.getItem(balanceKey);
            return balance ? JSON.parse(balance) : { cards: 0, tickets: 0 };
        }
        
        // Load Real Customers from Database
        function lcpLoadRealCustomers() {
            fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'lcp_get_customers',
                    nonce: '<?php echo wp_create_nonce("lcp_public_nonce"); ?>'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success && data.data.customers) {
                    const customers = data.data.customers;
                    const tbody = document.querySelector('#lcp-customers-table tbody');
                    
                    if (tbody && customers.length > 0) {
                        // Clear current rows
                        tbody.innerHTML = '';
                        
                        // Add real customers
                        customers.forEach(customer => {
                            const date = new Date(customer.created_at);
                            const formattedDate = date.toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric'
                            });
                            
                            const row = document.createElement('tr');
                            row.setAttribute('data-name', customer.name.toLowerCase());
                            row.setAttribute('data-phone', customer.phone);
                            row.innerHTML = `
                                <td><strong>${customer.name}</strong></td>
                                <td>${customer.phone}</td>
                                <td><span class="lcp-badge" style="background: #9C27B0; color: white; padding: 4px 12px; border-radius: 20px;">${customer.loyalty_cards || 0}</span></td>
                                <td><span class="lcp-badge" style="background: #FE7AC1; color: white; padding: 4px 12px; border-radius: 20px;">${customer.tickets || 0}</span></td>
                                <td><span class="lcp-badge" style="background: #4CAF50; color: white; padding: 4px 12px; border-radius: 20px;">${customer.visits || 0}</span></td>
                                <td>${formattedDate}</td>
                                <td>
                                    <button class="lcp-btn lcp-btn-sm lcp-btn-secondary" onclick="alert('View customer details: ${customer.name}')" style="padding: 6px 12px; font-size: 12px;">
                                        <span class="dashicons dashicons-visibility" style="font-size: 16px;"></span>
                                        View
                                    </button>
                                </td>
                            `;
                            tbody.appendChild(row);
                        });
                    }
                }
            })
            .catch(error => {
                console.error('Error loading customers:', error);
            });
        }
        
        // Load Saved Surprises on Page Load
        function lcpLoadSavedSurprises() {
            const surprises = lcpGetSavedSurprises();
            
            if (surprises.length > 0) {
                const tbody = document.getElementById('saved-surprises-tbody');
                tbody.innerHTML = ''; // Clear existing
                
                surprises.forEach(surprise => {
                    const newRow = document.createElement('tr');
                    newRow.setAttribute('data-customer-id', surprise.customerId);
                    newRow.setAttribute('data-cards-used', surprise.cardsUsed);
                    newRow.setAttribute('data-tickets-used', surprise.ticketsUsed);
                    newRow.setAttribute('data-surprise-id', surprise.id);
                    const gameType = surprise.gameType || 'Spin Wheel';
                    newRow.innerHTML = `
                        <td><strong>${surprise.customerName}</strong></td>
                        <td>${surprise.surpriseName}</td>
                        <td style="text-align: center;">
                            <input type="radio" name="selected-surprise" value="${surprise.id}" 
                                   data-customer-name="${surprise.customerName}" 
                                   data-surprise-name="${surprise.surpriseName}"
                                   style="width: 20px; height: 20px; cursor: pointer; accent-color: #FE7AC1;">
                        </td>
                        <td><span class="lcp-badge" style="background: #9C27B0; color: white; padding: 4px 12px; border-radius: 20px;">${surprise.cardsUsed}</span></td>
                        <td><span class="lcp-badge" style="background: #FE7AC1; color: white; padding: 4px 12px; border-radius: 20px;">${surprise.ticketsUsed}</span></td>
                        <td><span class="lcp-badge" style="background: #4CAF50; color: white; padding: 4px 12px; border-radius: 20px;">${surprise.remainingCards}C / ${surprise.remainingTickets}T</span></td>
                        <td>${surprise.dateCreated}</td>
                        <td>
                            <button class="lcp-btn" onclick="lcpDeleteSurprise(this)" 
                                    style="background: #f44336; color: white; padding: 6px 12px; font-size: 12px; min-width: auto;">
                                <span class="dashicons dashicons-trash" style="font-size: 16px; margin-right: 2px;"></span>
                                Delete
                            </button>
                        </td>
                    `;
                    tbody.appendChild(newRow);
                });
                
                document.getElementById('saved-surprises-section').style.display = 'block';
                
                // Restore selected radio and attach listeners
                setTimeout(() => {
                    lcpRestoreSelectedSurprise();
                    lcpAttachRadioListeners();
                }, 100);
            }
        }
        
        // Save selected radio button to localStorage
        function lcpSaveSelectedSurprise(surpriseId) {
            localStorage.setItem('lcp_selected_surprise', surpriseId);
        }
        
        // Get selected radio button from localStorage
        function lcpGetSelectedSurprise() {
            return localStorage.getItem('lcp_selected_surprise');
        }
        
        // Restore selected radio button on page load
        function lcpRestoreSelectedSurprise() {
            const selectedId = lcpGetSelectedSurprise();
            if (selectedId) {
                const radio = document.querySelector(`input[name="selected-surprise"][value="${selectedId}"]`);
                if (radio) {
                    radio.checked = true;
                }
            }
        }
        
        // Add event listeners to radio buttons
        function lcpAttachRadioListeners() {
            document.querySelectorAll('input[name="selected-surprise"]').forEach(radio => {
                radio.addEventListener('change', function() {
                    if (this.checked) {
                        lcpSaveSelectedSurprise(this.value);
                    }
                });
            });
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            lcpLoadSavedSurprises();
            lcpLoadRealCustomers();
            
            // Restore selected radio button after a short delay (to ensure table is loaded)
            setTimeout(() => {
                lcpRestoreSelectedSurprise();
                lcpAttachRadioListeners();
            }, 500);
            
            // Auto-refresh customers every 30 seconds
            setInterval(lcpLoadRealCustomers, 30000);
        });
        
        // Tab Switching
        function lcpSwitchFrontendTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.lcp-tab-content').forEach(tab => tab.classList.remove('active'));
            // Remove active class from all buttons
            document.querySelectorAll('.lcp-tab-btn:not(.play-game)').forEach(btn => btn.classList.remove('active'));
            // Show selected tab
            document.getElementById('lcp-tab-' + tabName).classList.add('active');
            // Add active class to clicked button
            event.target.classList.add('active');
        }
        
        // Search Customers
        function lcpSearchCustomers() {
            const searchTerm = document.getElementById('lcp-customer-search').value.toLowerCase();
            const rows = document.querySelectorAll('#lcp-customers-table tbody tr');
            
            rows.forEach(row => {
                const name = row.getAttribute('data-name');
                const phone = row.getAttribute('data-phone').toLowerCase();
                
                if (name.includes(searchTerm) || phone.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
        
        // Modal Functions
        function lcpOpenAddCustomer() {
            document.getElementById('lcp-add-customer-modal').classList.add('active');
        }
        
        function lcpCloseModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        function lcpAddCustomer(event) {
            event.preventDefault();
            alert('Customer added successfully!');
            lcpCloseModal('lcp-add-customer-modal');
        }
        
        function lcpShowQRCode() {
            document.getElementById('lcp-qr-code-modal').classList.add('active');
        }
        
        // Visit Tracking Functions
        function lcpSearchForVisit() {
            const searchValue = document.getElementById('lcp-visit-search').value.toLowerCase().trim();
            const customerPanel = document.getElementById('lcp-customer-details-panel');
            const suggestionsBox = document.getElementById('lcp-search-suggestions');
            
            if (searchValue.length > 0) {
                // Dynamic search through actual customer data
                const matchingCustomers = lcpCustomerData.filter(customer => {
                    const name = customer.name.toLowerCase();
                    const phone = customer.phone.toLowerCase();
                    return name.includes(searchValue) || phone.includes(searchValue);
                });
                
                // Show suggestions dropdown
                if (matchingCustomers.length > 0) {
                    let suggestionsHTML = '';
                    matchingCustomers.forEach(customer => {
                        suggestionsHTML += `
                            <div class="lcp-suggestion-item" onclick="lcpSelectCustomer(${customer.id})">
                                <span class="lcp-suggestion-name">${customer.name}</span>
                                <span class="lcp-suggestion-phone">${customer.phone}</span>
                            </div>
                        `;
                    });
                    suggestionsBox.innerHTML = suggestionsHTML;
                    suggestionsBox.style.display = 'block';
                } else {
                    suggestionsBox.innerHTML = '<div class="lcp-no-results">No customers found</div>';
                    suggestionsBox.style.display = 'block';
                    customerPanel.style.display = 'none';
                }
            } else {
                suggestionsBox.style.display = 'none';
                customerPanel.style.display = 'none';
            }
        }
        
        function lcpShowSearchSuggestions() {
            const searchValue = document.getElementById('lcp-visit-search').value;
            if (searchValue.length === 0) {
                const suggestionsBox = document.getElementById('lcp-search-suggestions');
                let suggestionsHTML = '<div style="padding: 10px; font-weight: 600; color: #FE7AC1; border-bottom: 1px solid #FFEFF7;">All Customers</div>';
                lcpCustomerData.forEach(customer => {
                    suggestionsHTML += `
                        <div class="lcp-suggestion-item" onclick="lcpSelectCustomer(${customer.id})">
                            <span class="lcp-suggestion-name">${customer.name}</span>
                            <span class="lcp-suggestion-phone">${customer.phone}</span>
                        </div>
                    `;
                });
                suggestionsBox.innerHTML = suggestionsHTML;
                suggestionsBox.style.display = 'block';
            }
        }
        
        function lcpSelectCustomer(customerId) {
            const customer = lcpCustomerData.find(c => c.id === customerId);
            if (customer) {
                // Calculate dummy visit count (based on customer ID for consistency)
                const dummyVisits = (customer.id * 5) + Math.floor(Math.random() * 10);
                
                // Format date
                const dateObj = new Date(customer.date);
                const formattedDate = dateObj.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
                
                // Update search input
                document.getElementById('lcp-visit-search').value = customer.name;
                
                // Show customer details
                document.getElementById('customer-detail-name').textContent = customer.name;
                document.getElementById('customer-detail-phone').textContent = customer.phone;
                document.getElementById('customer-detail-cards').textContent = customer.loyalty_cards;
                document.getElementById('customer-detail-visits').textContent = dummyVisits;
                document.getElementById('customer-detail-date').textContent = formattedDate;
                
                // Store customer ID for reference
                const customerPanel = document.getElementById('lcp-customer-details-panel');
                customerPanel.setAttribute('data-customer-id', customer.id);
                customerPanel.style.display = 'block';
                
                // Hide suggestions
                document.getElementById('lcp-search-suggestions').style.display = 'none';
            }
        }
        
        function lcpSubmitVisit() {
            const visitCountInput = document.getElementById('visit-count-input');
            const visitCount = parseInt(visitCountInput.value);
            const customerName = document.getElementById('customer-detail-name').textContent;
            const visitsElement = document.getElementById('customer-detail-visits');
            
            if (visitCount && customerName !== '-') {
                // Update the displayed visit count
                const currentVisits = parseInt(visitsElement.textContent);
                const newVisits = currentVisits + visitCount;
                
                // Smooth update with animation
                visitsElement.style.transition = 'all 0.3s ease';
                visitsElement.style.transform = 'scale(1.2)';
                visitsElement.style.color = '#FE7AC1';
                visitsElement.textContent = newVisits;
                
                // Reset animation
                setTimeout(() => {
                    visitsElement.style.transform = 'scale(1)';
                    visitsElement.style.color = '#333';
                }, 300);
                
                // Reset input
                visitCountInput.value = '1';
                
                // Visual feedback on button
                const submitButton = event.target.closest('button');
                const originalText = submitButton.innerHTML;
                submitButton.innerHTML = '<span class="dashicons dashicons-yes"></span> Recorded!';
                submitButton.style.background = '#4CAF50';
                
                setTimeout(() => {
                    submitButton.innerHTML = originalText;
                    submitButton.style.background = '';
                }, 1500);
            }
        }
        
        function lcpShowVisitQRCode() {
            // Open modal
            document.getElementById('lcp-qr-code-modal').classList.add('active');
            
            // Clear previous QR code if exists
            const qrContainer = document.getElementById('lcp-qr-code-display');
            qrContainer.innerHTML = '';
            
            // Get registration URL
            const registrationUrl = document.getElementById('lcp-registration-url').textContent.trim();
            
            // Generate new QR Code
            lcpQRCodeInstance = new QRCode(qrContainer, {
                text: registrationUrl,
                width: 256,
                height: 256,
                colorDark: "#000000",
                colorLight: "#ffffff",
                correctLevel: QRCode.CorrectLevel.H
            });
        }
        
        function lcpDownloadQRCode() {
            const canvas = document.querySelector('#lcp-qr-code-display canvas');
            if (canvas) {
                // Create download link
                const link = document.createElement('a');
                link.download = 'customer-registration-qr-code.png';
                link.href = canvas.toDataURL('image/png');
                link.click();
                
                // Show success message
                const btn = event.target.closest('button');
                const originalText = btn.innerHTML;
                btn.innerHTML = '<span class="dashicons dashicons-yes"></span> Downloaded!';
                btn.style.background = '#4CAF50';
                
                setTimeout(() => {
                    btn.innerHTML = originalText;
                    btn.style.background = '';
                }, 2000);
            } else {
                alert('QR Code not generated yet. Please try again.');
            }
        }
        
        function lcpPrintQRCode() {
            const qrContainer = document.getElementById('lcp-qr-code-display');
            const registrationUrl = document.getElementById('lcp-registration-url').textContent.trim();
            
            if (!qrContainer.innerHTML) {
                alert('QR Code not generated yet. Please try again.');
                return;
            }
            
            // Create print window
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Customer Registration QR Code</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            text-align: center;
                            padding: 40px;
                            margin: 0;
                        }
                        h1 {
                            color: #FE7AC1;
                            margin-bottom: 10px;
                            font-size: 28px;
                        }
                        .subtitle {
                            color: #666;
                            margin-bottom: 30px;
                            font-size: 16px;
                        }
                        .qr-container {
                            display: inline-block;
                            padding: 30px;
                            background: white;
                            border: 3px solid #FE7AC1;
                            border-radius: 20px;
                            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                            margin-bottom: 30px;
                        }
                        .url {
                            color: #666;
                            font-size: 14px;
                            margin-top: 20px;
                            word-break: break-all;
                            max-width: 600px;
                            margin-left: auto;
                            margin-right: auto;
                        }
                        .instructions {
                            color: #999;
                            font-size: 12px;
                            margin-top: 30px;
                            line-height: 1.6;
                        }
                        @media print {
                            body {
                                padding: 20px;
                            }
                        }
                    </style>
                </head>
                <body>
                    <h1>🌸 Customer Registration 🌸</h1>
                    <p class="subtitle">Scan this QR code to join our loyalty program</p>
                    <div class="qr-container">
                        ${qrContainer.innerHTML}
                    </div>
                    <p class="url"><strong>Registration URL:</strong><br>${registrationUrl}</p>
                    <div class="instructions">
                        <p><strong>Instructions:</strong></p>
                        <p>1. Open your phone's camera app</p>
                        <p>2. Point it at the QR code</p>
                        <p>3. Tap the notification to open the registration page</p>
                        <p>4. Fill in your details and submit</p>
                    </div>
                </body>
                </html>
            `);
            printWindow.document.close();
            
            // Wait for QR code to render, then print
            setTimeout(() => {
                printWindow.print();
            }, 500);
        }
        
        // Assign Loyalty Card Functions
        function lcpSearchForCardAssignment() {
            const searchValue = document.getElementById('lcp-assign-card-search').value.toLowerCase().trim();
            const suggestionsBox = document.getElementById('lcp-assign-card-suggestions');
            const customerDetailsPanel = document.getElementById('lcp-assign-customer-details');
            
            // Hide customer details when user starts typing
            const selectedId = document.getElementById('lcp-selected-customer-id').value;
            const currentInput = document.getElementById('lcp-assign-card-search').value;
            const selectedCustomer = lcpCustomerData.find(c => c.id == selectedId);
            
            if (selectedCustomer && currentInput !== selectedCustomer.name) {
                customerDetailsPanel.style.display = 'none';
                document.getElementById('lcp-selected-customer-id').value = '';
            }
            
            if (searchValue.length > 0) {
                // Dynamic search through actual customer data
                const matchingCustomers = lcpCustomerData.filter(customer => {
                    const name = customer.name.toLowerCase();
                    const phone = customer.phone.toLowerCase();
                    return name.includes(searchValue) || phone.includes(searchValue);
                });
                
                // Show suggestions dropdown
                if (matchingCustomers.length > 0) {
                    let suggestionsHTML = '';
                    matchingCustomers.forEach(customer => {
                        suggestionsHTML += `
                            <div class="lcp-suggestion-item" onclick="lcpSelectCustomerForCard(${customer.id})">
                                <span class="lcp-suggestion-name">${customer.name}</span>
                                <span class="lcp-suggestion-phone">${customer.phone}</span>
                            </div>
                        `;
                    });
                    suggestionsBox.innerHTML = suggestionsHTML;
                    suggestionsBox.style.display = 'block';
                } else {
                    suggestionsBox.innerHTML = '<div class="lcp-no-results">No customers found</div>';
                    suggestionsBox.style.display = 'block';
                }
            } else {
                suggestionsBox.style.display = 'none';
                customerDetailsPanel.style.display = 'none';
            }
        }
        
        function lcpShowCardAssignSuggestions() {
            const searchValue = document.getElementById('lcp-assign-card-search').value;
            if (searchValue.length === 0) {
                const suggestionsBox = document.getElementById('lcp-assign-card-suggestions');
                let suggestionsHTML = '<div style="padding: 10px; font-weight: 600; color: #FE7AC1; border-bottom: 1px solid #FFEFF7;">Select Customer</div>';
                lcpCustomerData.forEach(customer => {
                    suggestionsHTML += `
                        <div class="lcp-suggestion-item" onclick="lcpSelectCustomerForCard(${customer.id})">
                            <span class="lcp-suggestion-name">${customer.name}</span>
                            <span class="lcp-suggestion-phone">${customer.phone}</span>
                        </div>
                    `;
                });
                suggestionsBox.innerHTML = suggestionsHTML;
                suggestionsBox.style.display = 'block';
            }
        }
        
        function lcpSelectCustomerForCard(customerId) {
            const customer = lcpCustomerData.find(c => c.id === customerId);
            if (customer) {
                // Calculate dummy visit count (based on customer ID for consistency)
                const dummyVisits = (customer.id * 5) + Math.floor(Math.random() * 10);
                
                // Format date
                const dateObj = new Date(customer.date);
                const formattedDate = dateObj.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
                
                // Update search input
                document.getElementById('lcp-assign-card-search').value = customer.name;
                
                // Store customer ID
                document.getElementById('lcp-selected-customer-id').value = customerId;
                
                // Show and populate customer details
                document.getElementById('assign-customer-name').textContent = customer.name;
                document.getElementById('assign-customer-phone').textContent = customer.phone;
                document.getElementById('assign-customer-cards').textContent = customer.loyalty_cards;
                document.getElementById('assign-customer-visits').textContent = dummyVisits;
                document.getElementById('assign-customer-date').textContent = formattedDate;
                
                // Show customer details panel
                document.getElementById('lcp-assign-customer-details').style.display = 'block';
                
                // Hide suggestions
                document.getElementById('lcp-assign-card-suggestions').style.display = 'none';
            }
        }
        
        function lcpAssignCard() {
            const customerId = document.getElementById('lcp-selected-customer-id').value;
            const customerName = document.getElementById('lcp-assign-card-search').value;
            const cardCountInput = document.getElementById('card-count-input');
            const cardCount = parseInt(cardCountInput.value) || 1;
            
            if (customerId && customerName) {
                // Update loyalty cards count in the details panel
                const cardsElement = document.getElementById('assign-customer-cards');
                const currentCards = parseInt(cardsElement.textContent);
                const newCardCount = currentCards + cardCount;
                
                cardsElement.style.transition = 'all 0.3s ease';
                cardsElement.style.transform = 'scale(1.2)';
                cardsElement.style.color = '#FE7AC1';
                cardsElement.textContent = newCardCount;
                
                setTimeout(() => {
                    cardsElement.style.transform = 'scale(1)';
                    cardsElement.style.color = '#333';
                }, 300);
                
                // Visual feedback on button
                const assignButton = event.target.closest('button');
                const originalText = assignButton.innerHTML;
                assignButton.innerHTML = '<span class="dashicons dashicons-yes"></span> Cards Assigned!';
                assignButton.style.background = '#4CAF50';
                
                setTimeout(() => {
                    assignButton.innerHTML = originalText;
                    assignButton.style.background = '';
                    
                    // Clear selection
                    document.getElementById('lcp-assign-card-search').value = '';
                    document.getElementById('lcp-selected-customer-id').value = '';
                    cardCountInput.value = '1';
                    
                    // Hide customer details panel
                    document.getElementById('lcp-assign-customer-details').style.display = 'none';
                }, 2000);
            }
        }
        
        // Assign Ticket Functions
        function lcpSearchForTicketAssignment() {
            const searchValue = document.getElementById('lcp-assign-ticket-search').value.toLowerCase().trim();
            const suggestionsBox = document.getElementById('lcp-assign-ticket-suggestions');
            const customerDetailsPanel = document.getElementById('lcp-assign-ticket-details');
            
            // Hide customer details when user starts typing
            const selectedId = document.getElementById('lcp-selected-ticket-customer-id').value;
            const currentInput = document.getElementById('lcp-assign-ticket-search').value;
            const selectedCustomer = lcpCustomerData.find(c => c.id == selectedId);
            
            if (selectedCustomer && currentInput !== selectedCustomer.name) {
                customerDetailsPanel.style.display = 'none';
                document.getElementById('lcp-selected-ticket-customer-id').value = '';
            }
            
            if (searchValue.length > 0) {
                // Dynamic search through actual customer data
                const matchingCustomers = lcpCustomerData.filter(customer => {
                    const name = customer.name.toLowerCase();
                    const phone = customer.phone.toLowerCase();
                    return name.includes(searchValue) || phone.includes(searchValue);
                });
                
                // Show suggestions dropdown
                if (matchingCustomers.length > 0) {
                    let suggestionsHTML = '';
                    matchingCustomers.forEach(customer => {
                        suggestionsHTML += `
                            <div class="lcp-suggestion-item" onclick="lcpSelectCustomerForTicket(${customer.id})">
                                <span class="lcp-suggestion-name">${customer.name}</span>
                                <span class="lcp-suggestion-phone">${customer.phone}</span>
                            </div>
                        `;
                    });
                    suggestionsBox.innerHTML = suggestionsHTML;
                    suggestionsBox.style.display = 'block';
                } else {
                    suggestionsBox.innerHTML = '<div class="lcp-no-results">No customers found</div>';
                    suggestionsBox.style.display = 'block';
                }
            } else {
                suggestionsBox.style.display = 'none';
                customerDetailsPanel.style.display = 'none';
            }
        }
        
        function lcpShowTicketAssignSuggestions() {
            const searchValue = document.getElementById('lcp-assign-ticket-search').value;
            if (searchValue.length === 0) {
                const suggestionsBox = document.getElementById('lcp-assign-ticket-suggestions');
                let suggestionsHTML = '<div style="padding: 10px; font-weight: 600; color: #FE7AC1; border-bottom: 1px solid #FFEFF7;">Select Customer</div>';
                lcpCustomerData.forEach(customer => {
                    suggestionsHTML += `
                        <div class="lcp-suggestion-item" onclick="lcpSelectCustomerForTicket(${customer.id})">
                            <span class="lcp-suggestion-name">${customer.name}</span>
                            <span class="lcp-suggestion-phone">${customer.phone}</span>
                        </div>
                    `;
                });
                suggestionsBox.innerHTML = suggestionsHTML;
                suggestionsBox.style.display = 'block';
            }
        }
        
        function lcpSelectCustomerForTicket(customerId) {
            const customer = lcpCustomerData.find(c => c.id === customerId);
            if (customer) {
                // Calculate dummy ticket count (from customer data)
                const dummyTickets = customer.tickets || 0;
                
                // Format date
                const dateObj = new Date(customer.date);
                const formattedDate = dateObj.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
                
                // Update search input
                document.getElementById('lcp-assign-ticket-search').value = customer.name;
                
                // Store customer ID
                document.getElementById('lcp-selected-ticket-customer-id').value = customerId;
                
                // Show and populate customer details
                document.getElementById('assign-ticket-name').textContent = customer.name;
                document.getElementById('assign-ticket-phone').textContent = customer.phone;
                document.getElementById('assign-ticket-cards').textContent = customer.loyalty_cards;
                document.getElementById('assign-ticket-count').textContent = dummyTickets;
                document.getElementById('assign-ticket-date').textContent = formattedDate;
                
                // Show customer details panel
                document.getElementById('lcp-assign-ticket-details').style.display = 'block';
                
                // Hide suggestions
                document.getElementById('lcp-assign-ticket-suggestions').style.display = 'none';
            }
        }
        
        function lcpAssignTicket() {
            const customerId = document.getElementById('lcp-selected-ticket-customer-id').value;
            const customerName = document.getElementById('lcp-assign-ticket-search').value;
            const ticketCountInput = document.getElementById('ticket-count-input');
            const ticketCount = parseInt(ticketCountInput.value) || 1;
            
            if (customerId && customerName) {
                // Update ticket count in the details panel
                const ticketsElement = document.getElementById('assign-ticket-count');
                const currentTickets = parseInt(ticketsElement.textContent);
                const newTicketCount = currentTickets + ticketCount;
                
                ticketsElement.style.transition = 'all 0.3s ease';
                ticketsElement.style.transform = 'scale(1.2)';
                ticketsElement.style.color = '#FE7AC1';
                ticketsElement.textContent = newTicketCount;
                
                setTimeout(() => {
                    ticketsElement.style.transform = 'scale(1)';
                    ticketsElement.style.color = '#333';
                }, 300);
                
                // Visual feedback on button
                const assignButton = event.target.closest('button');
                const originalText = assignButton.innerHTML;
                assignButton.innerHTML = '<span class="dashicons dashicons-yes"></span> Tickets Given!';
                assignButton.style.background = '#4CAF50';
                
                setTimeout(() => {
                    assignButton.innerHTML = originalText;
                    assignButton.style.background = '';
                    
                    // Clear selection
                    document.getElementById('lcp-assign-ticket-search').value = '';
                    document.getElementById('lcp-selected-ticket-customer-id').value = '';
                    ticketCountInput.value = '1';
                    
                    // Hide customer details panel
                    document.getElementById('lcp-assign-ticket-details').style.display = 'none';
                }, 2000);
            }
        }
        
        // Surprise Search Functions
        function lcpSearchForSurprise() {
            const searchValue = document.getElementById('lcp-surprise-search').value.toLowerCase().trim();
            const suggestionsBox = document.getElementById('lcp-surprise-suggestions');
            const customerDetailsPanel = document.getElementById('lcp-surprise-customer-details');
            
            // Hide customer details when user starts typing
            const selectedId = document.getElementById('lcp-selected-surprise-customer-id').value;
            const currentInput = document.getElementById('lcp-surprise-search').value;
            const selectedCustomer = lcpCustomerData.find(c => c.id == selectedId);
            
            if (selectedCustomer && currentInput !== selectedCustomer.name) {
                customerDetailsPanel.style.display = 'none';
                document.getElementById('lcp-selected-surprise-customer-id').value = '';
            }
            
            if (searchValue.length > 0) {
                // Dynamic search through actual customer data
                const matchingCustomers = lcpCustomerData.filter(customer => {
                    const name = customer.name.toLowerCase();
                    const phone = customer.phone.toLowerCase();
                    return name.includes(searchValue) || phone.includes(searchValue);
                });
                
                // Show suggestions dropdown
                if (matchingCustomers.length > 0) {
                    let suggestionsHTML = '';
                    matchingCustomers.forEach(customer => {
                        suggestionsHTML += `
                            <div class="lcp-suggestion-item" onclick="lcpSelectCustomerForSurprise(${customer.id})">
                                <span class="lcp-suggestion-name">${customer.name}</span>
                                <span class="lcp-suggestion-phone">${customer.phone}</span>
                            </div>
                        `;
                    });
                    suggestionsBox.innerHTML = suggestionsHTML;
                    suggestionsBox.style.display = 'block';
                } else {
                    suggestionsBox.innerHTML = '<div class="lcp-no-results">No customers found</div>';
                    suggestionsBox.style.display = 'block';
                }
            } else {
                suggestionsBox.style.display = 'none';
                customerDetailsPanel.style.display = 'none';
            }
        }
        
        function lcpShowSurpriseSuggestions() {
            const searchValue = document.getElementById('lcp-surprise-search').value;
            if (searchValue.length === 0) {
                const suggestionsBox = document.getElementById('lcp-surprise-suggestions');
                let suggestionsHTML = '<div style="padding: 10px; font-weight: 600; color: #FE7AC1; border-bottom: 1px solid #FFEFF7;">Select Customer</div>';
                lcpCustomerData.forEach(customer => {
                    suggestionsHTML += `
                        <div class="lcp-suggestion-item" onclick="lcpSelectCustomerForSurprise(${customer.id})">
                            <span class="lcp-suggestion-name">${customer.name}</span>
                            <span class="lcp-suggestion-phone">${customer.phone}</span>
                        </div>
                    `;
                });
                suggestionsBox.innerHTML = suggestionsHTML;
                suggestionsBox.style.display = 'block';
            }
        }
        
        function lcpSelectCustomerForSurprise(customerId) {
            const customer = lcpCustomerData.find(c => c.id === customerId);
            if (customer) {
                // Calculate dummy ticket count
                const dummyTickets = customer.tickets || 0;
                
                // Get balance changes from localStorage
                const balanceChanges = lcpGetCustomerBalanceFromStorage(customerId);
                
                // Apply balance changes to current values
                const currentCards = customer.loyalty_cards + balanceChanges.cards;
                const currentTickets = dummyTickets + balanceChanges.tickets;
                
                // Format date
                const dateObj = new Date(customer.date);
                const formattedDate = dateObj.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
                
                // Update search input
                document.getElementById('lcp-surprise-search').value = customer.name;
                
                // Store customer ID
                document.getElementById('lcp-selected-surprise-customer-id').value = customerId;
                
                // Show and populate customer details (with updated balances)
                document.getElementById('surprise-customer-name').textContent = customer.name;
                document.getElementById('surprise-customer-phone').textContent = customer.phone;
                document.getElementById('surprise-customer-cards').textContent = currentCards;
                document.getElementById('surprise-customer-tickets').textContent = currentTickets;
                document.getElementById('surprise-customer-date').textContent = formattedDate;
                
                // Show customer details panel
                document.getElementById('lcp-surprise-customer-details').style.display = 'block';
                
                // Hide suggestions
                document.getElementById('lcp-surprise-suggestions').style.display = 'none';
            }
        }
        
        function lcpSaveSurprise() {
            const customerId = document.getElementById('lcp-selected-surprise-customer-id').value;
            const customerName = document.getElementById('surprise-customer-name').textContent;
            const surpriseType = document.getElementById('surprise-type').value;
            const surpriseValue = document.getElementById('surprise-value').value;
            const cardsRequired = parseInt(document.getElementById('cards-required').value) || 0;
            const ticketsRequired = parseInt(document.getElementById('tickets-required').value) || 0;
            const quantity = parseInt(document.getElementById('surprise-quantity').value) || 1;
            
            if (!customerId || customerName === '-') {
                alert('Please select a customer first!');
                return;
            }
            
            if (!surpriseValue.trim()) {
                alert('Please enter a surprise value!');
                return;
            }
            
            // Get current balances
            const cardsElement = document.getElementById('surprise-customer-cards');
            const ticketsElement = document.getElementById('surprise-customer-tickets');
            const currentCards = parseInt(cardsElement.textContent);
            const currentTickets = parseInt(ticketsElement.textContent);
            
            // Check if customer has enough loyalty cards
            if (cardsRequired > 0 && currentCards < cardsRequired) {
                alert('Customer does not have enough loyalty cards!\nRequired: ' + cardsRequired + '\nAvailable: ' + currentCards);
                return;
            }
            
            // Check if customer has enough tickets
            if (ticketsRequired > 0 && currentTickets < ticketsRequired) {
                alert('Customer does not have enough tickets!\nRequired: ' + ticketsRequired + '\nAvailable: ' + currentTickets);
                return;
            }
            
            // Calculate new balances
            const remainingCards = currentCards - cardsRequired;
            const remainingTickets = currentTickets - ticketsRequired;
            
            // Update loyalty cards balance with animation
            if (cardsRequired > 0) {
                cardsElement.style.transition = 'all 0.3s ease';
                cardsElement.style.transform = 'scale(1.2)';
                cardsElement.style.color = '#FE7AC1';
                cardsElement.textContent = remainingCards;
                
                setTimeout(() => {
                    cardsElement.style.transform = 'scale(1)';
                    cardsElement.style.color = '#333';
                }, 300);
            }
            
            // Update ticket balance with animation
            if (ticketsRequired > 0) {
                ticketsElement.style.transition = 'all 0.3s ease';
                ticketsElement.style.transform = 'scale(1.2)';
                ticketsElement.style.color = '#FE7AC1';
                ticketsElement.textContent = remainingTickets;
                
                setTimeout(() => {
                    ticketsElement.style.transform = 'scale(1)';
                    ticketsElement.style.color = '#333';
                }, 300);
            }
            
            // Create surprise entry
            const surpriseName = surpriseValue;
            const dateCreated = new Date().toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            // Generate unique ID for this surprise
            const surpriseId = 'surprise_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            
            // Save to localStorage
            const surpriseData = {
                id: surpriseId,
                customerId: customerId,
                customerName: customerName,
                surpriseName: surpriseName,
                gameType: 'Spin Wheel',
                cardsUsed: cardsRequired,
                ticketsUsed: ticketsRequired,
                remainingCards: remainingCards,
                remainingTickets: remainingTickets,
                dateCreated: dateCreated
            };
            lcpSaveSurpriseToStorage(surpriseData);
            
            // Update customer balance in storage (deduct)
            lcpUpdateCustomerBalanceInStorage(customerId, -cardsRequired, -ticketsRequired);
            
            // Add to saved surprises table
            const tbody = document.getElementById('saved-surprises-tbody');
            const newRow = document.createElement('tr');
            newRow.setAttribute('data-customer-id', customerId);
            newRow.setAttribute('data-cards-used', cardsRequired);
            newRow.setAttribute('data-tickets-used', ticketsRequired);
            newRow.setAttribute('data-surprise-id', surpriseId);
            newRow.innerHTML = `
                <td><strong>${customerName}</strong></td>
                <td>${surpriseName}</td>
                <td style="text-align: center;">
                    <input type="radio" name="selected-surprise" value="${surpriseId}" 
                           data-customer-name="${customerName}" 
                           data-surprise-name="${surpriseName}"
                           style="width: 20px; height: 20px; cursor: pointer; accent-color: #FE7AC1;">
                </td>
                <td><span class="lcp-badge" style="background: #9C27B0; color: white; padding: 4px 12px; border-radius: 20px;">${cardsRequired}</span></td>
                <td><span class="lcp-badge" style="background: #FE7AC1; color: white; padding: 4px 12px; border-radius: 20px;">${ticketsRequired}</span></td>
                <td><span class="lcp-badge" style="background: #4CAF50; color: white; padding: 4px 12px; border-radius: 20px;">${remainingCards}C / ${remainingTickets}T</span></td>
                <td>${dateCreated}</td>
                <td>
                    <button class="lcp-btn" onclick="lcpDeleteSurprise(this)" 
                            style="background: #f44336; color: white; padding: 6px 12px; font-size: 12px; min-width: auto;">
                        <span class="dashicons dashicons-trash" style="font-size: 16px; margin-right: 2px;"></span>
                        Delete
                    </button>
                </td>
            `;
            tbody.insertBefore(newRow, tbody.firstChild); // Add at the top
            
            // Show saved surprises section
            document.getElementById('saved-surprises-section').style.display = 'block';
            
            // Attach listeners to the new radio button
            setTimeout(() => {
                lcpAttachRadioListeners();
            }, 100);
            
            // Clear form fields
            document.getElementById('surprise-value').value = '';
            document.getElementById('cards-required').value = '0';
            document.getElementById('tickets-required').value = '0';
            document.getElementById('surprise-quantity').value = '0';
            
            // Visual feedback on button
            const saveButton = event.target.closest('button');
            const originalText = saveButton.innerHTML;
            saveButton.innerHTML = '<span class="dashicons dashicons-yes"></span> Surprise Saved!';
            saveButton.style.background = '#4CAF50';
            
            setTimeout(() => {
                saveButton.innerHTML = originalText;
                saveButton.style.background = '';
            }, 2000);
            
            // Scroll to saved surprises list
            setTimeout(() => {
                document.getElementById('saved-surprises-section').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }, 300);
        }
        
        function lcpDeleteSurprise(button) {
            if (!confirm('Are you sure you want to delete this surprise?\n\nThis will refund the cards and tickets back to the customer.')) {
                return;
            }
            
            // Get the row
            const row = button.closest('tr');
            const customerId = row.getAttribute('data-customer-id');
            const surpriseId = row.getAttribute('data-surprise-id');
            const cardsUsed = parseInt(row.getAttribute('data-cards-used')) || 0;
            const ticketsUsed = parseInt(row.getAttribute('data-tickets-used')) || 0;
            
            // Remove from localStorage
            lcpRemoveSurpriseFromStorage(surpriseId);
            
            // Update customer balance in storage (refund)
            lcpUpdateCustomerBalanceInStorage(customerId, cardsUsed, ticketsUsed);
            
            // Check if this is the currently selected customer
            const selectedCustomerId = document.getElementById('lcp-selected-surprise-customer-id').value;
            
            if (selectedCustomerId === customerId) {
                // Refund cards and tickets back to customer
                const cardsElement = document.getElementById('surprise-customer-cards');
                const ticketsElement = document.getElementById('surprise-customer-tickets');
                
                if (cardsElement && ticketsElement) {
                    const currentCards = parseInt(cardsElement.textContent);
                    const currentTickets = parseInt(ticketsElement.textContent);
                    
                    // Add back the used amounts
                    const newCards = currentCards + cardsUsed;
                    const newTickets = currentTickets + ticketsUsed;
                    
                    // Update with animation
                    if (cardsUsed > 0) {
                        cardsElement.style.transition = 'all 0.3s ease';
                        cardsElement.style.transform = 'scale(1.2)';
                        cardsElement.style.color = '#4CAF50';
                        cardsElement.textContent = newCards;
                        
                        setTimeout(() => {
                            cardsElement.style.transform = 'scale(1)';
                            cardsElement.style.color = '#333';
                        }, 300);
                    }
                    
                    if (ticketsUsed > 0) {
                        ticketsElement.style.transition = 'all 0.3s ease';
                        ticketsElement.style.transform = 'scale(1.2)';
                        ticketsElement.style.color = '#4CAF50';
                        ticketsElement.textContent = newTickets;
                        
                        setTimeout(() => {
                            ticketsElement.style.transform = 'scale(1)';
                            ticketsElement.style.color = '#333';
                        }, 300);
                    }
                }
            }
            
            // Remove the row with fade out animation
            row.style.transition = 'all 0.3s ease';
            row.style.opacity = '0';
            row.style.transform = 'translateX(20px)';
            
            setTimeout(() => {
                row.remove();
                
                // Hide section if no more surprises
                const tbody = document.getElementById('saved-surprises-tbody');
                if (tbody.children.length === 0) {
                    document.getElementById('saved-surprises-section').style.display = 'none';
                }
            }, 300);
        }
        
        // Game Functions
        function lcpOpenGame() {
            // Check if a surprise is selected via radio button
            const selectedRadio = document.querySelector('input[name="selected-surprise"]:checked');
            
            if (selectedRadio) {
                // Get selected surprise details
                const surpriseId = selectedRadio.value;
                const customerName = selectedRadio.getAttribute('data-customer-name');
                const surpriseName = selectedRadio.getAttribute('data-surprise-name');
                
                // Play with predetermined prize
                lcpPlaySurpriseWheel(surpriseId, customerName, surpriseName);
            } else {
                // No selection - show alert
                alert('Please select a customer first by clicking the radio button in the "Saved Surprises" table!');
            }
        }
        
        function lcpPlayScratchCard() {
            document.getElementById('lcp-game-selection').style.display = 'none';
            document.getElementById('lcp-scratch-card-game').style.display = 'block';
        }
        
        function lcpPlaySpinWheel() {
            document.getElementById('lcp-game-selection').style.display = 'none';
            document.getElementById('lcp-spin-wheel-game').style.display = 'block';
            
            // Initialize wheel
            setTimeout(() => {
                lcpInitWheel();
            }, 100);
        }
        
        function lcpBackToGameSelection() {
            document.getElementById('lcp-game-selection').style.display = 'block';
            document.getElementById('lcp-scratch-card-game').style.display = 'none';
            document.getElementById('lcp-spin-wheel-game').style.display = 'none';
        }
        
        function lcpRevealScratch(element) {
            const rewards = ['20% Off!', 'Free Manicure!', '$10 Voucher!', 'Free Product!', '50% Off!'];
            const reward = rewards[Math.floor(Math.random() * rewards.length)];
            
            element.innerHTML = '<div style="font-size: 48px; margin-bottom: 15px;">🎉</div><div style="font-size: 24px; font-weight: 700; color: white;">' + reward + '</div>';
            element.style.cursor = 'default';
            
            setTimeout(() => {
                alert('Congratulations! You won: ' + reward);
            }, 500);
        }
        
        // Spin Wheel Variables
        let wheelCanvas = null;
        let wheelCtx = null;
        let currentRotation = 0;
        let isSpinning = false;
        let predeterminedPrize = null; // For surprise wheel
        
        // Default wheel segments (fallback)
        const defaultWheelSegments = [
            { color: '#FE7AC1', text: '20% Off', icon: '💎' },
            { color: '#FFD700', text: 'Free Service', icon: '✨' },
            { color: '#4CAF50', text: '$15 Voucher', icon: '💰' },
            { color: '#FF6B6B', text: 'Try Again', icon: '🎲' },
            { color: '#4ECDC4', text: 'Free Product', icon: '🎁' },
            { color: '#FF9FF3', text: '50% Off', icon: '🌟' },
            { color: '#9C27B0', text: '$25 Voucher', icon: '💵' },
            { color: '#FF5722', text: 'Double Points', icon: '⭐' }
        ];
        
        let wheelSegments = [...defaultWheelSegments];
        let targetSegmentIndex = null; // Index of predetermined prize
        
        function lcpInitWheel() {
            wheelCanvas = document.getElementById('lcp-wheel-canvas');
            if (!wheelCanvas) return;
            
            wheelCtx = wheelCanvas.getContext('2d');
            
            // Build segments from saved surprises
            lcpBuildWheelSegments();
            
            lcpDrawWheel();
        }
        
        function lcpBuildWheelSegments() {
            const surprises = lcpGetSavedSurprises();
            
            if (surprises.length >= 3) {
                // Use saved surprises as wheel segments
                const colors = ['#FE7AC1', '#FFD700', '#4CAF50', '#FF6B6B', '#4ECDC4', '#FF9FF3', '#9C27B0', '#FF5722'];
                
                wheelSegments = surprises.map((surprise, index) => ({
                    color: colors[index % colors.length],
                    text: surprise.surpriseName,
                    icon: '🎁',
                    surpriseId: surprise.id
                }));
                
                // Find target segment if predetermined prize is set
                if (predeterminedPrize) {
                    targetSegmentIndex = wheelSegments.findIndex(seg => 
                        seg.text === predeterminedPrize
                    );
                }
            } else {
                // Use default segments if not enough surprises
                wheelSegments = [...defaultWheelSegments];
                targetSegmentIndex = null;
            }
        }
        
        function lcpDrawWheel() {
            if (!wheelCtx || !wheelCanvas) return;
            
            const centerX = wheelCanvas.width / 2;
            const centerY = wheelCanvas.height / 2;
            const radius = 180;
            const segmentAngle = (2 * Math.PI) / wheelSegments.length;
            
            // Clear canvas
            wheelCtx.clearRect(0, 0, wheelCanvas.width, wheelCanvas.height);
            
            // Save context
            wheelCtx.save();
            
            // Rotate canvas
            wheelCtx.translate(centerX, centerY);
            wheelCtx.rotate(currentRotation);
            wheelCtx.translate(-centerX, -centerY);
            
            // Draw segments
            wheelSegments.forEach((segment, index) => {
                const startAngle = index * segmentAngle - Math.PI / 2;
                const endAngle = startAngle + segmentAngle;
                
                // Draw segment
                wheelCtx.beginPath();
                wheelCtx.arc(centerX, centerY, radius, startAngle, endAngle);
                wheelCtx.lineTo(centerX, centerY);
                wheelCtx.fillStyle = segment.color;
                wheelCtx.fill();
                
                // Draw border
                wheelCtx.strokeStyle = 'white';
                wheelCtx.lineWidth = 3;
                wheelCtx.stroke();
                
                // Draw text
                wheelCtx.save();
                wheelCtx.translate(centerX, centerY);
                wheelCtx.rotate(startAngle + segmentAngle / 2);
                wheelCtx.textAlign = 'center';
                wheelCtx.fillStyle = 'white';
                wheelCtx.font = 'bold 16px Arial';
                wheelCtx.shadowColor = 'rgba(0,0,0,0.5)';
                wheelCtx.shadowBlur = 3;
                wheelCtx.fillText(segment.icon, radius - 60, 0);
                wheelCtx.font = 'bold 12px Arial';
                wheelCtx.fillText(segment.text, radius - 60, 20);
                wheelCtx.restore();
            });
            
            // Draw outer border
            wheelCtx.beginPath();
            wheelCtx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
            wheelCtx.strokeStyle = '#FE7AC1';
            wheelCtx.lineWidth = 8;
            wheelCtx.stroke();
            
            // Draw decorative circles
            wheelCtx.beginPath();
            wheelCtx.arc(centerX, centerY, radius + 4, 0, 2 * Math.PI);
            wheelCtx.strokeStyle = 'white';
            wheelCtx.lineWidth = 2;
            wheelCtx.stroke();
            
            wheelCtx.restore();
        }
        
        function lcpSpinTheWheel() {
            if (isSpinning) return;
            
            isSpinning = true;
            const spinBtn = document.getElementById('lcp-spin-center-btn');
            const statusText = document.getElementById('lcp-wheel-status');
            const resultDiv = document.getElementById('lcp-wheel-result');
            
            // Update UI
            spinBtn.classList.add('spinning');
            statusText.textContent = '🎰 Spinning... Good Luck! 🎰';
            resultDiv.style.display = 'none';
            
            // Calculate rotation
            let totalRotation;
            
            if (targetSegmentIndex !== null && targetSegmentIndex >= 0) {
                // CONTROLLED SPIN - Stop at predetermined segment
                const minSpins = 5;
                const maxSpins = 7;
                const spins = Math.random() * (maxSpins - minSpins) + minSpins;
                
                // Calculate exact angle needed to stop at target segment
                const segmentAngle = (2 * Math.PI) / wheelSegments.length;
                const targetAngle = targetSegmentIndex * segmentAngle;
                const pointerAngle = Math.PI / 2; // Pointer at top
                
                // Calculate rotation needed to align target with pointer
                const finalAngle = (2 * Math.PI - targetAngle + pointerAngle) % (2 * Math.PI);
                
                // Add multiple full rotations + final angle
                totalRotation = spins * 2 * Math.PI + finalAngle;
            } else {
                // RANDOM SPIN - Normal random behavior
                const minSpins = 5;
                const maxSpins = 8;
                const spins = Math.random() * (maxSpins - minSpins) + minSpins;
                const randomDegree = Math.random() * 360;
                totalRotation = (spins * 360 + randomDegree) * (Math.PI / 180);
            }
            
            // Animation parameters
            const duration = 5000; // 5 seconds
            const startTime = Date.now();
            const startRotation = currentRotation;
            
            function animate() {
                const elapsed = Date.now() - startTime;
                const progress = Math.min(elapsed / duration, 1);
                
                // Easing function (ease-out cubic)
                const easeOut = 1 - Math.pow(1 - progress, 3);
                
                currentRotation = startRotation + totalRotation * easeOut;
                lcpDrawWheel();
                
                if (progress < 1) {
                    requestAnimationFrame(animate);
                } else {
                    // Spin complete
                    lcpOnSpinComplete();
                }
            }
            
            animate();
        }
        
        function lcpOnSpinComplete() {
            isSpinning = false;
            
            // Use predetermined prize if available, otherwise calculate random
            let prize;
            if (predeterminedPrize) {
                prize = { icon: '🎁', text: predeterminedPrize };
            } else {
                // Calculate winning segment
                const normalizedRotation = (currentRotation % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI);
                const segmentAngle = (2 * Math.PI) / wheelSegments.length;
                const pointerAngle = Math.PI / 2; // Top of wheel
                const winningIndex = Math.floor(((2 * Math.PI - normalizedRotation + pointerAngle) % (2 * Math.PI)) / segmentAngle) % wheelSegments.length;
                prize = wheelSegments[winningIndex];
            }
            
            // Update UI
            const spinBtn = document.getElementById('lcp-spin-center-btn');
            const statusText = document.getElementById('lcp-wheel-status');
            const resultDiv = document.getElementById('lcp-wheel-result');
            const prizeText = document.getElementById('lcp-wheel-prize');
            
            spinBtn.classList.remove('spinning');
            
            // Show confetti
            confetti({
                particleCount: 150,
                spread: 70,
                origin: { y: 0.6 },
                colors: ['#FE7AC1', '#FFD700', '#4CAF50', '#FF6B6B', '#4ECDC4', '#FF9FF3']
            });
            
            // Show result after a brief delay
            setTimeout(() => {
                prizeText.textContent = prize.icon + ' ' + prize.text + ' ' + prize.icon;
                resultDiv.style.display = 'block';
                statusText.textContent = predeterminedPrize ? 'Congratulations on your surprise!' : 'Spin again to win more prizes!';
                
                // Reset predetermined prize and target index
                predeterminedPrize = null;
                targetSegmentIndex = null;
                
                // Additional confetti burst
                setTimeout(() => {
                    confetti({
                        particleCount: 50,
                        angle: 60,
                        spread: 55,
                        origin: { x: 0 },
                        colors: ['#FE7AC1', '#FF9FF3']
                    });
                    confetti({
                        particleCount: 50,
                        angle: 120,
                        spread: 55,
                        origin: { x: 1 },
                        colors: ['#FFD700', '#4CAF50']
                    });
                }, 200);
            }, 300);
        }
        
        // Play game with selected customer from radio button
        function lcpPlaySelectedSurprise() {
            const selectedRadio = document.querySelector('input[name="selected-surprise"]:checked');
            
            if (!selectedRadio) {
                alert('Please select a customer first by clicking the radio button!');
                return;
            }
            
            const surpriseId = selectedRadio.value;
            const customerName = selectedRadio.getAttribute('data-customer-name');
            const surpriseName = selectedRadio.getAttribute('data-surprise-name');
            
            lcpPlaySurpriseWheel(surpriseId, customerName, surpriseName);
        }
        
        // Play Spin Wheel for a specific surprise
        function lcpPlaySurpriseWheel(surpriseId, customerName, surpriseName) {
            // Set the predetermined prize
            predeterminedPrize = surpriseName;
            
            // Open game modal
            document.getElementById('lcp-game-modal').classList.add('active');
            document.getElementById('lcp-game-selection').style.display = 'none';
            document.getElementById('lcp-spin-wheel-game').style.display = 'block';
            
            // Initialize wheel
            setTimeout(() => {
                lcpInitWheel();
                
                // Update status message
                const statusText = document.getElementById('lcp-wheel-status');
                statusText.textContent = `🎁 ${customerName}, click SPIN to reveal your surprise!`;
                statusText.style.color = '#FE7AC1';
                statusText.style.fontWeight = '700';
            }, 100);
        }
        
        // Close modals when clicking outside
        document.querySelectorAll('.lcp-modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('active');
                }
            });
        });
        
        // Close search suggestions when clicking outside
        document.addEventListener('click', function(e) {
            // Close Visit Tracking suggestions
            const visitSearchBox = document.getElementById('lcp-visit-search');
            const visitSuggestionsBox = document.getElementById('lcp-search-suggestions');
            
            if (visitSuggestionsBox && visitSearchBox && 
                !visitSearchBox.contains(e.target) && 
                !visitSuggestionsBox.contains(e.target) &&
                !visitSearchBox.parentElement.contains(e.target)) {
                visitSuggestionsBox.style.display = 'none';
            }
            
            // Close Assign Card suggestions
            const assignSearchBox = document.getElementById('lcp-assign-card-search');
            const assignSuggestionsBox = document.getElementById('lcp-assign-card-suggestions');
            
            if (assignSuggestionsBox && assignSearchBox && 
                !assignSearchBox.contains(e.target) && 
                !assignSuggestionsBox.contains(e.target) &&
                !assignSearchBox.parentElement.contains(e.target)) {
                assignSuggestionsBox.style.display = 'none';
            }
            
            // Close Assign Ticket suggestions
            const ticketSearchBox = document.getElementById('lcp-assign-ticket-search');
            const ticketSuggestionsBox = document.getElementById('lcp-assign-ticket-suggestions');
            
            if (ticketSuggestionsBox && ticketSearchBox && 
                !ticketSearchBox.contains(e.target) && 
                !ticketSuggestionsBox.contains(e.target) &&
                !ticketSearchBox.parentElement.contains(e.target)) {
                ticketSuggestionsBox.style.display = 'none';
            }
            
            // Close Surprise Search suggestions
            const surpriseSearchBox = document.getElementById('lcp-surprise-search');
            const surpriseSuggestionsBox = document.getElementById('lcp-surprise-suggestions');
            
            if (surpriseSuggestionsBox && surpriseSearchBox && 
                !surpriseSearchBox.contains(e.target) && 
                !surpriseSuggestionsBox.contains(e.target) &&
                !surpriseSearchBox.parentElement.contains(e.target)) {
                surpriseSuggestionsBox.style.display = 'none';
            }
        });
        
        // Package Selection Modal Functions
        function lcpOpenPackageModal(type) {
            const modalId = type === 'loyalty' ? 'lcp-loyalty-package-modal' : 'lcp-ticket-package-modal';
            const modal = document.getElementById(modalId);
            
            if (modal) {
                modal.style.display = 'flex';
                
                // Load packages via AJAX
                lcpLoadPackages(type);
            }
        }
        
        function lcpClosePackageModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'none';
            }
        }
        
        function lcpLoadPackages(type) {
            const planType = type === 'loyalty' ? 'loyalty_cards' : 'tickets';
            const containerId = type === 'loyalty' ? 'lcp-loyalty-packages-list' : 'lcp-ticket-packages-list';
            
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'lcp_get_packages',
                    plan_type: planType,
                    nonce: '<?php echo wp_create_nonce('lcp_public_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success && response.data.packages) {
                        const container = document.getElementById(containerId);
                        if (container) {
                            container.innerHTML = '';
                            
                            response.data.packages.forEach(function(pkg) {
                                const packageCard = lcpCreatePackageCard(pkg, type);
                                container.appendChild(packageCard);
                            });
                        }
                    }
                },
                error: function() {
                    console.error('Error loading packages');
                }
            });
        }
        
        function lcpCreatePackageCard(pkg, type) {
            const div = document.createElement('div');
            div.className = 'lcp-package-card';
            div.style.cssText = 'border: 2px solid #FFEFF7; border-radius: 10px; padding: 20px; background: white; cursor: pointer; transition: all 0.3s; margin-bottom: 15px;';
            
            const limitLabel = type === 'loyalty' 
                ? pkg.client_limit + ' <?php echo esc_js(__('Clients', 'loyalty-card-pro')); ?>'
                : pkg.ticket_count + ' <?php echo esc_js(__('Tickets', 'loyalty-card-pro')); ?>';
            
            // Check if WooCommerce product ID is set
            const wcProductId = pkg.wc_product_id ? pkg.wc_product_id : pkg.id;
            const hasWcProduct = pkg.wc_product_id ? true : false;
            const buttonDisabled = !hasWcProduct ? 'disabled' : '';
            const buttonStyle = !hasWcProduct ? 'opacity: 0.5; cursor: not-allowed; margin-left: 20px;' : 'margin-left: 20px;';
            
            div.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="flex: 1;">
                        <h3 style="margin: 0 0 8px 0; color: #333; font-size: 18px;">${pkg.plan_name}</h3>
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <span style="background: #FE7AC1; color: white; padding: 6px 14px; border-radius: 20px; font-size: 13px; font-weight: 600;">
                                ${limitLabel}
                            </span>
                            <span style="color: #FE7AC1; font-size: 24px; font-weight: 700;">
                                $${parseFloat(pkg.price).toFixed(2)}
                            </span>
                        </div>
                        ${!hasWcProduct ? '<p style="margin: 8px 0 0 0; color: #ff9800; font-size: 12px;"><span class="dashicons dashicons-warning" style="font-size: 14px;"></span> <?php echo esc_js(__('No WooCommerce product linked', 'loyalty-card-pro')); ?></p>' : ''}
                    </div>
                    <button class="lcp-btn lcp-btn-primary" onclick="lcpPurchasePackage(${wcProductId}, '${pkg.plan_name}')" ${buttonDisabled} style="${buttonStyle}">
                        <span class="dashicons dashicons-cart"></span>
                        <?php _e('Purchase', 'loyalty-card-pro'); ?>
                    </button>
                </div>
            `;
            
            // Hover effect
            div.onmouseenter = function() {
                this.style.borderColor = '#FE7AC1';
                this.style.boxShadow = '0 4px 12px rgba(254, 122, 193, 0.2)';
            };
            div.onmouseleave = function() {
                this.style.borderColor = '#FFEFF7';
                this.style.boxShadow = 'none';
            };
            
            return div;
        }
        
        function lcpPurchasePackage(packageId, packageName) {
            // Get the button that was clicked
            var button = event.target.closest('.lcp-btn');
            var originalHtml = button ? button.innerHTML : '';
            
            // Disable button and show loading state
            if (button) {
                button.disabled = true;
                button.innerHTML = '<span class="dashicons dashicons-update" style="animation: spin 1s linear infinite;"></span> <?php echo esc_js(__('Processing...', 'loyalty-card-pro')); ?>';
            }
            
            // Add product to cart and redirect to checkout (no confirmation needed)
            jQuery.post('<?php echo admin_url('admin-ajax.php'); ?>', {
                action: 'lcp_add_to_cart_checkout',
                product_id: packageId,
                nonce: '<?php echo wp_create_nonce('lcp_cart_nonce'); ?>'
            }, function(response) {
                if (response.success) {
                    // Redirect directly to checkout
                    window.location.href = response.data.checkout_url;
                } else {
                    // Show error and re-enable button
                    alert(response.data.message || '<?php echo esc_js(__('Error adding to cart', 'loyalty-card-pro')); ?>');
                    if (button) {
                        button.disabled = false;
                        button.innerHTML = originalHtml;
                    }
                }
            }).fail(function() {
                // Handle AJAX errors
                alert('<?php echo esc_js(__('Error connecting to server. Please try again.', 'loyalty-card-pro')); ?>');
                if (button) {
                    button.disabled = false;
                    button.innerHTML = originalHtml;
                }
            });
        }
        </script>
        
        <!-- Package Selection Modals -->
        
        <!-- Loyalty Cards Package Modal -->
        <div id="lcp-loyalty-package-modal" class="lcp-modal" style="display: none; position: fixed; z-index: 999999; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); align-items: center; justify-content: center;">
            <div class="lcp-modal-content" style="background: white; padding: 30px; border-radius: 15px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto; position: relative;">
                <span class="lcp-modal-close" onclick="lcpClosePackageModal('lcp-loyalty-package-modal')" style="position: absolute; right: 20px; top: 20px; font-size: 32px; cursor: pointer; color: #999; transition: color 0.3s;">&times;</span>
                
                <h2 style="color: #FE7AC1; margin: 0 0 10px 0; font-size: 24px;">
                    <span class="dashicons dashicons-awards" style="font-size: 28px; vertical-align: middle;"></span>
                    <?php _e('Select Loyalty Card Package', 'loyalty-card-pro'); ?>
                </h2>
                <p style="color: #666; margin: 0 0 25px 0;">
                    <?php _e('Choose a package to purchase', 'loyalty-card-pro'); ?>
                </p>
                
                <div id="lcp-loyalty-packages-list">
                    <div style="text-align: center; padding: 40px; color: #999;">
                        <span class="dashicons dashicons-update" style="font-size: 32px; animation: spin 1s linear infinite;"></span>
                        <p><?php _e('Loading packages...', 'loyalty-card-pro'); ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Scratch Tickets Package Modal -->
        <div id="lcp-ticket-package-modal" class="lcp-modal" style="display: none; position: fixed; z-index: 999999; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); align-items: center; justify-content: center;">
            <div class="lcp-modal-content" style="background: white; padding: 30px; border-radius: 15px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto; position: relative;">
                <span class="lcp-modal-close" onclick="lcpClosePackageModal('lcp-ticket-package-modal')" style="position: absolute; right: 20px; top: 20px; font-size: 32px; cursor: pointer; color: #999; transition: color 0.3s;">&times;</span>
                
                <h2 style="color: #FE7AC1; margin: 0 0 10px 0; font-size: 24px;">
                    <span class="dashicons dashicons-tickets-alt" style="font-size: 28px; vertical-align: middle;"></span>
                    <?php _e('Select Ticket Package', 'loyalty-card-pro'); ?>
                </h2>
                <p style="color: #666; margin: 0 0 25px 0;">
                    <?php _e('Choose a package to purchase', 'loyalty-card-pro'); ?>
                </p>
                
                <div id="lcp-ticket-packages-list">
                    <div style="text-align: center; padding: 40px; color: #999;">
                        <span class="dashicons dashicons-update" style="font-size: 32px; animation: spin 1s linear infinite;"></span>
                        <p><?php _e('Loading packages...', 'loyalty-card-pro'); ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .lcp-package-card:hover {
            transform: translateY(-2px);
        }
        </style>
        
        <?php
    }
    
    /**
     * Enqueue styles
     */
    public function enqueue_styles() {
        if (is_account_page()) {
            wp_enqueue_style('dashicons');
        }
    }
    
    /**
     * Ensure billing fields are initialized to prevent undefined array key errors
     * This fixes compatibility with other plugins that expect billing fields to exist
     */
    public function ensure_billing_fields($value, $input) {
        // If value is already set, return it
        if ($value !== null && $value !== '') {
            return $value;
        }
        
        // List of billing fields that should have default empty string values
        $billing_fields = array(
            'billing_company',
            'billing_address_1',
            'billing_address_2',
            'billing_city',
            'billing_postcode',
            'billing_state',
            'billing_country',
            'billing_phone',
            'billing_email',
            'shipping_company',
            'shipping_address_1',
            'shipping_address_2',
            'shipping_city',
            'shipping_postcode',
            'shipping_state',
            'shipping_country'
        );
        
        // If this is a billing/shipping field and value is empty, return empty string
        if (in_array($input, $billing_fields)) {
            return '';
        }
        
        return $value;
    }
    
    /**
     * Ensure posted data has all billing fields (runs when WooCommerce processes checkout POST data)
     * This is CRITICAL - runs when form is submitted and other plugins access the posted data
     * Uses woocommerce_checkout_posted_data hook - the CORRECT hook for checkout form submission data
     * 
     * Following WordPress hook best practice:
     * 1. Check if billing_company is set
     * 2. If not, return an empty string ('')
     */
    public function ensure_posted_data_fields($posted_data) {
        // Static flag to prevent multiple executions
        static $executed = false;
        if ($executed) {
            return $posted_data;
        }
        $executed = true;
        
        // CRITICAL FIX: Check if billing_company is set in posted data
        // This is what the invoicing plugin accesses from woocommerce_checkout_posted_data hook
        if (!isset($posted_data['billing_company'])) {
            // If not set, return an empty string (as per instruction)
            $posted_data['billing_company'] = '';
        } else {
            // If it exists but is null or empty, ensure it's at least an empty string
            if ($posted_data['billing_company'] === null || $posted_data['billing_company'] === false) {
                $posted_data['billing_company'] = '';
            }
        }
        
        // Also ensure in $_POST and $_REQUEST for plugins that read directly from there
        if (!isset($_POST['billing_company'])) {
            $_POST['billing_company'] = '';
        }
        if (!isset($_REQUEST['billing_company'])) {
            $_REQUEST['billing_company'] = '';
        }
        
        // Ensure other billing fields exist too (for completeness)
        $other_billing_fields = array(
            'billing_address_1' => '',
            'billing_address_2' => '',
            'billing_city' => '',
            'billing_postcode' => '',
            'billing_state' => '',
            'billing_country' => '',
            'billing_phone' => '',
            'billing_email' => ''
        );
        
        foreach ($other_billing_fields as $field => $default_value) {
            if (!isset($posted_data[$field])) {
                $posted_data[$field] = $default_value;
            }
        }
        
        return $posted_data;
    }
    
    /**
     * Ensure checkout fields are initialized early (runs when WooCommerce processes checkout fields)
     * This runs BEFORE other plugins access the fields array
     * CRITICAL: Ensures billing_company exists in $fields array to prevent "Undefined array key" errors
     */
    public function ensure_checkout_fields_early($fields) {
        // Only run on checkout
        if (!function_exists('is_checkout') || !is_checkout()) {
            return $fields;
        }
        
        // Static flag to prevent multiple executions
        static $executed = false;
        if ($executed) {
            return $fields;
        }
        $executed = true;
        
        // CRITICAL FIX: Ensure billing_company exists in the $fields array
        // The invoicing plugin accesses $fields['billing_company'] directly on line 76
        // If it doesn't exist, it causes "Undefined array key" error
        // 
        // The plugin does: $company = $fields['billing_company'];
        // So we need to ensure it exists at the top level of $fields array
        
        // First, ensure billing_company exists in standard WooCommerce location
        if (!isset($fields['billing']) || !is_array($fields['billing'])) {
            $fields['billing'] = array();
        }
        
        if (!isset($fields['billing']['billing_company'])) {
            $fields['billing']['billing_company'] = array(
                'label'       => __('Company name', 'woocommerce'),
                'placeholder' => __('Company name', 'woocommerce'),
                'required'    => false,
                'class'       => array('form-row-wide'),
                'autocomplete' => 'organization',
                'priority'    => 30,
            );
        }
        
        // CRITICAL: Also ensure billing_company exists at top level of $fields array
        // The invoicing plugin accesses it as $fields['billing_company'] (not $fields['billing']['billing_company'])
        // This is the WordPress hook approach - check if it's set, if not return empty string
        if (!isset($fields['billing_company'])) {
            // Get the field definition from billing array if it exists
            if (isset($fields['billing']['billing_company'])) {
                // Copy the field definition to top level for the invoicing plugin
                $fields['billing_company'] = $fields['billing']['billing_company'];
            } else {
                // If it doesn't exist anywhere, set it to empty string to prevent undefined array key error
                // This follows the instruction: "If not, return an empty string ('')"
                $fields['billing_company'] = '';
            }
        } else {
            // If it exists but is null or empty, ensure it's at least an empty string
            if ($fields['billing_company'] === null) {
                $fields['billing_company'] = '';
            }
        }
        
        // Ensure billing_company exists in POST/REQUEST before other plugins access it
        if (!isset($_POST['billing_company'])) {
            $_POST['billing_company'] = '';
        }
        if (!isset($_REQUEST['billing_company'])) {
            $_REQUEST['billing_company'] = '';
        }
        
        // Also ensure in WooCommerce customer data if available
        if (function_exists('WC') && WC()->customer) {
            $customer = WC()->customer;
            $company = $customer->get_billing_company();
            if ($company === null || $company === false) {
                $customer->set_billing_company('');
            }
        }
        
        return $fields;
    }
    
    /**
     * Ensure billing fields are set early on checkout page to prevent errors
     * This runs before other plugins try to access billing fields
     * OPTIMIZED: Only runs on checkout page, uses static flag to prevent multiple runs
     * Also sets $_POST/$_REQUEST early to prevent undefined key errors
     */
    public function ensure_checkout_billing_fields() {
        // Static flag to prevent multiple executions
        static $executed = false;
        if ($executed) {
            return;
        }
        $executed = true;
        
        // Define billing fields once
        static $billing_fields = array(
            'billing_company' => '',
            'billing_address_1' => '',
            'billing_address_2' => '',
            'billing_city' => '',
            'billing_postcode' => '',
            'billing_state' => '',
            'billing_country' => '',
            'billing_phone' => '',
            'billing_email' => ''
        );
        
        // Only set fields if WooCommerce is active and we're on a WooCommerce page
        // This prevents unnecessary operations on non-WooCommerce pages
        $is_wc_page = false;
        if (function_exists('is_checkout') && is_checkout()) {
            $is_wc_page = true;
        } elseif (function_exists('is_cart') && is_cart()) {
            $is_wc_page = true;
        } elseif (function_exists('is_account_page') && is_account_page()) {
            $is_wc_page = true;
        } elseif (function_exists('is_shop') && is_shop()) {
            $is_wc_page = true;
        }
        
        // CRITICAL: Set $_POST and $_REQUEST fields to prevent "Undefined array key" errors
        // Only do this on WooCommerce-related pages for performance
        if ($is_wc_page || (function_exists('WC') && WC()->is_rest_api_request())) {
            foreach ($billing_fields as $field => $default_value) {
                if (!isset($_POST[$field])) {
                    $_POST[$field] = $default_value;
                }
                if (!isset($_REQUEST[$field])) {
                    $_REQUEST[$field] = $default_value;
                }
            }
        }
        
        // Only do customer meta operations on checkout page (performance optimization)
        if (!function_exists('is_checkout') || !is_checkout()) {
            return; // Exit early if not checkout
        }
        
        // Early exit if WooCommerce not available
        if (!function_exists('WC') || !WC()->customer) {
            return;
        }
        
        $customer = WC()->customer;
        $needs_save = false;
        
        // Set in customer meta if not already set
        foreach ($billing_fields as $field => $default_value) {
            $current_value = $customer->get_meta($field);
            if ($current_value === null || $current_value === false) {
                $customer->update_meta_data($field, $default_value);
                $needs_save = true;
            }
        }
        
        // Only save if we made changes
        if ($needs_save) {
            $customer->save_meta_data();
        }
    }
    
    /**
     * Initialize billing fields in WooCommerce session to prevent undefined array key errors
     * OPTIMIZED: Uses static flag to prevent multiple executions
     */
    public function initialize_billing_fields() {
        // Early exit if WooCommerce not available
        if (!function_exists('WC') || !WC()->session || !WC()->customer) {
            return;
        }
        
        // Static flag to prevent multiple executions
        static $executed = false;
        if ($executed) {
            return;
        }
        $executed = true;
        
        $customer = WC()->customer;
        
        // List of billing fields to ensure are set (defined once)
        static $billing_fields = array(
            'billing_company' => '',
            'billing_address_1' => '',
            'billing_address_2' => '',
            'billing_city' => '',
            'billing_postcode' => '',
            'billing_state' => '',
            'billing_country' => '',
            'billing_phone' => '',
            'billing_email' => '',
            'shipping_company' => '',
            'shipping_address_1' => '',
            'shipping_address_2' => '',
            'shipping_city' => '',
            'shipping_postcode' => '',
            'shipping_state' => '',
            'shipping_country' => ''
        );
        
        $needs_save = false;
        
        // Ensure all billing fields are set in customer data (optimized: single loop)
        foreach ($billing_fields as $field => $default_value) {
            // Set in $_POST if not already set (faster than checking customer meta first)
            if (!isset($_POST[$field])) {
                $_POST[$field] = $default_value;
            }
            
            // Only check customer meta if needed
            $current_value = $customer->get_meta($field);
            if ($current_value === null || $current_value === false) {
                $customer->update_meta_data($field, $default_value);
                $needs_save = true;
            }
        }
        
        // Only save if we made changes
        if ($needs_save) {
            $customer->save_meta_data();
        }
    }
    
    /**
     * AJAX handler to add product to cart and return checkout URL
     */
    public function ajax_add_to_cart_checkout() {
        check_ajax_referer('lcp_cart_nonce', 'nonce');
        
        if (!isset($_POST['product_id'])) {
            wp_send_json_error(array('message' => __('Invalid product ID', 'loyalty-card-pro')));
        }
        
        $product_id = intval($_POST['product_id']);
        
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            wp_send_json_error(array('message' => __('WooCommerce is not active', 'loyalty-card-pro')));
        }
        
        // Check if product exists
        $product = wc_get_product($product_id);
        if (!$product) {
            wp_send_json_error(array('message' => __('Product not found', 'loyalty-card-pro')));
        }
        
        // Clear cart (optional - ensures only this product is in cart)
        WC()->cart->empty_cart();
        
        // Add product to cart
        $cart_item_key = WC()->cart->add_to_cart($product_id, 1);
        
        if ($cart_item_key) {
            // Initialize billing fields before redirecting to checkout
            // This prevents "Undefined array key" errors in other plugins
            $this->initialize_billing_fields();
            
            wp_send_json_success(array(
                'message' => __('Product added to cart', 'loyalty-card-pro'),
                'checkout_url' => wc_get_checkout_url()
            ));
        } else {
            wp_send_json_error(array('message' => __('Failed to add product to cart', 'loyalty-card-pro')));
        }
    }
}
