<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php _e('Customer Registration', 'loyalty-card-pro'); ?> - <?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .lcp-registration-container {
            background: white;
            border-radius: 25px;
            box-shadow: 0 10px 50px rgba(0,0,0,0.2);
            max-width: 500px;
            width: 100%;
            padding: 40px;
            animation: slideIn 0.5s ease-out;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .lcp-registration-header {
            text-align: center;
            margin-bottom: 35px;
        }
        
        .lcp-registration-icon {
            font-size: 60px;
            margin-bottom: 15px;
        }
        
        .lcp-registration-header h1 {
            color: #FE7AC1;
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .lcp-registration-header p {
            color: #666;
            font-size: 15px;
            line-height: 1.6;
        }
        
        .lcp-form-group {
            margin-bottom: 25px;
        }
        
        .lcp-form-group label {
            display: block;
            color: #333;
            font-weight: 600;
            margin-bottom: 10px;
            font-size: 14px;
        }
        
        .lcp-form-group label .required {
            color: #FE7AC1;
            margin-left: 3px;
        }
        
        .lcp-form-group input {
            width: 100%;
            padding: 15px;
            border: 2px solid #FFEFF7;
            border-radius: 12px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: #FAFAFA;
        }
        
        .lcp-form-group input:focus {
            outline: none;
            border-color: #FE7AC1;
            background: white;
            box-shadow: 0 0 0 4px rgba(254, 122, 193, 0.1);
        }
        
        .lcp-submit-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .lcp-submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(254, 122, 193, 0.4);
        }
        
        .lcp-submit-btn:active {
            transform: translateY(0);
        }
        
        .lcp-submit-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .lcp-message {
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 14px;
            display: none;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
        
        .lcp-message.success {
            background: #d4edda;
            color: #155724;
            border: 2px solid #c3e6cb;
        }
        
        .lcp-message.error {
            background: #f8d7da;
            color: #721c24;
            border: 2px solid #f5c6cb;
        }
        
        .lcp-footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 2px solid #FFEFF7;
        }
        
        .lcp-footer p {
            color: #999;
            font-size: 13px;
        }
        
        .lcp-footer a {
            color: #FE7AC1;
            text-decoration: none;
            font-weight: 600;
        }
        
        .lcp-footer a:hover {
            text-decoration: underline;
        }
        
        .lcp-loader {
            display: none;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .lcp-success-animation {
            display: none;
            text-align: center;
            animation: scaleIn 0.5s ease;
        }
        
        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.5);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
        
        .lcp-success-animation .checkmark {
            font-size: 80px;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        
        .lcp-success-animation h2 {
            color: #4CAF50;
            margin-bottom: 15px;
            font-size: 24px;
        }
        
        .lcp-success-animation p {
            color: #666;
            font-size: 15px;
            line-height: 1.6;
        }
        
        @media (max-width: 768px) {
            .lcp-registration-container {
                padding: 30px 20px;
            }
            
            .lcp-registration-header h1 {
                font-size: 24px;
            }
            
            .lcp-registration-icon {
                font-size: 50px;
            }
        }
    </style>
</head>
<body>
    <div class="lcp-registration-container">
        <!-- Registration Form -->
        <div id="lcp-registration-form-container">
            <div class="lcp-registration-header">
                <div class="lcp-registration-icon">🌸</div>
                <h1><?php _e('Join Our Loyalty Program', 'loyalty-card-pro'); ?></h1>
                <p><?php _e('Register now and start earning rewards with every visit!', 'loyalty-card-pro'); ?></p>
            </div>
            
            <div id="lcp-message" class="lcp-message"></div>
            
            <form id="lcp-customer-registration-form">
                <div class="lcp-form-group">
                    <label for="customer_name">
                        <?php _e('Full Name', 'loyalty-card-pro'); ?>
                        <span class="required">*</span>
                    </label>
                    <input type="text" id="customer_name" name="name" placeholder="<?php _e('Enter your full name', 'loyalty-card-pro'); ?>" required>
                </div>
                
                <div class="lcp-form-group">
                    <label for="customer_phone">
                        <?php _e('Phone Number', 'loyalty-card-pro'); ?>
                        <span class="required">*</span>
                    </label>
                    <input type="tel" id="customer_phone" name="phone" placeholder="<?php _e('+1 555-0000', 'loyalty-card-pro'); ?>" required>
                </div>
                
                <div class="lcp-form-group">
                    <label for="customer_email">
                        <?php _e('Email Address', 'loyalty-card-pro'); ?>
                        <span style="color: #999; font-weight: 400;">(<?php _e('Optional', 'loyalty-card-pro'); ?>)</span>
                    </label>
                    <input type="email" id="customer_email" name="email" placeholder="<?php _e('your.email@example.com', 'loyalty-card-pro'); ?>">
                </div>
                
                <button type="submit" class="lcp-submit-btn" id="lcp-submit-btn">
                    <span id="lcp-btn-text"><?php _e('Register Now', 'loyalty-card-pro'); ?></span>
                    <div class="lcp-loader"></div>
                </button>
            </form>
            
            <div class="lcp-footer">
                <p>
                    <?php _e('Already registered?', 'loyalty-card-pro'); ?>
                    <a href="<?php echo home_url(); ?>"><?php _e('Visit our website', 'loyalty-card-pro'); ?></a>
                </p>
            </div>
        </div>
        
        <!-- Success Animation -->
        <div id="lcp-success-animation" class="lcp-success-animation">
            <div class="checkmark">✓</div>
            <h2><?php _e('Welcome Aboard!', 'loyalty-card-pro'); ?></h2>
            <p><?php _e('Your registration was successful. You can now enjoy exclusive rewards and benefits with every visit to our salon.', 'loyalty-card-pro'); ?></p>
            <button class="lcp-submit-btn" onclick="window.location.href='<?php echo home_url(); ?>'" style="margin-top: 25px;">
                <?php _e('Go to Homepage', 'loyalty-card-pro'); ?>
            </button>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('lcp-customer-registration-form');
        const submitBtn = document.getElementById('lcp-submit-btn');
        const btnText = document.getElementById('lcp-btn-text');
        const loader = document.querySelector('.lcp-loader');
        const message = document.getElementById('lcp-message');
        const formContainer = document.getElementById('lcp-registration-form-container');
        const successAnimation = document.getElementById('lcp-success-animation');
        
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading state
            submitBtn.disabled = true;
            btnText.style.display = 'none';
            loader.style.display = 'block';
            message.style.display = 'none';
            
            // Get form data
            const formData = new FormData(form);
            formData.append('action', 'lcp_register_customer');
            formData.append('nonce', '<?php echo wp_create_nonce("lcp_public_nonce"); ?>');
            
            // Send AJAX request
            fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Reset button state
                submitBtn.disabled = false;
                btnText.style.display = 'inline';
                loader.style.display = 'none';
                
                if (data.success) {
                    // Show success animation
                    formContainer.style.display = 'none';
                    successAnimation.style.display = 'block';
                } else {
                    // Show error message
                    message.className = 'lcp-message error';
                    message.textContent = data.data.message || '<?php _e('Registration failed. Please try again.', 'loyalty-card-pro'); ?>';
                    message.style.display = 'block';
                }
            })
            .catch(error => {
                // Reset button state
                submitBtn.disabled = false;
                btnText.style.display = 'inline';
                loader.style.display = 'none';
                
                // Show error message
                message.className = 'lcp-message error';
                message.textContent = '<?php _e('An error occurred. Please try again.', 'loyalty-card-pro'); ?>';
                message.style.display = 'block';
            });
        });
    });
    </script>
    
    <?php wp_footer(); ?>
</body>
</html>
