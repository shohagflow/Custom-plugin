<?php
/**
 * Beautician Dashboard class
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Beautician_Dashboard {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', array($this, 'add_beautician_menu'));
    }
    
    /**
     * Add beautician menu
     */
    public function add_beautician_menu() {
        if (!LCP_Roles::is_beautician()) {
            return;
        }
        
        add_submenu_page(
            'loyalty-card-pro',
            __('Clients', 'loyalty-card-pro'),
            __('Clients', 'loyalty-card-pro'),
            'lcp_manage_clients',
            'lcp-clients',
            array($this, 'render_clients_page')
        );
        
        add_submenu_page(
            'loyalty-card-pro',
            __('Loyalty Cards', 'loyalty-card-pro'),
            __('Loyalty Cards', 'loyalty-card-pro'),
            'lcp_manage_loyalty_cards',
            'lcp-loyalty-cards',
            array($this, 'render_loyalty_cards_page')
        );
        
        add_submenu_page(
            'loyalty-card-pro',
            __('Scratch Tickets', 'loyalty-card-pro'),
            __('Scratch Tickets', 'loyalty-card-pro'),
            'lcp_manage_tickets',
            'lcp-tickets',
            array($this, 'render_tickets_page')
        );
        
        add_submenu_page(
            'loyalty-card-pro',
            __('Purchase Plans', 'loyalty-card-pro'),
            __('Purchase Plans', 'loyalty-card-pro'),
            'lcp_view_dashboard',
            'lcp-purchase',
            array($this, 'render_purchase_page')
        );
    }
    
    /**
     * Render beautician dashboard
     */
    public static function render_beautician_dashboard() {
        $beautician_id = get_current_user_id();
        
        // Get statistics
        $client_count = LCP_Client::get_client_count($beautician_id);
        $client_limit = LCP_Subscription::get_client_limit($beautician_id);
        $loyalty_stats = LCP_Loyalty_Card::get_statistics($beautician_id);
        $ticket_stats = LCP_Ticket::get_statistics($beautician_id);
        
        // Get recent clients
        $recent_clients = LCP_Client::get_clients($beautician_id, '', 5, 0);
        
        ?>
        <div class="wrap lcp-beautician-dashboard">
            <h1><?php _e('Beautician Dashboard', 'loyalty-card-pro'); ?></h1>
            <p class="lcp-welcome"><?php printf(__('Welcome back, %s!', 'loyalty-card-pro'), wp_get_current_user()->display_name); ?></p>
            
            <!-- Quick Stats -->
            <div class="lcp-stats-grid">
                <div class="lcp-stat-card">
                    <div class="lcp-stat-icon">
                        <span class="dashicons dashicons-groups"></span>
                    </div>
                    <div class="lcp-stat-content">
                        <h3><?php echo $client_count; ?> / <?php echo $client_limit; ?></h3>
                        <p><?php _e('Clients', 'loyalty-card-pro'); ?></p>
                        <div class="lcp-progress-bar">
                            <div class="lcp-progress-fill" style="width: <?php echo ($client_limit > 0) ? ($client_count / $client_limit * 100) : 0; ?>%"></div>
                        </div>
                    </div>
                </div>
                
                <div class="lcp-stat-card">
                    <div class="lcp-stat-icon">
                        <span class="dashicons dashicons-awards"></span>
                    </div>
                    <div class="lcp-stat-content">
                        <h3><?php echo $loyalty_stats['active_cards']; ?></h3>
                        <p><?php _e('Active Loyalty Cards', 'loyalty-card-pro'); ?></p>
                        <small><?php echo $loyalty_stats['completed_cards']; ?> <?php _e('completed', 'loyalty-card-pro'); ?></small>
                    </div>
                </div>
                
                <div class="lcp-stat-card">
                    <div class="lcp-stat-icon">
                        <span class="dashicons dashicons-tickets-alt"></span>
                    </div>
                    <div class="lcp-stat-content">
                        <h3><?php echo $ticket_stats['available']; ?></h3>
                        <p><?php _e('Available Tickets', 'loyalty-card-pro'); ?></p>
                        <small><?php echo $ticket_stats['revealed']; ?> <?php _e('revealed', 'loyalty-card-pro'); ?></small>
                    </div>
                </div>
                
                <div class="lcp-stat-card lcp-stat-card-action">
                    <div class="lcp-stat-content">
                        <h3><?php _e('Quick Actions', 'loyalty-card-pro'); ?></h3>
                        <a href="#" class="button button-primary lcp-btn-add-client"><?php _e('Add Client', 'loyalty-card-pro'); ?></a>
                        <a href="<?php echo admin_url('admin.php?page=lcp-purchase'); ?>" class="button"><?php _e('Buy More', 'loyalty-card-pro'); ?></a>
                    </div>
                </div>
            </div>
            
            <!-- Recent Clients -->
            <div class="lcp-recent-section">
                <h2><?php _e('Recent Clients', 'loyalty-card-pro'); ?></h2>
                <?php if (empty($recent_clients)) : ?>
                    <div class="lcp-empty-state">
                        <span class="dashicons dashicons-groups"></span>
                        <p><?php _e('No clients yet. Add your first client to get started!', 'loyalty-card-pro'); ?></p>
                        <button class="button button-primary lcp-btn-add-client"><?php _e('Add First Client', 'loyalty-card-pro'); ?></button>
                    </div>
                <?php else : ?>
                    <div class="lcp-clients-grid">
                        <?php foreach ($recent_clients as $client) : ?>
                            <div class="lcp-client-card">
                                <div class="lcp-client-avatar">
                                    <?php echo strtoupper(substr($client->name, 0, 1)); ?>
                                </div>
                                <div class="lcp-client-info">
                                    <h4><?php echo esc_html($client->name); ?></h4>
                                    <p><?php echo esc_html($client->email); ?></p>
                                    <span class="lcp-badge"><?php echo $client->total_visits; ?> <?php _e('visits', 'loyalty-card-pro'); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <p>
                        <a href="<?php echo admin_url('admin.php?page=lcp-clients'); ?>" class="button"><?php _e('View All Clients', 'loyalty-card-pro'); ?></a>
                    </p>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render clients page
     */
    public function render_clients_page() {
        $beautician_id = get_current_user_id();
        $search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
        $clients = LCP_Client::get_clients($beautician_id, $search, 50, 0);
        $can_add_client = LCP_Subscription::can_add_client($beautician_id);
        $client_limit = LCP_Subscription::get_client_limit($beautician_id);
        $current_count = LCP_Client::get_client_count($beautician_id);
        
        ?>
        <div class="wrap lcp-clients-page">
            <h1><?php _e('Client Management', 'loyalty-card-pro'); ?></h1>
            
            <div class="lcp-page-header">
                <div class="lcp-search-box">
                    <form method="get">
                        <input type="hidden" name="page" value="lcp-clients">
                        <input type="text" name="search" value="<?php echo esc_attr($search); ?>" placeholder="<?php _e('Search clients...', 'loyalty-card-pro'); ?>">
                        <button type="submit" class="button"><?php _e('Search', 'loyalty-card-pro'); ?></button>
                    </form>
                </div>
                <div class="lcp-page-actions">
                    <span class="lcp-client-limit"><?php echo $current_count; ?> / <?php echo $client_limit; ?> <?php _e('clients', 'loyalty-card-pro'); ?></span>
                    <?php if ($can_add_client) : ?>
                        <button class="button button-primary lcp-btn-add-client"><?php _e('Add New Client', 'loyalty-card-pro'); ?></button>
                    <?php else : ?>
                        <a href="<?php echo admin_url('admin.php?page=lcp-purchase'); ?>" class="button button-primary"><?php _e('Upgrade to Add More', 'loyalty-card-pro'); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Clients Table -->
            <table class="wp-list-table widefat fixed striped lcp-clients-table">
                <thead>
                    <tr>
                        <th><?php _e('Name', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Email', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Phone', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Total Visits', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Loyalty Card', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Actions', 'loyalty-card-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($clients)) : ?>
                        <tr>
                            <td colspan="6">
                                <div class="lcp-empty-state">
                                    <?php _e('No clients found.', 'loyalty-card-pro'); ?>
                                </div>
                            </td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($clients as $client) : 
                            $loyalty_card = LCP_Loyalty_Card::get_active_card($client->id);
                        ?>
                            <tr data-client-id="<?php echo $client->id; ?>">
                                <td><strong><?php echo esc_html($client->name); ?></strong></td>
                                <td><?php echo esc_html($client->email); ?></td>
                                <td><?php echo esc_html($client->phone); ?></td>
                                <td><?php echo intval($client->total_visits); ?></td>
                                <td>
                                    <?php if ($loyalty_card) : ?>
                                        <span class="lcp-badge lcp-badge-success">
                                            <?php echo $loyalty_card->current_visits; ?>/<?php echo $loyalty_card->visit_limit; ?>
                                        </span>
                                    <?php else : ?>
                                        <span class="lcp-badge lcp-badge-inactive"><?php _e('No card', 'loyalty-card-pro'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="button button-small lcp-btn-add-visit" data-client-id="<?php echo $client->id; ?>"><?php _e('Add Visit', 'loyalty-card-pro'); ?></button>
                                    <button class="button button-small lcp-btn-assign-ticket" data-client-id="<?php echo $client->id; ?>"><?php _e('Give Ticket', 'loyalty-card-pro'); ?></button>
                                    <button class="button button-small lcp-btn-view-history" data-client-id="<?php echo $client->id; ?>"><?php _e('History', 'loyalty-card-pro'); ?></button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Add Client Modal -->
        <div id="lcp-add-client-modal" class="lcp-modal" style="display: none;">
            <div class="lcp-modal-content">
                <span class="lcp-modal-close">&times;</span>
                <h2><?php _e('Add New Client', 'loyalty-card-pro'); ?></h2>
                <form id="lcp-add-client-form">
                    <div class="lcp-form-group">
                        <label><?php _e('Full Name', 'loyalty-card-pro'); ?> *</label>
                        <input type="text" name="name" required>
                    </div>
                    <div class="lcp-form-group">
                        <label><?php _e('Email', 'loyalty-card-pro'); ?></label>
                        <input type="email" name="email">
                    </div>
                    <div class="lcp-form-group">
                        <label><?php _e('Phone', 'loyalty-card-pro'); ?></label>
                        <input type="text" name="phone">
                    </div>
                    <div class="lcp-form-group">
                        <label>
                            <input type="checkbox" name="create_loyalty_card" checked>
                            <?php _e('Create loyalty card for this client', 'loyalty-card-pro'); ?>
                        </label>
                    </div>
                    <div id="lcp-loyalty-card-options" class="lcp-form-section">
                        <div class="lcp-form-group">
                            <label><?php _e('Visit Limit', 'loyalty-card-pro'); ?></label>
                            <select name="visit_limit">
                                <option value="5">5 <?php _e('visits', 'loyalty-card-pro'); ?></option>
                                <option value="10" selected>10 <?php _e('visits', 'loyalty-card-pro'); ?></option>
                                <option value="15">15 <?php _e('visits', 'loyalty-card-pro'); ?></option>
                                <option value="20">20 <?php _e('visits', 'loyalty-card-pro'); ?></option>
                            </select>
                        </div>
                        <div class="lcp-form-group">
                            <label><?php _e('Reward Description', 'loyalty-card-pro'); ?></label>
                            <textarea name="reward_description" rows="3" placeholder="<?php _e('e.g., Free manicure after 10 visits', 'loyalty-card-pro'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="lcp-form-actions">
                        <button type="submit" class="button button-primary"><?php _e('Add Client', 'loyalty-card-pro'); ?></button>
                        <button type="button" class="button lcp-modal-close"><?php _e('Cancel', 'loyalty-card-pro'); ?></button>
                    </div>
                </form>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render loyalty cards page
     */
    public function render_loyalty_cards_page() {
        $beautician_id = get_current_user_id();
        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';
        $cards = LCP_Loyalty_Card::get_beautician_cards($beautician_id, $status_filter);
        
        ?>
        <div class="wrap lcp-loyalty-cards-page">
            <h1><?php _e('Loyalty Cards', 'loyalty-card-pro'); ?></h1>
            
            <div class="lcp-filter-bar">
                <a href="<?php echo admin_url('admin.php?page=lcp-loyalty-cards'); ?>" class="button <?php echo $status_filter === 'all' ? 'button-primary' : ''; ?>">
                    <?php _e('All', 'loyalty-card-pro'); ?>
                </a>
                <a href="<?php echo admin_url('admin.php?page=lcp-loyalty-cards&status=active'); ?>" class="button <?php echo $status_filter === 'active' ? 'button-primary' : ''; ?>">
                    <?php _e('Active', 'loyalty-card-pro'); ?>
                </a>
                <a href="<?php echo admin_url('admin.php?page=lcp-loyalty-cards&status=completed'); ?>" class="button <?php echo $status_filter === 'completed' ? 'button-primary' : ''; ?>">
                    <?php _e('Completed', 'loyalty-card-pro'); ?>
                </a>
            </div>
            
            <?php if (empty($cards)) : ?>
                <div class="lcp-empty-state">
                    <span class="dashicons dashicons-awards"></span>
                    <p><?php _e('No loyalty cards found.', 'loyalty-card-pro'); ?></p>
                </div>
            <?php else : ?>
                <div class="lcp-cards-grid">
                    <?php foreach ($cards as $card) : 
                        $client = LCP_Client::get_client($card->client_id);
                        $progress = ($card->visit_limit > 0) ? ($card->current_visits / $card->visit_limit * 100) : 0;
                    ?>
                        <div class="lcp-loyalty-card <?php echo $card->status === 'completed' ? 'completed' : ''; ?>">
                            <div class="lcp-card-header">
                                <h3><?php echo esc_html($client->name); ?></h3>
                                <?php if ($card->status === 'completed') : ?>
                                    <span class="lcp-badge lcp-badge-success"><?php _e('Completed!', 'loyalty-card-pro'); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="lcp-card-progress">
                                <div class="lcp-progress-bar">
                                    <div class="lcp-progress-fill" style="width: <?php echo $progress; ?>%"></div>
                                </div>
                                <p class="lcp-progress-text"><?php echo $card->current_visits; ?> / <?php echo $card->visit_limit; ?> <?php _e('visits', 'loyalty-card-pro'); ?></p>
                            </div>
                            <?php if (!empty($card->reward_description)) : ?>
                                <div class="lcp-card-reward">
                                    <strong><?php _e('Reward:', 'loyalty-card-pro'); ?></strong>
                                    <p><?php echo esc_html($card->reward_description); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if ($card->status === 'completed') : ?>
                                <button class="button button-primary lcp-btn-reset-card" data-card-id="<?php echo $card->id; ?>">
                                    <?php _e('Reset Card', 'loyalty-card-pro'); ?>
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render tickets page
     */
    public function render_tickets_page() {
        $beautician_id = get_current_user_id();
        $ticket_stats = LCP_Ticket::get_statistics($beautician_id);
        
        ?>
        <div class="wrap lcp-tickets-page">
            <h1><?php _e('Scratch-Off Surprise Tickets', 'loyalty-card-pro'); ?></h1>
            
            <div class="lcp-tickets-header">
                <div class="lcp-ticket-stats">
                    <div class="lcp-stat-item">
                        <span class="lcp-stat-number"><?php echo $ticket_stats['available']; ?></span>
                        <span class="lcp-stat-label"><?php _e('Available', 'loyalty-card-pro'); ?></span>
                    </div>
                    <div class="lcp-stat-item">
                        <span class="lcp-stat-number"><?php echo $ticket_stats['assigned']; ?></span>
                        <span class="lcp-stat-label"><?php _e('Assigned', 'loyalty-card-pro'); ?></span>
                    </div>
                    <div class="lcp-stat-item">
                        <span class="lcp-stat-number"><?php echo $ticket_stats['revealed']; ?></span>
                        <span class="lcp-stat-label"><?php _e('Revealed', 'loyalty-card-pro'); ?></span>
                    </div>
                </div>
                <div class="lcp-tickets-actions">
                    <a href="<?php echo admin_url('admin.php?page=lcp-purchase'); ?>" class="button button-primary">
                        <?php _e('Buy More Tickets', 'loyalty-card-pro'); ?>
                    </a>
                </div>
            </div>
            
            <?php if ($ticket_stats['available'] > 0) : ?>
                <div class="lcp-ticket-assign-section">
                    <h2><?php _e('Assign Ticket to Client', 'loyalty-card-pro'); ?></h2>
                    <p><?php _e('Select a client below to assign a random surprise ticket:', 'loyalty-card-pro'); ?></p>
                    
                    <?php
                    $clients = LCP_Client::get_clients($beautician_id, '', 100, 0);
                    if (!empty($clients)) :
                    ?>
                        <div class="lcp-client-select-grid">
                            <?php foreach ($clients as $client) : ?>
                                <div class="lcp-client-select-card" data-client-id="<?php echo $client->id; ?>">
                                    <div class="lcp-client-avatar"><?php echo strtoupper(substr($client->name, 0, 1)); ?></div>
                                    <div class="lcp-client-name"><?php echo esc_html($client->name); ?></div>
                                    <button class="button lcp-btn-assign-random-ticket" data-client-id="<?php echo $client->id; ?>">
                                        <?php _e('Assign Ticket', 'loyalty-card-pro'); ?>
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <p><?php _e('No clients found. Add clients first to assign tickets.', 'loyalty-card-pro'); ?></p>
                    <?php endif; ?>
                </div>
            <?php else : ?>
                <div class="lcp-empty-state">
                    <span class="dashicons dashicons-tickets-alt"></span>
                    <p><?php _e('You have no available tickets. Purchase a ticket bundle to get started!', 'loyalty-card-pro'); ?></p>
                    <a href="<?php echo admin_url('admin.php?page=lcp-purchase'); ?>" class="button button-primary">
                        <?php _e('Purchase Tickets', 'loyalty-card-pro'); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render purchase page
     */
    public function render_purchase_page() {
        $plans = LCP_Subscription::get_pricing_plans();
        
        ?>
        <div class="wrap lcp-purchase-page">
            <h1><?php _e('Purchase Plans', 'loyalty-card-pro'); ?></h1>
            <p class="lcp-subtitle"><?php _e('Expand your client base and get more surprise tickets!', 'loyalty-card-pro'); ?></p>
            
            <div class="lcp-pricing-grid">
                <?php foreach ($plans as $plan) : ?>
                    <div class="lcp-pricing-card">
                        <div class="lcp-plan-header">
                            <h3><?php echo esc_html($plan->plan_name); ?></h3>
                            <div class="lcp-plan-price">
                                <span class="lcp-currency">$</span>
                                <span class="lcp-amount"><?php echo number_format($plan->price, 2); ?></span>
                            </div>
                        </div>
                        <div class="lcp-plan-features">
                            <?php if ($plan->ticket_count > 0) : ?>
                                <div class="lcp-feature">
                                    <span class="dashicons dashicons-tickets-alt"></span>
                                    <span><?php echo $plan->ticket_count; ?> <?php _e('Scratch-Off Tickets', 'loyalty-card-pro'); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($plan->client_limit > 0) : ?>
                                <div class="lcp-feature">
                                    <span class="dashicons dashicons-groups"></span>
                                    <span>+<?php echo $plan->client_limit; ?> <?php _e('Client Slots', 'loyalty-card-pro'); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <button class="button button-primary button-hero lcp-btn-purchase-plan" data-plan-id="<?php echo $plan->id; ?>">
                            <?php _e('Purchase Now', 'loyalty-card-pro'); ?>
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="lcp-payment-info">
                <h3><?php _e('Payment Information', 'loyalty-card-pro'); ?></h3>
                <p><?php _e('Secure payment processing powered by WooCommerce. All transactions are encrypted and secure.', 'loyalty-card-pro'); ?></p>
            </div>
        </div>
        <?php
    }
}
