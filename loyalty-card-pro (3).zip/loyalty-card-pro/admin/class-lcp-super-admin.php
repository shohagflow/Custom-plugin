<?php
/**
 * Super Admin Dashboard class
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Super_Admin {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', array($this, 'add_super_admin_menu'));
        add_action('admin_notices', array($this, 'check_database_schema'));
        
        // AJAX handlers for package management
        add_action('wp_ajax_lcp_save_loyalty_plan', array($this, 'ajax_save_loyalty_plan'));
        add_action('wp_ajax_lcp_save_ticket_bundle', array($this, 'ajax_save_ticket_bundle'));
        add_action('wp_ajax_lcp_delete_plan', array($this, 'ajax_delete_plan'));
        add_action('wp_ajax_lcp_update_database', array($this, 'ajax_update_database'));
        add_action('wp_ajax_lcp_create_missing_products', array($this, 'ajax_create_missing_products'));
    }
    
    /**
     * Check if database needs updating
     */
    public function check_database_schema() {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        // Check if wc_product_id column exists
        $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $table LIKE 'wc_product_id'");
        
        if (empty($column_exists)) {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p>
                    <strong><?php _e('Loyalty Card Pro:', 'loyalty-card-pro'); ?></strong>
                    <?php _e('Database update required! The WooCommerce integration needs a database column update.', 'loyalty-card-pro'); ?>
                    <button type="button" class="button button-primary" onclick="lcpUpdateDatabase()" style="margin-left: 10px;">
                        <?php _e('Update Database Now', 'loyalty-card-pro'); ?>
                    </button>
                    <span id="lcp-db-update-status" style="margin-left: 10px;"></span>
                </p>
            </div>
            <script>
            function lcpUpdateDatabase() {
                var button = event.target;
                var status = document.getElementById('lcp-db-update-status');
                button.disabled = true;
                button.textContent = '<?php _e('Updating...', 'loyalty-card-pro'); ?>';
                status.innerHTML = '<span class="spinner is-active" style="float: none;"></span>';
                
                jQuery.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'lcp_update_database',
                        nonce: '<?php echo wp_create_nonce('lcp_db_update'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            status.innerHTML = '<span style="color: #46b450;">✓ ' + response.data.message + '</span>';
                            setTimeout(function() {
                                location.reload();
                            }, 1500);
                        } else {
                            status.innerHTML = '<span style="color: #dc3232;">✗ ' + response.data.message + '</span>';
                            button.disabled = false;
                            button.textContent = '<?php _e('Try Again', 'loyalty-card-pro'); ?>';
                        }
                    },
                    error: function() {
                        status.innerHTML = '<span style="color: #dc3232;">✗ <?php _e('Update failed', 'loyalty-card-pro'); ?></span>';
                        button.disabled = false;
                        button.textContent = '<?php _e('Try Again', 'loyalty-card-pro'); ?>';
                    }
                });
            }
            </script>
            <?php
        } else {
            // Check if there are packages without WooCommerce products
            $packages_without_products = $wpdb->get_var(
                "SELECT COUNT(*) FROM $table WHERE (wc_product_id IS NULL OR wc_product_id = 0) AND is_active = 1"
            );
            
            if ($packages_without_products > 0) {
                ?>
                <div class="notice notice-info is-dismissible">
                    <p>
                        <strong><?php _e('Loyalty Card Pro:', 'loyalty-card-pro'); ?></strong>
                        <?php printf(
                            _n(
                                'Found %d package without a WooCommerce product. Create products for existing packages?',
                                'Found %d packages without WooCommerce products. Create products for existing packages?',
                                $packages_without_products,
                                'loyalty-card-pro'
                            ),
                            $packages_without_products
                        ); ?>
                        <button type="button" class="button button-primary" onclick="lcpCreateMissingProducts()" style="margin-left: 10px;">
                            <?php _e('Create Products Now', 'loyalty-card-pro'); ?>
                        </button>
                        <span id="lcp-create-products-status" style="margin-left: 10px;"></span>
                    </p>
                </div>
                <script>
                function lcpCreateMissingProducts() {
                    var button = event.target;
                    var status = document.getElementById('lcp-create-products-status');
                    button.disabled = true;
                    button.textContent = '<?php _e('Creating...', 'loyalty-card-pro'); ?>';
                    status.innerHTML = '<span class="spinner is-active" style="float: none;"></span>';
                    
                    jQuery.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'lcp_create_missing_products',
                            nonce: '<?php echo wp_create_nonce('lcp_create_products'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                status.innerHTML = '<span style="color: #46b450;">✓ ' + response.data.message + '</span>';
                                setTimeout(function() {
                                    location.reload();
                                }, 1500);
                            } else {
                                status.innerHTML = '<span style="color: #dc3232;">✗ ' + response.data.message + '</span>';
                                button.disabled = false;
                                button.textContent = '<?php _e('Try Again', 'loyalty-card-pro'); ?>';
                            }
                        },
                        error: function() {
                            status.innerHTML = '<span style="color: #dc3232;">✗ <?php _e('Creation failed', 'loyalty-card-pro'); ?></span>';
                            button.disabled = false;
                            button.textContent = '<?php _e('Try Again', 'loyalty-card-pro'); ?>';
                        }
                    });
                }
                </script>
                <?php
            }
        }
    }
    
    /**
     * AJAX: Update database schema
     */
    public function ajax_update_database() {
        check_ajax_referer('lcp_db_update', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'loyalty-card-pro')));
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        // Add wc_product_id column
        $result = $wpdb->query("ALTER TABLE $table ADD COLUMN wc_product_id bigint(20) DEFAULT NULL AFTER price");
        
        if ($result !== false) {
            wp_send_json_success(array('message' => __('Database updated successfully!', 'loyalty-card-pro')));
        } else {
            wp_send_json_error(array('message' => __('Database update failed: ', 'loyalty-card-pro') . $wpdb->last_error));
        }
    }
    
    /**
     * AJAX: Create WooCommerce products for packages that don't have them
     */
    public function ajax_create_missing_products() {
        check_ajax_referer('lcp_create_products', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'loyalty-card-pro')));
        }
        
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            wp_send_json_error(array('message' => __('WooCommerce is not active', 'loyalty-card-pro')));
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        // Get all packages without WooCommerce products
        $packages = $wpdb->get_results(
            "SELECT * FROM $table WHERE (wc_product_id IS NULL OR wc_product_id = 0) AND is_active = 1",
            ARRAY_A
        );
        
        if (empty($packages)) {
            wp_send_json_success(array('message' => __('No packages need products created', 'loyalty-card-pro')));
        }
        
        $created_count = 0;
        $errors = array();
        
        foreach ($packages as $package) {
            try {
                // Create WooCommerce product
                $product = new WC_Product_Simple();
                $product->set_name($package['plan_name']);
                $product->set_status('publish');
                $product->set_regular_price($package['price']);
                
                // Set description based on package type
                if ($package['plan_type'] === 'loyalty_cards') {
                    $product->set_description(sprintf(
                        __('Loyalty Card Plan: %d clients', 'loyalty-card-pro'),
                        $package['client_limit']
                    ));
                } else {
                    $product->set_description(sprintf(
                        __('Scratch-Off Ticket Bundle: %d tickets', 'loyalty-card-pro'),
                        $package['ticket_count']
                    ));
                }
                
                $product->set_catalog_visibility('hidden');
                $product->set_virtual(true);
                $product->save();
                
                $wc_product_id = $product->get_id();
                
                // Update package with WooCommerce product ID
                $wpdb->update(
                    $table,
                    array('wc_product_id' => $wc_product_id),
                    array('id' => $package['id'])
                );
                
                $created_count++;
                
            } catch (Exception $e) {
                $errors[] = sprintf(
                    __('Error creating product for "%s": %s', 'loyalty-card-pro'),
                    $package['plan_name'],
                    $e->getMessage()
                );
            }
        }
        
        if ($created_count > 0) {
            $message = sprintf(
                _n(
                    'Successfully created %d WooCommerce product!',
                    'Successfully created %d WooCommerce products!',
                    $created_count,
                    'loyalty-card-pro'
                ),
                $created_count
            );
            
            if (!empty($errors)) {
                $message .= ' ' . __('Some products failed: ', 'loyalty-card-pro') . implode(', ', $errors);
            }
            
            wp_send_json_success(array('message' => $message));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to create products: ', 'loyalty-card-pro') . implode(', ', $errors)
            ));
        }
    }
    
    /**
     * Add super admin menu
     */
    public function add_super_admin_menu() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        add_submenu_page(
            'loyalty-card-pro',
            __('Beauticians Management', 'loyalty-card-pro'),
            __('Beauticians Management', 'loyalty-card-pro'),
            'manage_options',
            'lcp-beauticians-management',
            array($this, 'render_beauticians_management')
        );
        
        add_submenu_page(
            'loyalty-card-pro',
            __('Package Control', 'loyalty-card-pro'),
            __('Package Control', 'loyalty-card-pro'),
            'manage_options',
            'lcp-price-control',
            array($this, 'render_price_control')
        );
        
        add_submenu_page(
            'loyalty-card-pro',
            __('Payment Gateway', 'loyalty-card-pro'),
            __('Payment Gateway', 'loyalty-card-pro'),
            'manage_options',
            'lcp-payment-gateway',
            array($this, 'render_payment_gateway')
        );
    }
    
    /**
     * Render super admin dashboard (Overview)
     */
    public static function render_super_admin_dashboard() {
        global $wpdb;
        
        // Get statistics
        $beauticians_count = count(get_users(array('role' => 'lcp_beautician')));
        $clients_table = $wpdb->prefix . 'lcp_clients';
        $total_clients = $wpdb->get_var("SELECT COUNT(*) FROM $clients_table");
        
        $tickets_table = $wpdb->prefix . 'lcp_tickets';
        $total_tickets = $wpdb->get_var("SELECT COUNT(*) FROM $tickets_table");
        $available_tickets = $wpdb->get_var("SELECT COUNT(*) FROM $tickets_table WHERE status = 'available'");
        $used_tickets = $wpdb->get_var("SELECT COUNT(*) FROM $tickets_table WHERE status = 'revealed'");
        
        $loyalty_cards_table = $wpdb->prefix . 'lcp_loyalty_cards';
        $active_cards = $wpdb->get_var("SELECT COUNT(*) FROM $loyalty_cards_table WHERE status = 'active'");
        $completed_cards = $wpdb->get_var("SELECT COUNT(*) FROM $loyalty_cards_table WHERE status = 'completed'");
        
        $payments_table = $wpdb->prefix . 'lcp_payments';
        $total_revenue = $wpdb->get_var("SELECT SUM(amount) FROM $payments_table WHERE status = 'completed'");
        
        // Get recent activities
        $recent_clients = $wpdb->get_results("SELECT * FROM $clients_table ORDER BY created_at DESC LIMIT 5");
        
        // Get top beauticians by client count
        $top_beauticians = $wpdb->get_results("
            SELECT beautician_id, COUNT(*) as client_count 
            FROM $clients_table 
            GROUP BY beautician_id 
            ORDER BY client_count DESC 
            LIMIT 5
        ");
        
        ?>
        <div class="wrap lcp-super-admin-dashboard">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <div>
                    <h1 style="margin: 0; color: #FE7AC1;">
                        <span class="dashicons dashicons-chart-area" style="font-size: 32px;"></span>
                        <?php _e('Overview', 'loyalty-card-pro'); ?>
                    </h1>
                    <p style="margin: 5px 0 0 0; color: #666;"><?php _e('Welcome back! Here\'s what\'s happening with your loyalty program.', 'loyalty-card-pro'); ?></p>
                </div>
                <div>
                    <span style="background: #FFEFF7; color: #FE7AC1; padding: 8px 16px; border-radius: 20px; font-weight: 600;">
                        <?php echo date('l, F j, Y'); ?>
                    </span>
                </div>
            </div>
            
            <!-- Main Statistics Cards -->
            <div class="lcp-stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
                <div class="lcp-stat-card" style="background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%); color: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(254,122,193,0.3);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p style="margin: 0; opacity: 0.9; font-size: 14px;"><?php _e('Total Beauticians', 'loyalty-card-pro'); ?></p>
                            <h2 style="margin: 10px 0 0 0; font-size: 36px; font-weight: 700;"><?php echo number_format($beauticians_count); ?></h2>
                    </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 12px; border-radius: 10px;">
                            <span class="dashicons dashicons-admin-users" style="font-size: 28px;"></span>
                        </div>
                    </div>
                </div>
                
                <div class="lcp-stat-card" style="background: white; border: 2px solid #FFEFF7; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p style="margin: 0; color: #666; font-size: 14px;"><?php _e('Total Clients', 'loyalty-card-pro'); ?></p>
                            <h2 style="margin: 10px 0 0 0; font-size: 36px; font-weight: 700; color: #FE7AC1;"><?php echo number_format($total_clients); ?></h2>
                    </div>
                        <div style="background: #FFEFF7; padding: 12px; border-radius: 10px;">
                            <span class="dashicons dashicons-groups" style="font-size: 28px; color: #FE7AC1;"></span>
                        </div>
                    </div>
                </div>
                
                <div class="lcp-stat-card" style="background: white; border: 2px solid #FFEFF7; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p style="margin: 0; color: #666; font-size: 14px;"><?php _e('Total Tickets', 'loyalty-card-pro'); ?></p>
                            <h2 style="margin: 10px 0 5px 0; font-size: 36px; font-weight: 700; color: #FE7AC1;"><?php echo number_format($total_tickets); ?></h2>
                            <p style="margin: 0; font-size: 12px; color: #999;">
                                <span style="color: #4CAF50;">●</span> <?php echo number_format($available_tickets); ?> <?php _e('available', 'loyalty-card-pro'); ?> 
                                <span style="margin-left: 10px; color: #999;">●</span> <?php echo number_format($used_tickets); ?> <?php _e('used', 'loyalty-card-pro'); ?>
                            </p>
                    </div>
                        <div style="background: #FFEFF7; padding: 12px; border-radius: 10px;">
                            <span class="dashicons dashicons-tickets-alt" style="font-size: 28px; color: #FE7AC1;"></span>
                        </div>
                    </div>
                </div>
                
                <div class="lcp-stat-card" style="background: linear-gradient(135deg, #4CAF50 0%, #66BB6A 100%); color: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(76,175,80,0.3);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p style="margin: 0; opacity: 0.9; font-size: 14px;"><?php _e('Total Revenue', 'loyalty-card-pro'); ?></p>
                            <h2 style="margin: 10px 0 0 0; font-size: 36px; font-weight: 700;">$<?php echo number_format($total_revenue, 2); ?></h2>
                    </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 12px; border-radius: 10px;">
                            <span class="dashicons dashicons-money-alt" style="font-size: 28px;"></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Two Column Layout -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
                <!-- Loyalty Cards Stats -->
                <div style="background: white; padding: 25px; border-radius: 12px; border: 2px solid #FFEFF7; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <h3 style="margin: 0 0 20px 0; color: #FE7AC1; display: flex; align-items: center; gap: 10px;">
                        <span class="dashicons dashicons-awards"></span>
                        <?php _e('Loyalty Cards', 'loyalty-card-pro'); ?>
                    </h3>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div style="text-align: center; padding: 20px; background: #FFEFF7; border-radius: 8px;">
                            <h4 style="margin: 0; font-size: 32px; color: #FE7AC1; font-weight: 700;"><?php echo number_format($active_cards); ?></h4>
                            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;"><?php _e('Active Cards', 'loyalty-card-pro'); ?></p>
                        </div>
                        <div style="text-align: center; padding: 20px; background: #F0F0F1; border-radius: 8px;">
                            <h4 style="margin: 0; font-size: 32px; color: #4CAF50; font-weight: 700;"><?php echo number_format($completed_cards); ?></h4>
                            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;"><?php _e('Completed', 'loyalty-card-pro'); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div style="background: white; padding: 25px; border-radius: 12px; border: 2px solid #FFEFF7; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <h3 style="margin: 0 0 20px 0; color: #FE7AC1; display: flex; align-items: center; gap: 10px;">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <?php _e('Quick Actions', 'loyalty-card-pro'); ?>
                    </h3>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <a href="<?php echo admin_url('admin.php?page=lcp-beauticians-management'); ?>" class="button button-large" style="justify-content: flex-start; display: flex; align-items: center; gap: 10px; text-decoration: none;">
                            <span class="dashicons dashicons-admin-users"></span>
                            <?php _e('Manage Beauticians', 'loyalty-card-pro'); ?>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=lcp-price-control'); ?>" class="button button-large" style="justify-content: flex-start; display: flex; align-items: center; gap: 10px; text-decoration: none;">
                            <span class="dashicons dashicons-tag"></span>
                            <?php _e('Package Control', 'loyalty-card-pro'); ?>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=lcp-payment-gateway'); ?>" class="button button-large" style="justify-content: flex-start; display: flex; align-items: center; gap: 10px; text-decoration: none;">
                            <span class="dashicons dashicons-money-alt"></span>
                            <?php _e('Payment Settings', 'loyalty-card-pro'); ?>
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Two Column Layout -->
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
                <!-- Recent Clients -->
                <div style="background: white; padding: 25px; border-radius: 12px; border: 2px solid #FFEFF7; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <h3 style="margin: 0 0 20px 0; color: #FE7AC1; display: flex; align-items: center; gap: 10px;">
                        <span class="dashicons dashicons-groups"></span>
                        <?php _e('Recent Clients', 'loyalty-card-pro'); ?>
                    </h3>
                    <table class="wp-list-table widefat fixed striped" style="border: none;">
                    <thead>
                            <tr style="background: #FFEFF7;">
                            <th><?php _e('Name', 'loyalty-card-pro'); ?></th>
                            <th><?php _e('Email', 'loyalty-card-pro'); ?></th>
                            <th><?php _e('Beautician', 'loyalty-card-pro'); ?></th>
                                <th><?php _e('Visits', 'loyalty-card-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent_clients)) : ?>
                            <tr>
                                    <td colspan="4" style="text-align: center; padding: 40px; color: #999;">
                                        <span class="dashicons dashicons-groups" style="font-size: 48px; opacity: 0.3;"></span>
                                        <p><?php _e('No clients yet.', 'loyalty-card-pro'); ?></p>
                                    </td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($recent_clients as $client) : 
                                $beautician = get_userdata($client->beautician_id);
                            ?>
                                <tr>
                                        <td><strong><?php echo esc_html($client->name); ?></strong></td>
                                    <td><?php echo esc_html($client->email); ?></td>
                                    <td><?php echo $beautician ? esc_html($beautician->display_name) : __('N/A', 'loyalty-card-pro'); ?></td>
                                        <td><span style="background: #FE7AC1; color: white; padding: 3px 10px; border-radius: 12px; font-weight: 600;"><?php echo intval($client->total_visits); ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                </div>
                
                <!-- Top Beauticians -->
                <div style="background: white; padding: 25px; border-radius: 12px; border: 2px solid #FFEFF7; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    <h3 style="margin: 0 0 20px 0; color: #FE7AC1; display: flex; align-items: center; gap: 10px;">
                        <span class="dashicons dashicons-star-filled"></span>
                        <?php _e('Top Beauticians', 'loyalty-card-pro'); ?>
                    </h3>
                    <?php if (empty($top_beauticians)) : ?>
                        <p style="text-align: center; color: #999; padding: 20px 0;"><?php _e('No data available', 'loyalty-card-pro'); ?></p>
                    <?php else : ?>
                        <div style="display: flex; flex-direction: column; gap: 12px;">
                            <?php 
                            $rank = 1;
                            foreach ($top_beauticians as $top) : 
                                $beautician = get_userdata($top->beautician_id);
                                if ($beautician) :
                            ?>
                                <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #FFEFF7; border-radius: 8px;">
                                    <div style="width: 32px; height: 32px; background: #FE7AC1; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700;">
                                        <?php echo $rank; ?>
                                    </div>
                                    <div style="flex: 1;">
                                        <strong style="display: block; color: #333;"><?php echo esc_html($beautician->display_name); ?></strong>
                                        <span style="font-size: 12px; color: #666;"><?php echo number_format($top->client_count); ?> <?php _e('clients', 'loyalty-card-pro'); ?></span>
                                    </div>
                                </div>
                            <?php 
                                $rank++;
                                endif;
                            endforeach; 
                            ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render beauticians management page
     */
    public function render_beauticians_management() {
        global $wpdb;
        
        // Get filter parameter (dummy - UI only)
        $current_filter = isset($_GET['filter']) ? sanitize_text_field($_GET['filter']) : 'all';
        
        // Get all beauticians
        $beauticians = get_users(array('role' => 'lcp_beautician'));
        
        // Add dummy beauticians if none exist
        $dummy_beauticians = array(
            array('name' => 'Sarah Johnson', 'email' => 'sarah.johnson@beautysalon.com', 'visitors' => 145, 'clients' => 32),
            array('name' => 'Emma Wilson', 'email' => 'emma.wilson@beautysalon.com', 'visitors' => 198, 'clients' => 45),
            array('name' => 'Olivia Martinez', 'email' => 'olivia.martinez@beautysalon.com', 'visitors' => 167, 'clients' => 38),
            array('name' => 'Sophia Brown', 'email' => 'sophia.brown@beautysalon.com', 'visitors' => 123, 'clients' => 28),
            array('name' => 'Isabella Garcia', 'email' => 'isabella.garcia@beautysalon.com', 'visitors' => 189, 'clients' => 41),
            array('name' => 'Mia Anderson', 'email' => 'mia.anderson@beautysalon.com', 'visitors' => 156, 'clients' => 35),
            array('name' => 'Charlotte Taylor', 'email' => 'charlotte.taylor@beautysalon.com', 'visitors' => 134, 'clients' => 30),
            array('name' => 'Amelia Thomas', 'email' => 'amelia.thomas@beautysalon.com', 'visitors' => 178, 'clients' => 40),
        );
        
        ?>
        <div class="wrap lcp-beauticians-management">
            <h1><?php _e('Beauticians Management', 'loyalty-card-pro'); ?></h1>
            
            <!-- Filter Options (UI only) -->
            <div class="lcp-filter-tabs" style="margin: 20px 0; padding: 15px; background: #fff; border: 1px solid #ddd; border-radius: 4px;">
                <strong style="margin-right: 15px;"><?php _e('Filter:', 'loyalty-card-pro'); ?></strong>
                <a href="?page=lcp-beauticians-management&filter=daily" 
                   class="button <?php echo $current_filter === 'daily' ? 'button-primary' : ''; ?>" 
                   style="margin-right: 5px;">
                    <?php _e('Daily', 'loyalty-card-pro'); ?>
                </a>
                <a href="?page=lcp-beauticians-management&filter=weekly" 
                   class="button <?php echo $current_filter === 'weekly' ? 'button-primary' : ''; ?>" 
                   style="margin-right: 5px;">
                    <?php _e('Weekly', 'loyalty-card-pro'); ?>
                </a>
                <a href="?page=lcp-beauticians-management&filter=monthly" 
                   class="button <?php echo $current_filter === 'monthly' ? 'button-primary' : ''; ?>" 
                   style="margin-right: 5px;">
                    <?php _e('Monthly', 'loyalty-card-pro'); ?>
                </a>
                <a href="?page=lcp-beauticians-management" 
                   class="button <?php echo $current_filter === 'all' ? 'button-primary' : ''; ?>">
                    <?php _e('All Time', 'loyalty-card-pro'); ?>
                </a>
                <?php if ($current_filter !== 'all') : ?>
                    <span style="margin-left: 15px; color: #666; font-style: italic;">
                        <?php printf(__('Showing %s data', 'loyalty-card-pro'), ucfirst($current_filter)); ?>
                    </span>
                <?php endif; ?>
            </div>
            
            <!-- Beauticians Table -->
            <table class="wp-list-table widefat fixed striped lcp-beauticians-table">
                <thead>
                    <tr>
                        <th><?php _e('Name', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Email', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Total Visitors', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Total Clients', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Action', 'loyalty-card-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Show real beauticians if they exist, otherwise show dummy data
                    $display_beauticians = !empty($beauticians) ? $beauticians : null;
                    
                    if (empty($beauticians)) :
                        // Display dummy beauticians
                        foreach ($dummy_beauticians as $idx => $beautician) : 
                    ?>
                            <tr>
                                <td><strong><?php echo esc_html($beautician['name']); ?></strong></td>
                                <td><?php echo esc_html($beautician['email']); ?></td>
                                <td>
                                    <span class="lcp-stat-badge" style="background: #FE7AC1; color: white; padding: 3px 10px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($beautician['visitors']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="lcp-stat-badge" style="background: #FFEFF7; color: #FE7AC1; padding: 3px 10px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($beautician['clients']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button type="button" 
                                            class="button button-small button-link-delete lcp-delete-beautician-btn" 
                                            data-user-id="<?php echo ($idx + 1); ?>"
                                            data-user-name="<?php echo esc_attr($beautician['name']); ?>"
                                            style="color: #d63638;">
                                        <?php _e('Delete', 'loyalty-card-pro'); ?>
                                    </button>
                                </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <?php foreach ($beauticians as $beautician) : 
                            $client_count = LCP_Client::get_client_count($beautician->ID);
                            // Generate dummy visitor count based on client count
                            $visitor_count = $client_count > 0 ? rand($client_count * 2, $client_count * 5) : rand(0, 10);
                        ?>
                            <tr>
                                <td><strong><?php echo esc_html($beautician->display_name); ?></strong></td>
                                <td><?php echo esc_html($beautician->user_email); ?></td>
                                <td>
                                    <span class="lcp-stat-badge" style="background: #FE7AC1; color: white; padding: 3px 10px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($visitor_count); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="lcp-stat-badge" style="background: #FFEFF7; color: #FE7AC1; padding: 3px 10px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($client_count); ?>
                                    </span>
                                </td>
                                <td>
                                    <button type="button" 
                                            class="button button-small button-link-delete lcp-delete-beautician-btn" 
                                            data-user-id="<?php echo $beautician->ID; ?>"
                                            data-user-name="<?php echo esc_attr($beautician->display_name); ?>"
                                            style="color: #d63638;">
                                        <?php _e('Delete', 'loyalty-card-pro'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <p style="margin-top: 15px; padding: 10px; background: #f0f0f1; border-left: 4px solid #FE7AC1;">
                <strong><?php _e('Note:', 'loyalty-card-pro'); ?></strong> 
                <?php _e('Filters are currently for display purposes only. Delete action is UI-only (no backend logic).', 'loyalty-card-pro'); ?>
            </p>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // UI-only delete button (no actual deletion)
            $('.lcp-delete-beautician-btn').on('click', function() {
                var userName = $(this).data('user-name');
                var confirmed = confirm('Delete ' + userName + '? (Note: This is UI-only, no actual deletion will occur)');
                if (confirmed) {
                    $(this).closest('tr').fadeOut(300, function() {
                        $(this).remove();
                    });
                    
                    // Show success message
                    $('<div class="notice notice-success is-dismissible"><p>Beautician deleted successfully (UI-only demo).</p></div>')
                        .insertAfter('.lcp-beauticians-management h1')
                        .delay(3000)
                        .fadeOut();
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render price control page
     */
    public function render_price_control() {
        global $wpdb;
        
        // Get real data from database
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        // Get loyalty card plans
        $loyalty_cards = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, plan_name as name, client_limit, price, wc_product_id 
                FROM $table 
                WHERE plan_type = %s AND is_active = 1 
                ORDER BY price ASC",
                'loyalty_cards'
            ),
            ARRAY_A
        );
        
        // Get ticket bundle plans
        $ticket_bundles = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, plan_name as name, ticket_count as ticket_limit, price, wc_product_id 
                FROM $table 
                WHERE plan_type = %s AND is_active = 1 
                ORDER BY price ASC",
                'tickets'
            ),
            ARRAY_A
        );
        
        // If no plans exist, add defaults
        if (empty($loyalty_cards)) {
            $wpdb->insert($table, array(
                'plan_name' => 'Basic Card - 20 Clients',
                'plan_type' => 'loyalty_cards',
                'client_limit' => 20,
                'ticket_count' => 0,
                'price' => 15.00,
                'is_active' => 1
            ));
            $wpdb->insert($table, array(
                'plan_name' => 'Premium Card - 50 Clients',
                'plan_type' => 'loyalty_cards',
                'client_limit' => 50,
                'ticket_count' => 0,
                'price' => 35.00,
                'is_active' => 1
            ));
            $wpdb->insert($table, array(
                'plan_name' => 'Enterprise Card - 100 Clients',
                'plan_type' => 'loyalty_cards',
                'client_limit' => 100,
                'ticket_count' => 0,
                'price' => 65.00,
                'is_active' => 1
            ));
            
            // Reload data
            $loyalty_cards = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, plan_name as name, client_limit, price, wc_product_id 
                    FROM $table 
                    WHERE plan_type = %s AND is_active = 1 
                    ORDER BY price ASC",
                    'loyalty_cards'
                ),
                ARRAY_A
            );
        }
        
        if (empty($ticket_bundles)) {
            $wpdb->insert($table, array(
                'plan_name' => 'Starter Bundle - 50 Tickets',
                'plan_type' => 'tickets',
                'client_limit' => 0,
                'ticket_count' => 50,
                'price' => 10.00,
                'is_active' => 1
            ));
            $wpdb->insert($table, array(
                'plan_name' => 'Standard Bundle - 100 Tickets',
                'plan_type' => 'tickets',
                'client_limit' => 0,
                'ticket_count' => 100,
                'price' => 18.00,
                'is_active' => 1
            ));
            $wpdb->insert($table, array(
                'plan_name' => 'Premium Bundle - 200 Tickets',
                'plan_type' => 'tickets',
                'client_limit' => 0,
                'ticket_count' => 200,
                'price' => 32.00,
                'is_active' => 1
            ));
            
            // Reload data
            $ticket_bundles = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, plan_name as name, ticket_count as ticket_limit, price, wc_product_id 
                    FROM $table 
                    WHERE plan_type = %s AND is_active = 1 
                    ORDER BY price ASC",
                    'tickets'
                ),
                ARRAY_A
            );
        }
        
        ?>
        <div class="wrap lcp-price-control">
            <h1 style="color: #FE7AC1;">
                <span class="dashicons dashicons-tag" style="font-size: 32px;"></span>
                <?php _e('Package Control Management', 'loyalty-card-pro'); ?>
            </h1>
            <p class="description"><?php _e('Manage packages for Digital Loyalty Cards and Scratch-Off Surprise Tickets', 'loyalty-card-pro'); ?></p>
            
            <!-- Tab Navigation -->
            <div class="lcp-tab-navigation" style="margin: 25px 0 0 0; border-bottom: 2px solid #FFEFF7;">
                <button class="lcp-tab-button active" onclick="lcpSwitchTab('loyalty-cards')" data-tab="loyalty-cards" style="background: none; border: none; padding: 15px 30px; font-size: 16px; font-weight: 600; color: #666; cursor: pointer; border-bottom: 3px solid transparent; transition: all 0.3s;">
                    <span class="dashicons dashicons-awards" style="margin-right: 8px;"></span>
                    <?php _e('Digital Loyalty Card', 'loyalty-card-pro'); ?>
                </button>
                <button class="lcp-tab-button" onclick="lcpSwitchTab('scratch-tickets')" data-tab="scratch-tickets" style="background: none; border: none; padding: 15px 30px; font-size: 16px; font-weight: 600; color: #666; cursor: pointer; border-bottom: 3px solid transparent; transition: all 0.3s;">
                    <span class="dashicons dashicons-tickets-alt" style="margin-right: 8px;"></span>
                    <?php _e('Scratch-Off Surprise Tickets', 'loyalty-card-pro'); ?>
                </button>
                <button class="lcp-tab-button" onclick="lcpSwitchTab('user-purchases')" data-tab="user-purchases" style="background: none; border: none; padding: 15px 30px; font-size: 16px; font-weight: 600; color: #666; cursor: pointer; border-bottom: 3px solid transparent; transition: all 0.3s;">
                    <span class="dashicons dashicons-cart" style="margin-right: 8px;"></span>
                    <?php _e('User Purchases', 'loyalty-card-pro'); ?>
                </button>
            </div>
            
            <!-- Tab Content: Digital Loyalty Card Section -->
            <div id="lcp-tab-loyalty-cards" class="lcp-tab-content" style="display: block; padding-top: 30px;">
            <div class="lcp-price-section" style="background: white; padding: 25px; margin-bottom: 30px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h2 style="color: #FE7AC1; margin-top: 0;">
                    <span class="dashicons dashicons-awards"></span>
                    <?php _e('Digital Loyalty Card', 'loyalty-card-pro'); ?>
                </h2>
                <p style="color: #666; margin-bottom: 25px;"><?php _e('Create and manage digital loyalty card plans with client limits and pricing', 'loyalty-card-pro'); ?></p>
                
                <!-- Create/Edit Form -->
                <div class="lcp-price-form" style="background: #FFEFF7; padding: 20px; border-radius: 6px; margin-bottom: 25px;">
                    <h3 style="margin-top: 0;"><?php _e('Create/Edit Digital Loyalty Card Plan', 'loyalty-card-pro'); ?></h3>
                    <input type="hidden" id="lcp_loyalty_plan_id" value="">
                    <table class="form-table">
                        <tr>
                            <th><label for="lcp_loyalty_plan_name"><?php _e('Plan Name', 'loyalty-card-pro'); ?></label></th>
                            <td><input type="text" id="lcp_loyalty_plan_name" class="regular-text" placeholder="e.g., Premium Card - 50 Clients" value=""></td>
                        </tr>
                        <tr>
                            <th><label for="lcp_loyalty_client_limit"><?php _e('Client Limit', 'loyalty-card-pro'); ?></label></th>
                            <td>
                                <input type="number" id="lcp_loyalty_client_limit" class="regular-text" placeholder="20" value="" min="1" step="1">
                                <p class="description"><?php _e('Number of clients beauticians can manage with this plan', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="lcp_loyalty_price"><?php _e('Price ($)', 'loyalty-card-pro'); ?></label></th>
                            <td>
                                <input type="number" id="lcp_loyalty_price" class="regular-text" placeholder="15.00" value="" min="0" step="0.01">
                                <p class="description"><?php _e('Price in USD (WooCommerce product will be auto-created)', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <p>
                        <button type="button" id="lcp_save_loyalty_plan" class="button button-primary button-large" style="background: #FE7AC1; border-color: #FE7AC1;">
                            <span class="dashicons dashicons-saved" style="margin-top: 3px;"></span> 
                            <?php _e('Save Plan', 'loyalty-card-pro'); ?>
                        </button>
                        <button type="button" class="button button-large" onclick="lcpClearLoyaltyForm()">
                            <?php _e('Clear', 'loyalty-card-pro'); ?>
                        </button>
                    </p>
                </div>
                
                <!-- Existing Plans Table -->
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="margin: 0;"><?php _e('Existing Plans', 'loyalty-card-pro'); ?></h3>
                    <?php
                    // Check if there are packages without WooCommerce products
                    $packages_without_products = 0;
                    foreach ($loyalty_cards as $card) {
                        if (empty($card['wc_product_id']) || $card['wc_product_id'] == 0) {
                            $packages_without_products++;
                        }
                    }
                    
                    if ($packages_without_products > 0 && class_exists('WooCommerce')): ?>
                        <button type="button" class="button button-primary" onclick="lcpBulkCreateProducts('loyalty')" style="background: #FF9800; border-color: #FF9800;">
                            <span class="dashicons dashicons-products" style="margin-top: 3px;"></span>
                            <?php printf(
                                _n(
                                    'Create WC Product (%d missing)',
                                    'Create WC Products (%d missing)',
                                    $packages_without_products,
                                    'loyalty-card-pro'
                                ),
                                $packages_without_products
                            ); ?>
                        </button>
                    <?php endif; ?>
                </div>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr style="background: #FFEFF7;">
                            <th style="width: 35%;"><?php _e('Plan Name', 'loyalty-card-pro'); ?></th>
                            <th style="width: 15%;"><?php _e('Client Limit', 'loyalty-card-pro'); ?></th>
                            <th style="width: 15%;"><?php _e('Price', 'loyalty-card-pro'); ?></th>
                            <th style="width: 20%;"><?php _e('WC Product ID', 'loyalty-card-pro'); ?></th>
                            <th style="width: 15%;"><?php _e('Action', 'loyalty-card-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="lcp_loyalty_plans_table">
                        <?php if (!empty($loyalty_cards)): foreach ($loyalty_cards as $card) : ?>
                            <tr>
                                <td><strong><?php echo esc_html($card['name']); ?></strong></td>
                                <td>
                                    <span style="background: #FE7AC1; color: white; padding: 4px 12px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($card['client_limit']); ?> clients
                                    </span>
                                </td>
                                <td><strong style="color: #FE7AC1; font-size: 16px;">$<?php echo number_format($card['price'], 2); ?></strong></td>
                                <td>
                                    <?php if (!empty($card['wc_product_id'])): ?>
                                        <span style="background: #4CAF50; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                            <span class="dashicons dashicons-yes-alt" style="font-size: 14px; vertical-align: middle;"></span> 
                                            ID: <?php echo $card['wc_product_id']; ?>
                                        </span>
                                        <a href="<?php echo admin_url('post.php?post=' . $card['wc_product_id'] . '&action=edit'); ?>" 
                                           target="_blank" 
                                           style="margin-left: 5px; text-decoration: none;" 
                                           title="<?php _e('View in WooCommerce', 'loyalty-card-pro'); ?>">
                                            <span class="dashicons dashicons-external" style="font-size: 16px;"></span>
                                        </a>
                                    <?php else: ?>
                                        <span style="background: #ff9800; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                            <?php _e('Not Created', 'loyalty-card-pro'); ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button type="button" class="button button-small" 
                                            onclick="lcpEditLoyaltyPlan(<?php echo $card['id']; ?>, '<?php echo esc_js($card['name']); ?>', <?php echo $card['client_limit']; ?>, <?php echo $card['price']; ?>)" 
                                            style="color: #FE7AC1;">
                                        <?php _e('Edit', 'loyalty-card-pro'); ?>
                                    </button>
                                    <button type="button" class="button button-small button-link-delete" 
                                            onclick="lcpDeleteLoyaltyPlan(<?php echo $card['id']; ?>)" 
                                            style="color: #dc3232;">
                                        <?php _e('Delete', 'loyalty-card-pro'); ?>
                                    </button>
                                </td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr>
                                <td colspan="4" style="text-align: center; color: #666;">
                                    <?php _e('No loyalty card plans found. Create one above!', 'loyalty-card-pro'); ?>
                                </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            </div>
            
            <!-- Tab Content: Scratch-Off Surprise Tickets Section -->
            <div id="lcp-tab-scratch-tickets" class="lcp-tab-content" style="display: none; padding-top: 30px;">
            <div class="lcp-price-section" style="background: white; padding: 25px; margin-bottom: 30px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h2 style="color: #FE7AC1; margin-top: 0;">
                    <span class="dashicons dashicons-tickets-alt"></span>
                    <?php _e('Scratch-Off Surprise Tickets', 'loyalty-card-pro'); ?>
                </h2>
                <p style="color: #666; margin-bottom: 25px;"><?php _e('Create and manage scratch-off ticket bundles with ticket limits and pricing', 'loyalty-card-pro'); ?></p>
                
                <!-- Create/Edit Form -->
                <div class="lcp-price-form" style="background: #FFEFF7; padding: 20px; border-radius: 6px; margin-bottom: 25px;">
                    <h3 style="margin-top: 0;"><?php _e('Create/Edit Scratch-Off Ticket Bundle', 'loyalty-card-pro'); ?></h3>
                    <input type="hidden" id="lcp_ticket_bundle_id" value="">
                    <table class="form-table">
                        <tr>
                            <th><label for="lcp_ticket_bundle_name"><?php _e('Bundle Name', 'loyalty-card-pro'); ?></label></th>
                            <td><input type="text" id="lcp_ticket_bundle_name" class="regular-text" placeholder="e.g., Standard Bundle - 100 Tickets" value=""></td>
                        </tr>
                        <tr>
                            <th><label for="lcp_ticket_limit"><?php _e('Ticket Limit', 'loyalty-card-pro'); ?></label></th>
                            <td>
                                <input type="number" id="lcp_ticket_limit" class="regular-text" placeholder="50" value="" min="1" step="1">
                                <p class="description"><?php _e('Number of scratch-off tickets in this bundle', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="lcp_ticket_price"><?php _e('Price ($)', 'loyalty-card-pro'); ?></label></th>
                            <td>
                                <input type="number" id="lcp_ticket_price" class="regular-text" placeholder="10.00" value="" min="0" step="0.01">
                                <p class="description"><?php _e('Price in USD (WooCommerce product will be auto-created)', 'loyalty-card-pro'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <p>
                        <button type="button" id="lcp_save_ticket_bundle" class="button button-primary button-large" style="background: #FE7AC1; border-color: #FE7AC1;">
                            <span class="dashicons dashicons-saved" style="margin-top: 3px;"></span> 
                            <?php _e('Save Bundle', 'loyalty-card-pro'); ?>
                        </button>
                        <button type="button" class="button button-large" onclick="lcpClearTicketForm()">
                            <?php _e('Clear', 'loyalty-card-pro'); ?>
                        </button>
                    </p>
            </div>
            
                <!-- Existing Bundles Table -->
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="margin: 0;"><?php _e('Existing Bundles', 'loyalty-card-pro'); ?></h3>
                    <?php
                    // Check if there are bundles without WooCommerce products
                    $bundles_without_products = 0;
                    foreach ($ticket_bundles as $bundle) {
                        if (empty($bundle['wc_product_id']) || $bundle['wc_product_id'] == 0) {
                            $bundles_without_products++;
                        }
                    }
                    
                    if ($bundles_without_products > 0 && class_exists('WooCommerce')): ?>
                        <button type="button" class="button button-primary" onclick="lcpBulkCreateProducts('tickets')" style="background: #FF9800; border-color: #FF9800;">
                            <span class="dashicons dashicons-products" style="margin-top: 3px;"></span>
                            <?php printf(
                                _n(
                                    'Create WC Product (%d missing)',
                                    'Create WC Products (%d missing)',
                                    $bundles_without_products,
                                    'loyalty-card-pro'
                                ),
                                $bundles_without_products
                            ); ?>
                        </button>
                    <?php endif; ?>
                </div>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                        <tr style="background: #FFEFF7;">
                            <th style="width: 35%;"><?php _e('Bundle Name', 'loyalty-card-pro'); ?></th>
                            <th style="width: 15%;"><?php _e('Ticket Limit', 'loyalty-card-pro'); ?></th>
                            <th style="width: 15%;"><?php _e('Price', 'loyalty-card-pro'); ?></th>
                            <th style="width: 20%;"><?php _e('WC Product ID', 'loyalty-card-pro'); ?></th>
                            <th style="width: 15%;"><?php _e('Action', 'loyalty-card-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="lcp_ticket_bundles_table">
                        <?php if (!empty($ticket_bundles)): foreach ($ticket_bundles as $bundle) : ?>
                            <tr>
                                <td><strong><?php echo esc_html($bundle['name']); ?></strong></td>
                                <td>
                                    <span style="background: #FE7AC1; color: white; padding: 4px 12px; border-radius: 12px; font-weight: 600;">
                                        <?php echo number_format($bundle['ticket_limit']); ?> tickets
                                    </span>
                                </td>
                                <td><strong style="color: #FE7AC1; font-size: 16px;">$<?php echo number_format($bundle['price'], 2); ?></strong></td>
                                <td>
                                    <?php if (!empty($bundle['wc_product_id'])): ?>
                                        <span style="background: #4CAF50; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                            <span class="dashicons dashicons-yes-alt" style="font-size: 14px; vertical-align: middle;"></span> 
                                            ID: <?php echo $bundle['wc_product_id']; ?>
                                        </span>
                                        <a href="<?php echo admin_url('post.php?post=' . $bundle['wc_product_id'] . '&action=edit'); ?>" 
                                           target="_blank" 
                                           style="margin-left: 5px; text-decoration: none;" 
                                           title="<?php _e('View in WooCommerce', 'loyalty-card-pro'); ?>">
                                            <span class="dashicons dashicons-external" style="font-size: 16px;"></span>
                                        </a>
                                    <?php else: ?>
                                        <span style="background: #ff9800; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                            <?php _e('Not Created', 'loyalty-card-pro'); ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button type="button" class="button button-small" 
                                            onclick="lcpEditTicketBundle(<?php echo $bundle['id']; ?>, '<?php echo esc_js($bundle['name']); ?>', <?php echo $bundle['ticket_limit']; ?>, <?php echo $bundle['price']; ?>)" 
                                            style="color: #FE7AC1;">
                                        <?php _e('Edit', 'loyalty-card-pro'); ?>
                                    </button>
                                    <button type="button" class="button button-small button-link-delete" 
                                            onclick="lcpDeleteTicketBundle(<?php echo $bundle['id']; ?>)" 
                                            style="color: #dc3232;">
                                        <?php _e('Delete', 'loyalty-card-pro'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; else: ?>
                            <tr>
                                <td colspan="4" style="text-align: center; color: #666;">
                                    <?php _e('No ticket bundles found. Create one above!', 'loyalty-card-pro'); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            </div>
            
            <!-- Tab Content: User Purchases Section -->
            <div id="lcp-tab-user-purchases" class="lcp-tab-content" style="display: none; padding-top: 30px;">
            <div class="lcp-price-section" style="background: white; padding: 25px; margin-bottom: 30px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <h2 style="color: #FE7AC1; margin-top: 0;">
                    <span class="dashicons dashicons-cart"></span>
                    <?php _e('User Purchases History', 'loyalty-card-pro'); ?>
                </h2>
                <p style="color: #666; margin-bottom: 25px;"><?php _e('View all users who purchased Digital Loyalty Cards and Scratch-Off Surprise Tickets', 'loyalty-card-pro'); ?></p>
                
                <?php
                // Get real purchase data from database
                global $wpdb;
                $payments_table = $wpdb->prefix . 'lcp_payments';
                $plans_table = $wpdb->prefix . 'lcp_pricing_plans';
                
                // Get all completed payments with user and plan details
                $purchases_query = "
                    SELECT 
                        p.id,
                        p.user_id,
                        p.amount,
                        p.payment_date,
                        p.status,
                        pl.plan_type,
                        pl.client_limit,
                        pl.ticket_count,
                        u.display_name as user_name,
                        u.user_email as user_email
                    FROM $payments_table p
                    LEFT JOIN $plans_table pl ON p.plan_id = pl.id
                    LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID
                    WHERE p.status = 'completed'
                    ORDER BY p.payment_date DESC
                ";
                
                $all_purchases = $wpdb->get_results($purchases_query, ARRAY_A);
                
                // Group purchases by user
                $grouped_purchases = array();
                foreach ($all_purchases as $payment) {
                    $user_id = $payment['user_id'];
                    
                    if (!isset($grouped_purchases[$user_id])) {
                        $grouped_purchases[$user_id] = array(
                            'user' => $payment['user_name'] ?: 'Unknown User',
                            'email' => $payment['user_email'] ?: 'N/A',
                            'loyalty_cards' => 0,
                            'loyalty_price' => 0,
                            'tickets' => 0,
                            'tickets_price' => 0,
                            'total' => 0,
                            'date' => $payment['payment_date'],
                            'status' => $payment['status']
                        );
                    }
                    
                    // Aggregate data
                    if ($payment['plan_type'] == 'loyalty_cards') {
                        $grouped_purchases[$user_id]['loyalty_cards']++;
                        $grouped_purchases[$user_id]['loyalty_price'] += floatval($payment['amount']);
                    } elseif ($payment['plan_type'] == 'tickets') {
                        $grouped_purchases[$user_id]['tickets'] += intval($payment['ticket_count']);
                        $grouped_purchases[$user_id]['tickets_price'] += floatval($payment['amount']);
                    }
                    
                    $grouped_purchases[$user_id]['total'] += floatval($payment['amount']);
                    
                    // Use the most recent payment date
                    if (strtotime($payment['payment_date']) > strtotime($grouped_purchases[$user_id]['date'])) {
                        $grouped_purchases[$user_id]['date'] = $payment['payment_date'];
                    }
                }
                
                // Convert to indexed array and sort by date
                $dummy_purchases = array_values($grouped_purchases);
                usort($dummy_purchases, function($a, $b) {
                    return strtotime($b['date']) - strtotime($a['date']);
                });
                
                // Calculate totals
                $total_loyalty_revenue = 0;
                $total_tickets_revenue = 0;
                $grand_total = 0;
                
                if (!empty($dummy_purchases)) {
                    foreach ($dummy_purchases as $purchase) {
                        $total_loyalty_revenue += floatval($purchase['loyalty_price']);
                        $total_tickets_revenue += floatval($purchase['tickets_price']);
                        $grand_total += floatval($purchase['total']);
                    }
                }
                ?>
                
                <!-- Summary Cards -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 30px;">
                    <div style="background: linear-gradient(135deg, #FE7AC1 0%, #ff94d1 100%); color: white; padding: 20px; border-radius: 10px; text-align: center;">
                        <p style="margin: 0; opacity: 0.9; font-size: 14px;"><?php _e('Total Revenue', 'loyalty-card-pro'); ?></p>
                        <h3 style="margin: 10px 0 0 0; font-size: 28px; font-weight: 700; color: white;">$<?php echo number_format($grand_total, 2); ?></h3>
                    </div>
                    <div style="background: white; border: 2px solid #FFEFF7; padding: 20px; border-radius: 10px; text-align: center;">
                        <p style="margin: 0; color: #666; font-size: 14px;"><?php _e('Loyalty Cards Revenue', 'loyalty-card-pro'); ?></p>
                        <h3 style="margin: 10px 0 0 0; font-size: 28px; font-weight: 700; color: #FE7AC1;">$<?php echo number_format($total_loyalty_revenue, 2); ?></h3>
                    </div>
                    <div style="background: white; border: 2px solid #FFEFF7; padding: 20px; border-radius: 10px; text-align: center;">
                        <p style="margin: 0; color: #666; font-size: 14px;"><?php _e('Tickets Revenue', 'loyalty-card-pro'); ?></p>
                        <h3 style="margin: 10px 0 0 0; font-size: 28px; font-weight: 700; color: #FE7AC1;">$<?php echo number_format($total_tickets_revenue, 2); ?></h3>
                    </div>
                    <div style="background: white; border: 2px solid #FFEFF7; padding: 20px; border-radius: 10px; text-align: center;">
                        <p style="margin: 0; color: #666; font-size: 14px;"><?php _e('Total Purchases', 'loyalty-card-pro'); ?></p>
                        <h3 style="margin: 10px 0 0 0; font-size: 28px; font-weight: 700; color: #FE7AC1;"><?php echo count($dummy_purchases); ?></h3>
                    </div>
                </div>
                
                <!-- Purchases Table -->
                <h3><?php _e('Purchase History', 'loyalty-card-pro'); ?></h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr style="background: #FFEFF7;">
                            <th style="width: 20%;"><?php _e('User', 'loyalty-card-pro'); ?></th>
                            <th style="width: 20%;"><?php _e('Email', 'loyalty-card-pro'); ?></th>
                            <th style="width: 15%;"><?php _e('Loyalty Cards', 'loyalty-card-pro'); ?></th>
                            <th style="width: 15%;"><?php _e('Tickets', 'loyalty-card-pro'); ?></th>
                            <th style="width: 10%;"><?php _e('Total', 'loyalty-card-pro'); ?></th>
                            <th style="width: 10%;"><?php _e('Date', 'loyalty-card-pro'); ?></th>
                            <th style="width: 10%;"><?php _e('Status', 'loyalty-card-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                        <?php if (!empty($dummy_purchases)) : ?>
                            <?php foreach ($dummy_purchases as $purchase) : ?>
                                <tr>
                                    <td><strong><?php echo esc_html($purchase['user']); ?></strong></td>
                                    <td><?php echo esc_html($purchase['email']); ?></td>
                                    <td>
                                        <?php if ($purchase['loyalty_cards'] > 0) : ?>
                                            <span style="display: block; font-weight: 600; color: #333;">
                                                <?php echo $purchase['loyalty_cards']; ?> <?php _e('plan(s)', 'loyalty-card-pro'); ?>
                                            </span>
                                            <span style="display: block; font-size: 12px; color: #FE7AC1;">
                                                $<?php echo number_format($purchase['loyalty_price'], 2); ?>
                                            </span>
                    <?php else : ?>
                                            <span style="color: #999;">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($purchase['tickets'] > 0) : ?>
                                            <span style="display: block; font-weight: 600; color: #333;">
                                                <?php echo number_format($purchase['tickets']); ?> <?php _e('tickets', 'loyalty-card-pro'); ?>
                                            </span>
                                            <span style="display: block; font-size: 12px; color: #FE7AC1;">
                                                $<?php echo number_format($purchase['tickets_price'], 2); ?>
                                            </span>
                                    <?php else : ?>
                                            <span style="color: #999;">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                        <strong style="color: #FE7AC1; font-size: 16px;">
                                            $<?php echo number_format($purchase['total'], 2); ?>
                                        </strong>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($purchase['date'])); ?></td>
                                    <td>
                                        <?php
                                        $status = isset($purchase['status']) ? $purchase['status'] : 'completed';
                                        $status_colors = array(
                                            'completed' => '#4CAF50',
                                            'pending' => '#FF9800',
                                            'failed' => '#f44336'
                                        );
                                        $status_color = isset($status_colors[$status]) ? $status_colors[$status] : '#4CAF50';
                                        ?>
                                        <span style="background: <?php echo $status_color; ?>; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600; text-transform: capitalize;">
                                            <?php echo esc_html(ucfirst($status)); ?>
                                        </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 40px; color: #999;">
                                    <span class="dashicons dashicons-cart" style="font-size: 48px; color: #ddd; margin-bottom: 10px;"></span>
                                    <p style="font-size: 16px; margin: 10px 0 0 0;"><?php _e('No purchases yet', 'loyalty-card-pro'); ?></p>
                                    <p style="font-size: 13px; margin: 5px 0 0 0;"><?php _e('Purchase history will appear here when users buy plans.', 'loyalty-card-pro'); ?></p>
                                </td>
                            </tr>
                    <?php endif; ?>
                </tbody>
                    <tfoot>
                        <tr style="background: #FFEFF7; font-weight: 600;">
                            <td colspan="2"><strong><?php _e('TOTAL', 'loyalty-card-pro'); ?></strong></td>
                            <td>
                                <strong style="color: #FE7AC1;">
                                    $<?php echo number_format($total_loyalty_revenue, 2); ?>
                                </strong>
                            </td>
                            <td>
                                <strong style="color: #FE7AC1;">
                                    $<?php echo number_format($total_tickets_revenue, 2); ?>
                                </strong>
                            </td>
                            <td>
                                <strong style="color: #FE7AC1; font-size: 18px;">
                                    $<?php echo number_format($grand_total, 2); ?>
                                </strong>
                            </td>
                            <td colspan="2"></td>
                        </tr>
                    </tfoot>
            </table>
        </div>
            </div>
            
            <!-- Info Notice -->
            <div class="notice notice-info" style="border-left-color: #FE7AC1; margin-top: 30px;">
                <p>
                    <strong><?php _e('Note:', 'loyalty-card-pro'); ?></strong> 
                    <?php _e('All values are editable from the UI. This is currently a dummy interface with no backend logic.', 'loyalty-card-pro'); ?>
                </p>
            </div>
        </div>
        
        <style>
        .lcp-tab-button {
            position: relative;
            background: none !important;
            box-shadow: none !important;
        }
        .lcp-tab-button:hover {
            color: #FE7AC1 !important;
        }
        .lcp-tab-button.active {
            color: #FE7AC1 !important;
            border-bottom-color: #FE7AC1 !important;
        }
        .lcp-tab-content {
            animation: fadeIn 0.3s ease-in;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        </style>
        
        <script>
        function lcpSwitchTab(tabName) {
            // Hide all tab contents
            var tabContents = document.querySelectorAll('.lcp-tab-content');
            tabContents.forEach(function(content) {
                content.style.display = 'none';
            });
            
            // Remove active class from all tab buttons
            var tabButtons = document.querySelectorAll('.lcp-tab-button');
            tabButtons.forEach(function(button) {
                button.classList.remove('active');
            });
            
            // Show selected tab content
            var selectedTab = document.getElementById('lcp-tab-' + tabName);
            if (selectedTab) {
                selectedTab.style.display = 'block';
            }
            
            // Add active class to clicked button
            var activeButton = document.querySelector('.lcp-tab-button[data-tab="' + tabName + '"]');
            if (activeButton) {
                activeButton.classList.add('active');
            }
        }
        
        // Show notice message
        function lcpShowNotice(message, type) {
            var noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
            var notice = jQuery('<div class="notice ' + noticeClass + ' is-dismissible" style="margin: 20px 0;"><p>' + message + '</p></div>');
            jQuery('.lcp-price-control h1').after(notice);
            
            // Auto dismiss after 5 seconds
            setTimeout(function() {
                notice.fadeOut(300, function() {
                    jQuery(this).remove();
                });
            }, 5000);
            
            // Scroll to top to see notice
            jQuery('html, body').animate({scrollTop: 0}, 300);
        }
        
        // Create loyalty card table row
        function lcpCreateLoyaltyRow(plan) {
            var row = '<tr>' +
                '<td><strong>' + plan.name + '</strong></td>' +
                '<td><span style="background: #FE7AC1; color: white; padding: 4px 12px; border-radius: 12px; font-weight: 600;">' + 
                Number(plan.client_limit).toLocaleString() + ' clients</span></td>' +
                '<td><strong style="color: #FE7AC1; font-size: 16px;">$' + Number(plan.price).toFixed(2) + '</strong></td>' +
                '<td>' +
                (plan.wc_product_id ? 
                    '<span style="background: #4CAF50; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;">' +
                    '<span class="dashicons dashicons-yes-alt" style="font-size: 14px; vertical-align: middle;"></span> ID: ' + plan.wc_product_id + '</span>' +
                    '<a href="<?php echo admin_url('post.php?post='); ?>' + plan.wc_product_id + '&action=edit" target="_blank" style="margin-left: 5px; text-decoration: none;">' +
                    '<span class="dashicons dashicons-external" style="font-size: 16px;"></span></a>' :
                    '<span style="background: #ff9800; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;">Auto-Creating...</span>'
                ) +
                '</td>' +
                '<td>' +
                '<button type="button" class="button button-small" onclick="lcpEditLoyaltyPlan(' + plan.id + ', \'' + 
                plan.name.replace(/'/g, "\\'") + '\', ' + plan.client_limit + ', ' + plan.price + ')" style="color: #FE7AC1;">' +
                '<?php echo esc_js(__('Edit', 'loyalty-card-pro')); ?></button> ' +
                '<button type="button" class="button button-small button-link-delete" onclick="lcpDeleteLoyaltyPlan(' + plan.id + ')" style="color: #dc3232;">' +
                '<?php echo esc_js(__('Delete', 'loyalty-card-pro')); ?></button>' +
                '</td>' +
                '</tr>';
            return row;
        }
        
        // Create ticket bundle table row
        function lcpCreateTicketRow(bundle) {
            var row = '<tr>' +
                '<td><strong>' + bundle.name + '</strong></td>' +
                '<td><span style="background: #FE7AC1; color: white; padding: 4px 12px; border-radius: 12px; font-weight: 600;">' + 
                Number(bundle.ticket_limit).toLocaleString() + ' tickets</span></td>' +
                '<td><strong style="color: #FE7AC1; font-size: 16px;">$' + Number(bundle.price).toFixed(2) + '</strong></td>' +
                '<td>' +
                (bundle.wc_product_id ? 
                    '<span style="background: #4CAF50; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;">' +
                    '<span class="dashicons dashicons-yes-alt" style="font-size: 14px; vertical-align: middle;"></span> ID: ' + bundle.wc_product_id + '</span>' +
                    '<a href="<?php echo admin_url('post.php?post='); ?>' + bundle.wc_product_id + '&action=edit" target="_blank" style="margin-left: 5px; text-decoration: none;">' +
                    '<span class="dashicons dashicons-external" style="font-size: 16px;"></span></a>' :
                    '<span style="background: #ff9800; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;">Auto-Creating...</span>'
                ) +
                '</td>' +
                '<td>' +
                '<button type="button" class="button button-small" onclick="lcpEditTicketBundle(' + bundle.id + ', \'' + 
                bundle.name.replace(/'/g, "\\'") + '\', ' + bundle.ticket_limit + ', ' + bundle.price + ')" style="color: #FE7AC1;">' +
                '<?php echo esc_js(__('Edit', 'loyalty-card-pro')); ?></button> ' +
                '<button type="button" class="button button-small button-link-delete" onclick="lcpDeleteTicketBundle(' + bundle.id + ')" style="color: #dc3232;">' +
                '<?php echo esc_js(__('Delete', 'loyalty-card-pro')); ?></button>' +
                '</td>' +
                '</tr>';
            return row;
        }
        
        // Clear loyalty card form
        function lcpClearLoyaltyForm() {
            jQuery('#lcp_loyalty_plan_id').val('');
            jQuery('#lcp_loyalty_plan_name').val('');
            jQuery('#lcp_loyalty_client_limit').val('');
            jQuery('#lcp_loyalty_price').val('');
            jQuery('#lcp_save_loyalty_plan').html('<span class="dashicons dashicons-saved" style="margin-top: 3px;"></span> <?php echo esc_js(__('Save Plan', 'loyalty-card-pro')); ?>');
        }
        
        // Clear ticket bundle form
        function lcpClearTicketForm() {
            jQuery('#lcp_ticket_bundle_id').val('');
            jQuery('#lcp_ticket_bundle_name').val('');
            jQuery('#lcp_ticket_limit').val('');
            jQuery('#lcp_ticket_price').val('');
            jQuery('#lcp_save_ticket_bundle').html('<span class="dashicons dashicons-saved" style="margin-top: 3px;"></span> <?php echo esc_js(__('Save Bundle', 'loyalty-card-pro')); ?>');
        }
        
        // Edit loyalty plan
        function lcpEditLoyaltyPlan(id, name, clientLimit, price) {
            jQuery('#lcp_loyalty_plan_id').val(id);
            jQuery('#lcp_loyalty_plan_name').val(name);
            jQuery('#lcp_loyalty_client_limit').val(clientLimit);
            jQuery('#lcp_loyalty_price').val(price);
            jQuery('#lcp_save_loyalty_plan').html('<span class="dashicons dashicons-update" style="margin-top: 3px;"></span> <?php echo esc_js(__('Update Plan', 'loyalty-card-pro')); ?>');
            jQuery('html, body').animate({scrollTop: 0}, 500);
        }
        
        // Edit ticket bundle
        function lcpEditTicketBundle(id, name, ticketLimit, price) {
            jQuery('#lcp_ticket_bundle_id').val(id);
            jQuery('#lcp_ticket_bundle_name').val(name);
            jQuery('#lcp_ticket_limit').val(ticketLimit);
            jQuery('#lcp_ticket_price').val(price);
            jQuery('#lcp_save_ticket_bundle').html('<span class="dashicons dashicons-update" style="margin-top: 3px;"></span> <?php echo esc_js(__('Update Bundle', 'loyalty-card-pro')); ?>');
            jQuery('html, body').animate({scrollTop: 0}, 500);
        }
        
        // Delete loyalty plan
        function lcpDeleteLoyaltyPlan(id) {
            if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this plan?', 'loyalty-card-pro')); ?>')) {
                return;
            }
            
            jQuery.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'lcp_delete_plan',
                    plan_id: id,
                    nonce: '<?php echo wp_create_nonce('lcp_package_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        // Remove row from table with animation
                        var row = jQuery('#lcp_loyalty_plans_table tr').filter(function() {
                            return jQuery(this).find('button[onclick*="' + id + '"]').length > 0;
                        });
                        
                        row.fadeOut(300, function() {
                            jQuery(this).remove();
                            
                            // If no rows left, show empty message
                            if (jQuery('#lcp_loyalty_plans_table tr').length === 0) {
                                jQuery('#lcp_loyalty_plans_table').html(
                                    '<tr><td colspan="4" style="text-align: center; color: #666;">' +
                                    '<?php echo esc_js(__('No loyalty card plans found. Create one above!', 'loyalty-card-pro')); ?>' +
                                    '</td></tr>'
                                );
                            }
                        });
                        
                        lcpShowNotice(response.data.message, 'success');
                    } else {
                        lcpShowNotice(response.data.message || '<?php echo esc_js(__('Error deleting plan', 'loyalty-card-pro')); ?>', 'error');
                    }
                },
                error: function() {
                    lcpShowNotice('<?php echo esc_js(__('Error deleting plan', 'loyalty-card-pro')); ?>', 'error');
                }
            });
        }
        
        // Delete ticket bundle
        function lcpDeleteTicketBundle(id) {
            if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this bundle?', 'loyalty-card-pro')); ?>')) {
                return;
            }
            
            jQuery.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'lcp_delete_plan',
                    plan_id: id,
                    nonce: '<?php echo wp_create_nonce('lcp_package_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        // Remove row from table with animation
                        var row = jQuery('#lcp_ticket_bundles_table tr').filter(function() {
                            return jQuery(this).find('button[onclick*="' + id + '"]').length > 0;
                        });
                        
                        row.fadeOut(300, function() {
                            jQuery(this).remove();
                            
                            // If no rows left, show empty message
                            if (jQuery('#lcp_ticket_bundles_table tr').length === 0) {
                                jQuery('#lcp_ticket_bundles_table').html(
                                    '<tr><td colspan="4" style="text-align: center; color: #666;">' +
                                    '<?php echo esc_js(__('No ticket bundles found. Create one above!', 'loyalty-card-pro')); ?>' +
                                    '</td></tr>'
                                );
                            }
                        });
                        
                        lcpShowNotice(response.data.message, 'success');
                    } else {
                        lcpShowNotice(response.data.message || '<?php echo esc_js(__('Error deleting bundle', 'loyalty-card-pro')); ?>', 'error');
                    }
                },
                error: function() {
                    lcpShowNotice('<?php echo esc_js(__('Error deleting bundle', 'loyalty-card-pro')); ?>', 'error');
                }
            });
        }
        
        // Bulk create WooCommerce products for packages without them
        function lcpBulkCreateProducts(type) {
            if (!confirm('<?php echo esc_js(__('This will create WooCommerce products for all packages that don\'t have them. Continue?', 'loyalty-card-pro')); ?>')) {
                return;
            }
            
            var button = event.target.closest('button');
            var originalHtml = jQuery(button).html();
            jQuery(button).prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 1s linear infinite;"></span> <?php echo esc_js(__('Creating products...', 'loyalty-card-pro')); ?>');
            
            jQuery.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'lcp_create_missing_products',
                    nonce: '<?php echo wp_create_nonce('lcp_create_products'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        lcpShowNotice(response.data.message, 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        lcpShowNotice(response.data.message || '<?php echo esc_js(__('Error creating products', 'loyalty-card-pro')); ?>', 'error');
                        jQuery(button).prop('disabled', false).html(originalHtml);
                    }
                },
                error: function() {
                    lcpShowNotice('<?php echo esc_js(__('Error creating products', 'loyalty-card-pro')); ?>', 'error');
                    jQuery(button).prop('disabled', false).html(originalHtml);
                }
            });
        }
        
        // Initialize tabs on page load
        jQuery(document).ready(function($) {
            // Ensure first tab is active by default
            lcpSwitchTab('loyalty-cards');
            
            // Save loyalty plan
            $('#lcp_save_loyalty_plan').on('click', function() {
                var planId = $('#lcp_loyalty_plan_id').val();
                var planName = $('#lcp_loyalty_plan_name').val();
                var clientLimit = $('#lcp_loyalty_client_limit').val();
                var price = $('#lcp_loyalty_price').val();
                
                if (!planName || !clientLimit || !price) {
                    lcpShowNotice('<?php echo esc_js(__('Please fill in all fields', 'loyalty-card-pro')); ?>', 'error');
                    return;
                }
                
                var button = $(this);
                var originalHtml = button.html();
                button.prop('disabled', true).text('<?php echo esc_js(__('Creating WooCommerce product...', 'loyalty-card-pro')); ?>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'lcp_save_loyalty_plan',
                        plan_id: planId,
                        plan_name: planName,
                        client_limit: clientLimit,
                        price: price,
                        nonce: '<?php echo wp_create_nonce('lcp_package_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            lcpShowNotice(response.data.message, 'success');
                            
                            // Update or add row in table
                            var plan = response.data.plan;
                            var tableBody = $('#lcp_loyalty_plans_table');
                            
                            if (planId) {
                                // Update existing row
                                var existingRow = tableBody.find('tr').filter(function() {
                                    return $(this).find('button[onclick*="' + planId + '"]').length > 0;
                                });
                                
                                if (existingRow.length) {
                                    existingRow.replaceWith(lcpCreateLoyaltyRow(plan));
                                }
                            } else {
                                // Remove "no plans" message if exists
                                tableBody.find('td[colspan]').parent().remove();
                                
                                // Add new row
                                tableBody.append(lcpCreateLoyaltyRow(plan));
                            }
                            
                            // Clear form
                            lcpClearLoyaltyForm();
                            button.prop('disabled', false).html(originalHtml);
                        } else {
                            lcpShowNotice(response.data.message || '<?php echo esc_js(__('Error saving plan', 'loyalty-card-pro')); ?>', 'error');
                            button.prop('disabled', false).html(originalHtml);
                        }
                    },
                    error: function() {
                        lcpShowNotice('<?php echo esc_js(__('Error saving plan', 'loyalty-card-pro')); ?>', 'error');
                        button.prop('disabled', false).html(originalHtml);
                    }
                });
            });
            
            // Save ticket bundle
            $('#lcp_save_ticket_bundle').on('click', function() {
                var bundleId = $('#lcp_ticket_bundle_id').val();
                var bundleName = $('#lcp_ticket_bundle_name').val();
                var ticketLimit = $('#lcp_ticket_limit').val();
                var price = $('#lcp_ticket_price').val();
                
                if (!bundleName || !ticketLimit || !price) {
                    lcpShowNotice('<?php echo esc_js(__('Please fill in all fields', 'loyalty-card-pro')); ?>', 'error');
                    return;
                }
                
                var button = $(this);
                var originalHtml = button.html();
                button.prop('disabled', true).text('<?php echo esc_js(__('Creating WooCommerce product...', 'loyalty-card-pro')); ?>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'lcp_save_ticket_bundle',
                        bundle_id: bundleId,
                        bundle_name: bundleName,
                        ticket_limit: ticketLimit,
                        price: price,
                        nonce: '<?php echo wp_create_nonce('lcp_package_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            lcpShowNotice(response.data.message, 'success');
                            
                            // Update or add row in table
                            var bundle = response.data.plan;
                            var tableBody = $('#lcp_ticket_bundles_table');
                            
                            if (bundleId) {
                                // Update existing row
                                var existingRow = tableBody.find('tr').filter(function() {
                                    return $(this).find('button[onclick*="' + bundleId + '"]').length > 0;
                                });
                                
                                if (existingRow.length) {
                                    existingRow.replaceWith(lcpCreateTicketRow(bundle));
                                }
                            } else {
                                // Remove "no bundles" message if exists
                                tableBody.find('td[colspan]').parent().remove();
                                
                                // Add new row
                                tableBody.append(lcpCreateTicketRow(bundle));
                            }
                            
                            // Clear form
                            lcpClearTicketForm();
                            button.prop('disabled', false).html(originalHtml);
                        } else {
                            lcpShowNotice(response.data.message || '<?php echo esc_js(__('Error saving bundle', 'loyalty-card-pro')); ?>', 'error');
                            button.prop('disabled', false).html(originalHtml);
                        }
                    },
                    error: function() {
                        lcpShowNotice('<?php echo esc_js(__('Error saving bundle', 'loyalty-card-pro')); ?>', 'error');
                        button.prop('disabled', false).html(originalHtml);
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render payment gateway settings page
     */
    public function render_payment_gateway() {
        // Save settings if form submitted
        if (isset($_POST['lcp_save_payment_settings']) && check_admin_referer('lcp_payment_settings_nonce')) {
            update_option('lcp_enable_wc_payment', isset($_POST['lcp_enable_wc_payment']) ? '1' : '0');
            update_option('lcp_enable_checkout_redirect', isset($_POST['lcp_enable_checkout_redirect']) ? '1' : '0');
            update_option('lcp_enable_test_mode', isset($_POST['lcp_enable_test_mode']) ? '1' : '0');
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Settings saved successfully!', 'loyalty-card-pro') . '</p></div>';
        }
        
        // Get current settings
        $enable_wc_payment = get_option('lcp_enable_wc_payment', '0');
        $enable_checkout_redirect = get_option('lcp_enable_checkout_redirect', '1'); // Default: Always Active
        $enable_test_mode = get_option('lcp_enable_test_mode', '0');
        
        // Check if WooCommerce is active
        $wc_active = class_exists('WooCommerce');
        ?>
        <div class="wrap lcp-payment-gateway">
            <h1 style="color: #FE7AC1;">
                <span class="dashicons dashicons-cart" style="font-size: 32px;"></span>
                <?php _e('Payment Gateway Settings', 'loyalty-card-pro'); ?>
            </h1>
            <p class="description"><?php _e('Configure WooCommerce checkout redirection settings', 'loyalty-card-pro'); ?></p>
            
            <?php if (!$wc_active): ?>
                <div class="notice notice-error" style="margin-top: 20px;">
                    <p>
                        <strong><?php _e('WooCommerce Not Active!', 'loyalty-card-pro'); ?></strong><br>
                        <?php _e('WooCommerce must be installed and activated to use checkout redirection features.', 'loyalty-card-pro'); ?>
                    </p>
                </div>
            <?php endif; ?>
            
            <!-- Tab Navigation -->
            <div style="margin-top: 25px; border-bottom: 2px solid #FFEFF7;">
                <nav class="lcp-payment-tab-nav">
                    <button type="button" class="lcp-payment-tab-button active" data-tab="wc-integration" onclick="lcpSwitchPaymentTab('wc-integration')">
                        <span class="dashicons dashicons-wordpress"></span>
                        <?php _e('WooCommerce Integration', 'loyalty-card-pro'); ?>
                    </button>
                    <button type="button" class="lcp-payment-tab-button" data-tab="payment-gateways" onclick="lcpSwitchPaymentTab('payment-gateways')">
                        <span class="dashicons dashicons-money-alt"></span>
                        <?php _e('Payment Gateways', 'loyalty-card-pro'); ?>
                    </button>
                </nav>
            </div>
            
            <form method="post" action="">
                <?php wp_nonce_field('lcp_payment_settings_nonce'); ?>
                
                <!-- Tab Content: WooCommerce Integration -->
                <div id="lcp-payment-tab-wc-integration" class="lcp-payment-tab-content active">
                <!-- WooCommerce Integration Card -->
            <div class="lcp-gateway-card" style="background: white; padding: 30px; margin-bottom: 30px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <div style="display: flex; align-items: center; margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; background: #96588A; border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 20px;">
                        <span class="dashicons dashicons-wordpress" style="color: white; font-size: 32px;"></span>
                    </div>
                    <div>
                        <h2 style="margin: 0; color: #96588A; font-size: 24px;"><?php _e('WooCommerce Integration', 'loyalty-card-pro'); ?></h2>
                        <p style="margin: 5px 0 0 0; color: #666;"><?php _e('Enable direct checkout redirection for products', 'loyalty-card-pro'); ?></p>
                    </div>
                </div>
                
                <hr style="margin: 25px 0; border: none; border-top: 1px solid #eee;">
                
                <table class="form-table">
                    <tr>
                        <th style="width: 250px; padding-left: 0;">
                            <label for="lcp_enable_wc_payment"><?php _e('Enable WooCommerce Payment', 'loyalty-card-pro'); ?></label>
                        </th>
                        <td>
                            <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
                                <label class="lcp-toggle-switch" style="position: relative; display: inline-block; width: 60px; height: 30px;">
                                    <input type="checkbox" 
                                           id="lcp_enable_wc_payment" 
                                           name="lcp_enable_wc_payment" 
                                           value="1" 
                                           <?php checked($enable_wc_payment, '1'); ?>
                                           <?php disabled(!$wc_active); ?>
                                           style="opacity: 0; width: 0; height: 0;">
                                    <span class="lcp-slider" style="position: absolute; cursor: <?php echo $wc_active ? 'pointer' : 'not-allowed'; ?>; top: 0; left: 0; right: 0; bottom: 0; background-color: <?php echo $enable_wc_payment == '1' ? '#28a745' : '#ccc'; ?>; border-radius: 30px; transition: 0.4s;">
                                        <span style="position: absolute; height: 22px; width: 22px; left: <?php echo $enable_wc_payment == '1' ? '33px' : '4px'; ?>; bottom: 4px; background-color: white; border-radius: 50%; transition: 0.4s; box-shadow: 0 2px 4px rgba(0,0,0,0.2);"></span>
                                    </span>
                                </label>
                                <span id="lcp_wc_payment_status" class="lcp-status-badge" style="padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; background: <?php echo $enable_wc_payment == '1' ? '#E8F5E9' : '#F5F5F5'; ?>; color: <?php echo $enable_wc_payment == '1' ? '#2E7D32' : '#757575'; ?>;">
                                    <span class="dashicons <?php echo $enable_wc_payment == '1' ? 'dashicons-yes-alt' : 'dashicons-dismiss'; ?>" style="font-size: 16px;"></span>
                                    <span id="lcp_wc_payment_text"><?php echo $enable_wc_payment == '1' ? __('Enabled', 'loyalty-card-pro') : __('Disabled', 'loyalty-card-pro'); ?></span>
                                </span>
                            </div>
                            <p class="description" style="margin: 0;">
                                <?php _e('Allow users to be redirected directly to WooCommerce checkout via URL parameter (?buy_pkg=product_id)', 'loyalty-card-pro'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Checkout Redirection Active -->
                    <tr>
                        <th style="padding-left: 0;">
                            <label for="lcp_enable_checkout_redirect"><?php _e('Checkout Redirection Active', 'loyalty-card-pro'); ?></label>
                        </th>
                        <td>
                            <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
                                <label class="lcp-toggle-switch" style="position: relative; display: inline-block; width: 60px; height: 30px;">
                                    <input type="checkbox" 
                                           id="lcp_enable_checkout_redirect" 
                                           name="lcp_enable_checkout_redirect" 
                                           value="1" 
                                           <?php checked($enable_checkout_redirect, '1'); ?>
                                           <?php disabled(!$wc_active || $enable_wc_payment != '1'); ?>
                                           style="opacity: 0; width: 0; height: 0;">
                                    <span class="lcp-slider" style="position: absolute; cursor: <?php echo ($wc_active && $enable_wc_payment == '1') ? 'pointer' : 'not-allowed'; ?>; top: 0; left: 0; right: 0; bottom: 0; background-color: <?php echo $enable_checkout_redirect == '1' ? '#4CAF50' : '#ccc'; ?>; border-radius: 30px; transition: 0.4s;">
                                        <span style="position: absolute; height: 22px; width: 22px; left: <?php echo $enable_checkout_redirect == '1' ? '33px' : '4px'; ?>; bottom: 4px; background-color: white; border-radius: 50%; transition: 0.4s; box-shadow: 0 2px 4px rgba(0,0,0,0.2);"></span>
                                    </span>
                                </label>
                                <span id="lcp_checkout_redirect_status" class="lcp-status-badge" style="padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; background: <?php echo ($enable_checkout_redirect == '1' && $enable_wc_payment == '1' && $wc_active) ? '#E8F5E9' : '#F5F5F5'; ?>; color: <?php echo ($enable_checkout_redirect == '1' && $enable_wc_payment == '1' && $wc_active) ? '#2E7D32' : '#757575'; ?>;">
                                    <span class="dashicons <?php echo ($enable_checkout_redirect == '1' && $enable_wc_payment == '1' && $wc_active) ? 'dashicons-yes-alt' : 'dashicons-dismiss'; ?>" style="font-size: 16px;"></span>
                                    <span id="lcp_checkout_redirect_text"><?php echo ($enable_checkout_redirect == '1' && $enable_wc_payment == '1' && $wc_active) ? __('Active', 'loyalty-card-pro') : __('Inactive', 'loyalty-card-pro'); ?></span>
                                </span>
                            </div>
                            <p class="description" style="margin: 0 0 10px 0;">
                                <?php _e('When active, ?buy_pkg parameter will automatically redirect users to checkout', 'loyalty-card-pro'); ?>
                            </p>
                            <?php if ($enable_wc_payment != '1'): ?>
                                <div style="background: #FFF3E0; border-left: 4px solid #FF9800; padding: 10px 15px; border-radius: 4px; margin-top: 10px;">
                                    <p style="margin: 0; color: #E65100; font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                                        <span class="dashicons dashicons-warning" style="font-size: 16px;"></span>
                                        <?php _e('Please enable "WooCommerce Payment" first', 'loyalty-card-pro'); ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                    <tr>
                        <th style="padding-left: 0;">
                            <label for="lcp_enable_test_mode"><?php _e('Enable Test Mode', 'loyalty-card-pro'); ?></label>
                        </th>
                        <td>
                            <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
                                <label class="lcp-toggle-switch" style="position: relative; display: inline-block; width: 60px; height: 30px;">
                                    <input type="checkbox" 
                                           id="lcp_enable_test_mode" 
                                           name="lcp_enable_test_mode" 
                                           value="1" 
                                           <?php checked($enable_test_mode, '1'); ?>
                                           style="opacity: 0; width: 0; height: 0;">
                                    <span class="lcp-slider" style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: <?php echo $enable_test_mode == '1' ? '#ff9800' : '#ccc'; ?>; border-radius: 30px; transition: 0.4s;">
                                        <span style="position: absolute; height: 22px; width: 22px; left: <?php echo $enable_test_mode == '1' ? '33px' : '4px'; ?>; bottom: 4px; background-color: white; border-radius: 50%; transition: 0.4s; box-shadow: 0 2px 4px rgba(0,0,0,0.2);"></span>
                                    </span>
                                </label>
                                <span id="lcp_test_mode_status" class="lcp-status-badge" style="padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; background: <?php echo $enable_test_mode == '1' ? '#FFF3E0' : '#E8F5E9'; ?>; color: <?php echo $enable_test_mode == '1' ? '#E65100' : '#2E7D32'; ?>;">
                                    <span class="dashicons <?php echo $enable_test_mode == '1' ? 'dashicons-admin-tools' : 'dashicons-yes-alt'; ?>" style="font-size: 16px;"></span>
                                    <span id="lcp_test_mode_text"><?php echo $enable_test_mode == '1' ? __('Test Mode', 'loyalty-card-pro') : __('Live Mode', 'loyalty-card-pro'); ?></span>
                                </span>
                            </div>
                            <p class="description" style="margin: 0;">
                                <?php _e('Enable test mode for debugging and testing purposes', 'loyalty-card-pro'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <hr style="margin: 25px 0; border: none; border-top: 1px solid #eee;">
                
                <?php submit_button(__('Save Settings', 'loyalty-card-pro'), 'primary large', 'lcp_save_payment_settings', true, array('style' => 'background: #FE7AC1; border-color: #FE7AC1; text-shadow: none; box-shadow: none;')); ?>
            </div>
            
            <!-- Usage Instructions -->
            <div style="background: #E8F5E9; padding: 25px; border-radius: 8px; border-left: 4px solid #4CAF50; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #4CAF50;">
                    <span class="dashicons dashicons-info" style="font-size: 20px;"></span>
                    <?php _e('How to Use', 'loyalty-card-pro'); ?>
                </h3>
                <p style="margin-bottom: 15px; color: #333;">
                    <?php _e('To redirect users directly to checkout with a specific product, use this URL format:', 'loyalty-card-pro'); ?>
                </p>
                <code style="background: white; padding: 12px 20px; border-radius: 6px; display: block; font-size: 14px; border: 1px solid #4CAF50;">
                    <?php echo esc_url(home_url('/?buy_pkg=123')); ?>
                </code>
                <p style="margin-top: 15px; color: #666; font-size: 13px;">
                    <?php _e('Replace "123" with your actual WooCommerce product ID', 'loyalty-card-pro'); ?>
                </p>
                <ul style="color: #666; margin-top: 15px; line-height: 1.8;">
                    <li><strong><?php _e('Product ID:', 'loyalty-card-pro'); ?></strong> <?php _e('The WooCommerce product ID you want to add to cart', 'loyalty-card-pro'); ?></li>
                    <li><strong><?php _e('Behavior:', 'loyalty-card-pro'); ?></strong> <?php _e('Clears cart, adds product, redirects to checkout', 'loyalty-card-pro'); ?></li>
                    <li><strong><?php _e('Status:', 'loyalty-card-pro'); ?></strong> <?php echo $enable_wc_payment == '1' ? '<span style="color: #4CAF50;">✓ Active</span>' : '<span style="color: #f44336;">✗ Disabled</span>'; ?></li>
                </ul>
            </div>
            
            <!-- Status Notice -->
            <?php if ($wc_active && $enable_wc_payment == '1'): ?>
                <div class="notice notice-success" style="border-left-color: #4CAF50;">
                    <p>
                        <strong><?php _e('WooCommerce Checkout Redirection is Active!', 'loyalty-card-pro'); ?></strong><br>
                        <?php _e('Users can now be redirected directly to checkout using the ?buy_pkg parameter.', 'loyalty-card-pro'); ?>
                    </p>
                </div>
            <?php elseif ($wc_active && $enable_wc_payment != '1'): ?>
                <div class="notice notice-warning">
                    <p>
                        <strong><?php _e('Feature Disabled:', 'loyalty-card-pro'); ?></strong>
                        <?php _e('Enable "WooCommerce Payment" above to activate checkout redirection.', 'loyalty-card-pro'); ?>
                    </p>
                </div>
            <?php endif; ?>
            </div>
            <!-- End Tab Content: WooCommerce Integration -->
            
            <!-- Tab Content: Payment Gateways -->
            <div id="lcp-payment-tab-payment-gateways" class="lcp-payment-tab-content">
            
            <!-- Active Payment Gateways Section -->
            <?php if ($wc_active): 
                $payment_gateways = WC()->payment_gateways->payment_gateways();
                $active_count = 0;
                foreach ($payment_gateways as $gateway) {
                    if ($gateway->enabled === 'yes') {
                        $active_count++;
                    }
                }
            ?>
            <div style="background: white; padding: 30px; margin-bottom: 30px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <div style="display: flex; align-items: center; margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 20px;">
                        <span class="dashicons dashicons-money-alt" style="color: white; font-size: 32px;"></span>
                    </div>
                    <div>
                        <h2 style="margin: 0; color: #667eea; font-size: 24px;"><?php _e('Payment Gateways', 'loyalty-card-pro'); ?></h2>
                        <p style="margin: 5px 0 0 0; color: #666;">
                            <?php printf(__('%d total gateway(s) | %d active', 'loyalty-card-pro'), count($payment_gateways), $active_count); ?>
                        </p>
                    </div>
                </div>
                
                <hr style="margin: 25px 0; border: none; border-top: 1px solid #eee;">
                
                <?php if (!empty($payment_gateways)): ?>
                    <div style="display: grid; gap: 20px;">
                        <?php foreach ($payment_gateways as $gateway): ?>
                            <div style="border: 2px solid <?php echo $gateway->enabled === 'yes' ? '#4CAF50' : '#e0e0e0'; ?>; border-radius: 10px; padding: 20px; background: <?php echo $gateway->enabled === 'yes' ? '#f1f8f4' : '#fafafa'; ?>; transition: all 0.3s ease;">
                                <div style="display: flex; align-items: center; justify-content: space-between;">
                                    <div style="flex: 1; display: flex; align-items: center; gap: 20px;">
                                        <!-- Gateway Icon -->
                                        <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                                            <span class="dashicons dashicons-money-alt" style="color: white; font-size: 28px;"></span>
                                        </div>
                                        
                                        <!-- Gateway Info -->
                                        <div style="flex: 1;">
                                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                                                <h3 style="margin: 0; font-size: 18px; color: #333;">
                                                    <?php echo esc_html($gateway->get_title()); ?>
                                                </h3>
                                                
                                                <!-- Status Badge -->
                                                <?php if ($gateway->enabled === 'yes'): ?>
                                                    <span style="background: #4CAF50; color: white; padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 600; text-transform: uppercase; display: inline-flex; align-items: center; gap: 5px;">
                                                        <span class="dashicons dashicons-yes-alt" style="font-size: 14px;"></span>
                                                        <?php _e('Active', 'loyalty-card-pro'); ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span style="background: #9E9E9E; color: white; padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 600; text-transform: uppercase;">
                                                        <?php _e('Inactive', 'loyalty-card-pro'); ?>
                                                    </span>
                                                <?php endif; ?>
                                                
                                                <!-- Official Badge -->
                                                <span style="background: #2196F3; color: white; padding: 4px 10px; border-radius: 12px; font-size: 10px; font-weight: 600;">
                                                    <?php _e('WooCommerce', 'loyalty-card-pro'); ?>
                                                </span>
                                            </div>
                                            
                                            <?php if ($gateway->get_method_description()): ?>
                                                <p style="margin: 0; color: #666; font-size: 13px; line-height: 1.6;">
                                                    <?php echo esc_html($gateway->get_method_description()); ?>
                                                </p>
                                            <?php else: ?>
                                                <p style="margin: 0; color: #999; font-size: 13px; font-style: italic;">
                                                    <?php _e('No description available', 'loyalty-card-pro'); ?>
                                                </p>
                                            <?php endif; ?>
                                            
                                            <!-- Gateway ID -->
                                            <p style="margin: 8px 0 0 0; color: #999; font-size: 12px; font-family: monospace;">
                                                <?php _e('ID:', 'loyalty-card-pro'); ?> <code style="background: #f5f5f5; padding: 2px 6px; border-radius: 3px;"><?php echo esc_html($gateway->id); ?></code>
                                            </p>
                                        </div>
                                    </div>
                                    
                                    <!-- View in WooCommerce Button -->
                                    <div style="margin-left: 20px;">
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=' . $gateway->id)); ?>" class="button button-secondary" style="display: inline-flex; align-items: center; gap: 5px;" target="_blank">
                                            <span class="dashicons dashicons-admin-generic" style="font-size: 16px;"></span>
                                            <?php _e('Configure', 'loyalty-card-pro'); ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px; background: #f9f9f9; border-radius: 8px; border: 2px dashed #ddd;">
                        <span class="dashicons dashicons-warning" style="font-size: 48px; color: #ff9800; margin-bottom: 15px;"></span>
                        <h3 style="color: #666; margin: 10px 0;"><?php _e('No Payment Gateways Found', 'loyalty-card-pro'); ?></h3>
                        <p style="color: #999; margin: 10px 0 20px 0;"><?php _e('Please configure payment gateways in WooCommerce settings first.', 'loyalty-card-pro'); ?></p>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=checkout')); ?>" class="button button-primary" target="_blank">
                            <?php _e('Go to WooCommerce Payment Settings', 'loyalty-card-pro'); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            </div>
            <!-- End Tab Content: Payment Gateways -->
            
            </form>
        </div>
        
        <style>
        /* Tab Navigation Styles */
        .lcp-payment-tab-nav {
            display: flex;
            gap: 0;
            margin: 0;
            padding: 0;
        }
        .lcp-payment-tab-button {
            background: #f9f9f9;
            border: none;
            border-bottom: 3px solid transparent;
            padding: 15px 25px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            color: #666;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            outline: none;
        }
        .lcp-payment-tab-button:hover {
            background: #fff;
            color: #FE7AC1;
        }
        .lcp-payment-tab-button.active {
            background: white;
            color: #FE7AC1;
            border-bottom-color: #FE7AC1;
        }
        .lcp-payment-tab-button .dashicons {
            font-size: 18px;
        }
        .lcp-payment-tab-content {
            display: none;
            animation: fadeIn 0.3s ease-in;
            margin-top: 25px;
        }
        .lcp-payment-tab-content.active {
            display: block;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        </style>
        
        <style>
        .lcp-toggle-switch input:checked + .lcp-slider {
            background-color: #28a745 !important;
        }
        .lcp-toggle-switch input:checked + .lcp-slider span {
            left: 33px !important;
        }
        #lcp_enable_checkout_redirect:checked + .lcp-slider {
            background-color: #4CAF50 !important;
        }
        #lcp_enable_test_mode:checked + .lcp-slider {
            background-color: #ff9800 !important;
        }
        .lcp-toggle-switch input:disabled + .lcp-slider {
            opacity: 0.5;
        }
        </style>
        
        <script>
        // Tab switching function
        function lcpSwitchPaymentTab(tabName) {
            // Hide all tab contents
            var tabContents = document.querySelectorAll('.lcp-payment-tab-content');
            tabContents.forEach(function(content) {
                content.classList.remove('active');
            });
            
            // Remove active class from all tab buttons
            var tabButtons = document.querySelectorAll('.lcp-payment-tab-button');
            tabButtons.forEach(function(button) {
                button.classList.remove('active');
            });
            
            // Show selected tab content
            var selectedTab = document.getElementById('lcp-payment-tab-' + tabName);
            if (selectedTab) {
                selectedTab.classList.add('active');
            }
            
            // Add active class to clicked button
            var activeButton = document.querySelector('.lcp-payment-tab-button[data-tab="' + tabName + '"]');
            if (activeButton) {
                activeButton.classList.add('active');
            }
        }
        
        jQuery(document).ready(function($) {
            // Initialize first tab as active
            lcpSwitchPaymentTab('wc-integration');
            
            // Handle Enable WooCommerce Payment toggle
            $('#lcp_enable_wc_payment').on('change', function() {
                var isChecked = $(this).is(':checked');
                var slider = $(this).siblings('.lcp-slider');
                var statusBadge = $('#lcp_wc_payment_status');
                var statusText = $('#lcp_wc_payment_text');
                var statusIcon = statusBadge.find('.dashicons');
                
                if (isChecked) {
                    slider.css('background-color', '#28a745');
                    slider.find('span').css('left', '33px');
                    statusBadge.css({'background': '#E8F5E9', 'color': '#2E7D32'});
                    statusIcon.removeClass('dashicons-dismiss').addClass('dashicons-yes-alt');
                    statusText.text('<?php echo esc_js(__('Enabled', 'loyalty-card-pro')); ?>');
                } else {
                    slider.css('background-color', '#ccc');
                    slider.find('span').css('left', '4px');
                    statusBadge.css({'background': '#F5F5F5', 'color': '#757575'});
                    statusIcon.removeClass('dashicons-yes-alt').addClass('dashicons-dismiss');
                    statusText.text('<?php echo esc_js(__('Disabled', 'loyalty-card-pro')); ?>');
                }
                
                // Update Checkout Redirection toggle state
                var checkoutToggle = $('#lcp_enable_checkout_redirect');
                if (!isChecked) {
                    checkoutToggle.prop('checked', false).prop('disabled', true).trigger('change');
                } else {
                    checkoutToggle.prop('disabled', false);
                }
            });
            
            // Handle Checkout Redirection Active toggle
            $('#lcp_enable_checkout_redirect').on('change', function() {
                var isChecked = $(this).is(':checked');
                var slider = $(this).siblings('.lcp-slider');
                var statusBadge = $('#lcp_checkout_redirect_status');
                var statusText = $('#lcp_checkout_redirect_text');
                var statusIcon = statusBadge.find('.dashicons');
                
                if (isChecked) {
                    slider.css('background-color', '#4CAF50');
                    slider.find('span').css('left', '33px');
                    statusBadge.css({'background': '#E8F5E9', 'color': '#2E7D32'});
                    statusIcon.removeClass('dashicons-dismiss').addClass('dashicons-yes-alt');
                    statusText.text('<?php echo esc_js(__('Active', 'loyalty-card-pro')); ?>');
                } else {
                    slider.css('background-color', '#ccc');
                    slider.find('span').css('left', '4px');
                    statusBadge.css({'background': '#F5F5F5', 'color': '#757575'});
                    statusIcon.removeClass('dashicons-yes-alt').addClass('dashicons-dismiss');
                    statusText.text('<?php echo esc_js(__('Inactive', 'loyalty-card-pro')); ?>');
                }
            });
            
            // Handle Enable Test Mode toggle
            $('#lcp_enable_test_mode').on('change', function() {
                var isChecked = $(this).is(':checked');
                var slider = $(this).siblings('.lcp-slider');
                var statusBadge = $('#lcp_test_mode_status');
                var statusText = $('#lcp_test_mode_text');
                var statusIcon = statusBadge.find('.dashicons');
                
                if (isChecked) {
                    slider.css('background-color', '#ff9800');
                    slider.find('span').css('left', '33px');
                    statusBadge.css({'background': '#FFF3E0', 'color': '#E65100'});
                    statusIcon.removeClass('dashicons-yes-alt').addClass('dashicons-admin-tools');
                    statusText.text('<?php echo esc_js(__('Test Mode', 'loyalty-card-pro')); ?>');
                } else {
                    slider.css('background-color', '#ccc');
                    slider.find('span').css('left', '4px');
                    statusBadge.css({'background': '#E8F5E9', 'color': '#2E7D32'});
                    statusIcon.removeClass('dashicons-admin-tools').addClass('dashicons-yes-alt');
                    statusText.text('<?php echo esc_js(__('Live Mode', 'loyalty-card-pro')); ?>');
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render payments page
     */
    public function render_payments() {
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_payments';
        
        // Get payments with user details
        $payments = $wpdb->get_results("
            SELECT p.*, u.display_name, u.user_email
            FROM $table p
            LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID
            ORDER BY p.payment_date DESC
            LIMIT 100
        ");
        
        // Calculate totals
        $total_revenue = $wpdb->get_var("SELECT SUM(amount) FROM $table WHERE status = 'completed'");
        $pending_amount = $wpdb->get_var("SELECT SUM(amount) FROM $table WHERE status = 'pending'");
        
        ?>
        <div class="wrap lcp-payments">
            <h1><?php _e('Payments', 'loyalty-card-pro'); ?></h1>
            
            <div class="lcp-payment-summary">
                <div class="lcp-summary-card">
                    <h3><?php _e('Total Revenue', 'loyalty-card-pro'); ?></h3>
                    <p class="lcp-amount">$<?php echo number_format($total_revenue, 2); ?></p>
                </div>
                <div class="lcp-summary-card">
                    <h3><?php _e('Pending Payments', 'loyalty-card-pro'); ?></h3>
                    <p class="lcp-amount">$<?php echo number_format($pending_amount, 2); ?></p>
                </div>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('ID', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('User', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Email', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Amount', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Method', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Transaction ID', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Status', 'loyalty-card-pro'); ?></th>
                        <th><?php _e('Date', 'loyalty-card-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($payments)) : ?>
                        <tr>
                            <td colspan="8"><?php _e('No payments found.', 'loyalty-card-pro'); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($payments as $payment) : ?>
                            <tr>
                                <td><?php echo intval($payment->id); ?></td>
                                <td><?php echo esc_html($payment->display_name); ?></td>
                                <td><?php echo esc_html($payment->user_email); ?></td>
                                <td>$<?php echo number_format($payment->amount, 2); ?></td>
                                <td><?php echo esc_html($payment->payment_method); ?></td>
                                <td><?php echo esc_html($payment->transaction_id); ?></td>
                                <td>
                                    <?php if ($payment->status === 'completed') : ?>
                                        <span class="lcp-badge lcp-badge-success"><?php _e('Completed', 'loyalty-card-pro'); ?></span>
                                    <?php elseif ($payment->status === 'pending') : ?>
                                        <span class="lcp-badge lcp-badge-warning"><?php _e('Pending', 'loyalty-card-pro'); ?></span>
                                    <?php else : ?>
                                        <span class="lcp-badge lcp-badge-error"><?php _e('Failed', 'loyalty-card-pro'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M d, Y H:i', strtotime($payment->payment_date)); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    /**
     * AJAX: Save loyalty plan
     * Auto-creates/updates WooCommerce product with hidden catalog visibility
     */
    public function ajax_save_loyalty_plan() {
        check_ajax_referer('lcp_package_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'loyalty-card-pro')));
        }
        
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            wp_send_json_error(array('message' => __('WooCommerce is not active', 'loyalty-card-pro')));
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
        $plan_name = isset($_POST['plan_name']) ? sanitize_text_field($_POST['plan_name']) : '';
        $client_limit = isset($_POST['client_limit']) ? intval($_POST['client_limit']) : 0;
        $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
        
        if (empty($plan_name) || $client_limit <= 0 || $price < 0) {
            wp_send_json_error(array('message' => __('Invalid data', 'loyalty-card-pro')));
        }
        
        // Get existing WooCommerce product ID if updating
        $existing_wc_product_id = null;
        if ($plan_id > 0) {
            $existing_plan = $wpdb->get_row($wpdb->prepare("SELECT wc_product_id FROM $table WHERE id = %d", $plan_id), ARRAY_A);
            $existing_wc_product_id = $existing_plan ? $existing_plan['wc_product_id'] : null;
        }
        
        // Create or update WooCommerce product
        try {
            if ($existing_wc_product_id) {
                // Update existing WooCommerce product
                $product = wc_get_product($existing_wc_product_id);
                if (!$product) {
                    throw new Exception(__('WooCommerce product not found', 'loyalty-card-pro'));
                }
                $product->set_name($plan_name);
                $product->set_regular_price($price);
                $product->set_description(sprintf(__('Loyalty Card Plan: %d clients', 'loyalty-card-pro'), $client_limit));
                $product->set_catalog_visibility('hidden');
                $product->save();
                $wc_product_id = $existing_wc_product_id;
            } else {
                // Create new WooCommerce product
                $product = new WC_Product_Simple();
                $product->set_name($plan_name);
                $product->set_status('publish');
                $product->set_regular_price($price);
                $product->set_description(sprintf(__('Loyalty Card Plan: %d clients', 'loyalty-card-pro'), $client_limit));
                $product->set_catalog_visibility('hidden'); // Hidden from shop/catalog
                $product->set_virtual(true); // Virtual product (no shipping)
                $product->save();
                $wc_product_id = $product->get_id();
            }
        } catch (Exception $e) {
            wp_send_json_error(array('message' => __('Error creating WooCommerce product: ', 'loyalty-card-pro') . $e->getMessage()));
        }
        
        // Save package data with linked WooCommerce product ID
        $data = array(
            'plan_name' => $plan_name,
            'plan_type' => 'loyalty_cards',
            'client_limit' => $client_limit,
            'ticket_count' => 0,
            'price' => $price,
            'wc_product_id' => $wc_product_id,
            'is_active' => 1
        );
        
        if ($plan_id > 0) {
            // Update existing plan
            $result = $wpdb->update($table, $data, array('id' => $plan_id));
            $message = __('Plan updated successfully! WooCommerce product updated.', 'loyalty-card-pro');
            $new_plan_id = $plan_id;
        } else {
            // Insert new plan
            $result = $wpdb->insert($table, $data);
            $message = __('Plan created successfully! WooCommerce product created.', 'loyalty-card-pro');
            $new_plan_id = $wpdb->insert_id;
        }
        
        if ($result !== false || $plan_id > 0) { // Update returns 0 if no changes
            // Return plan data for dynamic update
            $plan_data = array(
                'id' => $new_plan_id,
                'name' => $plan_name,
                'client_limit' => $client_limit,
                'price' => $price,
                'wc_product_id' => $wc_product_id
            );
            
            wp_send_json_success(array(
                'message' => $message,
                'plan' => $plan_data
            ));
        } else {
            wp_send_json_error(array('message' => __('Error saving plan', 'loyalty-card-pro')));
        }
    }
    
    /**
     * AJAX: Save ticket bundle
     * Auto-creates/updates WooCommerce product with hidden catalog visibility
     */
    public function ajax_save_ticket_bundle() {
        check_ajax_referer('lcp_package_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'loyalty-card-pro')));
        }
        
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            wp_send_json_error(array('message' => __('WooCommerce is not active', 'loyalty-card-pro')));
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        $bundle_id = isset($_POST['bundle_id']) ? intval($_POST['bundle_id']) : 0;
        $bundle_name = isset($_POST['bundle_name']) ? sanitize_text_field($_POST['bundle_name']) : '';
        $ticket_limit = isset($_POST['ticket_limit']) ? intval($_POST['ticket_limit']) : 0;
        $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
        
        if (empty($bundle_name) || $ticket_limit <= 0 || $price < 0) {
            wp_send_json_error(array('message' => __('Invalid data', 'loyalty-card-pro')));
        }
        
        // Get existing WooCommerce product ID if updating
        $existing_wc_product_id = null;
        if ($bundle_id > 0) {
            $existing_bundle = $wpdb->get_row($wpdb->prepare("SELECT wc_product_id FROM $table WHERE id = %d", $bundle_id), ARRAY_A);
            $existing_wc_product_id = $existing_bundle ? $existing_bundle['wc_product_id'] : null;
        }
        
        // Create or update WooCommerce product
        try {
            if ($existing_wc_product_id) {
                // Update existing WooCommerce product
                $product = wc_get_product($existing_wc_product_id);
                if (!$product) {
                    throw new Exception(__('WooCommerce product not found', 'loyalty-card-pro'));
                }
                $product->set_name($bundle_name);
                $product->set_regular_price($price);
                $product->set_description(sprintf(__('Scratch-Off Ticket Bundle: %d tickets', 'loyalty-card-pro'), $ticket_limit));
                $product->set_catalog_visibility('hidden');
                $product->save();
                $wc_product_id = $existing_wc_product_id;
            } else {
                // Create new WooCommerce product
                $product = new WC_Product_Simple();
                $product->set_name($bundle_name);
                $product->set_status('publish');
                $product->set_regular_price($price);
                $product->set_description(sprintf(__('Scratch-Off Ticket Bundle: %d tickets', 'loyalty-card-pro'), $ticket_limit));
                $product->set_catalog_visibility('hidden'); // Hidden from shop/catalog
                $product->set_virtual(true); // Virtual product (no shipping)
                $product->save();
                $wc_product_id = $product->get_id();
            }
        } catch (Exception $e) {
            wp_send_json_error(array('message' => __('Error creating WooCommerce product: ', 'loyalty-card-pro') . $e->getMessage()));
        }
        
        // Save bundle data with linked WooCommerce product ID
        $data = array(
            'plan_name' => $bundle_name,
            'plan_type' => 'tickets',
            'client_limit' => 0,
            'ticket_count' => $ticket_limit,
            'price' => $price,
            'wc_product_id' => $wc_product_id,
            'is_active' => 1
        );
        
        if ($bundle_id > 0) {
            // Update existing bundle
            $result = $wpdb->update($table, $data, array('id' => $bundle_id));
            $message = __('Bundle updated successfully! WooCommerce product updated.', 'loyalty-card-pro');
            $new_bundle_id = $bundle_id;
        } else {
            // Insert new bundle
            $result = $wpdb->insert($table, $data);
            $message = __('Bundle created successfully! WooCommerce product created.', 'loyalty-card-pro');
            $new_bundle_id = $wpdb->insert_id;
        }
        
        if ($result !== false || $bundle_id > 0) { // Update returns 0 if no changes
            // Return bundle data for dynamic update
            $bundle_data = array(
                'id' => $new_bundle_id,
                'name' => $bundle_name,
                'ticket_limit' => $ticket_limit,
                'price' => $price,
                'wc_product_id' => $wc_product_id
            );
            
            wp_send_json_success(array(
                'message' => $message,
                'plan' => $bundle_data
            ));
        } else {
            wp_send_json_error(array('message' => __('Error saving bundle', 'loyalty-card-pro')));
        }
    }
    
    /**
     * AJAX: Delete plan
     */
    /**
     * AJAX: Delete plan
     * Also deletes/trashes the linked WooCommerce product
     */
    public function ajax_delete_plan() {
        check_ajax_referer('lcp_package_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'loyalty-card-pro')));
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
        
        if ($plan_id <= 0) {
            wp_send_json_error(array('message' => __('Invalid plan ID', 'loyalty-card-pro')));
        }
        
        // Get WooCommerce product ID before deleting
        $plan = $wpdb->get_row($wpdb->prepare("SELECT wc_product_id FROM $table WHERE id = %d", $plan_id), ARRAY_A);
        $wc_product_id = $plan ? $plan['wc_product_id'] : null;
        
        // Delete linked WooCommerce product if exists
        if ($wc_product_id && class_exists('WooCommerce')) {
            $product = wc_get_product($wc_product_id);
            if ($product) {
                // Move to trash instead of permanent delete
                $product->delete(false); // false = move to trash, true = permanent delete
            }
        }
        
        // Soft delete by setting is_active to 0
        $result = $wpdb->update($table, array('is_active' => 0), array('id' => $plan_id));
        
        if ($result !== false) {
            wp_send_json_success(array('message' => __('Plan deleted successfully! WooCommerce product moved to trash.', 'loyalty-card-pro')));
        } else {
            wp_send_json_error(array('message' => __('Error deleting plan', 'loyalty-card-pro')));
        }
    }
}
