<?php
/**
 * Database handler class
 */

if (!defined('ABSPATH')) {
    exit;
}

class LCP_Database {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Constructor
    }
    
    /**
     * Create database tables
     */
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Clients table
        $table_clients = $wpdb->prefix . 'lcp_clients';
        $sql_clients = "CREATE TABLE $table_clients (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            beautician_id bigint(20) UNSIGNED NOT NULL,
            name varchar(255) NOT NULL,
            email varchar(255),
            phone varchar(50),
            total_visits int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY beautician_id (beautician_id),
            KEY email (email)
        ) $charset_collate;";
        dbDelta($sql_clients);
        
        // Loyalty cards table
        $table_loyalty = $wpdb->prefix . 'lcp_loyalty_cards';
        $sql_loyalty = "CREATE TABLE $table_loyalty (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            client_id bigint(20) UNSIGNED NOT NULL,
            beautician_id bigint(20) UNSIGNED NOT NULL,
            visit_limit int(11) DEFAULT 10,
            current_visits int(11) DEFAULT 0,
            reward_description text,
            status varchar(20) DEFAULT 'active',
            completed_at datetime,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY client_id (client_id),
            KEY beautician_id (beautician_id)
        ) $charset_collate;";
        dbDelta($sql_loyalty);
        
        // Visit history table
        $table_visits = $wpdb->prefix . 'lcp_visits';
        $sql_visits = "CREATE TABLE $table_visits (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            client_id bigint(20) UNSIGNED NOT NULL,
            beautician_id bigint(20) UNSIGNED NOT NULL,
            loyalty_card_id bigint(20) UNSIGNED,
            visit_date datetime DEFAULT CURRENT_TIMESTAMP,
            notes text,
            PRIMARY KEY (id),
            KEY client_id (client_id),
            KEY beautician_id (beautician_id),
            KEY visit_date (visit_date)
        ) $charset_collate;";
        dbDelta($sql_visits);
        
        // Tickets table
        $table_tickets = $wpdb->prefix . 'lcp_tickets';
        $sql_tickets = "CREATE TABLE $table_tickets (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            beautician_id bigint(20) UNSIGNED NOT NULL,
            ticket_code varchar(50) UNIQUE NOT NULL,
            reward_type varchar(50),
            reward_value varchar(255),
            reward_description text,
            status varchar(20) DEFAULT 'available',
            assigned_client_id bigint(20) UNSIGNED,
            assigned_at datetime,
            revealed_at datetime,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY beautician_id (beautician_id),
            KEY ticket_code (ticket_code),
            KEY status (status)
        ) $charset_collate;";
        dbDelta($sql_tickets);
        
        // Subscriptions table
        $table_subscriptions = $wpdb->prefix . 'lcp_subscriptions';
        $sql_subscriptions = "CREATE TABLE $table_subscriptions (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            beautician_id bigint(20) UNSIGNED NOT NULL,
            plan_type varchar(50),
            client_limit int(11) DEFAULT 20,
            ticket_bundle_size int(11) DEFAULT 0,
            status varchar(20) DEFAULT 'active',
            started_at datetime DEFAULT CURRENT_TIMESTAMP,
            expires_at datetime,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY beautician_id (beautician_id),
            KEY status (status)
        ) $charset_collate;";
        dbDelta($sql_subscriptions);
        
        // Pricing plans table
        $table_pricing = $wpdb->prefix . 'lcp_pricing_plans';
        $sql_pricing = "CREATE TABLE $table_pricing (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            plan_name varchar(255) NOT NULL,
            plan_type varchar(50),
            ticket_count int(11) DEFAULT 0,
            client_limit int(11) DEFAULT 0,
            price decimal(10,2) NOT NULL,
            wc_product_id bigint(20) DEFAULT NULL,
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        dbDelta($sql_pricing);
        
        // Add wc_product_id column if it doesn't exist (for existing installations)
        $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $table_pricing LIKE 'wc_product_id'");
        if (empty($column_exists)) {
            $wpdb->query("ALTER TABLE $table_pricing ADD COLUMN wc_product_id bigint(20) DEFAULT NULL AFTER price");
        }
        
        // Payment transactions table
        $table_payments = $wpdb->prefix . 'lcp_payments';
        $sql_payments = "CREATE TABLE $table_payments (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            plan_id bigint(20) UNSIGNED,
            amount decimal(10,2) NOT NULL,
            currency varchar(10) DEFAULT 'USD',
            payment_method varchar(50),
            transaction_id varchar(255),
            status varchar(20) DEFAULT 'pending',
            payment_date datetime DEFAULT CURRENT_TIMESTAMP,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY status (status)
        ) $charset_collate;";
        dbDelta($sql_payments);
        
        // Insert default pricing plans
        self::insert_default_pricing_plans();
        
        update_option('lcp_db_version', LCP_VERSION);
    }
    
    /**
     * Insert default pricing plans
     */
    private static function insert_default_pricing_plans() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'lcp_pricing_plans';
        
        // Check if plans already exist
        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        
        if ($count == 0) {
            $default_plans = array(
                array(
                    'plan_name' => 'Scratch Ticket Bundle - 50 Tickets',
                    'plan_type' => 'tickets',
                    'ticket_count' => 50,
                    'client_limit' => 0,
                    'price' => 10.00,
                    'is_active' => 1,
                ),
                array(
                    'plan_name' => 'Client Expansion - 20 More Clients',
                    'plan_type' => 'clients',
                    'ticket_count' => 0,
                    'client_limit' => 20,
                    'price' => 15.00,
                    'is_active' => 1,
                ),
                array(
                    'plan_name' => 'Starter Package - 50 Tickets + 20 Clients',
                    'plan_type' => 'bundle',
                    'ticket_count' => 50,
                    'client_limit' => 20,
                    'price' => 20.00,
                    'is_active' => 1,
                ),
            );
            
            foreach ($default_plans as $plan) {
                $wpdb->insert($table, $plan);
            }
        }
    }
    
    /**
     * Drop all tables (use with caution!)
     */
    public static function drop_tables() {
        global $wpdb;
        
        $tables = array(
            $wpdb->prefix . 'lcp_clients',
            $wpdb->prefix . 'lcp_loyalty_cards',
            $wpdb->prefix . 'lcp_visits',
            $wpdb->prefix . 'lcp_tickets',
            $wpdb->prefix . 'lcp_subscriptions',
            $wpdb->prefix . 'lcp_pricing_plans',
            $wpdb->prefix . 'lcp_payments',
        );
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
        
        delete_option('lcp_db_version');
    }
}
