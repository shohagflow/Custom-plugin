<?php
/**
 * Plugin Name: Loyalty Card Pro
 * Plugin URI: https://loyaltycardpro.com
 * Description: A comprehensive digital loyalty card and scratch-off ticket system for beauticians with client management, rewards tracking, and engagement tools.
 * Version: 1.0.0
 * Author: Loyalty Card Pro Team
 * Author URI: https://loyaltycardpro.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: loyalty-card-pro
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 9.5
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('LCP_VERSION', '1.0.0');
define('LCP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LCP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('LCP_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Brand Colors
define('LCP_COLOR_PRIMARY', '#FE7AC1');
define('LCP_COLOR_SECONDARY', '#FFEFF7');
define('LCP_COLOR_WHITE', '#FFFFFF');

/**
 * Declare compatibility with WooCommerce features
 */
add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'cart_checkout_blocks',
            __FILE__,
            true
        );
    }
});

/**
 * Main plugin class
 */
class Loyalty_Card_Pro {
    
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    /**
     * Load required files
     */
    private function load_dependencies() {
        // Core classes
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-database.php';
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-roles.php';
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-client.php';
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-loyalty-card.php';
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-ticket.php';
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-subscription.php';
        
        // Admin classes
        require_once LCP_PLUGIN_DIR . 'admin/class-lcp-admin.php';
        require_once LCP_PLUGIN_DIR . 'admin/class-lcp-super-admin.php';
        require_once LCP_PLUGIN_DIR . 'admin/class-lcp-beautician-dashboard.php';
        
        // Frontend classes
        require_once LCP_PLUGIN_DIR . 'public/class-lcp-public.php';
        require_once LCP_PLUGIN_DIR . 'public/class-lcp-my-account.php';
        
        // AJAX handlers
        require_once LCP_PLUGIN_DIR . 'includes/class-lcp-ajax.php';
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        add_action('plugins_loaded', array($this, 'init'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'public_enqueue_scripts'));
        add_action('init', array($this, 'register_customer_registration_page'));
        add_action('template_redirect', array($this, 'customer_registration_template'));
        
        // AJAX handlers for customer registration
        add_action('wp_ajax_lcp_register_customer', array($this, 'ajax_register_customer'));
        add_action('wp_ajax_nopriv_lcp_register_customer', array($this, 'ajax_register_customer'));
        
        // AJAX handler to get customers
        add_action('wp_ajax_lcp_get_customers', array($this, 'ajax_get_customers'));
        
        // AJAX handler to get packages
        add_action('wp_ajax_lcp_get_packages', array($this, 'ajax_get_packages'));
        add_action('wp_ajax_nopriv_lcp_get_packages', array($this, 'ajax_get_packages'));
        
        // WooCommerce checkout redirection
        add_action('template_redirect', array($this, 'handle_buy_pkg_redirect'));
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Quick Fix: Disable PHP Error Reporting for warnings (hide "Undefined array key" warnings)
        // This suppresses warnings like "Undefined array key 'billing_company'"
        // Note: This is a temporary workaround - the proper fix is ensuring fields exist via hooks
        // Suppress warnings only on checkout pages to avoid hiding important errors elsewhere
        add_action('template_redirect', array($this, 'suppress_checkout_warnings'), 1);
        
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return;
        }
        
        // Initialize components
        LCP_Database::get_instance();
        LCP_Roles::get_instance();
        LCP_Admin::get_instance();
        LCP_Super_Admin::get_instance();
        LCP_Beautician_Dashboard::get_instance();
        LCP_Public::get_instance();
        LCP_My_Account::get_instance();
        LCP_Ajax::get_instance();
        
        // Load text domain
        load_plugin_textdomain('loyalty-card-pro', false, dirname(LCP_PLUGIN_BASENAME) . '/languages');
    }
    
    /**
     * Suppress PHP warnings on checkout pages (Quick Fix)
     * This hides "Undefined array key" warnings from other plugins
     * Specifically hides "Undefined array key 'billing_company'" warning
     */
    public function suppress_checkout_warnings() {
        // Only suppress on checkout pages
        if (function_exists('is_checkout') && is_checkout()) {
            // Suppress warnings and notices (hides "Undefined array key" warnings)
            // This is a quick fix - the proper solution is ensuring fields exist via hooks
            $current_error_reporting = error_reporting();
            error_reporting($current_error_reporting & ~E_WARNING & ~E_NOTICE);
            
            // Also suppress display_errors to prevent warnings from showing on screen
            // Only if not in admin (to avoid hiding important errors in admin)
            if (!is_admin()) {
                ini_set('display_errors', 0);
            }
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        LCP_Database::create_tables();
        LCP_Roles::add_roles();
        
        // Register the endpoints before flushing
        add_rewrite_endpoint('beautician-dashboard', EP_ROOT | EP_PAGES);
        add_action('init', array($this, 'register_customer_registration_page'));
        
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * Register customer registration page
     */
    public function register_customer_registration_page() {
        add_rewrite_rule(
            '^customer-registration/?$',
            'index.php?lcp_customer_registration=1',
            'top'
        );
        add_filter('query_vars', function($vars) {
            $vars[] = 'lcp_customer_registration';
            return $vars;
        });
    }
    
    /**
     * Load customer registration template
     */
    public function customer_registration_template() {
        if (get_query_var('lcp_customer_registration')) {
            include LCP_PLUGIN_DIR . 'public/templates/customer-registration.php';
            exit;
        }
    }
    
    /**
     * AJAX handler for customer registration
     */
    public function ajax_register_customer() {
        // Verify nonce for security
        check_ajax_referer('lcp_public_nonce', 'nonce');
        
        // Get form data
        $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
        $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
        $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        
        // Validate required fields
        if (empty($name) || empty($phone)) {
            wp_send_json_error(array('message' => __('Name and phone number are required.', 'loyalty-card-pro')));
            return;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'lcp_clients';
        
        // Check if customer already exists by phone
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE phone = %s",
            $phone
        ));
        
        if ($existing) {
            wp_send_json_error(array('message' => __('A customer with this phone number already exists.', 'loyalty-card-pro')));
            return;
        }
        
        // Insert new customer
        $result = $wpdb->insert(
            $table_name,
            array(
                'name' => $name,
                'phone' => $phone,
                'email' => $email,
                'loyalty_cards' => 0,
                'tickets' => 0,
                'visits' => 0,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ),
            array('%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s')
        );
        
        if ($result) {
            wp_send_json_success(array(
                'message' => __('Registration successful! Welcome to our loyalty program.', 'loyalty-card-pro'),
                'customer_id' => $wpdb->insert_id
            ));
        } else {
            wp_send_json_error(array('message' => __('Registration failed. Please try again.', 'loyalty-card-pro')));
        }
    }
    
    /**
     * AJAX handler to get all customers
     */
    public function ajax_get_customers() {
        // Check nonce
        check_ajax_referer('lcp_public_nonce', 'nonce');
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'lcp_clients';
        
        // Get all customers ordered by most recent first
        $customers = $wpdb->get_results(
            "SELECT * FROM $table_name ORDER BY created_at DESC",
            ARRAY_A
        );
        
        if ($customers) {
            wp_send_json_success(array('customers' => $customers));
        } else {
            wp_send_json_success(array('customers' => array()));
        }
    }
    
    /**
     * AJAX handler to get packages
     */
    public function ajax_get_packages() {
        // Check nonce
        check_ajax_referer('lcp_public_nonce', 'nonce');
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'lcp_pricing_plans';
        
        $plan_type = isset($_POST['plan_type']) ? sanitize_text_field($_POST['plan_type']) : '';
        
        if (empty($plan_type)) {
            wp_send_json_error(array('message' => __('Invalid plan type', 'loyalty-card-pro')));
        }
        
        // Get active packages of the requested type
        $packages = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE plan_type = %s AND is_active = 1 ORDER BY price ASC",
                $plan_type
            ),
            ARRAY_A
        );
        
        if ($packages) {
            wp_send_json_success(array('packages' => $packages));
        } else {
            wp_send_json_success(array('packages' => array()));
        }
    }
    
    /**
     * Handle WooCommerce checkout redirection via ?buy_pkg parameter
     */
    public function handle_buy_pkg_redirect() {
        // Check if buy_pkg parameter is set
        if (!isset($_GET['buy_pkg'])) {
            return;
        }
        
        // Check if test mode is enabled
        $test_mode = get_option('lcp_enable_test_mode', '0');
        $debug_info = array();
        
        // Check if WooCommerce payment is enabled
        $enable_wc_payment = get_option('lcp_enable_wc_payment', '0');
        if ($test_mode == '1') {
            $debug_info[] = sprintf(__('WooCommerce Payment Status: %s', 'loyalty-card-pro'), $enable_wc_payment == '1' ? '✓ Enabled' : '✗ Disabled');
        }
        if ($enable_wc_payment != '1') {
            return;
        }
        
        // Check if checkout redirection is active
        $enable_checkout_redirect = get_option('lcp_enable_checkout_redirect', '0');
        if ($test_mode == '1') {
            $debug_info[] = sprintf(__('Checkout Redirection Status: %s', 'loyalty-card-pro'), $enable_checkout_redirect == '1' ? '✓ Active' : '✗ Inactive');
        }
        if ($enable_checkout_redirect != '1') {
            wp_die(__('Checkout redirection is not active. Please enable it in Payment Gateway Settings.', 'loyalty-card-pro'));
            return;
        }
        
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            wp_die(__('WooCommerce is not active. Please install and activate WooCommerce to use this feature.', 'loyalty-card-pro'));
            return;
        }
        if ($test_mode == '1') {
            $debug_info[] = '✓ ' . __('WooCommerce is active', 'loyalty-card-pro');
        }
        
        // Get and validate product ID
        $product_id = absint($_GET['buy_pkg']);
        if ($test_mode == '1') {
            $debug_info[] = sprintf(__('Product ID: %d', 'loyalty-card-pro'), $product_id);
        }
        if ($product_id <= 0) {
            wp_die(__('Invalid product ID.', 'loyalty-card-pro'));
            return;
        }
        
        // Check if product exists
        $product = wc_get_product($product_id);
        if (!$product) {
            wp_die(__('Product not found.', 'loyalty-card-pro'));
            return;
        }
        if ($test_mode == '1') {
            $debug_info[] = sprintf(__('Product Found: %s (Price: %s)', 'loyalty-card-pro'), $product->get_name(), wc_price($product->get_price()));
        }
        
        // Show debug info in test mode
        if ($test_mode == '1') {
            $debug_info[] = '✓ ' . __('Clearing cart...', 'loyalty-card-pro');
            $debug_info[] = '✓ ' . __('Adding product to cart...', 'loyalty-card-pro');
            $debug_info[] = sprintf(__('Redirect URL: %s', 'loyalty-card-pro'), wc_get_checkout_url());
            
            echo '<div style="font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 30px; background: #f8f9fa; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">';
            echo '<div style="background: linear-gradient(135deg, #FF9800 0%, #F57C00 100%); padding: 20px; border-radius: 8px 8px 0 0; margin: -30px -30px 20px -30px;">';
            echo '<h2 style="margin: 0; color: white; display: flex; align-items: center; gap: 10px;"><span style="font-size: 24px;">🛠️</span> Test Mode - Debug Information</h2>';
            echo '</div>';
            echo '<div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">';
            echo '<h3 style="color: #FF9800; margin-top: 0;">Checkout Redirection Process:</h3>';
            echo '<ul style="line-height: 2; color: #333;">';
            foreach ($debug_info as $info) {
                echo '<li>' . esc_html($info) . '</li>';
            }
            echo '</ul>';
            echo '</div>';
            echo '<div style="background: #E3F2FD; padding: 15px; border-radius: 8px; border-left: 4px solid #2196F3; margin-bottom: 20px;">';
            echo '<p style="margin: 0; color: #1565C0;"><strong>ℹ️ Note:</strong> In Test Mode, the redirect is paused so you can review the process. Click the button below to proceed to checkout.</p>';
            echo '</div>';
            echo '<a href="' . esc_url(wc_get_checkout_url()) . '" style="display: inline-block; background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: 600; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: transform 0.2s;" onmouseover="this.style.transform=\'translateY(-2px)\'" onmouseout="this.style.transform=\'translateY(0)\'">✓ Continue to Checkout</a>';
            echo ' <a href="' . esc_url(home_url()) . '" style="display: inline-block; background: #757575; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: 600; margin-left: 10px;">← Back to Home</a>';
            echo '</div>';
            exit;
        }
        
        // Clear cart
        WC()->cart->empty_cart();
        
        // Add product to cart
        $added = WC()->cart->add_to_cart($product_id);
        
        if ($added) {
            // Redirect to checkout
            wp_safe_redirect(wc_get_checkout_url());
            exit;
        } else {
            wp_die(__('Failed to add product to cart. Please try again.', 'loyalty-card-pro'));
        }
    }
    
    /**
     * WooCommerce missing notice
     */
    public function woocommerce_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('Loyalty Card Pro requires WooCommerce to be installed and active.', 'loyalty-card-pro'); ?></p>
        </div>
        <?php
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function admin_enqueue_scripts($hook) {
        wp_enqueue_style('lcp-admin-style', LCP_PLUGIN_URL . 'assets/css/admin-style.css', array(), LCP_VERSION);
        wp_enqueue_script('lcp-admin-script', LCP_PLUGIN_URL . 'assets/js/admin-script.js', array('jquery'), LCP_VERSION, true);
        
        // Localize script
        wp_localize_script('lcp-admin-script', 'lcpAdmin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('lcp_admin_nonce'),
            'colors' => array(
                'primary' => LCP_COLOR_PRIMARY,
                'secondary' => LCP_COLOR_SECONDARY,
                'white' => LCP_COLOR_WHITE,
            ),
        ));
    }
    
    /**
     * Enqueue public scripts and styles
     */
    public function public_enqueue_scripts() {
        wp_enqueue_style('lcp-public-style', LCP_PLUGIN_URL . 'assets/css/public-style.css', array(), LCP_VERSION);
        wp_enqueue_script('lcp-public-script', LCP_PLUGIN_URL . 'assets/js/public-script.js', array('jquery'), LCP_VERSION, true);
        
        // Localize script
        wp_localize_script('lcp-public-script', 'lcpPublic', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('lcp_public_nonce'),
            'colors' => array(
                'primary' => LCP_COLOR_PRIMARY,
                'secondary' => LCP_COLOR_SECONDARY,
                'white' => LCP_COLOR_WHITE,
            ),
        ));
    }
}

/**
 * Initialize the plugin
 */
function lcp_init() {
    return Loyalty_Card_Pro::get_instance();
}

// Start the plugin
lcp_init();
