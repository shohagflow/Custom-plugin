jQuery(document).ready(function($) {

    var i18n = cpof_ajax.i18n || {};

    function cpof_format_price(price) {
        return parseFloat(price).toFixed(2);
    }

    function cpof_format_money(price) {
        var symbol = cpof_ajax.currency_symbol || '€';
        return symbol + cpof_format_price(price);
    }

    function cpof_get_delivery_fee() {
        return $('input[name="delivery_method"]:checked').val() === 'delivery'
            ? parseFloat(cpof_ajax.delivery_fee || 0)
            : 0;
    }

    function cpof_toggle_delivery_address_required() {
        var isDelivery = $('input[name="delivery_method"]:checked').val() === 'delivery';
        var $field = $('#cpof_delivery_address');
        var $group = $('.cpof-delivery-address-group');

        $field.prop('required', isDelivery);

        if (isDelivery) {
            $group.show();
        } else {
            $field.val('').css('border-color', '#EDEDED');
            $group.removeClass('is-error');
        }
    }

    function cpof_update_order_totals() {
        var product = cpof_ajax.default_product;

        if (!product || !product.id) {
            return;
        }

        var productPrice = parseFloat(product.price);
        var deliveryFee = cpof_get_delivery_fee();
        var total = productPrice + deliveryFee;
        var formattedProductPrice = cpof_format_money(productPrice);
        var formattedTotal = cpof_format_money(total);

        $('#cpof_preview_subtotal').text(formattedProductPrice);
        $('#cpof_order_subtotal').text(formattedProductPrice);
        $('#cpof_order_total').text(formattedTotal);

        if (deliveryFee > 0) {
            $('#cpof_delivery_amount').text('+ ' + cpof_format_money(deliveryFee));
        } else {
            $('#cpof_delivery_amount').text(i18n.collection_free || 'Point de collecte - Gratuit');
        }

        $('#cpof_pay_button').prop('disabled', false).text((i18n.create_order || 'Créer la commande') + ' - ' + formattedTotal);
    }

    function cpof_apply_default_product() {
        var product = cpof_ajax.default_product;

        if (!product || !product.id) {
            return;
        }

        $('#cpof_selected_product_id').val(product.id);
        $('#cpof_preview_title').text(product.title);
        $('#cpof_preview_product_image').attr('src', product.image || '');
        $('#cpof_product_preview').show();
        cpof_update_order_totals();
    }

    $('input[name="delivery_method"]').on('change', function() {
        $('.cpof-delivery-options').removeClass('is-error');
        cpof_toggle_delivery_address_required();
        cpof_update_order_totals();
    });

    $('#cpof_email, #cpof_email_confirm').on('input', function() {
        $(this).css('border-color', '#EDEDED');
    });

    $('#cpof_delivery_address').on('input', function() {
        $(this).css('border-color', '#EDEDED');
        $('.cpof-delivery-address-group').removeClass('is-error');
    });

    $('#cpof_order_form').on('submit', function(e) {
        e.preventDefault();

        var isValid = true;
        $('#cpof_order_form input[required]:not([type="checkbox"]):not([type="radio"]), #cpof_order_form select[required], #cpof_order_form textarea[required]').each(function() {
            if (!$(this).val()) {
                isValid = false;
                $(this).css('border-color', 'red');
            } else {
                $(this).css('border-color', '#EDEDED');
            }
        });

        if (!$('input[name="delivery_method"]:checked').length) {
            isValid = false;
            $('.cpof-delivery-options').addClass('is-error');
        } else {
            $('.cpof-delivery-options').removeClass('is-error');
        }

        var $termsGroup = $('.cpof-terms-group');
        if (!$('#cpof_terms_accepted').is(':checked')) {
            isValid = false;
            $termsGroup.addClass('is-error');
        } else {
            $termsGroup.removeClass('is-error');
        }

        if ($('#cpof_email').val() !== $('#cpof_email_confirm').val()) {
            isValid = false;
            $('#cpof_email, #cpof_email_confirm').css('border-color', 'red');
        }

        if (!isValid) {
            alert(i18n.fill_required || 'Veuillez remplir tous les champs obligatoires, confirmer votre adresse e-mail et accepter les conditions relatives à vos données personnelles.');
            return;
        }

        if ($('input[name="delivery_method"]:checked').val() === 'delivery' && !$.trim($('#cpof_delivery_address').val())) {
            $('.cpof-delivery-address-group').addClass('is-error');
            $('#cpof_delivery_address').css('border-color', 'red');
            alert(i18n.delivery_address_req || 'Veuillez saisir votre adresse de livraison.');
            return;
        }

        if (!$('#cpof_selected_product_id').val()) {
            alert(i18n.no_product || 'Aucun produit disponible pour cette commande.');
            return;
        }

        var $btn = $('#cpof_pay_button');
        var $msg = $('#cpof_form_message');
        var originalBtnText = $btn.text();

        $btn.prop('disabled', true).text(i18n.redirect_stripe || 'Redirection vers Stripe...');
        $msg.removeClass('error success').hide();

        var formData = $(this).serialize();
        formData += '&action=cpof_start_checkout';
        formData += '&nonce=' + cpof_ajax.nonce;
        formData += '&return_url=' + encodeURIComponent(cpof_ajax.return_url || window.location.href.split('?')[0]);

        $.ajax({
            url: cpof_ajax.ajax_url,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success && response.data.redirect_url) {
                    window.location.href = response.data.redirect_url;
                    return;
                }

                $msg.addClass('error').text(response.data && response.data.message ? response.data.message : (i18n.generic_error || 'Une erreur est survenue.')).show();
                $btn.prop('disabled', false).text(originalBtnText);
            },
            error: function() {
                $msg.addClass('error').text(i18n.checkout_error || 'Une erreur est survenue lors de la création de votre commande. Veuillez réessayer.').show();
                $btn.prop('disabled', false).text(originalBtnText);
            }
        });
    });

    $('#cpof_terms_accepted').on('change', function() {
        $('.cpof-terms-group').removeClass('is-error');
    });

    function cpof_reset_form() {
        $('#cpof_order_form')[0].reset();
        $('.cpof-terms-group').removeClass('is-error');
        $('.cpof-delivery-options').removeClass('is-error');
        $('.cpof-delivery-address-group').removeClass('is-error');
        $('#cpof_form_message').removeClass('error success').hide();
        cpof_toggle_delivery_address_required();
        cpof_apply_default_product();
    }

    cpof_toggle_delivery_address_required();
    cpof_apply_default_product();

    $('#cpof_close_confirmation').on('click', function() {
        $('#cpof_order_confirmation_modal').fadeOut(200);
        cpof_reset_form();
    });

    function cpof_clean_payment_url() {
        if (window.history.replaceState) {
            window.history.replaceState({}, document.title, cpof_ajax.return_url || window.location.pathname);
        }
    }

    if (cpof_ajax.payment_result && cpof_ajax.payment_result.status) {
        if (cpof_ajax.payment_result.status === 'success') {
            if (cpof_ajax.payment_result.message) {
                $('#cpof_confirmation_message').text(cpof_ajax.payment_result.message);
            }

            cpof_reset_form();
            $('#cpof_order_confirmation_modal').fadeIn(200);
            cpof_clean_payment_url();
        } else if (cpof_ajax.payment_result.status === 'cancel') {
            cpof_reset_form();
            alert(cpof_ajax.payment_result.message);
            cpof_clean_payment_url();
        } else if (cpof_ajax.payment_result.status === 'error') {
            cpof_reset_form();
            alert(cpof_ajax.payment_result.message);
            cpof_clean_payment_url();
        }
    }
});
