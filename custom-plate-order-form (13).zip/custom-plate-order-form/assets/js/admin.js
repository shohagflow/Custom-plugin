jQuery(document).ready(function($) {
    var $copyBtn = $('#cpof-copy-shortcode');
    var $shortcode = $('#cpof-shortcode-text');

    if ($copyBtn.length && $shortcode.length) {
        var defaultHtml = $copyBtn.html();

        $copyBtn.on('click', function() {
            var text = $shortcode.text().trim();

            if (!text) {
                return;
            }

            function showCopiedState() {
                $copyBtn.addClass('cpof-btn--copied').text('Copied!');

                window.setTimeout(function() {
                    $copyBtn.removeClass('cpof-btn--copied').html(defaultHtml);
                }, 1800);
            }

            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(showCopiedState);
                return;
            }

            var $temp = $('<textarea>');
            $('body').append($temp);
            $temp.val(text).select();
            document.execCommand('copy');
            $temp.remove();
            showCopiedState();
        });
    }

    function cpofToggleStripeFields() {
        if ($('#cpof_stripe_test_mode').is(':checked')) {
            $('#cpof-test-stripe-fields').show();
            $('#cpof-live-stripe-note').hide();
        } else {
            $('#cpof-test-stripe-fields').hide();
            $('#cpof-live-stripe-note').show();
        }
    }

    $('#cpof_stripe_test_mode').on('change', cpofToggleStripeFields);
    cpofToggleStripeFields();
});
