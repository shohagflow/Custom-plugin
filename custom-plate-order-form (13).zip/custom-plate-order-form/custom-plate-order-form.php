<?php
/**
 * Plugin Name: Custom Plate Order Form
 * Description: A custom plugin to order plates with live preview and WooCommerce integration.
 * Version: 1.1.7
 * Author: Shohag Rana 
 * Text Domain: custom-plate-order-form
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'CPOF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CPOF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CPOF_VERSION', '1.3.6' );
define( 'CPOF_DELIVERY_FEE_DEFAULT', 25 );

/**
 * Get the configured delivery fee for Livraison orders.
 */
function cpof_get_delivery_fee() {
    $fee = get_option( 'cpof_delivery_fee', CPOF_DELIVERY_FEE_DEFAULT );

    return max( 0, round( (float) $fee, 2 ) );
}

/**
 * French departments and overseas regions for the order form.
 *
 * @return array<string, string>
 */
function cpof_get_french_regions() {
    return array(
        '01'  => '01 - Ain',
        '02'  => '02 - Aisne',
        '03'  => '03 - Allier',
        '04'  => '04 - Alpes-de-Haute-Provence',
        '05'  => '05 - Hautes-Alpes',
        '06'  => '06 - Alpes-Maritimes',
        '07'  => '07 - Ardèche',
        '08'  => '08 - Ardennes',
        '09'  => '09 - Ariège',
        '10'  => '10 - Aube',
        '11'  => '11 - Aude',
        '12'  => '12 - Aveyron',
        '13'  => '13 - Bouches-du-Rhône',
        '14'  => '14 - Calvados',
        '15'  => '15 - Cantal',
        '16'  => '16 - Charente',
        '17'  => '17 - Charente-Maritime',
        '18'  => '18 - Cher',
        '19'  => '19 - Corrèze',
        '2A'  => '2A - Corse-du-Sud',
        '2B'  => '2B - Haute-Corse',
        '21'  => '21 - Côte-d\'Or',
        '22'  => '22 - Côtes-d\'Armor',
        '23'  => '23 - Creuse',
        '24'  => '24 - Dordogne',
        '25'  => '25 - Doubs',
        '26'  => '26 - Drôme',
        '27'  => '27 - Eure',
        '28'  => '28 - Eure-et-Loir',
        '29'  => '29 - Finistère',
        '30'  => '30 - Gard',
        '31'  => '31 - Haute-Garonne',
        '32'  => '32 - Gers',
        '33'  => '33 - Gironde',
        '34'  => '34 - Hérault',
        '35'  => '35 - Ille-et-Vilaine',
        '36'  => '36 - Indre',
        '37'  => '37 - Indre-et-Loire',
        '38'  => '38 - Isère',
        '39'  => '39 - Jura',
        '40'  => '40 - Landes',
        '41'  => '41 - Loir-et-Cher',
        '42'  => '42 - Loire',
        '43'  => '43 - Haute-Loire',
        '44'  => '44 - Loire-Atlantique',
        '45'  => '45 - Loiret',
        '46'  => '46 - Lot',
        '47'  => '47 - Lot-et-Garonne',
        '48'  => '48 - Lozère',
        '49'  => '49 - Maine-et-Loire',
        '50'  => '50 - Manche',
        '51'  => '51 - Marne',
        '52'  => '52 - Haute-Marne',
        '53'  => '53 - Mayenne',
        '54'  => '54 - Meurthe-et-Moselle',
        '55'  => '55 - Meuse',
        '56'  => '56 - Morbihan',
        '57'  => '57 - Moselle',
        '58'  => '58 - Nièvre',
        '59'  => '59 - Nord',
        '60'  => '60 - Oise',
        '61'  => '61 - Orne',
        '62'  => '62 - Pas-de-Calais',
        '63'  => '63 - Puy-de-Dôme',
        '64'  => '64 - Pyrénées-Atlantiques',
        '65'  => '65 - Hautes-Pyrénées',
        '66'  => '66 - Pyrénées-Orientales',
        '67'  => '67 - Bas-Rhin',
        '68'  => '68 - Haut-Rhin',
        '69'  => '69 - Rhône',
        '70'  => '70 - Haute-Saône',
        '71'  => '71 - Saône-et-Loire',
        '72'  => '72 - Sarthe',
        '73'  => '73 - Savoie',
        '74'  => '74 - Haute-Savoie',
        '75'  => '75 - Paris',
        '76'  => '76 - Seine-Maritime',
        '77'  => '77 - Seine-et-Marne',
        '78'  => '78 - Yvelines',
        '79'  => '79 - Deux-Sèvres',
        '80'  => '80 - Somme',
        '81'  => '81 - Tarn',
        '82'  => '82 - Tarn-et-Garonne',
        '83'  => '83 - Var',
        '84'  => '84 - Vaucluse',
        '85'  => '85 - Vendée',
        '86'  => '86 - Vienne',
        '87'  => '87 - Haute-Vienne',
        '88'  => '88 - Vosges',
        '89'  => '89 - Yonne',
        '90'  => '90 - Territoire de Belfort',
        '91'  => '91 - Essonne',
        '92'  => '92 - Hauts-de-Seine',
        '93'  => '93 - Seine-Saint-Denis',
        '94'  => '94 - Val-de-Marne',
        '95'  => '95 - Val-d\'Oise',
        '971' => '971 - Guadeloupe',
        '972' => '972 - Martinique',
        '973' => '973 - Guyane',
        '974' => '974 - La Réunion',
        '976' => '976 - Mayotte',
    );
}

/**
 * Normalize a French department code for comparisons.
 */
function cpof_format_region_code( $code ) {
    $code = strtoupper( trim( (string) $code ) );

    if ( preg_match( '/^\d{1,2}$/', $code ) ) {
        return str_pad( $code, 2, '0', STR_PAD_LEFT );
    }

    return $code;
}

/**
 * Resolve submitted region value to a canonical department code.
 */
function cpof_resolve_region_code( $region ) {
    $region = strtoupper( trim( sanitize_text_field( (string) $region ) ) );

    if ( '' === $region ) {
        return '';
    }

    foreach ( cpof_get_french_regions() as $code => $label ) {
        $canonical_code = cpof_format_region_code( $code );

        if ( $canonical_code === cpof_format_region_code( $region ) ) {
            return $canonical_code;
        }

        if ( strtoupper( (string) $code ) === $region ) {
            return $canonical_code;
        }
    }

    return '';
}

/**
 * Get the display label for a French region code.
 */
function cpof_get_french_region_label( $region_code ) {
    $resolved_code = cpof_resolve_region_code( $region_code );

    if ( '' === $resolved_code ) {
        return $region_code;
    }

    foreach ( cpof_get_french_regions() as $code => $label ) {
        if ( cpof_format_region_code( $code ) === $resolved_code ) {
            return $label;
        }
    }

    return $region_code;
}

require_once CPOF_PLUGIN_DIR . 'includes/class-cpof-stripe.php';
require_once CPOF_PLUGIN_DIR . 'includes/class-cpof-admin.php';

/**
 * Check whether WooCommerce is active (site or network).
 */
function cpof_is_woocommerce_active() {
    if ( class_exists( 'WooCommerce' ) ) {
        return true;
    }

    if ( ! function_exists( 'is_plugin_active' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
        return true;
    }

    if ( is_multisite() && function_exists( 'is_plugin_active_for_network' ) ) {
        return is_plugin_active_for_network( 'woocommerce/woocommerce.php' );
    }

    return false;
}

function cpof_init() {
    new CPOF_Admin();

    if ( cpof_is_woocommerce_active() ) {
        require_once CPOF_PLUGIN_DIR . 'includes/class-cpof-frontend.php';
        require_once CPOF_PLUGIN_DIR . 'includes/class-cpof-woocommerce.php';

        new CPOF_Frontend();
        new CPOF_WooCommerce();
        return;
    }

    add_action( 'admin_notices', 'cpof_woocommerce_missing_notice' );
}
add_action( 'plugins_loaded', 'cpof_init' );

function cpof_woocommerce_missing_notice() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="notice notice-error is-dismissible">
        <p>
            <strong><?php esc_html_e( 'Custom Plate Order Form', 'custom-plate-order-form' ); ?></strong>
            <?php esc_html_e( 'requires WooCommerce to be installed and activated. The order form will not work until WooCommerce is enabled.', 'custom-plate-order-form' ); ?>
        </p>
    </div>
    <?php
}
