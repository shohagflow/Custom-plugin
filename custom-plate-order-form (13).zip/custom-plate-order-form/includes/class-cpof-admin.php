<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CPOF_Admin {

    private $page_slug = 'cpof-settings';

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
    }

    public function add_admin_menu() {
        add_menu_page(
            __( 'Order Plate Settings', 'custom-plate-order-form' ),
            __( 'Order Plate', 'custom-plate-order-form' ),
            'manage_options',
            $this->page_slug,
            array( $this, 'settings_page_html' ),
            'dashicons-car',
            56
        );
    }

    public function enqueue_admin_assets( $hook ) {
        if ( 'toplevel_page_' . $this->page_slug !== $hook ) {
            return;
        }

        wp_enqueue_style(
            'cpof-admin-style',
            CPOF_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            CPOF_VERSION
        );

        wp_enqueue_script(
            'cpof-admin-script',
            CPOF_PLUGIN_URL . 'assets/js/admin.js',
            array( 'jquery' ),
            CPOF_VERSION,
            true
        );
    }

    public function register_settings() {
        register_setting( 'cpof_settings_group', 'cpof_delivery_fee', array( $this, 'sanitize_delivery_fee' ) );
        register_setting( 'cpof_settings_group', 'cpof_stripe_test_mode', array( $this, 'sanitize_bool' ) );
        register_setting( 'cpof_settings_group', 'cpof_stripe_test_publishable_key', array( $this, 'sanitize_text' ) );
        register_setting( 'cpof_settings_group', 'cpof_stripe_test_secret_key', array( $this, 'sanitize_text' ) );
    }

    public function sanitize_text( $value ) {
        return sanitize_text_field( $value );
    }

    public function sanitize_bool( $value ) {
        return ! empty( $value ) ? 1 : 0;
    }

    public function sanitize_delivery_fee( $value ) {
        if ( function_exists( 'wc_format_decimal' ) ) {
            $fee = wc_format_decimal( $value, 2 );
        } else {
            $fee = number_format( (float) $value, 2, '.', '' );
        }

        return max( 0, (float) $fee );
    }

    public function settings_page_html() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $orders_url     = admin_url( 'admin.php?page=wc-orders' );
        $products_url   = admin_url( 'edit.php?post_type=product' );
        $wc_settings    = admin_url( 'admin.php?page=wc-settings&tab=general' );
        $payments_url   = admin_url( 'admin.php?page=wc-settings&tab=checkout' );
        $shortcode      = '[plate_order_form]';
        $stripe_status  = CPOF_Stripe::get_config_status();
        $wc_stripe_url  = $stripe_status['woocommerce_stripe_settings'];
        ?>
        <div class="wrap cpof-admin-wrap">
            <h1 class="screen-reader-text"><?php esc_html_e( 'Order Plate Settings', 'custom-plate-order-form' ); ?></h1>

            <header class="cpof-admin-header">
                <p class="cpof-admin-title"><?php esc_html_e( 'Order Plate Settings', 'custom-plate-order-form' ); ?></p>
            </header>

            <div class="cpof-admin-grid">
                <div class="cpof-admin-main">
                    <section class="cpof-card">
                        <div class="cpof-card__header">
                            <h2><?php esc_html_e( 'Order Form Shortcode', 'custom-plate-order-form' ); ?></h2>
                            <p><?php esc_html_e( 'Add this shortcode to any page or post to display the plate order form.', 'custom-plate-order-form' ); ?></p>
                        </div>
                        <div class="cpof-shortcode-box">
                            <code id="cpof-shortcode-text"><?php echo esc_html( $shortcode ); ?></code>
                            <button type="button" class="cpof-btn cpof-btn--secondary" id="cpof-copy-shortcode">
                                <span class="dashicons dashicons-admin-page"></span>
                                <?php esc_html_e( 'Copy', 'custom-plate-order-form' ); ?>
                            </button>
                        </div>
                    </section>

                    <form method="post" action="options.php" class="cpof-settings-form">
                        <?php settings_fields( 'cpof_settings_group' ); ?>

                    <section class="cpof-card">
                        <div class="cpof-card__header cpof-card__header--compact">
                            <h2><?php esc_html_e( 'Delivery Settings', 'custom-plate-order-form' ); ?></h2>
                            <p><?php esc_html_e( 'Configure the extra charge added when a customer selects Livraison on the order form.', 'custom-plate-order-form' ); ?></p>
                        </div>

                            <div class="cpof-field">
                                <label for="cpof_delivery_fee"><?php esc_html_e( 'Delivery charge', 'custom-plate-order-form' ); ?></label>
                                <input name="cpof_delivery_fee" type="number" id="cpof_delivery_fee" value="<?php echo esc_attr( cpof_get_delivery_fee() ); ?>" class="cpof-input cpof-input--number" min="0" step="0.01" />
                                <span class="cpof-field__help"><?php esc_html_e( 'This amount is added to the product price on the invoice and Stripe checkout when Livraison is selected. Point de collecte stays free.', 'custom-plate-order-form' ); ?></span>
                            </div>
                    </section>

                    <section class="cpof-card">
                        <div class="cpof-card__header cpof-card__header--compact">
                            <h2><?php esc_html_e( 'Stripe Payment', 'custom-plate-order-form' ); ?></h2>
                            <p><?php esc_html_e( 'The order form always redirects customers to Stripe Checkout to pay. Test mode OFF uses live WooCommerce Stripe keys for real payments.', 'custom-plate-order-form' ); ?></p>
                        </div>

                            <div class="cpof-field cpof-field--toggle">
                                <label class="cpof-toggle" for="cpof_stripe_test_mode">
                                    <input type="hidden" name="cpof_stripe_test_mode" value="0" />
                                    <input name="cpof_stripe_test_mode" type="checkbox" id="cpof_stripe_test_mode" value="1" <?php checked( 1, get_option( 'cpof_stripe_test_mode', 0 ) ); ?> />
                                    <span class="cpof-toggle__slider"></span>
                                </label>
                                <div class="cpof-field__content">
                                    <strong><?php esc_html_e( 'Test mode', 'custom-plate-order-form' ); ?></strong>
                                    <span><?php esc_html_e( 'ON = test keys below. OFF = live payments via WooCommerce Stripe.', 'custom-plate-order-form' ); ?></span>
                                </div>
                            </div>

                            <div id="cpof-test-stripe-fields" class="cpof-custom-stripe-fields">
                                <div class="cpof-field">
                                    <label for="cpof_stripe_test_publishable_key"><?php esc_html_e( 'Test publishable key', 'custom-plate-order-form' ); ?></label>
                                    <input name="cpof_stripe_test_publishable_key" type="text" id="cpof_stripe_test_publishable_key" value="<?php echo esc_attr( get_option( 'cpof_stripe_test_publishable_key', '' ) ); ?>" class="cpof-input" placeholder="pk_test_..." />
                                </div>

                                <div class="cpof-field">
                                    <label for="cpof_stripe_test_secret_key"><?php esc_html_e( 'Test secret key', 'custom-plate-order-form' ); ?></label>
                                    <input name="cpof_stripe_test_secret_key" type="password" id="cpof_stripe_test_secret_key" value="<?php echo esc_attr( get_option( 'cpof_stripe_test_secret_key', '' ) ); ?>" class="cpof-input" placeholder="sk_test_..." autocomplete="off" />
                                    <span class="cpof-field__help"><?php esc_html_e( 'Test card: 4242 4242 4242 4242 · any future date · any CVC', 'custom-plate-order-form' ); ?></span>
                                </div>
                            </div>

                            <div id="cpof-live-stripe-note" class="cpof-info-box">
                                <strong><?php esc_html_e( 'Live payments', 'custom-plate-order-form' ); ?></strong>
                                <p>
                                    <?php
                                    printf(
                                        wp_kses(
                                            /* translators: %s: WooCommerce Stripe settings URL */
                                            __( 'Turn test mode OFF and add your live Stripe keys in <a href="%s">WooCommerce → Payments → Stripe</a>. Customers will pay with real cards.', 'custom-plate-order-form' ),
                                            array( 'a' => array( 'href' => array() ) )
                                        ),
                                        esc_url( $wc_stripe_url )
                                    );
                                    ?>
                                </p>
                            </div>
                    </section>

                        <?php submit_button( __( 'Save Settings', 'custom-plate-order-form' ), 'primary cpof-btn cpof-btn--primary', 'submit', false ); ?>
                    </form>
                </div>

                <aside class="cpof-admin-sidebar">
                    <section class="cpof-card cpof-card--compact">
                        <div class="cpof-card__header">
                            <h2><?php esc_html_e( 'Quick Links', 'custom-plate-order-form' ); ?></h2>
                        </div>
                        <nav class="cpof-link-list">
                            <a href="<?php echo esc_url( $orders_url ); ?>" class="cpof-link-item">
                                <span class="dashicons dashicons-list-view"></span>
                                <span><?php esc_html_e( 'WooCommerce Orders', 'custom-plate-order-form' ); ?></span>
                            </a>
                            <a href="<?php echo esc_url( $products_url ); ?>" class="cpof-link-item">
                                <span class="dashicons dashicons-products"></span>
                                <span><?php esc_html_e( 'Manage Products', 'custom-plate-order-form' ); ?></span>
                            </a>
                            <a href="<?php echo esc_url( $payments_url ); ?>" class="cpof-link-item">
                                <span class="dashicons dashicons-money-alt"></span>
                                <span><?php esc_html_e( 'Payment Gateways', 'custom-plate-order-form' ); ?></span>
                            </a>
                            <?php if ( $stripe_status['woocommerce_stripe_active'] ) : ?>
                                <a href="<?php echo esc_url( $wc_stripe_url ); ?>" class="cpof-link-item">
                                    <span class="dashicons dashicons-admin-plugins"></span>
                                    <span><?php esc_html_e( 'WooCommerce Stripe Settings', 'custom-plate-order-form' ); ?></span>
                                </a>
                            <?php endif; ?>
                            <a href="<?php echo esc_url( $wc_settings ); ?>" class="cpof-link-item">
                                <span class="dashicons dashicons-admin-site"></span>
                                <span><?php esc_html_e( 'Countries & Store Settings', 'custom-plate-order-form' ); ?></span>
                            </a>
                        </nav>
                    </section>
                </aside>
            </div>
        </div>
        <?php
    }
}
