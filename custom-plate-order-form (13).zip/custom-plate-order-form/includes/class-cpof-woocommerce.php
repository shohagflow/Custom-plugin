<?php

if ( ! defined( 'ABSPATH' ) ) {

    exit;

}



class CPOF_WooCommerce {



    public function __construct() {

        add_action( 'wp_ajax_cpof_start_checkout', array( $this, 'start_checkout' ) );

        add_action( 'wp_ajax_nopriv_cpof_start_checkout', array( $this, 'start_checkout' ) );

    }



    /**

     * Create WooCommerce order and redirect to Stripe Checkout.

     */

    public function start_checkout() {

        check_ajax_referer( 'cpof_checkout_nonce', 'nonce' );



        $first_name   = sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) );

        $last_name    = sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) );

        $civilite     = sanitize_text_field( wp_unslash( $_POST['civilite'] ?? '' ) );

        $email           = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );

        $email_confirm   = sanitize_email( wp_unslash( $_POST['email_confirm'] ?? '' ) );

        $phone           = sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) );

        $number_plate    = sanitize_text_field( wp_unslash( $_POST['number_plate'] ?? '' ) );

        $region = cpof_resolve_region_code( wp_unslash( $_POST['region'] ?? ( $_POST['country'] ?? '' ) ) );

        $delivery_address = sanitize_textarea_field( wp_unslash( $_POST['delivery_address'] ?? '' ) );

        $product_id     = absint( $_POST['plate_id'] ?? 0 );

        $delivery_method = sanitize_text_field( wp_unslash( $_POST['delivery_method'] ?? '' ) );

        $terms_accepted = ! empty( $_POST['cpof_terms_accepted'] );

        $return_url   = esc_url_raw( wp_unslash( $_POST['return_url'] ?? '' ) );



        if ( empty( $first_name ) || empty( $last_name ) || empty( $civilite ) || empty( $email ) || empty( $phone ) || empty( $number_plate ) || empty( $region ) || empty( $product_id ) ) {

            wp_send_json_error( array( 'message' => __( 'Champs obligatoires manquants.', 'custom-plate-order-form' ) ) );

        }



        $allowed_civilites = array( 'mr', 'mme', 'mlle' );

        if ( ! in_array( $civilite, $allowed_civilites, true ) ) {

            wp_send_json_error( array( 'message' => __( 'Civilité invalide.', 'custom-plate-order-form' ) ) );

        }



        if ( ! $terms_accepted ) {

            wp_send_json_error( array( 'message' => __( 'Veuillez accepter les conditions relatives à vos données personnelles.', 'custom-plate-order-form' ) ) );

        }



        $allowed_delivery_methods = array( 'delivery', 'collection_point' );

        if ( ! in_array( $delivery_method, $allowed_delivery_methods, true ) ) {

            wp_send_json_error( array( 'message' => __( 'Mode de réception invalide.', 'custom-plate-order-form' ) ) );

        }



        if ( ! is_email( $email ) ) {

            wp_send_json_error( array( 'message' => __( 'Adresse e-mail invalide.', 'custom-plate-order-form' ) ) );

        }



        if ( empty( $email_confirm ) || $email !== $email_confirm ) {

            wp_send_json_error( array( 'message' => __( 'Les adresses e-mail ne correspondent pas.', 'custom-plate-order-form' ) ) );

        }



        if ( 'delivery' === $delivery_method && empty( $delivery_address ) ) {

            wp_send_json_error( array( 'message' => __( 'Veuillez saisir votre adresse de livraison.', 'custom-plate-order-form' ) ) );

        }



        if ( empty( $region ) ) {

            wp_send_json_error( array( 'message' => __( 'Région invalide.', 'custom-plate-order-form' ) ) );

        }



        if ( empty( $return_url ) ) {

            $return_url = wp_get_referer() ? wp_get_referer() : home_url( '/' );

        }



        $return_url = remove_query_arg( array( 'cpof_oid', 'cpof_t', 'cpof_cancel', 'cpof_payment', 'session_id' ), $return_url );



        $product = wc_get_product( $product_id );

        if ( ! $product || ! $product->is_purchasable() ) {

            wp_send_json_error( array( 'message' => __( 'Produit invalide sélectionné.', 'custom-plate-order-form' ) ) );

        }

        $stripe_check = CPOF_Stripe::validate_checkout_config();

        if ( is_wp_error( $stripe_check ) ) {

            wp_send_json_error( array( 'message' => $stripe_check->get_error_message() ) );

        }



        try {

            $customer    = $this->create_or_get_customer( $email, $first_name, $last_name, $phone );

            $customer_id = $customer->get_id();



            $order = wc_create_order(

                array(

                    'customer_id' => $customer_id,

                    'status'      => 'pending',

                )

            );



            if ( is_wp_error( $order ) ) {

                wp_send_json_error(

                    array(

                        'message' => sprintf(

                            /* translators: %s: error message */

                            __( 'Échec de la création de la commande : %s', 'custom-plate-order-form' ),

                            $order->get_error_message()

                        ),

                    )

                );

            }



            $order->add_product( $product, 1 );

            if ( 'delivery' === $delivery_method ) {

                $delivery_fee = new WC_Order_Item_Fee();

                $delivery_fee->set_name( __( 'Livraison', 'custom-plate-order-form' ) );

                $delivery_fee->set_amount( cpof_get_delivery_fee() );

                $delivery_fee->set_total( cpof_get_delivery_fee() );

                $delivery_fee->set_tax_status( 'none' );

                $order->add_item( $delivery_fee );

            }

            $order->calculate_totals();



            $order->set_payment_method( 'stripe' );

            $order->set_payment_method_title( 'Stripe' );



            $order->update_meta_data( '_cpof_product_id', $product_id );

            $order->update_meta_data( '_cpof_civilite', $civilite );

            $order->update_meta_data( '_cpof_number_plate', $number_plate );

            $order->update_meta_data( '_cpof_region', $region );

            $order->update_meta_data( '_cpof_region_label', cpof_get_french_region_label( $region ) );

            $order->update_meta_data( '_cpof_country', 'FR' );

            $order->update_meta_data( '_cpof_delivery_method', $delivery_method );

            $order->update_meta_data( '_cpof_terms_accepted', current_time( 'mysql' ) );

            $order->update_meta_data( '_cpof_phone', $phone );

            if ( ! empty( $delivery_address ) ) {

                $order->update_meta_data( '_cpof_delivery_address', $delivery_address );

            }



            $order->set_billing_first_name( $first_name );

            $order->set_billing_last_name( $last_name );

            $order->set_billing_email( $email );

            $order->set_billing_phone( $phone );

            $order->set_billing_country( 'FR' );

            $order->set_billing_state( $region );

            if ( ! empty( $delivery_address ) ) {

                $order->set_billing_address_1( $delivery_address );

                $order->set_shipping_first_name( $first_name );

                $order->set_shipping_last_name( $last_name );

                $order->set_shipping_country( 'FR' );

                $order->set_shipping_state( $region );

                $order->set_shipping_address_1( $delivery_address );

            }



            $order->save();



            $note = sprintf(

                "Détails de la commande de plaque personnalisée :\n" .

                "Civilité : %s\n" .

                "Numéro de plaque : %s\n" .

                "Région : %s\n" .

                "Mode de réception : %s\n" .

                "%s" .

                "RGPD : accepté",

                $this->get_civilite_label( $civilite ),

                $number_plate,

                cpof_get_french_region_label( $region ),

                'delivery' === $delivery_method ? __( 'Livraison', 'custom-plate-order-form' ) : __( 'Point de collecte', 'custom-plate-order-form' ),

                ! empty( $delivery_address )
                    ? sprintf(
                        /* translators: %s: delivery address */
                        __( "Adresse de livraison : %s\n", 'custom-plate-order-form' ),
                        $delivery_address
                    )
                    : ''

            );

            $order->add_order_note( $note );



            $redirect_url = CPOF_Stripe::create_checkout_session( $order, $product, $return_url );



            if ( is_wp_error( $redirect_url ) ) {

                $order->update_status( 'failed', $redirect_url->get_error_message() );

                wp_send_json_error( array( 'message' => $redirect_url->get_error_message() ) );

            }



            wp_send_json_success(

                array(

                    'redirect_url' => $redirect_url,

                    'order_id'     => $order->get_id(),

                )

            );

        } catch ( Exception $e ) {

            wp_send_json_error(

                array(

                    'message' => sprintf(

                        /* translators: %s: error message */

                        __( 'Erreur : %s', 'custom-plate-order-form' ),

                        $e->getMessage()

                    ),

                )

            );

        }

    }



    /**

     * Get display label for civilité value.

     */

    private function get_civilite_label( $civilite ) {

        $labels = array(

            'mr'   => __( 'Mr', 'custom-plate-order-form' ),

            'mme'  => __( 'Mme', 'custom-plate-order-form' ),

            'mlle' => __( 'Mlle', 'custom-plate-order-form' ),

        );

        return $labels[ $civilite ] ?? $civilite;

    }



    /**

     * Create or get existing customer.

     */

    private function create_or_get_customer( $email, $first_name, $last_name, $phone ) {

        $customer_query = new WP_User_Query(

            array(

                'search'         => $email,

                'search_columns' => array( 'user_email' ),

            )

        );



        $users = $customer_query->get_results();



        if ( ! empty( $users ) ) {

            return new WC_Customer( $users[0]->ID );

        }



        $user_id = wc_create_new_customer( $email, '', '' );



        if ( is_wp_error( $user_id ) ) {

            throw new Exception( $user_id->get_error_message() );

        }



        $customer = new WC_Customer( $user_id );

        $customer->set_first_name( $first_name );

        $customer->set_last_name( $last_name );

        $customer->set_billing_phone( $phone );

        $customer->save();



        return $customer;

    }

}


