<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CPOF_Stripe {

    /**
     * Check if WooCommerce Stripe gateway plugin is available.
     */
    public static function is_woocommerce_stripe_active() {
        return class_exists( 'WC_Stripe_Helper' );
    }

    /**
     * Whether the order form uses Stripe test mode (plugin setting).
     */
    public static function is_test_mode() {
        return filter_var( get_option( 'cpof_stripe_test_mode', 0 ), FILTER_VALIDATE_BOOLEAN );
    }

    /**
     * Get the active key source label for admin display.
     */
    public static function get_active_source() {
        return self::is_test_mode() ? 'test' : 'woocommerce';
    }

    /**
     * Get publishable key for the current mode.
     */
    public static function get_publishable_key( $test_mode = null ) {
        if ( null === $test_mode ) {
            $test_mode = self::is_test_mode();
        }

        if ( $test_mode ) {
            return trim( get_option( 'cpof_stripe_test_publishable_key', '' ) );
        }

        return self::get_woocommerce_live_publishable_key();
    }

    /**
     * Get secret key for the current mode.
     */
    public static function get_secret_key( $test_mode = null ) {
        if ( null === $test_mode ) {
            $test_mode = self::is_test_mode();
        }

        if ( $test_mode ) {
            return trim( get_option( 'cpof_stripe_test_secret_key', '' ) );
        }

        return self::get_woocommerce_live_secret_key();
    }

    /**
     * Read live publishable key from WooCommerce Stripe settings.
     */
    public static function get_woocommerce_live_publishable_key() {
        if ( ! self::is_woocommerce_stripe_active() ) {
            return '';
        }

        $settings = WC_Stripe_Helper::get_stripe_settings();

        return trim( $settings['publishable_key'] ?? '' );
    }

    /**
     * Read live secret key from WooCommerce Stripe settings.
     */
    public static function get_woocommerce_live_secret_key() {
        if ( ! self::is_woocommerce_stripe_active() ) {
            return '';
        }

        $settings = WC_Stripe_Helper::get_stripe_settings();
        $live_key = trim( $settings['secret_key'] ?? '' );

        if ( ! empty( $live_key ) ) {
            return $live_key;
        }

        if ( class_exists( 'WC_Stripe_API' ) ) {
            WC_Stripe_API::set_secret_key_for_mode( 'live' );

            return trim( WC_Stripe_API::get_secret_key() );
        }

        return '';
    }

    /**
     * Detect whether a Stripe key is test or live.
     */
    public static function get_key_mode( $key ) {
        $key = trim( (string) $key );

        if ( 0 === strpos( $key, 'sk_live_' ) || 0 === strpos( $key, 'pk_live_' ) ) {
            return 'live';
        }

        if ( 0 === strpos( $key, 'sk_test_' ) || 0 === strpos( $key, 'pk_test_' ) ) {
            return 'test';
        }

        return 'unknown';
    }

    /**
     * Validate Stripe configuration before starting checkout.
     */
    public static function validate_checkout_config() {
        $test_mode  = self::is_test_mode();
        $secret_key = self::get_secret_key( $test_mode );

        if ( empty( $secret_key ) ) {
            if ( $test_mode ) {
                return new WP_Error(
                    'cpof_stripe_config',
                    __( 'Stripe test n\'est pas configuré. Ajoutez vos clés test dans Order Plate Settings.', 'custom-plate-order-form' )
                );
            }

            return new WP_Error(
                'cpof_stripe_config',
                __( 'Stripe live n\'est pas configuré. Ajoutez vos clés live dans WooCommerce → Paiements → Stripe.', 'custom-plate-order-form' )
            );
        }

        if ( $test_mode ) {
            if ( 'live' === self::get_key_mode( $secret_key ) ) {
                return new WP_Error(
                    'cpof_stripe_config',
                    __( 'Le mode test est activé mais une clé Stripe live a été détectée.', 'custom-plate-order-form' )
                );
            }

            return true;
        }

        if ( ! self::is_woocommerce_stripe_active() ) {
            return new WP_Error(
                'cpof_stripe_config',
                __( 'Le plugin WooCommerce Stripe doit être installé pour les paiements live.', 'custom-plate-order-form' )
            );
        }

        if ( ! self::is_woocommerce_stripe_enabled() ) {
            return new WP_Error(
                'cpof_stripe_config',
                __( 'Activez Stripe dans WooCommerce → Paiements avant d\'accepter les paiements live.', 'custom-plate-order-form' )
            );
        }

        if ( 'test' === self::get_key_mode( $secret_key ) ) {
            return new WP_Error(
                'cpof_stripe_config',
                __( 'Le mode test est désactivé mais WooCommerce utilise encore une clé Stripe test. Ajoutez vos clés live dans WooCommerce → Paiements → Stripe et désactivez le mode test WooCommerce.', 'custom-plate-order-form' )
            );
        }

        return true;
    }

    /**
     * Build admin status details for the settings page.
     */
    public static function get_config_status() {
        $test_mode  = self::is_test_mode();
        $secret     = self::get_secret_key( $test_mode );
        $key_mode   = self::get_key_mode( $secret );
        $wc_test_on = self::is_woocommerce_stripe_active() && class_exists( 'WC_Stripe_Mode' ) && WC_Stripe_Mode::is_test();

        return array(
            'test_mode'                   => $test_mode,
            'configured'                  => ! empty( $secret ),
            'key_mode'                    => $key_mode,
            'mode_label'                  => $test_mode
                ? __( 'Test (plugin keys)', 'custom-plate-order-form' )
                : __( 'Live (WooCommerce Stripe)', 'custom-plate-order-form' ),
            'secret_key_masked'           => self::mask_key( $secret ),
            'publishable_key_masked'      => self::mask_key( self::get_publishable_key( $test_mode ) ),
            'woocommerce_stripe_active'   => self::is_woocommerce_stripe_active(),
            'woocommerce_stripe_enabled'  => self::is_woocommerce_stripe_enabled(),
            'woocommerce_stripe_testmode' => $wc_test_on,
            'woocommerce_stripe_settings' => admin_url( 'admin.php?page=wc-settings&tab=checkout&section=stripe' ),
        );
    }

    /**
     * Check whether WooCommerce Stripe gateway is enabled in checkout settings.
     */
    public static function is_woocommerce_stripe_enabled() {
        if ( ! self::is_woocommerce_stripe_active() ) {
            return false;
        }

        $settings = WC_Stripe_Helper::get_stripe_settings();
        return isset( $settings['enabled'] ) && 'yes' === $settings['enabled'];
    }

    /**
     * Validate Stripe API credentials for the current mode.
     */
    public static function test_connection() {
        $test_mode  = self::is_test_mode();
        $secret_key = self::get_secret_key( $test_mode );

        if ( empty( $secret_key ) ) {
            if ( $test_mode ) {
                return new WP_Error(
                    'cpof_stripe_config',
                    __( 'Add your Stripe test publishable and secret keys, then save.', 'custom-plate-order-form' )
                );
            }

            if ( ! self::is_woocommerce_stripe_active() ) {
                return new WP_Error(
                    'cpof_stripe_config',
                    __( 'Install and configure the WooCommerce Stripe plugin for live payments.', 'custom-plate-order-form' )
                );
            }

            return new WP_Error(
                'cpof_stripe_config',
                __( 'Add your live Stripe keys in WooCommerce → Payments → Stripe.', 'custom-plate-order-form' )
            );
        }

        $response = wp_remote_get(
            'https://api.stripe.com/v1/balance',
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $secret_key,
                ),
                'timeout' => 20,
            )
        );

        if ( is_wp_error( $response ) ) {
            return new WP_Error(
                'cpof_stripe_request',
                sprintf(
                    /* translators: %s: error message */
                    __( 'Could not connect to Stripe: %s', 'custom-plate-order-form' ),
                    $response->get_error_message()
                )
            );
        }

        $data = json_decode( wp_remote_retrieve_body( $response ) );

        if ( isset( $data->error ) ) {
            return new WP_Error( 'cpof_stripe_error', $data->error->message );
        }

        return array(
            'message' => $test_mode
                ? __( 'Stripe test connection successful.', 'custom-plate-order-form' )
                : __( 'Stripe live connection successful via WooCommerce.', 'custom-plate-order-form' ),
            'mode'    => $test_mode ? 'test' : 'live',
        );
    }

    /**
     * Create a Stripe Checkout Session for a WooCommerce order.
     */
    public static function create_checkout_session( $order, $product, $return_url ) {
        $test_mode  = self::is_test_mode();
        $secret_key = self::get_secret_key( $test_mode );

        if ( empty( $secret_key ) ) {
            if ( $test_mode ) {
                return new WP_Error(
                    'cpof_stripe_config',
                    __( 'Stripe test n\'est pas configuré. Veuillez contacter l\'administrateur.', 'custom-plate-order-form' )
                );
            }

            return new WP_Error(
                'cpof_stripe_config',
                __( 'Stripe live n\'est pas configuré dans WooCommerce. Veuillez configurer WooCommerce → Paiements → Stripe.', 'custom-plate-order-form' )
            );
        }

        $currency        = strtolower( get_woocommerce_currency() );
        $delivery_method = $order->get_meta( '_cpof_delivery_method' );
        $product_amount  = (int) round( (float) $product->get_price() * 100 );
        $product_name    = $product->get_name();
        $number_plate    = $order->get_meta( '_cpof_number_plate' );

        if ( $product_amount <= 0 ) {
            return new WP_Error( 'cpof_stripe_amount', __( 'Montant de produit invalide.', 'custom-plate-order-form' ) );
        }

        $line_items = array(
            array(
                'price_data' => array(
                    'currency'     => $currency,
                    'unit_amount'  => $product_amount,
                    'product_data' => array(
                        'name'        => $product_name,
                        'description' => sprintf(
                            /* translators: %s: license plate number */
                            __( 'Plaque: %s', 'custom-plate-order-form' ),
                            $number_plate
                        ),
                    ),
                ),
                'quantity'   => 1,
            ),
        );

        if ( 'delivery' === $delivery_method ) {
            $line_items[] = array(
                'price_data' => array(
                    'currency'     => $currency,
                    'unit_amount'  => (int) round( cpof_get_delivery_fee() * 100 ),
                    'product_data' => array(
                        'name' => __( 'Livraison', 'custom-plate-order-form' ),
                    ),
                ),
                'quantity'   => 1,
            );
        }

        $return_token = $order->get_meta( '_cpof_return_token' );
        if ( empty( $return_token ) ) {
            $return_token = wp_generate_password( 20, false, false );
            $order->update_meta_data( '_cpof_return_token', $return_token );
            $order->save();
        }

        // Short query args avoid ModSecurity blocks from Stripe session IDs in the URL.
        $success_url = add_query_arg(
            array(
                'cpof_oid' => $order->get_id(),
                'cpof_t'   => $return_token,
            ),
            $return_url
        );

        $cancel_url = add_query_arg( 'cpof_cancel', '1', $return_url );

        $body = array(
            'payment_method_types' => array( 'card' ),
            'mode'                 => 'payment',
            'success_url'          => $success_url,
            'cancel_url'           => $cancel_url,
            'customer_email'       => $order->get_billing_email(),
            'client_reference_id'  => (string) $order->get_id(),
            'metadata'             => array(
                'order_id'   => (string) $order->get_id(),
                'cpof_order' => 'yes',
            ),
            'line_items'           => $line_items,
        );

        $response = self::api_request( 'checkout/sessions', $body, $secret_key );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        if ( empty( $response->url ) || empty( $response->id ) ) {
            return new WP_Error( 'cpof_stripe_session', __( 'Impossible de créer la session de paiement Stripe.', 'custom-plate-order-form' ) );
        }

        $order->update_meta_data( '_cpof_stripe_session_id', sanitize_text_field( $response->id ) );
        $order->update_meta_data( '_cpof_stripe_source', self::get_active_source() );
        $order->update_meta_data( '_cpof_stripe_test_mode', $test_mode ? 'yes' : 'no' );
        $order->save();

        return $response->url;
    }

    /**
     * Verify payment after Stripe redirect using order ID and return token.
     */
    public static function verify_order_payment( $order_id, $token ) {
        $order_id = absint( $order_id );
        $token    = sanitize_text_field( $token );

        if ( ! $order_id || empty( $token ) ) {
            return new WP_Error( 'cpof_stripe_order', __( 'Lien de retour de paiement invalide.', 'custom-plate-order-form' ) );
        }

        $order = wc_get_order( $order_id );

        if ( ! $order ) {
            return new WP_Error( 'cpof_stripe_order', __( 'Commande introuvable.', 'custom-plate-order-form' ) );
        }

        $stored_token = (string) $order->get_meta( '_cpof_return_token' );

        if ( empty( $stored_token ) || ! hash_equals( $stored_token, $token ) ) {
            return new WP_Error( 'cpof_stripe_order', __( 'Jeton de paiement invalide.', 'custom-plate-order-form' ) );
        }

        if ( $order->is_paid() ) {
            return array(
                'order_id'     => $order_id,
                'already_paid' => true,
            );
        }

        $session_id = (string) $order->get_meta( '_cpof_stripe_session_id' );

        if ( empty( $session_id ) ) {
            return new WP_Error( 'cpof_stripe_session', __( 'Session de paiement introuvable.', 'custom-plate-order-form' ) );
        }

        return self::verify_checkout_session( $session_id );
    }

    /**
     * Verify a Stripe Checkout Session and mark the WooCommerce order as paid.
     */
    public static function verify_checkout_session( $session_id ) {
        $session_id = sanitize_text_field( $session_id );

        if ( empty( $session_id ) ) {
            return new WP_Error( 'cpof_stripe_session', __( 'Session de paiement invalide.', 'custom-plate-order-form' ) );
        }

        $response = wp_remote_get(
            'https://api.stripe.com/v1/checkout/sessions/' . rawurlencode( $session_id ),
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . self::get_secret_key_for_session_lookup( $session_id ),
                ),
                'timeout' => 30,
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $data = json_decode( wp_remote_retrieve_body( $response ) );

        if ( isset( $data->error ) ) {
            return new WP_Error( 'cpof_stripe_error', $data->error->message );
        }

        if ( empty( $data->payment_status ) || 'paid' !== $data->payment_status ) {
            return new WP_Error( 'cpof_stripe_unpaid', __( 'Le paiement n\'a pas été confirmé.', 'custom-plate-order-form' ) );
        }

        $order_id = 0;

        if ( ! empty( $data->metadata->order_id ) ) {
            $order_id = absint( $data->metadata->order_id );
        } elseif ( ! empty( $data->client_reference_id ) ) {
            $order_id = absint( $data->client_reference_id );
        }

        if ( ! $order_id ) {
            return new WP_Error( 'cpof_stripe_order', __( 'Commande introuvable pour ce paiement.', 'custom-plate-order-form' ) );
        }

        $order = wc_get_order( $order_id );

        if ( ! $order ) {
            return new WP_Error( 'cpof_stripe_order', __( 'Commande introuvable.', 'custom-plate-order-form' ) );
        }

        if ( $order->is_paid() ) {
            return array(
                'order_id'     => $order_id,
                'already_paid' => true,
            );
        }

        $transaction_id = '';

        if ( ! empty( $data->payment_intent ) && is_string( $data->payment_intent ) ) {
            $transaction_id = $data->payment_intent;
        }

        $order->set_payment_method( 'stripe' );
        $order->set_payment_method_title( 'Stripe' );
        $order->update_meta_data( '_cpof_stripe_session_id', $session_id );

        if ( $transaction_id ) {
            $order->set_transaction_id( $transaction_id );
        }

        $order->payment_complete( $transaction_id );
        $order->delete_meta_data( '_cpof_return_token' );
        $order->save();
        $order->add_order_note( __( 'Paiement Stripe confirmé via Checkout.', 'custom-plate-order-form' ) );

        return array(
            'order_id'     => $order_id,
            'already_paid' => false,
        );
    }

    /**
     * Resolve the correct secret key when verifying a checkout session.
     */
    private static function get_secret_key_for_session_lookup( $session_id ) {
        $orders = wc_get_orders(
            array(
                'limit'      => 1,
                'meta_key'   => '_cpof_stripe_session_id',
                'meta_value' => $session_id,
                'return'     => 'objects',
            )
        );

        if ( ! empty( $orders ) ) {
            $order     = $orders[0];
            $test_mode = 'yes' === $order->get_meta( '_cpof_stripe_test_mode' );
            $key       = self::get_secret_key( $test_mode );

            if ( ! empty( $key ) ) {
                return $key;
            }
        }

        return self::get_secret_key();
    }

    /**
     * Mask a Stripe key for display.
     */
    public static function mask_key( $key ) {
        $key = trim( (string) $key );

        if ( empty( $key ) ) {
            return '—';
        }

        if ( strlen( $key ) <= 12 ) {
            return str_repeat( '*', strlen( $key ) );
        }

        return substr( $key, 0, 7 ) . str_repeat( '*', max( 0, strlen( $key ) - 11 ) ) . substr( $key, -4 );
    }

    /**
     * Send a POST request to the Stripe API.
     */
    private static function api_request( $endpoint, $params, $secret_key ) {
        $response = wp_remote_post(
            'https://api.stripe.com/v1/' . ltrim( $endpoint, '/' ),
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $secret_key,
                    'Content-Type'  => 'application/x-www-form-urlencoded',
                ),
                'body'    => self::build_query( $params ),
                'timeout' => 30,
            )
        );

        if ( is_wp_error( $response ) ) {
            return new WP_Error(
                'cpof_stripe_request',
                sprintf(
                    /* translators: %s: error message */
                    __( 'Erreur de connexion à Stripe : %s', 'custom-plate-order-form' ),
                    $response->get_error_message()
                )
            );
        }

        $data = json_decode( wp_remote_retrieve_body( $response ) );

        if ( isset( $data->error ) ) {
            return new WP_Error( 'cpof_stripe_error', $data->error->message );
        }

        return $data;
    }

    private static function build_query( $params, $prefix = null ) {
        $query = array();

        foreach ( $params as $key => $value ) {
            $full_key = is_null( $prefix ) ? $key : $prefix . '[' . $key . ']';

            if ( is_array( $value ) ) {
                $query[] = self::build_query( $value, $full_key );
            } else {
                $query[] = rawurlencode( $full_key ) . '=' . rawurlencode( $value );
            }
        }

        return implode( '&', $query );
    }
}
