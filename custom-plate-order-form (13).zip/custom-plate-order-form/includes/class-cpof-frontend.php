<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CPOF_Frontend {

    public function __construct() {
        add_shortcode( 'plate_order_form', array( $this, 'render_form' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
    }

    public function enqueue_scripts() {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) || ! has_shortcode( $post->post_content, 'plate_order_form' ) ) {
            return;
        }

        wp_enqueue_style( 'cpof-frontend-style', CPOF_PLUGIN_URL . 'assets/css/frontend.css', array(), CPOF_VERSION );
        wp_enqueue_script( 'cpof-frontend-script', CPOF_PLUGIN_URL . 'assets/js/frontend.js', array( 'jquery' ), CPOF_VERSION, true );

        $payment_result  = array(
            'status'  => '',
            'message' => '',
        );
        $default_product = $this->get_default_product();

        if ( isset( $_GET['cpof_oid'] ) && isset( $_GET['cpof_t'] ) ) {
            $verify = CPOF_Stripe::verify_order_payment(
                absint( wp_unslash( $_GET['cpof_oid'] ) ),
                sanitize_text_field( wp_unslash( $_GET['cpof_t'] ) )
            );

            if ( is_wp_error( $verify ) ) {
                $payment_result = array(
                    'status'  => 'error',
                    'message' => $verify->get_error_message(),
                );
            } else {
                $payment_result = array(
                    'status'  => 'success',
                    'message' => __( 'Votre commande a été terminée avec succès. Merci pour votre achat !', 'custom-plate-order-form' ),
                );
            }
        } elseif ( isset( $_GET['cpof_cancel'] ) ) {
            $payment_result = array(
                'status'  => 'cancel',
                'message' => __( 'Le paiement a été annulé. Veuillez réessayer.', 'custom-plate-order-form' ),
            );
        }

        wp_localize_script(
            'cpof-frontend-script',
            'cpof_ajax',
            array(
                'ajax_url'        => admin_url( 'admin-ajax.php' ),
                'nonce'           => wp_create_nonce( 'cpof_checkout_nonce' ),
                'return_url'      => get_permalink( $post->ID ),
                'payment_result'  => $payment_result,
                'default_product' => $default_product,
                'delivery_fee'    => cpof_get_delivery_fee(),
                'currency_symbol' => get_woocommerce_currency_symbol(),
                'i18n'            => array(
                    'collection_free'       => __( 'Point de collecte - Gratuit', 'custom-plate-order-form' ),
                    'create_order'          => __( 'Créer la commande', 'custom-plate-order-form' ),
                    'redirect_stripe'       => __( 'Redirection vers Stripe...', 'custom-plate-order-form' ),
                    'fill_required'         => __( 'Veuillez remplir tous les champs obligatoires, confirmer votre adresse e-mail et accepter les conditions relatives à vos données personnelles.', 'custom-plate-order-form' ),
                    'delivery_address_req'  => __( 'Veuillez saisir votre adresse de livraison.', 'custom-plate-order-form' ),
                    'no_product'            => __( 'Aucun produit disponible pour cette commande.', 'custom-plate-order-form' ),
                    'generic_error'         => __( 'Une erreur est survenue.', 'custom-plate-order-form' ),
                    'checkout_error'        => __( 'Une erreur est survenue lors de la création de votre commande. Veuillez réessayer.', 'custom-plate-order-form' ),
                ),
            )
        );
    }

    private function get_default_product() {
        $products_query = new WP_Query(
            array(
                'post_type'      => 'product',
                'posts_per_page' => 1,
                'post_status'    => 'publish',
                'orderby'        => 'date',
                'order'          => 'DESC',
            )
        );

        if ( ! $products_query->have_posts() ) {
            return null;
        }

        $products_query->the_post();
        $product = wc_get_product( get_the_ID() );
        wp_reset_postdata();

        if ( ! $product ) {
            return null;
        }

        $product_id    = $product->get_id();
        $product_image = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'medium' );

        return array(
            'id'    => $product_id,
            'price' => $product->get_price(),
            'title' => $product->get_name(),
            'image' => $product_image ? $product_image[0] : wc_placeholder_img_src(),
        );
    }

    public function render_form( $atts ) {
        $default_product  = $this->get_default_product();
        $currency_symbol  = get_woocommerce_currency_symbol();
        $delivery_fee     = cpof_get_delivery_fee();
        ob_start();
        ?>
        <div class="cpof-form-container">
            <form id="cpof_order_form" class="cpof-order-form">
                <div class="cpof-layout">
                    <div class="cpof-form-section">
                        <div class="cpof-form-group">
                            <label for="cpof_civilite"><?php esc_html_e( 'Civilité', 'custom-plate-order-form' ); ?> *</label>
                            <select id="cpof_civilite" name="civilite" required>
                                <option value=""><?php esc_html_e( 'Sélectionnez une civilité', 'custom-plate-order-form' ); ?></option>
                                <option value="mr"><?php esc_html_e( 'Mr', 'custom-plate-order-form' ); ?></option>
                                <option value="mme"><?php esc_html_e( 'Mme', 'custom-plate-order-form' ); ?></option>
                                <option value="mlle"><?php esc_html_e( 'Mlle', 'custom-plate-order-form' ); ?></option>
                            </select>
                        </div>

                        <div class="cpof-form-row">
                            <div class="cpof-form-group cpof-half-width">
                                <label for="cpof_first_name"><?php esc_html_e( 'Prénom', 'custom-plate-order-form' ); ?> *</label>
                                <input type="text" id="cpof_first_name" name="first_name" placeholder="<?php esc_attr_e( 'Jean', 'custom-plate-order-form' ); ?>" required>
                            </div>

                            <div class="cpof-form-group cpof-half-width">
                                <label for="cpof_last_name"><?php esc_html_e( 'Nom de famille', 'custom-plate-order-form' ); ?> *</label>
                                <input type="text" id="cpof_last_name" name="last_name" placeholder="<?php esc_attr_e( 'Dupont', 'custom-plate-order-form' ); ?>" required>
                            </div>
                        </div>

                        <div class="cpof-form-group">
                            <label for="cpof_phone"><?php esc_html_e( 'Téléphone', 'custom-plate-order-form' ); ?> *</label>
                            <input type="tel" id="cpof_phone" name="phone" placeholder="07123456789" required>
                        </div>

                        <div class="cpof-form-group">
                            <label for="cpof_email"><?php esc_html_e( 'Adresse e-mail', 'custom-plate-order-form' ); ?> *</label>
                            <input type="email" id="cpof_email" name="email" placeholder="jean@exemple.com" required>
                        </div>

                        <div class="cpof-form-group">
                            <label for="cpof_email_confirm"><?php esc_html_e( 'Confirmer l\'adresse e-mail', 'custom-plate-order-form' ); ?> *</label>
                            <input type="email" id="cpof_email_confirm" name="email_confirm" placeholder="jean@exemple.com" required autocomplete="off">
                        </div>

                        <div class="cpof-form-group">
                            <label for="cpof_number_plate"><?php esc_html_e( 'Plaque d\'immatriculation', 'custom-plate-order-form' ); ?> *</label>
                            <input type="text" id="cpof_number_plate" name="number_plate" placeholder="AB-123-CD" required maxlength="10">
                        </div>

                        <div class="cpof-form-group">
                            <label><?php esc_html_e( 'Mode de réception *', 'custom-plate-order-form' ); ?></label>
                            <div class="cpof-delivery-options">
                                <label class="cpof-delivery-option">
                                    <input type="radio" id="cpof_delivery_collection" name="delivery_method" value="collection_point" checked required>
                                    <span class="cpof-delivery-option__label"><?php esc_html_e( 'Point de collecte', 'custom-plate-order-form' ); ?></span>
                                    <span class="cpof-delivery-option__hint"><?php esc_html_e( 'Gratuit', 'custom-plate-order-form' ); ?></span>
                                </label>
                                <label class="cpof-delivery-option">
                                    <input type="radio" id="cpof_delivery_home" name="delivery_method" value="delivery" required>
                                    <span class="cpof-delivery-option__label"><?php esc_html_e( 'Livraison', 'custom-plate-order-form' ); ?></span>
                                    <span class="cpof-delivery-option__hint">+ <?php echo esc_html( $currency_symbol . number_format( $delivery_fee, $delivery_fee == floor( $delivery_fee ) ? 0 : 2 ) ); ?></span>
                                </label>
                            </div>
                        </div>

                        <div class="cpof-form-group">
                            <label for="cpof_region"><?php esc_html_e( 'Région', 'custom-plate-order-form' ); ?> *</label>
                            <select id="cpof_region" name="region" required>
                                <option value=""><?php esc_html_e( 'Sélectionnez une région', 'custom-plate-order-form' ); ?></option>
                                <?php foreach ( cpof_get_french_regions() as $region_code => $region_label ) : ?>
                                    <option value="<?php echo esc_attr( $region_code ); ?>"><?php echo esc_html( $region_label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="cpof-form-group cpof-delivery-address-group">
                            <label for="cpof_delivery_address"><?php esc_html_e( 'Adresse de livraison', 'custom-plate-order-form' ); ?></label>
                            <textarea id="cpof_delivery_address" name="delivery_address" rows="3" placeholder="<?php esc_attr_e( 'Rue, numéro, ville, code postal', 'custom-plate-order-form' ); ?>"></textarea>
                        </div>
                    </div>

                    <div class="cpof-form-section">
                        <input type="hidden" id="cpof_selected_product_id" name="plate_id" value="<?php echo $default_product ? esc_attr( $default_product['id'] ) : ''; ?>">

                        <div class="cpof-order-summary">
                            <?php if ( $default_product ) : ?>
                            <div id="cpof_product_preview" class="cpof-product-preview">
                                <h4><?php esc_html_e( 'VOTRE COMMANDE', 'custom-plate-order-form' ); ?></h4>

                                <div class="cpof-product-preview__image">
                                    <img id="cpof_preview_product_image" src="<?php echo esc_url( $default_product['image'] ); ?>" alt="<?php esc_attr_e( 'Produit', 'custom-plate-order-form' ); ?>">
                                </div>

                                <div class="cpof-product-preview__lines">
                                    <div class="cpof-product-preview__header">
                                        <span><?php esc_html_e( 'Produit', 'custom-plate-order-form' ); ?></span>
                                        <span><?php esc_html_e( 'Sous-total', 'custom-plate-order-form' ); ?></span>
                                    </div>
                                    <div class="cpof-product-preview__item">
                                        <div>
                                            <div id="cpof_preview_title" class="cpof-product-preview__name"><?php echo esc_html( $default_product['title'] ); ?></div>
                                            <div class="cpof-product-preview__qty">× 1</div>
                                        </div>
                                        <div id="cpof_preview_subtotal" class="cpof-product-preview__price"><?php echo esc_html( $currency_symbol . number_format( (float) $default_product['price'], 2 ) ); ?></div>
                                    </div>
                                </div>

                                <div class="cpof-product-preview__row">
                                    <span><?php esc_html_e( 'Sous-total', 'custom-plate-order-form' ); ?></span>
                                    <span id="cpof_order_subtotal"><?php echo esc_html( $currency_symbol . number_format( (float) $default_product['price'], 2 ) ); ?></span>
                                </div>
                                <div class="cpof-product-preview__row">
                                    <span><?php esc_html_e( 'Livraison', 'custom-plate-order-form' ); ?></span>
                                    <span id="cpof_delivery_amount"><?php esc_html_e( 'Point de collecte - Gratuit', 'custom-plate-order-form' ); ?></span>
                                </div>
                                <div class="cpof-product-preview__total">
                                    <span><?php esc_html_e( 'Total', 'custom-plate-order-form' ); ?></span>
                                    <span id="cpof_order_total"><?php echo esc_html( $currency_symbol . number_format( (float) $default_product['price'], 2 ) ); ?></span>
                                </div>
                            </div>
                            <?php else : ?>
                            <p class="cpof-no-products"><?php esc_html_e( 'Aucun produit disponible. Veuillez ajouter des produits dans WooCommerce.', 'custom-plate-order-form' ); ?></p>
                            <?php endif; ?>

                            <div class="cpof-terms-group">
                                <label for="cpof_terms_accepted" class="cpof-terms-label">
                                    <input type="checkbox" id="cpof_terms_accepted" name="cpof_terms_accepted" value="1" required>
                                    <span class="cpof-terms-text">
                                        <?php esc_html_e( 'Les informations collectées lors de votre commande (nom, adresse, numéro d\'immatriculation) sont utilisées exclusivement dans le cadre du traitement et de la livraison de votre plaque. Elles ne sont ni revendues, ni transmises à des tiers. Conformément au Règlement Général sur la Protection des Données (RGPD), vous disposez d\'un droit d\'accès, de rectification et de suppression de vos données personnelles. Pour toute demande, contactez-nous via le site midocaz.com.', 'custom-plate-order-form' ); ?>
                                    </span>
                                </label>
                            </div>

                            <button type="submit" id="cpof_pay_button" class="cpof-btn"<?php echo $default_product ? '' : ' disabled'; ?>>
                                <?php
                                if ( $default_product ) {
                                    echo esc_html( __( 'Créer la commande', 'custom-plate-order-form' ) . ' - ' . $currency_symbol . number_format( (float) $default_product['price'], 2 ) );
                                } else {
                                    esc_html_e( 'Aucun produit disponible', 'custom-plate-order-form' );
                                }
                                ?>
                            </button>
                            <div id="cpof_form_message" class="cpof-message"></div>
                        </div>
                    </div>
                </div>

                <div id="cpof_order_confirmation_modal" class="cpof-modal" style="display:none;">
                    <div class="cpof-modal-content">
                        <h3><?php esc_html_e( 'Commande confirmée', 'custom-plate-order-form' ); ?></h3>
                        <p id="cpof_confirmation_message"><?php esc_html_e( 'Votre commande a été terminée avec succès. Merci pour votre achat !', 'custom-plate-order-form' ); ?></p>
                        <button type="button" id="cpof_close_confirmation" class="cpof-btn" style="width: auto; padding: 10px 20px;"><?php esc_html_e( 'Fermer', 'custom-plate-order-form' ); ?></button>
                    </div>
                </div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }
}
