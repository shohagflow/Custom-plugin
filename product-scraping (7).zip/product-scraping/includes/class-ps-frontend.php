<?php
/**
 * Frontend functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class PS_Frontend {
    
    /**
     * Get AJAX URL for scraping
     * Uses WordPress AJAX - no external server needed
     */
    private function get_ajax_url() {
        return admin_url('admin-ajax.php');
    }
    
    /**
     * Store shortcode instances
     */
    private static $instances = array();
    
    /**
     * Instance counter for unique IDs
     */
    private static $instance_counter = 0;
    
    /**
     * Current instance ID
     */
    private $instance_id;
    
    /**
     * URL to scrape
     */
    private $scrape_url;
    
    /**
     * Constructor
     */
    public function __construct() {
        self::$instance_counter++;
        $this->instance_id = 'ps-' . self::$instance_counter;
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        // Only enqueue once per page
        static $enqueued = false;
        if ($enqueued) {
            return;
        }
        $enqueued = true;
        
        // Enqueue CSS
        wp_enqueue_style(
            'ps-frontend-style',
            PS_PLUGIN_URL . 'includes/ps-style.css',
            array(),
            PS_VERSION
        );
        
        // Enqueue JavaScript
        wp_enqueue_script(
            'ps-frontend-script',
            PS_PLUGIN_URL . 'includes/ps-scripts.js',
            array(),
            PS_VERSION,
            true
        );
        
        // Localize script to pass AJAX URL and nonce to JavaScript
        wp_localize_script(
            'ps-frontend-script',
            'psData',
            array(
                'ajaxUrl' => $this->get_ajax_url(),
                'nonce' => wp_create_nonce('ps_scrape_nonce'),
            )
        );
    }
    
    /**
     * Render products container
     */
    public function render_products($url = '') {
        // Store instance data
        $this->scrape_url = esc_url_raw($url);
        self::$instances[$this->instance_id] = array(
            'url' => $this->scrape_url,
        );
        
        // Get settings to check if sidebar should be shown
        $settings = get_option('ps_settings', array());
        $show_sidebar = isset($settings['show_sidebar']) ? intval($settings['show_sidebar']) : 1;
        
        // Ensure scripts are enqueued
        $this->enqueue_scripts();
        
        ob_start();
        ?>
        <div class="ps-products-container <?php echo $show_sidebar ? '' : 'ps-no-sidebar'; ?>" id="<?php echo esc_attr($this->instance_id); ?>">
            <div class="ps-loading">
                <p><?php esc_html_e('Loading products...', 'product-scraping'); ?></p>
            </div>
            <div class="ps-products-wrapper" id="<?php echo esc_attr($this->instance_id); ?>-wrapper" style="display: none;">
                <?php if ($show_sidebar): ?>
                <!-- Filter Sidebar -->
                <aside class="ps-filter-sidebar" id="<?php echo esc_attr($this->instance_id); ?>-filters">
                    <h3 class="ps-filter-title"><?php esc_html_e('Narrow Results', 'product-scraping'); ?></h3>
                    <div class="ps-filter-section ps-search-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-search">
                        <div class="ps-search-wrapper">
                            <input type="text" 
                                   class="ps-search-input" 
                                   id="<?php echo esc_attr($this->instance_id); ?>-search-input" 
                                   placeholder="<?php esc_attr_e('Search ', 'product-scraping'); ?>"
                                   autocomplete="off">
                            <button type="button" class="ps-search-arrow-btn" id="<?php echo esc_attr($this->instance_id); ?>-search-btn" aria-label="Search">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6 3L11 8L6 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-price">
                        <h4><?php esc_html_e('Price Range', 'product-scraping'); ?></h4>
                        <div class="ps-price-range">
                            <div class="ps-price-range-wrapper">
                                <div class="ps-price-range-active" id="<?php echo esc_attr($this->instance_id); ?>-price-range-active"></div>
                                <input type="range" class="ps-price-slider" id="<?php echo esc_attr($this->instance_id); ?>-price-min" min="0" max="1000" value="0">
                                <input type="range" class="ps-price-slider" id="<?php echo esc_attr($this->instance_id); ?>-price-max" min="0" max="1000" value="1000">
                            </div>
                            <div class="ps-price-display">
                                <span id="<?php echo esc_attr($this->instance_id); ?>-price-min-display">$0</span>
                                <span> - </span>
                                <span id="<?php echo esc_attr($this->instance_id); ?>-price-max-display">$1000+</span>
                            </div>
                        </div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-division">
                        <h4><?php esc_html_e('DIVISION', 'product-scraping'); ?></h4>
                        <div class="ps-filter-options" id="<?php echo esc_attr($this->instance_id); ?>-division-options"></div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-tag">
                        <h4><?php esc_html_e('HAND', 'product-scraping'); ?></h4>
                        <div class="ps-filter-options" id="<?php echo esc_attr($this->instance_id); ?>-tag-options"></div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-size">
                        <h4><?php esc_html_e('FLEX', 'product-scraping'); ?></h4>
                        <div class="ps-filter-options" id="<?php echo esc_attr($this->instance_id); ?>-size-options"></div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-pattern">
                        <h4><?php esc_html_e('PATTERN', 'product-scraping'); ?></h4>
                        <div class="ps-filter-options" id="<?php echo esc_attr($this->instance_id); ?>-pattern-options"></div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-brand">
                        <h4><?php esc_html_e('BRAND', 'product-scraping'); ?></h4>
                        <div class="ps-filter-options" id="<?php echo esc_attr($this->instance_id); ?>-brand-options"></div>
                    </div>
                </aside>
                <?php endif; ?>
                <!-- Products Grid -->
                <div class="ps-products-content">
                    <?php if ($show_sidebar): ?>
                    <div class="ps-products-header">
                        <p class="ps-products-count" id="<?php echo esc_attr($this->instance_id); ?>-count"></p>
                        <div class="ps-per-page-selector">
                            <label for="<?php echo esc_attr($this->instance_id); ?>-per-page"><?php esc_html_e('Per page:', 'product-scraping'); ?></label>
                            <select id="<?php echo esc_attr($this->instance_id); ?>-per-page" class="ps-per-page-select">
                                <option value="12">12</option>
                                <option value="24" selected>24</option>
                                <option value="48">48</option>
                                <option value="96">96</option>
                            </select>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="ps-products-grid" id="<?php echo esc_attr($this->instance_id); ?>-grid">
                        <!-- Products will be injected here by JavaScript -->
                    </div>
                    <div class="ps-pagination" id="<?php echo esc_attr($this->instance_id); ?>-pagination" style="display: none;">
                        <!-- Pagination will be injected here by JavaScript -->
                    </div>
                </div>
            </div>
            <div class="ps-error" id="<?php echo esc_attr($this->instance_id); ?>-error" style="display: none;">
                <p><?php esc_html_e('Failed to load products. Please try again later.', 'product-scraping'); ?></p>
            </div>
        </div>
        <script type="text/javascript">
            if (typeof psInstances === 'undefined') {
                var psInstances = {};
            }
            psInstances['<?php echo esc_js($this->instance_id); ?>'] = {
                url: '<?php echo esc_js($this->scrape_url); ?>'
            };
        </script>
        <?php
        return ob_get_clean();
    }

    /**
     * Render products container for a group of URLs (multiple sources, one filter)
     */
    public function render_products_group($urls = array(), $show_sidebar = null) {
        if (!is_array($urls) || empty($urls)) {
            return '';
        }

        // Sanitize URLs
        $clean_urls = array();
        foreach ($urls as $url) {
            $clean = esc_url_raw($url);
            if (!empty($clean)) {
                $clean_urls[] = $clean;
            }
        }

        if (empty($clean_urls)) {
            return '';
        }

        // Get sidebar setting - use passed parameter, or fall back to global setting
        if ($show_sidebar === null) {
            $settings = get_option('ps_settings', array());
            $show_sidebar = isset($settings['show_sidebar']) ? intval($settings['show_sidebar']) : 1;
        } else {
            $show_sidebar = intval($show_sidebar);
        }

        // Store instance data
        self::$instances[$this->instance_id] = array(
            'urls' => $clean_urls,
        );

        // Ensure scripts are enqueued
        $this->enqueue_scripts();

        ob_start();
        ?>
        <div class="ps-products-container <?php echo $show_sidebar ? '' : 'ps-no-sidebar'; ?>" id="<?php echo esc_attr($this->instance_id); ?>">
            <div class="ps-loading">
                <p><?php esc_html_e('Loading products...', 'product-scraping'); ?></p>
            </div>
            <div class="ps-products-wrapper" id="<?php echo esc_attr($this->instance_id); ?>-wrapper" style="display: none;">
                <?php if ($show_sidebar): ?>
                <!-- Filter Sidebar -->
                <aside class="ps-filter-sidebar" id="<?php echo esc_attr($this->instance_id); ?>-filters">
                    <h3 class="ps-filter-title"><?php esc_html_e('Narrow Results', 'product-scraping'); ?></h3>
                    <div class="ps-filter-section ps-search-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-search">
                        <div class="ps-search-wrapper">
                            <input type="text" 
                                   class="ps-search-input" 
                                   id="<?php echo esc_attr($this->instance_id); ?>-search-input" 
                                   placeholder="<?php esc_attr_e('Search ', 'product-scraping'); ?>"
                                   autocomplete="off">
                            <button type="button" class="ps-search-arrow-btn" id="<?php echo esc_attr($this->instance_id); ?>-search-btn" aria-label="Search">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6 3L11 8L6 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-price">
                        <h4><?php esc_html_e('Price Range', 'product-scraping'); ?></h4>
                        <div class="ps-price-range">
                            <div class="ps-price-range-wrapper">
                                <div class="ps-price-range-active" id="<?php echo esc_attr($this->instance_id); ?>-price-range-active"></div>
                                <input type="range" class="ps-price-slider" id="<?php echo esc_attr($this->instance_id); ?>-price-min" min="0" max="1000" value="0">
                                <input type="range" class="ps-price-slider" id="<?php echo esc_attr($this->instance_id); ?>-price-max" min="0" max="1000" value="1000">
                            </div>
                            <div class="ps-price-display">
                                <span id="<?php echo esc_attr($this->instance_id); ?>-price-min-display">$0</span>
                                <span> - </span>
                                <span id="<?php echo esc_attr($this->instance_id); ?>-price-max-display">$1000+</span>
                            </div>
                        </div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-division">
                        <h4><?php esc_html_e('DIVISION', 'product-scraping'); ?></h4>
                        <div class="ps-filter-options" id="<?php echo esc_attr($this->instance_id); ?>-division-options"></div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-tag">
                        <h4><?php esc_html_e('HAND', 'product-scraping'); ?></h4>
                        <div class="ps-filter-options" id="<?php echo esc_attr($this->instance_id); ?>-tag-options"></div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-size">
                        <h4><?php esc_html_e('FLEX', 'product-scraping'); ?></h4>
                        <div class="ps-filter-options" id="<?php echo esc_attr($this->instance_id); ?>-size-options"></div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-pattern">
                        <h4><?php esc_html_e('PATTERN', 'product-scraping'); ?></h4>
                        <div class="ps-filter-options" id="<?php echo esc_attr($this->instance_id); ?>-pattern-options"></div>
                    </div>
                    <div class="ps-filter-section" id="<?php echo esc_attr($this->instance_id); ?>-filter-brand">
                        <h4><?php esc_html_e('BRAND', 'product-scraping'); ?></h4>
                        <div class="ps-filter-options" id="<?php echo esc_attr($this->instance_id); ?>-brand-options"></div>
                    </div>
                </aside>
                <?php endif; ?>
                <!-- Products Grid -->
                <div class="ps-products-content">
                    <?php if ($show_sidebar): ?>
                    <div class="ps-products-header">
                        <p class="ps-products-count" id="<?php echo esc_attr($this->instance_id); ?>-count"></p>
                        <div class="ps-per-page-selector">
                            <label for="<?php echo esc_attr($this->instance_id); ?>-per-page"><?php esc_html_e('Per page:', 'product-scraping'); ?></label>
                            <select id="<?php echo esc_attr($this->instance_id); ?>-per-page" class="ps-per-page-select">
                                <option value="12">12</option>
                                <option value="24" selected>24</option>
                                <option value="48">48</option>
                                <option value="96">96</option>
                            </select>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="ps-products-grid" id="<?php echo esc_attr($this->instance_id); ?>-grid">
                        <!-- Products will be injected here by JavaScript -->
                    </div>
                    <div class="ps-pagination" id="<?php echo esc_attr($this->instance_id); ?>-pagination" style="display: none;">
                        <!-- Pagination will be injected here by JavaScript -->
                    </div>
                </div>
            </div>
            <div class="ps-error" id="<?php echo esc_attr($this->instance_id); ?>-error" style="display: none;">
                <p><?php esc_html_e('Failed to load products. Please try again later.', 'product-scraping'); ?></p>
            </div>
        </div>
        <script type="text/javascript">
            if (typeof psInstances === 'undefined') {
                var psInstances = {};
            }
            psInstances['<?php echo esc_js($this->instance_id); ?>'] = {
                urls: <?php echo wp_json_encode(array_values($clean_urls)); ?>
            };
        </script>
        <?php
        return ob_get_clean();
    }

    /**
     * Render a compact grid of featured products from a group (no filters)
     */
     public function render_products_group_featured($urls = array(), $limit = 4, $columns = 4) {
        if (!is_array($urls) || empty($urls)) {
            return '';
        }

        $limit = max(1, intval($limit));
        $columns = max(1, intval($columns));

        // Sanitize URLs
        $clean_urls = array();
        foreach ($urls as $url) {
            $clean = esc_url_raw($url);
            if (!empty($clean)) {
                $clean_urls[] = $clean;
            }
        }

        if (empty($clean_urls)) {
            return '';
        }

        // Store instance data
        self::$instances[$this->instance_id] = array(
            'urls' => $clean_urls,
            'featuredLimit' => $limit,
            'featuredColumns' => $columns,
        );

        // Ensure scripts are enqueued
        $this->enqueue_scripts();

        ob_start();
        ?>
        <div class="ps-products-container ps-products-container-featured" id="<?php echo esc_attr($this->instance_id); ?>">
            <div class="ps-loading">
                <p><?php esc_html_e('Loading products...', 'product-scraping'); ?></p>
            </div>
            <div class="ps-products-content">
                <div class="ps-products-grid ps-products-grid-featured" id="<?php echo esc_attr($this->instance_id); ?>-grid" style="--ps-featured-columns: <?php echo intval($columns); ?>;">
                    <!-- Featured products will be injected here by JavaScript -->
                </div>
            </div>
            <div class="ps-error" id="<?php echo esc_attr($this->instance_id); ?>-error" style="display: none;">
                <p><?php esc_html_e('Failed to load products. Please try again later.', 'product-scraping'); ?></p>
            </div>
        </div>
        <script type="text/javascript">
            if (typeof psInstances === 'undefined') {
                var psInstances = {};
            }
            psInstances['<?php echo esc_js($this->instance_id); ?>'] = {
                urls: <?php echo wp_json_encode(array_values($clean_urls)); ?>,
                featuredLimit: <?php echo intval($limit); ?>,
                featuredColumns: <?php echo intval($columns); ?>
            };
        </script>
        <?php
        return ob_get_clean();
    }

    /**
     * Render standalone search bar (for header use)
     */
    public function render_search_bar() {
        // Ensure scripts are enqueued
        $this->enqueue_scripts();

        ob_start();
        ?>
        <div class="ps-search-bar-container" id="ps-global-search">
            <div class="ps-search-bar-wrapper">
                <input type="text" 
                       class="ps-search-bar-input" 
                       id="ps-global-search-input" 
                       placeholder="<?php esc_attr_e('Search products...', 'product-scraping'); ?>"
                       autocomplete="off">
                <button type="button" class="ps-search-bar-button" id="ps-global-search-button">
                    <span class="ps-search-bar-icon">🔍</span>
                </button>
            </div>
            <div class="ps-search-results-popup" id="ps-search-results-popup" style="display: none;">
                <div class="ps-search-results-header">
                    <span class="ps-search-results-count" id="ps-search-results-count">0 results</span>
                    <button type="button" class="ps-search-close-popup" id="ps-search-close-popup">&times;</button>
                </div>
                <div class="ps-search-results-list" id="ps-search-results-list">
                    <!-- Search results will be populated here -->
                </div>
            </div>
        </div>
        <script type="text/javascript">
            // Initialize global search functionality
            if (typeof psGlobalSearchInitialized === 'undefined') {
                psGlobalSearchInitialized = true;
                
                function showSearchPopup(results, query) {
                    const popup = document.getElementById('ps-search-results-popup');
                    const resultsList = document.getElementById('ps-search-results-list');
                    const resultsCount = document.getElementById('ps-search-results-count');
                    
                    if (!popup || !resultsList) return;
                    
                    if (!query || query.length === 0) {
                        popup.style.display = 'none';
                        return;
                    }
                    
                    if (results.length === 0) {
                        // Check if products are still loading
                        const allProducts = [];
                        if (typeof psInstances !== 'undefined' && typeof productData !== 'undefined') {
                            Object.keys(psInstances).forEach(function(instanceId) {
                                if (productData[instanceId]) {
                                    const products = productData[instanceId].all || 
                                                   productData[instanceId].filtered || 
                                                   [];
                                    if (Array.isArray(products)) {
                                        allProducts.push.apply(allProducts, products);
                                    }
                                }
                            });
                        }
                        
                        if (allProducts.length === 0 && query.length > 0) {
                            resultsList.innerHTML = '<div class="ps-search-no-results">Loading products...</div>';
                        } else {
                            resultsList.innerHTML = '<div class="ps-search-no-results">No products found</div>';
                        }
                        
                        if (resultsCount) {
                            resultsCount.textContent = '0 results';
                        }
                        popup.style.display = 'block';
                        return;
                    }
                    
                    // Show results (max 10 in popup)
                    const maxResults = 10;
                    const displayResults = results.slice(0, maxResults);
                    
                    let html = '';
                    displayResults.forEach(function(product) {
                        const image = product.image || '';
                        const title = product.title || 'Untitled Product';
                        const price = product.price || 'Price not available';
                        const link = product.link || '#';
                        
                        html += '<div class="ps-search-result-item" data-link="' + escapeHtml(link) + '">';
                        if (image) {
                            html += '<img src="' + escapeHtml(image) + '" alt="' + escapeHtml(title) + '" class="ps-search-result-image" onerror="this.style.display=\'none\'">';
                        }
                        html += '<div class="ps-search-result-content">';
                        html += '<div class="ps-search-result-title">' + escapeHtml(title) + '</div>';
                        html += '<div class="ps-search-result-price">' + escapeHtml(price) + '</div>';
                        html += '</div>';
                        html += '</div>';
                    });
                    
                    resultsList.innerHTML = html;
                    
                    if (resultsCount) {
                        resultsCount.textContent = results.length + (results.length === 1 ? ' result' : ' results');
                    }
                    
                    popup.style.display = 'block';
                    
                    // Add click handlers
                    resultsList.querySelectorAll('.ps-search-result-item').forEach(function(item) {
                        item.addEventListener('click', function() {
                            const link = this.getAttribute('data-link');
                            if (link && link !== '#') {
                                window.open(link, '_blank');
                            }
                        });
                    });
                }
                
                function escapeHtml(text) {
                    const div = document.createElement('div');
                    div.textContent = text;
                    return div.innerHTML;
                }
                
                function applyGlobalSearch(searchQuery) {
                    // Function to collect all products from all instances
                    function getAllProducts() {
                        const allProducts = [];
                        
                        // Method 1: Get from productData
                        if (typeof psInstances !== 'undefined' && typeof productData !== 'undefined') {
                            Object.keys(psInstances).forEach(function(instanceId) {
                                if (productData[instanceId]) {
                                    // Try 'all' first, then 'filtered'
                                    const products = productData[instanceId].all || 
                                                   productData[instanceId].filtered || 
                                                   [];
                                    if (Array.isArray(products) && products.length > 0) {
                                        allProducts.push.apply(allProducts, products);
                                    }
                                }
                            });
                        }
                        
                        // Method 2: Fallback - extract from rendered product cards if productData not available
                        if (allProducts.length === 0 && typeof psInstances !== 'undefined') {
                            Object.keys(psInstances).forEach(function(instanceId) {
                                const grid = document.getElementById(instanceId + '-grid');
                                if (grid) {
                                    const cards = grid.querySelectorAll('.ps-product-card');
                                    cards.forEach(function(card) {
                                        const titleEl = card.querySelector('.ps-product-title');
                                        const priceEl = card.querySelector('.ps-product-price-current');
                                        const imageEl = card.querySelector('.ps-product-image img');
                                        const linkEl = card.querySelector('.ps-product-button');
                                        
                                        if (titleEl) {
                                            const product = {
                                                title: titleEl.textContent || '',
                                                price: priceEl ? priceEl.textContent : '',
                                                image: imageEl ? imageEl.src : '',
                                                link: linkEl ? linkEl.href : ''
                                            };
                                            if (product.title) {
                                                allProducts.push(product);
                                            }
                                        }
                                    });
                                }
                            });
                        }
                        
                        return allProducts;
                    }
                    
                    // Try to get products with retry mechanism and AJAX fallback
                    function searchWithRetry(retryCount) {
                        retryCount = retryCount || 0;
                        const maxRetries = 5;
                        
                        const allProducts = getAllProducts();
                        
                        // If no products found locally, fetch via AJAX (for other pages)
                        if (allProducts.length === 0 && searchQuery && searchQuery.length > 0) {
                            // Fetch products from all URL groups via AJAX
                            const ajaxUrl = typeof psData !== 'undefined' ? psData.ajaxUrl : '';
                            const nonce = typeof psData !== 'undefined' ? psData.nonce : '';
                            
                            if (ajaxUrl && nonce) {
                                fetch(ajaxUrl, {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded',
                                    },
                                    body: 'action=ps_search_all_products&search_query=' + encodeURIComponent(searchQuery) + '&nonce=' + encodeURIComponent(nonce)
                                })
                                    .then(function(response) {
                                        if (!response.ok) {
                                            throw new Error('Network response was not ok');
                                        }
                                        return response.json();
                                    })
                                    .then(function(data) {
                                        if (data.success && data.data && data.data.products) {
                                            showSearchPopup(data.data.products, searchQuery);
                                        } else {
                                            showSearchPopup([], searchQuery);
                                        }
                                    })
                                    .catch(function(err) {
                                        console.error('Search error:', err);
                                        showSearchPopup([], searchQuery);
                                    });
                                return;
                            }
                        }
                        
                        // If no products found and we haven't exceeded retries, wait and try again
                        if (allProducts.length === 0 && retryCount < maxRetries) {
                            setTimeout(function() {
                                searchWithRetry(retryCount + 1);
                            }, 200);
                            return;
                        }
                        
                        // Filter products by search query
                        let matchingProducts = [];
                        if (searchQuery && searchQuery.length > 0) {
                            matchingProducts = allProducts.filter(function(product) {
                                // More lenient validation - only require title
                                if (!product.title) {
                                    return false;
                                }
                                
                                const searchText = (
                                    (product.title || '') + ' ' +
                                    (product.brand || '') + ' ' +
                                    (product.category || '') + ' ' +
                                    (product.description || '') + ' ' +
                                    (product.curveCode || '') + ' ' +
                                    (product.flexValue || '')
                                ).toLowerCase();
                                
                                return searchText.indexOf(searchQuery) !== -1;
                            });
                        }
                        
                        // Show popup
                        showSearchPopup(matchingProducts, searchQuery);
                    }
                    
                    // Start search
                    searchWithRetry(0);
                    
                    // Apply search to product grids
                    function tryApplySearch() {
                        if (typeof psInstances !== 'undefined') {
                            Object.keys(psInstances).forEach(function(instanceId) {
                                const searchInput = document.getElementById(instanceId + '-search-input');
                                const grid = document.getElementById(instanceId + '-grid');
                                
                                // Update sidebar search input if it exists
                                if (searchInput) {
                                    searchInput.value = searchQuery;
                                }
                                
                                // Update product data and apply filters
                                if (typeof productData !== 'undefined' && productData[instanceId]) {
                                    productData[instanceId].searchQuery = searchQuery;
                                    
                                    // Use exposed global functions if available
                                    if (grid && typeof window.psApplyFilters === 'function') {
                                        window.psApplyFilters(instanceId);
                                    } else if (grid && searchInput) {
                                        // Fallback: trigger input event on sidebar search
                                        const event = new Event('input', { bubbles: true, cancelable: true });
                                        searchInput.dispatchEvent(event);
                                    }
                                    
                                    // Update clear button
                                    if (typeof window.psUpdateClearButton === 'function') {
                                        window.psUpdateClearButton(instanceId);
                                    }
                                } else if (searchInput) {
                                    // If productData not ready yet, update input and trigger event
                                    searchInput.value = searchQuery;
                                    const event = new Event('input', { bubbles: true, cancelable: true });
                                    searchInput.dispatchEvent(event);
                                }
                            });
                        } else {
                            // Retry if psInstances not ready yet
                            setTimeout(tryApplySearch, 100);
                        }
                    }
                    
                    tryApplySearch();
                }
                
                document.addEventListener('DOMContentLoaded', function() {
                    const globalSearchInput = document.getElementById('ps-global-search-input');
                    const globalSearchButton = document.getElementById('ps-global-search-button');
                    const popup = document.getElementById('ps-search-results-popup');
                    const closePopup = document.getElementById('ps-search-close-popup');
                    
                    // Close popup button
                    if (closePopup) {
                        closePopup.addEventListener('click', function() {
                            if (popup) {
                                popup.style.display = 'none';
                            }
                            if (globalSearchInput) {
                                globalSearchInput.value = '';
                                applyGlobalSearch('');
                            }
                        });
                    }
                    
                    // Close popup when clicking outside
                    document.addEventListener('click', function(e) {
                        if (popup && !popup.contains(e.target) && 
                            e.target !== globalSearchInput && 
                            !globalSearchInput.contains(e.target) &&
                            e.target !== globalSearchButton &&
                            !globalSearchButton.contains(e.target)) {
                            popup.style.display = 'none';
                        }
                    });
                    
                    if (globalSearchInput) {
                        let searchTimeout;
                        
                        // Live search on input
                        globalSearchInput.addEventListener('input', function() {
                            const searchQuery = this.value.trim().toLowerCase();
                            clearTimeout(searchTimeout);
                            
                            // Show popup immediately if there's a query
                            if (searchQuery.length > 0) {
                                const popup = document.getElementById('ps-search-results-popup');
                                if (popup) {
                                    popup.style.display = 'block';
                                    const resultsList = document.getElementById('ps-search-results-list');
                                    if (resultsList) {
                                        resultsList.innerHTML = '<div class="ps-search-no-results">Searching...</div>';
                                    }
                                }
                            }
                            
                            searchTimeout = setTimeout(function() {
                                applyGlobalSearch(searchQuery);
                            }, 300);
                        });
                        
                        // Show popup on focus if there's text
                        globalSearchInput.addEventListener('focus', function() {
                            const searchQuery = this.value.trim().toLowerCase();
                            if (searchQuery.length > 0) {
                                applyGlobalSearch(searchQuery);
                            }
                        });
                        
                        // Search on button click
                        if (globalSearchButton) {
                            globalSearchButton.addEventListener('click', function() {
                                const searchQuery = globalSearchInput.value.trim().toLowerCase();
                                clearTimeout(searchTimeout);
                                applyGlobalSearch(searchQuery);
                            });
                        }
                        
                        // Search on Enter key
                        globalSearchInput.addEventListener('keypress', function(e) {
                            if (e.key === 'Enter') {
                                e.preventDefault();
                                clearTimeout(searchTimeout);
                                const searchQuery = this.value.trim().toLowerCase();
                                applyGlobalSearch(searchQuery);
                            }
                        });
                    }
                });
            }
        </script>
        <?php
        return ob_get_clean();
    }
}

