/**
 * Product Scraping Frontend Script
 * Fetches products via WordPress AJAX and renders them
 */

(function() {
    'use strict';
    
    // Wait for DOM to be ready
    document.addEventListener('DOMContentLoaded', function() {
        // Get AJAX URL and nonce from localized script
        const ajaxUrl = typeof psData !== 'undefined' ? psData.ajaxUrl : '';
        const nonce = typeof psData !== 'undefined' ? psData.nonce : '';
        
        if (!ajaxUrl) {
            console.error('Product Scraping: AJAX URL not configured');
            return;
        }
        
        // Process all instances
        if (typeof psInstances !== 'undefined') {
            Object.keys(psInstances).forEach(function(instanceId) {
                const instance = psInstances[instanceId];
                const urls = Array.isArray(instance.urls)
                    ? instance.urls
                    : (instance.url ? [instance.url] : []);
                
                if (!urls || urls.length === 0) {
                    console.error('Product Scraping: No URL(s) provided for instance', instanceId);
                    return;
                }
                
                // Get container elements
                const container = document.getElementById(instanceId);
                if (!container) {
                    return;
                }
                
                const grid = document.getElementById(instanceId + '-grid');
                const loading = container.querySelector('.ps-loading');
                const error = document.getElementById(instanceId + '-error');
                
                // Fetch products via WordPress AJAX for all URLs in this instance
                const allProducts = [];
                const urlProductCounts = {}; // Track product count per URL
                let completed = 0;
                
                urls.forEach(function(scrapeUrl) {
                    urlProductCounts[scrapeUrl] = 0; // Initialize count
                    
                    fetch(ajaxUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'action=ps_scrape_products&url=' + encodeURIComponent(scrapeUrl) + '&nonce=' + encodeURIComponent(nonce)
                    })
                        .then(function(response) {
                            if (!response.ok) {
                                throw new Error('Network response was not ok: ' + response.status);
                            }
                            return response.json();
                        })
                        .then(function(data) {
                            if (data.success && data.data && data.data.status === 'ok' && data.data.products && Array.isArray(data.data.products)) {
                                urlProductCounts[scrapeUrl] = data.data.products.length;
                                Array.prototype.push.apply(allProducts, data.data.products);
                            } else {
                                var errorMsg = data.data && data.data.message ? data.data.message : 'Failed to load products';
                                console.warn('Product Scraping: ' + errorMsg + ' for URL:', scrapeUrl);
                            }
                        })
                        .catch(function(err) {
                            console.error('Product Scraping Error:', err);
                        })
                        .finally(function() {
                            completed++;
                            if (completed === urls.length) {
                                // All URLs processed
                                if (loading) {
                                    loading.style.display = 'none';
                                }
                                
                                if (!allProducts.length) {
                                    showError(error, loading, 'No products found for any URL.');
                                    return;
                                }
                                
                                // Remove duplicate products (based on product link/URL)
                                // Run deduplication multiple times to catch any edge cases
                                let uniqueProducts = removeDuplicateProducts(allProducts);
                                let previousCount = uniqueProducts.length;
                                let passCount = 1;
                                
                                // Keep running deduplication until no more duplicates are found
                                while (passCount < 5) { // Max 5 passes for safety
                                    const newUnique = removeDuplicateProducts(uniqueProducts);
                                    if (newUnique.length === previousCount) {
                                        // No more duplicates found
                                        break;
                                    }
                                    uniqueProducts = newUnique;
                                    previousCount = uniqueProducts.length;
                                    passCount++;
                                }
                                
                                // Debug: Log counts
                                console.log('Product Scraping Debug:', {
                                    totalFetched: allProducts.length,
                                    uniqueAfterDedup: uniqueProducts.length,
                                    duplicatesRemoved: allProducts.length - uniqueProducts.length,
                                    dedupPasses: passCount,
                                    sampleProducts: uniqueProducts.slice(0, 3).map(function(p) {
                                        return {
                                            title: p.title ? p.title.substring(0, 30) : 'N/A',
                                            link: p.link ? p.link.substring(0, 50) : 'N/A',
                                            price: p.price || 'N/A'
                                        };
                                    })
                                });
                                
                                // If this instance is "featured", only render a subset and skip filters
                                const limit = instance.featuredLimit ? parseInt(instance.featuredLimit, 10) : null;
                                if (limit && limit > 0) {
                                    const limitedProducts = uniqueProducts.slice(0, limit);
                                    renderProducts(limitedProducts, grid, instanceId);
                                } else {
                                    const wrapper = document.getElementById(instanceId + '-wrapper');
                                    if (wrapper) {
                                        wrapper.style.display = 'flex';
                                    }
                                    initializeFilters(uniqueProducts, instanceId);
                                    renderProducts(uniqueProducts, grid, instanceId);
                                }
                            }
                        });
                });
            });
        }
        
        // Store all products and filtered products per instance
        const productData = {};
        
        // Initialize pagination state per instance
        const paginationState = {};
        
        // Initialize Compare functionality
        initializeCompare();
        
        /**
         * Initialize filters from products
         */
        function initializeFilters(products, instanceId) {
            // Filter valid products first (more lenient - only require title and price)
            const validProducts = products.filter(function(product) {
                return product.title && 
                       product.title.trim() !== '' &&
                       product.price && 
                       product.price.trim() !== '' &&
                       product.price !== 'Price not available';
                // Note: Image is optional - products without images will show placeholder
            });
            
            // Extract filter data
            const filterData = extractFilterData(validProducts);
            
            // Initialize product data storage
            productData[instanceId] = {
                all: validProducts,
                filtered: validProducts,
                searchQuery: '' // Initialize search query
            };
            
            // Build filter UI
            buildFilters(filterData, instanceId, validProducts);
            
            // Setup filter event listeners
            setupFilterListeners(instanceId);
        }
        
        /**
         * Extract filterable data from products
         */
        function extractFilterData(products) {
            const data = {
                categories: new Set(),
                tags: new Set(),
                hands: new Set(), // Left/Right for HAND filter
                divisions: new Set(), // Division filter
                patterns: new Set(), // Pattern filter
                sizes: new Set(),
                colors: new Set(),
                brands: new Set(),
                curves: new Set(),
                flexes: new Set(),
                prices: []
            };
            
            const curveNameMap = {
                'matthews': 'P90TM',
                'mcdavid': 'P28',
                'kane': 'P88',
                'ovechkin': 'P92',
                'giroux': 'P28',
                'kucherov': 'P28',
                'backstrom': 'P92',
                'stamkos': 'P92',
                'benn': 'P02',
                'nasht': 'P92',
                'eichel': 'P90',
                'monahan': 'P90',
                'gaudreau': 'P88',
                'marchand': 'P28'
            };
            
            products.forEach(function(product) {
                // Category - try multiple strategies so the sidebar never stays empty
                let category = '';
                
                // 1) Use category coming from backend if available
                if (product.category && product.category.trim()) {
                    category = product.category.trim();
                }
                
                // 2) Derive from product link path (e.g. /bauer-hockey-stick-vapor-x3-jr.html)
                if (!category && product.link) {
                    try {
                        const url = new URL(product.link);
                        const segments = url.pathname.split('/').filter(Boolean);
                        if (segments.length) {
                            // Try second-to-last segment first, then last
                            let slug = segments.length > 1 ? segments[segments.length - 2] : segments[segments.length - 1];
                            // Clean up slug to make a readable category
                            slug = slug
                                .replace(/\.html?$/i, '')
                                .replace(/[-_]+/g, ' ')
                                .replace(/\d+/g, '')
                                .trim();
                            if (slug.length >= 3) {
                                category = slug.charAt(0).toUpperCase() + slug.slice(1);
                            }
                        }
                    } catch (e) {
                        // Ignore URL parse errors and fall back to title-based logic
                    }
                }
                
                // 3) Fallback: infer from title keywords (useful for hockey gear)
                if (!category && product.title) {
                    const titleLower = product.title.toLowerCase();
                    if (titleLower.indexOf('stick') !== -1) {
                        category = 'Sticks';
                    } else if (titleLower.indexOf('skate') !== -1) {
                        category = 'Skates';
                    } else if (titleLower.indexOf('glove') !== -1) {
                        category = 'Gloves';
                    } else if (titleLower.indexOf('helmet') !== -1) {
                        category = 'Helmets';
                    } else if (titleLower.indexOf('pants') !== -1 || titleLower.indexOf('shorts') !== -1) {
                        category = 'Pants';
                    } else if (titleLower.indexOf('shoulder') !== -1 || titleLower.indexOf('elbow') !== -1 || titleLower.indexOf('shin') !== -1) {
                        category = 'Protective';
                    }
                }
                
                // Store derived category back on the product so filters and UI are consistent
                if (category) {
                    data.categories.add(category);
                    product.category = category;
                }
                
                // Brand
                if (product.brand && product.brand.trim()) {
                    data.brands.add(product.brand.trim());
                }
                
                // Tags (from description or title keywords)
                if (product.tags && Array.isArray(product.tags)) {
                    product.tags.forEach(function(tag) {
                        if (tag && tag.trim()) {
                            data.tags.add(tag.trim());
                        }
                    });
                }
                
                // Size (try to extract from title or description)
                const sizeMatch = (product.title + ' ' + (product.description || '')).match(/\b(XS|S|M|L|XL|XXL|XXXL|\d+[A-Z]?)\b/gi);
                if (sizeMatch) {
                    sizeMatch.forEach(function(size) {
                        data.sizes.add(size.toUpperCase());
                    });
                }
                
                // Color (try to extract from title or description)
                const colorKeywords = ['red', 'blue', 'green', 'yellow', 'black', 'white', 'gray', 'grey', 'orange', 'purple', 'pink', 'brown'];
                const text = (product.title + ' ' + (product.description || '')).toLowerCase();
                colorKeywords.forEach(function(color) {
                    if (text.indexOf(color) !== -1) {
                        data.colors.add(color.charAt(0).toUpperCase() + color.slice(1));
                    }
                });
                
                // Curve extraction - multiple strategies
                const productText = (product.title + ' ' + (product.description || '') + ' ' + (product.link || '')).toLowerCase();
                
                // Strategy 1: Standard curve codes (P92, P28, P88, W03, etc.)
                const curveRegex1 = /\b(?:P|PP|PM|W|E|TC|MC|N|HK)[\s\-\/\.]?\d{1,3}[A-Z]*\b/gi;
                const curveMatch1 = productText.match(curveRegex1);
                if (curveMatch1) {
                    curveMatch1.forEach(function(curve) {
                        const cleanCurve = curve.replace(/curve\s*/gi, '').replace(/[\s\-\/\.]/g, '').trim().toUpperCase();
                        if (cleanCurve && cleanCurve.length >= 2) {
                            data.curves.add(cleanCurve);
                            if (!product.curveCode) {
                                product.curveCode = cleanCurve;
                            }
                        }
                    });
                }
                
                // Strategy 2: Pattern like "P-92", "P 28", "P/88"
                const curveRegex2 = /\b(?:P|W|E)[\s\-\/\.]+(\d{1,3})[A-Z]*\b/gi;
                const curveMatch2 = productText.match(curveRegex2);
                if (curveMatch2) {
                    curveMatch2.forEach(function(curve) {
                        const cleanCurve = curve.replace(/[\s\-\/\.]/g, '').trim().toUpperCase();
                        if (cleanCurve && cleanCurve.length >= 2) {
                            data.curves.add(cleanCurve);
                            if (!product.curveCode) {
                                product.curveCode = cleanCurve;
                            }
                        }
                    });
                }
                
                // Strategy 3: Common curve patterns without prefix (92, 28, 88, etc. when context suggests curve)
                const curveRegex3 = /\b(?:curve|blade)[\s\-\/\.:]*(\d{1,3})[A-Z]*\b/gi;
                const curveMatch3 = productText.match(curveRegex3);
                if (curveMatch3) {
                    curveMatch3.forEach(function(match) {
                        const numMatch = match.match(/\d{1,3}/);
                        if (numMatch) {
                            // Check if it's a common curve number
                            const num = parseInt(numMatch[0], 10);
                            if (num >= 2 && num <= 99) {
                                // Try to infer prefix from context
                                let prefix = 'P';
                                if (productText.indexOf('wrist') !== -1 || productText.indexOf('w03') !== -1) {
                                    prefix = 'W';
                                }
                                const cleanCurve = prefix + numMatch[0];
                                data.curves.add(cleanCurve);
                                if (!product.curveCode) {
                                    product.curveCode = cleanCurve;
                                }
                            }
                        }
                    });
                }
                
                // Strategy 4: Curve from known pro/player names (Matthews, McDavid, etc.)
                Object.keys(curveNameMap).forEach(function(key) {
                    if (productText.indexOf(key) !== -1) {
                        const mappedCurve = curveNameMap[key];
                        data.curves.add(mappedCurve);
                        if (!product.curveCode) {
                            product.curveCode = mappedCurve;
                        }
                    }
                });
                
                // Strategy 5: Extract from URL if available
                if (product.link) {
                    try {
                        const url = new URL(product.link);
                        const urlText = url.pathname.toLowerCase();
                        const urlCurveMatch = urlText.match(/\b(?:p|w|e)[\s\-\/\.]?(\d{1,3})[a-z]*\b/gi);
                        if (urlCurveMatch) {
                            urlCurveMatch.forEach(function(curve) {
                                const cleanCurve = curve.replace(/[\s\-\/\.]/g, '').trim().toUpperCase();
                                if (cleanCurve && cleanCurve.length >= 2) {
                                    data.curves.add(cleanCurve);
                                    if (!product.curveCode) {
                                        product.curveCode = cleanCurve;
                                    }
                                }
                            });
                        }
                    } catch (e) {
                        // Ignore URL parse errors
                    }
                }
                
                // Flex (extract from title/description - common patterns: 40 Flex, 75 Flex, Flex 85, 65 Flex - Senior, etc.)
                const productTextForFlex = product.title + ' ' + (product.description || '');
                const flexMatch = productTextForFlex.match(/\b(\d{2,3})\s*[Ff]lex(?:\s*[-–]\s*(Senior|Junior|Intermediate|Youth))?\b|\b[Ff]lex\s*(\d{2,3})\b/gi);
                if (flexMatch) {
                    flexMatch.forEach(function(flex) {
                        const flexNum = flex.match(/\d{2,3}/);
                        if (flexNum) {
                            const flexValue = flexNum[0];
                            // Check for qualifier (Senior, Junior, etc.)
                            const qualifierMatch = flex.match(/\b(Senior|Junior|Intermediate|Youth)\b/i);
                            const qualifier = qualifierMatch ? qualifierMatch[1] : '';
                            
                            // Create flex key: "65" or "65 - Senior"
                            const flexKey = qualifier ? flexValue + ' - ' + qualifier : flexValue;
                            data.flexes.add(flexKey);
                            
                            // Store both the numeric value and full key
                            if (!product.flexValue) {
                                product.flexValue = flexValue;
                            }
                            if (!product.flexKey) {
                                product.flexKey = flexKey;
                            }
                        }
                    });
                }

                // Extract hand information (Left/Right) for HAND filter
                const fullText = (product.title + ' ' + (product.description || '')).toLowerCase();
                
                // Check for Left/Right hand indicators
                if (fullText.indexOf('left') !== -1 || fullText.indexOf('lh') !== -1 || fullText.indexOf('left-handed') !== -1) {
                    data.hands.add('Left');
                    if (!product.hand) {
                        product.hand = 'Left';
                    }
                }
                if (fullText.indexOf('right') !== -1 || fullText.indexOf('rh') !== -1 || fullText.indexOf('right-handed') !== -1) {
                    data.hands.add('Right');
                    if (!product.hand) {
                        product.hand = 'Right';
                    }
                }
                
                // Extract Division information (e.g., NHL, AHL, College, Youth, etc.)
                const divisionKeywords = [
                    { keyword: 'nhl', label: 'NHL' },
                    { keyword: 'ahl', label: 'AHL' },
                    { keyword: 'college', label: 'College' },
                    { keyword: 'university', label: 'College' },
                    { keyword: 'ncaa', label: 'College' },
                    { keyword: 'junior', label: 'Junior' },
                    { keyword: 'youth', label: 'Youth' },
                    { keyword: 'minor', label: 'Minor' },
                    { keyword: 'recreational', label: 'Recreational' },
                    { keyword: 'beer league', label: 'Recreational' },
                    { keyword: 'adult', label: 'Adult' }
                ];
                
                divisionKeywords.forEach(function(div) {
                    if (fullText.indexOf(div.keyword) !== -1) {
                        data.divisions.add(div.label);
                        if (!product.division) {
                            product.division = div.label;
                        }
                    }
                });
                
                // Extract Pattern information (e.g., P28, P92, P88, etc. - common hockey stick patterns)
                const patternMatch = fullText.match(/\b(p\d{1,3}|p\s*\d{1,3}|pattern\s*\d{1,3})\b/i);
                if (patternMatch) {
                    const pattern = patternMatch[1].replace(/\s+/g, '').toUpperCase();
                    // Normalize pattern format (P28, P92, etc.)
                    const normalizedPattern = pattern.replace(/^P/i, 'P');
                    data.patterns.add(normalizedPattern);
                    if (!product.pattern) {
                        product.pattern = normalizedPattern;
                    }
                }
                
                // Also check for common curve patterns in text
                const commonPatterns = ['P28', 'P92', 'P88', 'P90', 'P02', 'P90TM'];
                commonPatterns.forEach(function(pattern) {
                    if (fullText.indexOf(pattern.toLowerCase()) !== -1 || fullText.indexOf(pattern) !== -1) {
                        data.patterns.add(pattern);
                        if (!product.pattern) {
                            product.pattern = pattern;
                        }
                    }
                });
                
                // Auto-generate useful tags from title/description (level, promo, etc.) - excluding hand
                const autoTagDefinitions = [
                    { keyword: 'junior', label: 'Junior' },
                    { keyword: 'youth', label: 'Youth' },
                    { keyword: 'intermediate', label: 'Intermediate' },
                    { keyword: 'senior', label: 'Senior' },
                    { keyword: 'pro', label: 'Pro' },
                    { keyword: 'clearance', label: 'Clearance' },
                    { keyword: 'sale', label: 'On Sale' },
                ];

                autoTagDefinitions.forEach(function(def) {
                    if (fullText.indexOf(def.keyword) !== -1) {
                        data.tags.add(def.label);
                        // Also reflect back on product.tags so filters work consistently
                        if (!Array.isArray(product.tags)) {
                            product.tags = [];
                        }
                        if (product.tags.indexOf(def.label) === -1) {
                            product.tags.push(def.label);
                        }
                    }
                });
                
                // Price
                const price = parsePrice(product.price);
                if (price !== null) {
                    data.prices.push(price);
                }
            });
            
            return {
                categories: Array.from(data.categories).sort(),
                tags: Array.from(data.tags).sort(),
                hands: Array.from(data.hands).sort(), // Left, Right
                divisions: Array.from(data.divisions).sort(), // Division options
                patterns: Array.from(data.patterns).sort(), // Pattern options
                sizes: Array.from(data.sizes).sort(),
                // colors kept internally for potential future use, but not exposed in UI
                colors: Array.from(data.colors).sort(),
                brands: Array.from(data.brands).sort(),
                curves: Array.from(data.curves).sort(),
                flexes: Array.from(data.flexes).sort(function(a, b) {
                    return parseInt(a) - parseInt(b);
                }),
                minPrice: data.prices.length > 0 ? Math.min.apply(null, data.prices) : 0,
                maxPrice: data.prices.length > 0 ? Math.max.apply(null, data.prices) : 1000
            };
        }
        
        /**
         * Parse price string to number
         */
        function parsePrice(priceStr) {
            if (!priceStr) return null;
            // Remove currency symbols and extract number
            const match = priceStr.match(/[\d,]+\.?\d*/);
            if (match) {
                return parseFloat(match[0].replace(/,/g, ''));
            }
            return null;
        }
        
        /**
         * Build filter UI
         */
        function buildFilters(filterData, instanceId, products) {
            // Price range
            const priceMinSlider = document.getElementById(instanceId + '-price-min');
            const priceMaxSlider = document.getElementById(instanceId + '-price-max');
            const priceMinDisplay = document.getElementById(instanceId + '-price-min-display');
            const priceMaxDisplay = document.getElementById(instanceId + '-price-max-display');
            
            if (priceMinSlider && priceMaxSlider) {
                priceMinSlider.min = Math.floor(filterData.minPrice);
                priceMinSlider.max = Math.ceil(filterData.maxPrice);
                priceMinSlider.value = Math.floor(filterData.minPrice);
                priceMaxSlider.min = Math.floor(filterData.minPrice);
                priceMaxSlider.max = Math.ceil(filterData.maxPrice);
                priceMaxSlider.value = Math.ceil(filterData.maxPrice);
                
                if (priceMinDisplay) {
                    priceMinDisplay.textContent = '$' + Math.floor(filterData.minPrice);
                }
                if (priceMaxDisplay) {
                    priceMaxDisplay.textContent = '$' + Math.ceil(filterData.maxPrice) + '+';
                }
                
                // Initialize range track
                setTimeout(function() {
                    updatePriceRangeTrack(instanceId);
                }, 100);
            }
            
            // Build category filter
            buildFilterOptions(instanceId + '-category-options', filterData.categories, 'category', products);
            
            // Build tag filter (HAND filter - shows Left/Right)
            buildFilterOptions(instanceId + '-tag-options', filterData.hands, 'tag', products);
            
            // Build division filter
            buildFilterOptions(instanceId + '-division-options', filterData.divisions, 'division', products);
            
            // Build pattern filter
            buildFilterOptions(instanceId + '-pattern-options', filterData.patterns, 'pattern', products);
            
            // Build size filter (using flex data for FLEX display)
            buildFlexFilterOptions(instanceId + '-size-options', filterData.flexes, 'flex', products);
            
            // Build brand filter
            buildFilterOptions(instanceId + '-brand-options', filterData.brands, 'brand', products);
            
            // Build curve filter
            buildFilterOptions(instanceId + '-curve-options', filterData.curves, 'curve', products);
            
            // Build flex filter
            buildFilterOptions(instanceId + '-flex-options', filterData.flexes, 'flex', products);
        }
        
        /**
         * Build flex filter options with custom formatting (XX Flex (count) or XX Flex - Senior (count))
         */
        function buildFlexFilterOptions(containerId, options, filterType, products) {
            const container = document.getElementById(containerId);
            if (!container) return;
            
            container.innerHTML = '';
            
            if (options.length === 0) {
                container.innerHTML = '<p style="color: #999; font-size: 12px; margin: 0;">No options available</p>';
                return;
            }
            
            // Calculate counts for each flex option
            const optionCounts = {};
            options.forEach(function(option) {
                let count = 0;
                if (products && Array.isArray(products)) {
                    products.forEach(function(product) {
                        // Check if product matches this flex option
                        // Option can be "65" or "65 - Senior"
                        const flexValue = option.split(' - ')[0]; // Get numeric part
                        const qualifier = option.split(' - ')[1]; // Get qualifier if exists
                        
                        let matches = false;
                        if (product.flexKey) {
                            // Use flexKey if available (includes qualifier)
                            matches = product.flexKey === option;
                        } else if (product.flexValue) {
                            // Fallback to flexValue (numeric only)
                            if (qualifier) {
                                // If option has qualifier, check product text for both flex and qualifier
                                const productText = (product.title + ' ' + (product.description || '')).toLowerCase();
                                matches = product.flexValue === flexValue && 
                                         productText.indexOf(qualifier.toLowerCase()) !== -1;
                            } else {
                                // No qualifier, just match flex value
                                matches = product.flexValue === flexValue;
                            }
                        }
                        if (matches) count++;
                    });
                }
                optionCounts[option] = count;
            });
            
            // Sort flex options numerically
            const sortedOptions = options.sort(function(a, b) {
                const numA = parseInt(a.split(' - ')[0], 10);
                const numB = parseInt(b.split(' - ')[0], 10);
                if (numA !== numB) {
                    return numA - numB;
                }
                // If same number, sort by qualifier
                const qualA = a.split(' - ')[1] || '';
                const qualB = b.split(' - ')[1] || '';
                return qualA.localeCompare(qualB);
            });
            
            // Show More threshold
            const cutoff = 7;
            const shouldTruncate = sortedOptions.length > cutoff;
            const visibleCount = shouldTruncate ? cutoff : sortedOptions.length;
            
            // Create list container
            const listContainer = document.createElement('ul');
            listContainer.className = 'ps-filter-options-list';
            listContainer.style.listStyle = 'none';
            listContainer.style.padding = '0';
            listContainer.style.margin = '0';
            
            sortedOptions.forEach(function(option, index) {
                const optionLi = document.createElement('li');
                optionLi.className = 'ps-filter-option';
                if (index >= visibleCount) {
                    optionLi.classList.add('ps-hidden');
                }
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.id = containerId + '-' + option.replace(/\s+/g, '-').replace(/[^a-z0-9-]/gi, '').toLowerCase();
                checkbox.value = option;
                checkbox.dataset.filterType = filterType;
                
                const label = document.createElement('label');
                label.htmlFor = checkbox.id;
                
                // Format display text: "XX Flex" or "XX Flex - Senior"
                const flexValue = option.split(' - ')[0];
                const qualifier = option.split(' - ')[1];
                const displayText = qualifier ? flexValue + ' Flex - ' + qualifier : flexValue + ' Flex';
                
                // Create text span
                const textSpan = document.createElement('span');
                textSpan.className = 'ps-filter-text';
                textSpan.textContent = displayText;
                
                // Create count span
                const countSpan = document.createElement('span');
                countSpan.className = 'ps-filter-count';
                countSpan.textContent = ' (' + optionCounts[option] + ')';
                
                label.appendChild(checkbox);
                label.appendChild(textSpan);
                label.appendChild(countSpan);
                optionLi.appendChild(label);
                listContainer.appendChild(optionLi);
            });
            
            container.appendChild(listContainer);
            
            // Add Show More/Less button if needed
            if (shouldTruncate) {
                const toggleBtn = document.createElement('a');
                toggleBtn.className = 'ps-action-toggle';
                toggleBtn.href = '#';
                toggleBtn.textContent = '(+) Show ' + (sortedOptions.length - cutoff) + ' More';
                toggleBtn.dataset.isOpen = 'false';
                
                toggleBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const isOpen = this.dataset.isOpen === 'true';
                    
                    // Toggle visibility
                    for (let i = cutoff; i < sortedOptions.length; i++) {
                        const hiddenItems = listContainer.querySelectorAll('.ps-hidden');
                        hiddenItems.forEach(function(item) {
                            item.style.display = isOpen ? 'none' : 'block';
                        });
                    }
                    
                    this.textContent = isOpen
                        ? '(+) Show ' + (sortedOptions.length - cutoff) + ' More'
                        : '(-) Show Less';
                    this.dataset.isOpen = (!isOpen).toString();
                });
                
                container.appendChild(toggleBtn);
            }
        }
        
        /**
         * Build filter options checkboxes with counts and Show More functionality
         */
        function buildFilterOptions(containerId, options, filterType, products) {
            const container = document.getElementById(containerId);
            if (!container) return;
            
            container.innerHTML = '';
            
            if (options.length === 0) {
                container.innerHTML = '<p style="color: #999; font-size: 12px; margin: 0;">No options available</p>';
                return;
            }
            
            // Calculate counts for each option
            const optionCounts = {};
            options.forEach(function(option) {
                let count = 0;
                if (products && Array.isArray(products)) {
                    products.forEach(function(product) {
                        let matches = false;
                        const optionLower = option.toLowerCase();
                        
                        switch(filterType) {
                            case 'category':
                                matches = product.category && product.category.toLowerCase() === optionLower;
                                break;
                            case 'tag':
                                // For HAND filter, check product.hand property (Left/Right)
                                if (optionLower === 'left' || optionLower === 'right') {
                                    matches = product.hand && product.hand.toLowerCase() === optionLower;
                                } else {
                                    // For other tags, check product.tags array
                                    matches = product.tags && Array.isArray(product.tags) && 
                                             product.tags.some(function(tag) { return tag.toLowerCase() === optionLower; });
                                }
                                break;
                            case 'division':
                                // Check product.division property or search in title/description
                                if (product.division) {
                                    matches = product.division.toLowerCase() === optionLower;
                                } else {
                                    const productText = (product.title + ' ' + (product.description || '')).toLowerCase();
                                    matches = productText.indexOf(optionLower) !== -1;
                                }
                                break;
                            case 'pattern':
                                // Check product.pattern property or search in title/description
                                if (product.pattern) {
                                    matches = product.pattern.toLowerCase() === optionLower;
                                } else {
                                    const productText = (product.title + ' ' + (product.description || '')).toUpperCase();
                                    matches = productText.indexOf(option.toUpperCase()) !== -1;
                                }
                                break;
                            case 'size':
                                matches = product.size && product.size.toLowerCase() === optionLower;
                                break;
                            case 'brand':
                                matches = product.brand && product.brand.toLowerCase() === optionLower;
                                break;
                            case 'curve':
                                matches = product.curveCode && product.curveCode.toLowerCase() === optionLower;
                                break;
                            case 'flex':
                                // Flex option can be "65" or "65 - Senior"
                                const flexValue = option.split(' - ')[0];
                                const qualifier = option.split(' - ')[1];
                                
                                if (product.flexKey) {
                                    // Use flexKey if available (includes qualifier)
                                    matches = product.flexKey === option;
                                } else if (product.flexValue) {
                                    // Fallback to flexValue
                                    if (qualifier) {
                                        // If option has qualifier, check product text
                                        const productText = (product.title + ' ' + (product.description || '')).toLowerCase();
                                        matches = product.flexValue === flexValue && 
                                                 productText.indexOf(qualifier.toLowerCase()) !== -1;
                                    } else {
                                        // No qualifier, just match flex value
                                        matches = product.flexValue === flexValue;
                                    }
                                }
                                break;
                        }
                        if (matches) count++;
                    });
                }
                optionCounts[option] = count;
            });
            
            // Show More threshold (show first 7, then expand)
            const cutoff = 7;
            const shouldTruncate = options.length > cutoff;
            const visibleCount = shouldTruncate ? cutoff : options.length;
            
            // Create list container
            const listContainer = document.createElement('ul');
            listContainer.className = 'ps-filter-options-list';
            listContainer.style.listStyle = 'none';
            listContainer.style.padding = '0';
            listContainer.style.margin = '0';
            
            options.forEach(function(option, index) {
                const optionLi = document.createElement('li');
                optionLi.className = 'ps-filter-option';
                if (index >= visibleCount) {
                    optionLi.classList.add('ps-hidden');
                }
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.id = containerId + '-' + option.replace(/\s+/g, '-').toLowerCase();
                checkbox.value = option;
                checkbox.dataset.filterType = filterType;
                
                const label = document.createElement('label');
                label.htmlFor = checkbox.id;
                
                // Create text span
                const textSpan = document.createElement('span');
                textSpan.className = 'ps-filter-text';
                textSpan.textContent = option;
                
                // Create count span
                const countSpan = document.createElement('span');
                countSpan.className = 'ps-filter-count';
                countSpan.textContent = ' (' + optionCounts[option] + ')';
                
                label.appendChild(textSpan);
                label.appendChild(countSpan);
                
                optionLi.appendChild(checkbox);
                optionLi.appendChild(label);
                listContainer.appendChild(optionLi);
            });
            
            container.appendChild(listContainer);
            
            // Add Show More/Less button if needed
            if (shouldTruncate) {
                const toggleBtn = document.createElement('a');
                toggleBtn.className = 'ps-action-toggle';
                toggleBtn.href = '#';
                toggleBtn.textContent = '(+) Show ' + (options.length - cutoff) + ' More';
                toggleBtn.dataset.isOpen = 'false';
                
                toggleBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const isOpen = this.dataset.isOpen === 'true';
                    
                    // Toggle visibility
                    for (let i = cutoff; i < options.length; i++) {
                        const optionLi = listContainer.children[i];
                        if (isOpen) {
                            optionLi.classList.add('ps-hidden');
                        } else {
                            optionLi.classList.remove('ps-hidden');
                        }
                    }
                    
                    // Update button text
                    if (isOpen) {
                        this.textContent = '(+) Show ' + (options.length - cutoff) + ' More';
                        this.dataset.isOpen = 'false';
                    } else {
                        this.textContent = '(-) Show Less';
                        this.dataset.isOpen = 'true';
                    }
                });
                
                container.appendChild(toggleBtn);
            }
        }
        
        /**
         * Update active range track
         */
        function updatePriceRangeTrack(instanceId) {
            const priceMaxSlider = document.getElementById(instanceId + '-price-max');
            const activeTrack = document.getElementById(instanceId + '-price-range-active');
            
            if (!priceMaxSlider || !activeTrack) return;
            
            const max = parseFloat(priceMaxSlider.value);
            const minRange = parseFloat(priceMaxSlider.min);
            const maxRange = parseFloat(priceMaxSlider.max);
            
            const maxPercent = ((max - minRange) / (maxRange - minRange)) * 100;
            
            // Always start from the left (0%) so the line runs from start to handle
            activeTrack.style.left = '0%';
            activeTrack.style.width = maxPercent + '%';
        }
        
        /**
         * Setup filter event listeners
         */
        function setupFilterListeners(instanceId) {
            const grid = document.getElementById(instanceId + '-grid');
            const clearBtn = document.getElementById(instanceId + '-clear-filters');
            const searchInput = document.getElementById(instanceId + '-search-input');
            
            // Ensure productData is initialized
            if (!productData[instanceId]) {
                console.warn('Product Scraping: productData not initialized for instance', instanceId);
                return;
            }
            const priceMinSlider = document.getElementById(instanceId + '-price-min');
            const priceMaxSlider = document.getElementById(instanceId + '-price-max');
            const priceMinDisplay = document.getElementById(instanceId + '-price-min-display');
            const priceMaxDisplay = document.getElementById(instanceId + '-price-max-display');
            
            // Make filter sections collapsible
            const filterSections = document.querySelectorAll('#' + instanceId + '-filters .ps-filter-section h4');
            filterSections.forEach(function(heading) {
                // Skip search section
                if (heading.closest('.ps-search-section')) {
                    return;
                }
                
                heading.style.cursor = 'pointer';
                heading.addEventListener('click', function() {
                    const section = this.closest('.ps-filter-section');
                    if (section) {
                        section.classList.toggle('ps-collapsed');
                    }
                });
            });
            
            // Search functionality - button triggered search
            const searchBtn = document.getElementById(instanceId + '-search-btn');
            
            // Function to perform search
            function performSearch() {
                if (!searchInput) {
                    console.warn('Product Scraping: Search input not found for instance', instanceId);
                    return;
                }
                if (!productData[instanceId]) {
                    console.warn('Product Scraping: productData not initialized for instance', instanceId);
                    return;
                }
                if (!grid) {
                    console.warn('Product Scraping: grid not found for instance', instanceId);
                    return;
                }
                const searchQuery = searchInput.value.trim().toLowerCase();
                productData[instanceId].searchQuery = searchQuery;
                applyFilters(instanceId, grid);
                updateClearButton(instanceId);
            }
            
            // Arrow button click handler
            if (searchBtn) {
                searchBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    performSearch();
                });
            }
            
            // Enter key handler (still works)
            if (searchInput) {
                searchInput.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        performSearch();
                    }
                });
            } else {
                console.warn('Product Scraping: Search input not found for instance', instanceId);
            }
            
            // Price slider listeners
            if (priceMinSlider && priceMaxSlider) {
                function updatePriceDisplay() {
                    const min = parseInt(priceMinSlider.value);
                    const max = parseInt(priceMaxSlider.value);
                    if (priceMinDisplay) {
                        priceMinDisplay.textContent = '$' + min;
                    }
                    if (priceMaxDisplay) {
                        priceMaxDisplay.textContent = '$' + max + '+';
                    }
                    // Ensure min <= max
                    if (min > max) {
                        priceMinSlider.value = max;
                        if (priceMinDisplay) {
                            priceMinDisplay.textContent = '$' + max;
                        }
                    }
                    updatePriceRangeTrack(instanceId);
                    applyFilters(instanceId, grid);
                }
                
                priceMinSlider.addEventListener('input', updatePriceDisplay);
                priceMaxSlider.addEventListener('input', updatePriceDisplay);
                
                // Initialize range track
                updatePriceRangeTrack(instanceId);
            }
            
            // Checkbox listeners for all filter types (color removed)
            const filterContainers = ['category', 'tag', 'size', 'brand', 'curve', 'flex'];
            filterContainers.forEach(function(filterType) {
                const container = document.getElementById(instanceId + '-' + filterType + '-options');
                if (container) {
                    container.addEventListener('change', function(e) {
                        if (e.target.type === 'checkbox') {
                            applyFilters(instanceId, grid);
                            updateClearButton(instanceId);
                        }
                    });
                }
            });
            
            // Clear filters button
            if (clearBtn) {
                clearBtn.addEventListener('click', function() {
                    clearAllFilters(instanceId, grid);
                });
            }
        }
        
        /**
         * Apply filters to products
         */
        function applyFilters(instanceId, grid) {
            if (!productData[instanceId]) return;
            
            const allProducts = productData[instanceId].all;
            const searchQuery = productData[instanceId].searchQuery || '';
            
            let filtered = allProducts.filter(function(product) {
                // Basic validation
                if (!product.title || !product.price || !product.image ||
                    product.price === 'Price not available') {
                    return false;
                }
                
                // Search filter (live search)
                if (searchQuery && searchQuery.length > 0) {
                    const searchText = (
                        (product.title || '') + ' ' +
                        (product.brand || '') + ' ' +
                        (product.category || '') + ' ' +
                        (product.description || '') + ' ' +
                        (product.curveCode || '') + ' ' +
                        (product.flexValue || '') + ' ' +
                        (product.division || '') + ' ' +
                        (product.pattern || '') + ' ' +
                        (product.hand || '')
                    ).toLowerCase().trim();
                    
                    const query = searchQuery.toLowerCase().trim();
                    if (!searchText || searchText.indexOf(query) === -1) {
                        return false;
                    }
                }
                
                // Price filter
                const priceMinSlider = document.getElementById(instanceId + '-price-min');
                const priceMaxSlider = document.getElementById(instanceId + '-price-max');
                if (priceMinSlider && priceMaxSlider) {
                    const minPrice = parseFloat(priceMinSlider.value);
                    const maxPrice = parseFloat(priceMaxSlider.value);
                    const productPrice = parsePrice(product.price);
                    if (productPrice === null || productPrice < minPrice || productPrice > maxPrice) {
                        return false;
                    }
                }
                
                // Category filter
                if (!checkFilter(instanceId, 'category', product.category)) {
                    return false;
                }
                
                // Brand filter
                if (!checkFilter(instanceId, 'brand', product.brand)) {
                    return false;
                }
                
                // Curve filter (prefer extracted curve code, fall back to searching text)
                const curveValue = product.curveCode ? product.curveCode : (product.title + ' ' + (product.description || ''));
                const curveIsText = product.curveCode ? false : true;
                if (!checkFilter(instanceId, 'curve', curveValue, curveIsText)) {
                    return false;
                }
                
                // Flex filter (use flexKey if available, otherwise flexValue)
                const flexValue = product.flexKey || product.flexValue || (product.title + ' ' + (product.description || ''));
                const flexIsText = !product.flexKey && !product.flexValue;
                if (!checkFilter(instanceId, 'flex', flexValue, flexIsText)) {
                    return false;
                }
                
                // Tag filter (HAND filter - Left/Right)
                // Check product.hand for Left/Right, otherwise check product.tags
                const tagValue = product.hand || product.tags;
                if (!checkFilter(instanceId, 'tag', tagValue)) {
                    return false;
                }
                
                // Division filter
                const divisionValue = product.division || (product.title + ' ' + (product.description || ''));
                if (!checkFilter(instanceId, 'division', divisionValue, true)) {
                    return false;
                }
                
                // Pattern filter
                const patternValue = product.pattern || (product.title + ' ' + (product.description || ''));
                if (!checkFilter(instanceId, 'pattern', patternValue, true)) {
                    return false;
                }
                
                // Size filter (check in title/description)
                const sizeText = (product.title + ' ' + (product.description || '')).toUpperCase();
                if (!checkFilter(instanceId, 'size', sizeText, true)) {
                    return false;
                }
                
                return true;
            });
            
            productData[instanceId].filtered = filtered;
            // Reset to page 1 when filters change
            if (paginationState[instanceId]) {
                paginationState[instanceId].currentPage = 1;
            }
            renderProducts(filtered, grid, instanceId);
        }
        
        /**
         * Check if product matches filter
         */
        function checkFilter(instanceId, filterType, productValue, isTextSearch) {
            const container = document.getElementById(instanceId + '-' + filterType + '-options');
            if (!container) return true;
            
            const checkedBoxes = container.querySelectorAll('input[type="checkbox"]:checked');
            if (checkedBoxes.length === 0) return true; // No filter applied
            
            if (isTextSearch) {
                // For size, color, curve, and flex - search in text
                for (let i = 0; i < checkedBoxes.length; i++) {
                    const filterValue = checkedBoxes[i].value;
                    // For curve and flex, use case-insensitive search
                    const searchText = (filterType === 'curve' || filterType === 'flex') 
                        ? productValue.toUpperCase() 
                        : productValue.toLowerCase();
                    const searchValue = (filterType === 'curve' || filterType === 'flex')
                        ? filterValue.toUpperCase()
                        : filterValue.toLowerCase();
                    
                    // For flex, also check for "Flex XX" pattern
                    if (filterType === 'flex') {
                        const flexPattern = new RegExp('\\b' + searchValue + '\\s*[Ff]lex\\b|\\b[Ff]lex\\s*' + searchValue + '\\b', 'i');
                        if (flexPattern.test(productValue)) {
                            return true;
                        }
                    }
                    
                    if (searchText.indexOf(searchValue) !== -1) {
                        return true;
                    }
                }
                return false;
            } else {
                // For category, brand, tag - exact match
                if (Array.isArray(productValue)) {
                    // Tags array
                    for (let i = 0; i < checkedBoxes.length; i++) {
                        if (productValue.indexOf(checkedBoxes[i].value) !== -1) {
                            return true;
                        }
                    }
                    return false;
                } else {
                    // Single value (for tag filter, this could be hand: "Left" or "Right")
                    // For flex filter, this could be "65" or "65 - Senior"
                    for (let i = 0; i < checkedBoxes.length; i++) {
                        const filterVal = checkedBoxes[i].value;
                        
                        // For flex filter, handle qualifiers
                        if (filterType === 'flex') {
                            const filterFlexNum = filterVal.split(' - ')[0];
                            const filterQualifier = filterVal.split(' - ')[1];
                            const productFlexNum = productValue.split(' - ')[0];
                            const productQualifier = productValue.split(' - ')[1];
                            
                            // Match if flex numbers match
                            if (filterFlexNum === productFlexNum) {
                                // If filter has qualifier, product must have same qualifier or no qualifier
                                // If filter has no qualifier, match any product with that flex number
                                if (!filterQualifier || filterQualifier === productQualifier || !productQualifier) {
                            return true;
                                }
                            }
                        } else {
                            // Case-insensitive comparison for other values
                            if (productValue && productValue.trim().toLowerCase() === filterVal.toLowerCase()) {
                                return true;
                            }
                        }
                    }
                    return false;
                }
            }
        }
        
        /**
         * Clear all filters
         */
        function clearAllFilters(instanceId, grid) {
            // Clear search input
            const searchInput = document.getElementById(instanceId + '-search-input');
            if (searchInput) {
                searchInput.value = '';
                if (productData[instanceId]) {
                    productData[instanceId].searchQuery = '';
                }
            }
            
            // Uncheck all checkboxes (color removed)
            const filterContainers = ['category', 'tag', 'size', 'brand', 'curve', 'flex'];
            filterContainers.forEach(function(filterType) {
                const container = document.getElementById(instanceId + '-' + filterType + '-options');
                if (container) {
                    const checkboxes = container.querySelectorAll('input[type="checkbox"]');
                    checkboxes.forEach(function(checkbox) {
                        checkbox.checked = false;
                    });
                }
            });
            
            // Reset price sliders
            const priceMinSlider = document.getElementById(instanceId + '-price-min');
            const priceMaxSlider = document.getElementById(instanceId + '-price-max');
            if (priceMinSlider && priceMaxSlider && productData[instanceId]) {
                const filterData = extractFilterData(productData[instanceId].all);
                priceMinSlider.value = Math.floor(filterData.minPrice);
                priceMaxSlider.value = Math.ceil(filterData.maxPrice);
                
                const priceMinDisplay = document.getElementById(instanceId + '-price-min-display');
                const priceMaxDisplay = document.getElementById(instanceId + '-price-max-display');
                if (priceMinDisplay) {
                    priceMinDisplay.textContent = '$' + Math.floor(filterData.minPrice);
                }
                if (priceMaxDisplay) {
                    priceMaxDisplay.textContent = '$' + Math.ceil(filterData.maxPrice) + '+';
                }
                
                // Update range track
                updatePriceRangeTrack(instanceId);
            }
            
            // Reset pagination to page 1
            if (paginationState[instanceId]) {
                paginationState[instanceId].currentPage = 1;
            }
            
            updateClearButton(instanceId);
            applyFilters(instanceId, grid);
        }
        
        /**
         * Update clear filters button visibility
         */
        function updateClearButton(instanceId) {
            const clearBtn = document.getElementById(instanceId + '-clear-filters');
            if (!clearBtn) return;
            
            let hasActiveFilters = false;
            
            // Check checkboxes
            const filterContainers = ['category', 'tag', 'size', 'brand', 'curve', 'flex'];
            filterContainers.forEach(function(filterType) {
                const container = document.getElementById(instanceId + '-' + filterType + '-options');
                if (container) {
                    const checked = container.querySelectorAll('input[type="checkbox"]:checked');
                    if (checked.length > 0) {
                        hasActiveFilters = true;
                    }
                }
            });
            
            // Check price range
            const priceMinSlider = document.getElementById(instanceId + '-price-min');
            const priceMaxSlider = document.getElementById(instanceId + '-price-max');
            if (priceMinSlider && priceMaxSlider && productData[instanceId]) {
                const filterData = extractFilterData(productData[instanceId].all);
                const minPrice = parseFloat(priceMinSlider.value);
                const maxPrice = parseFloat(priceMaxSlider.value);
                if (minPrice !== Math.floor(filterData.minPrice) || 
                    maxPrice !== Math.ceil(filterData.maxPrice)) {
                    hasActiveFilters = true;
                }
            }
            
            // Check search query
            if (productData[instanceId] && productData[instanceId].searchQuery && productData[instanceId].searchQuery.length > 0) {
                hasActiveFilters = true;
            }
            
            clearBtn.style.display = hasActiveFilters ? 'block' : 'none';
        }
        
        /**
         * Remove duplicate products from array
         * Checks by product link (URL) first, then by title + price combination
         */
        function removeDuplicateProducts(products) {
            if (!Array.isArray(products) || products.length === 0) {
                return products;
            }
            
            const seen = new Set();
            const uniqueProducts = [];
            
            products.forEach(function(product) {
                // Multiple strategies to identify duplicates
                let keys = [];
                
                // Strategy 1: Normalize and use product link/URL
                if (product.link && product.link.trim() !== '') {
                    let normalizedUrl = product.link.trim().toLowerCase()
                        .replace(/\/$/, '') // Remove trailing slash
                        .split('?')[0] // Remove query parameters
                        .split('#')[0]; // Remove hash
                    
                    // Extract product identifier from URL (e.g., /product-name.html or /product-name)
                    const urlParts = normalizedUrl.split('/');
                    const lastPart = urlParts[urlParts.length - 1];
                    if (lastPart) {
                        const productSlug = lastPart.replace(/\.html?$/i, '').replace(/[^a-z0-9-]/gi, '');
                        if (productSlug) {
                            keys.push('url:' + productSlug);
                        }
                    }
                    keys.push('fullurl:' + normalizedUrl);
                }
                
                // Strategy 2: Use title + price combination (normalized)
                if (product.title && product.price) {
                    const normalizedTitle = product.title.trim().toLowerCase()
                        .replace(/[^a-z0-9]/gi, '') // Remove special chars
                        .substring(0, 50); // Limit length
                    const normalizedPrice = product.price.trim().toLowerCase()
                        .replace(/[^0-9.]/g, ''); // Extract numbers only
                    if (normalizedTitle && normalizedPrice) {
                        keys.push('titleprice:' + normalizedTitle + '|' + normalizedPrice);
                    }
                }
                
                // Strategy 3: Use title only (for cases where price might vary slightly)
                if (product.title) {
                    const normalizedTitle = product.title.trim().toLowerCase()
                        .replace(/[^a-z0-9]/gi, '')
                        .substring(0, 50);
                    if (normalizedTitle) {
                        keys.push('title:' + normalizedTitle);
                    }
                }
                
                // Check if any key matches a previously seen product
                let isDuplicate = false;
                for (let i = 0; i < keys.length; i++) {
                    if (seen.has(keys[i])) {
                        isDuplicate = true;
                        break;
                    }
                }
                
                // If not duplicate, add all keys to seen set and add product
                if (!isDuplicate && keys.length > 0) {
                    keys.forEach(function(key) {
                        seen.add(key);
                    });
                    uniqueProducts.push(product);
                } else if (keys.length === 0) {
                    // If no keys could be generated, still add the product (edge case)
                    // But mark it with a generic key to prevent exact duplicates
                    const titleHash = product.title ? product.title.toLowerCase().replace(/[^a-z0-9]/gi, '').substring(0, 20) : 'unknown';
                    const fallbackKey = 'fallback:' + titleHash + '|' + (product.price || '0');
                    if (!seen.has(fallbackKey)) {
                        seen.add(fallbackKey);
                        uniqueProducts.push(product);
                    }
                }
            });
            
            return uniqueProducts;
        }
        
        /**
         * Render products into grid
         */
        function renderProducts(products, grid, instanceId) {
            if (!grid) {
                return;
            }
            
            // Initialize pagination state if not exists
            if (!paginationState[instanceId]) {
                paginationState[instanceId] = {
                    currentPage: 1,
                    perPage: 24
                };
            }
            
            // Get per page value
            const perPageSelect = document.getElementById(instanceId + '-per-page');
            if (perPageSelect) {
                paginationState[instanceId].perPage = parseInt(perPageSelect.value, 10);
            }
            
            // Clear existing content
            grid.innerHTML = '';
            
            // Update product count
            const countElement = document.getElementById(instanceId + '-count');
            if (countElement) {
                const count = products.length;
                countElement.textContent = count + ' product' + (count !== 1 ? 's' : '') + ' found';
            }
            
            // Check if products array is empty
            if (products.length === 0) {
                grid.innerHTML = '<p class="ps-no-products">No products found matching your filters.</p>';
                grid.style.display = 'block';
                const pagination = document.getElementById(instanceId + '-pagination');
                if (pagination) {
                    pagination.style.display = 'none';
                }
                return;
            }
            
            // Calculate pagination
            const perPage = paginationState[instanceId].perPage;
            const totalPages = Math.ceil(products.length / perPage);
            const currentPage = Math.min(paginationState[instanceId].currentPage, totalPages || 1);
            paginationState[instanceId].currentPage = currentPage;
            
            // Get products for current page
            const startIndex = (currentPage - 1) * perPage;
            const endIndex = startIndex + perPage;
            const paginatedProducts = products.slice(startIndex, endIndex);
            
            // Create product cards
            paginatedProducts.forEach(function(product) {
                const productCard = createProductCard(product);
                grid.appendChild(productCard);
            });
            
            // Show grid
            grid.style.display = 'grid';
            
            // Render pagination
            renderPagination(instanceId, currentPage, totalPages, products.length);
            
            // Setup per page change listener
            if (perPageSelect && !perPageSelect.dataset.listenerAdded) {
                perPageSelect.addEventListener('change', function() {
                    paginationState[instanceId].currentPage = 1;
                    const filtered = productData[instanceId] ? productData[instanceId].filtered : [];
                    renderProducts(filtered, grid, instanceId);
                });
                perPageSelect.dataset.listenerAdded = 'true';
            }
        }
        
        /**
         * Render pagination controls
         */
        function renderPagination(instanceId, currentPage, totalPages, totalProducts) {
            const pagination = document.getElementById(instanceId + '-pagination');
            if (!pagination) {
                return;
            }
            
            // Hide pagination if only one page or no products
            if (totalPages <= 1 || totalProducts === 0) {
                pagination.style.display = 'none';
                return;
            }
            
            pagination.style.display = 'flex';
            pagination.innerHTML = '';
            
            // Previous button
            const prevBtn = document.createElement('button');
            prevBtn.className = 'ps-pagination-btn ps-pagination-prev';
            prevBtn.textContent = '← Previous';
            prevBtn.disabled = currentPage === 1;
            prevBtn.addEventListener('click', function() {
                if (currentPage > 1) {
                    paginationState[instanceId].currentPage = currentPage - 1;
                    const grid = document.getElementById(instanceId + '-grid');
                    const filtered = productData[instanceId] ? productData[instanceId].filtered : [];
                    renderProducts(filtered, grid, instanceId);
                    // Scroll to top of grid
                    if (grid) {
                        grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                }
            });
            pagination.appendChild(prevBtn);
            
            // Page numbers
            const pageNumbers = document.createElement('div');
            pageNumbers.className = 'ps-pagination-numbers';
            
            // Show max 5 page numbers
            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, currentPage + 2);
            
            if (endPage - startPage < 4) {
                if (startPage === 1) {
                    endPage = Math.min(5, totalPages);
                } else {
                    startPage = Math.max(1, totalPages - 4);
                }
            }
            
            // First page
            if (startPage > 1) {
                const firstBtn = createPageButton(instanceId, 1, currentPage);
                pageNumbers.appendChild(firstBtn);
                if (startPage > 2) {
                    const ellipsis = document.createElement('span');
                    ellipsis.className = 'ps-pagination-ellipsis';
                    ellipsis.textContent = '...';
                    pageNumbers.appendChild(ellipsis);
                }
            }
            
            // Page number buttons
            for (let i = startPage; i <= endPage; i++) {
                const pageBtn = createPageButton(instanceId, i, currentPage);
                pageNumbers.appendChild(pageBtn);
            }
            
            // Last page
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) {
                    const ellipsis = document.createElement('span');
                    ellipsis.className = 'ps-pagination-ellipsis';
                    ellipsis.textContent = '...';
                    pageNumbers.appendChild(ellipsis);
                }
                const lastBtn = createPageButton(instanceId, totalPages, currentPage);
                pageNumbers.appendChild(lastBtn);
            }
            
            pagination.appendChild(pageNumbers);
            
            // Next button
            const nextBtn = document.createElement('button');
            nextBtn.className = 'ps-pagination-btn ps-pagination-next';
            nextBtn.textContent = 'Next →';
            nextBtn.disabled = currentPage === totalPages;
            nextBtn.addEventListener('click', function() {
                if (currentPage < totalPages) {
                    paginationState[instanceId].currentPage = currentPage + 1;
                    const grid = document.getElementById(instanceId + '-grid');
                    const filtered = productData[instanceId] ? productData[instanceId].filtered : [];
                    renderProducts(filtered, grid, instanceId);
                    // Scroll to top of grid
                    if (grid) {
                        grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                }
            });
            pagination.appendChild(nextBtn);
        }
        
        /**
         * Create a page number button
         */
        function createPageButton(instanceId, pageNum, currentPage) {
            const btn = document.createElement('button');
            btn.className = 'ps-pagination-page';
            if (pageNum === currentPage) {
                btn.classList.add('active');
            }
            btn.textContent = pageNum;
            btn.addEventListener('click', function() {
                paginationState[instanceId].currentPage = pageNum;
                const grid = document.getElementById(instanceId + '-grid');
                const filtered = productData[instanceId] ? productData[instanceId].filtered : [];
                renderProducts(filtered, grid, instanceId);
                // Scroll to top of grid
                if (grid) {
                    grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
            return btn;
        }
        
        /**
         * Create product card element
         */
        function createProductCard(product) {
            const card = document.createElement('div');
            card.className = 'ps-product-card';
            
            // Product image
            const image = document.createElement('div');
            image.className = 'ps-product-image';
            const img = document.createElement('img');
            
            // Try to get image from data-src, data-srcset, srcset, or src
            let imageUrl = product.image || '';
            if (product['data-src']) {
                imageUrl = product['data-src'];
            } else if (product['data-srcset']) {
                // Get first image from data-srcset
                imageUrl = product['data-srcset'].split(',')[0].trim().split(' ')[0];
            } else if (product.srcset) {
                // Get first image from srcset
                imageUrl = product.srcset.split(',')[0].trim().split(' ')[0];
            }
            
            img.src = imageUrl;
            img.alt = product.title || 'Product Image';
            img.onerror = function() {
                this.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="300" height="300"%3E%3Crect fill="%23ddd" width="300" height="300"/%3E%3Ctext fill="%23999" font-family="sans-serif" font-size="18" dy="10.5" font-weight="bold" x="50%25" y="50%25" text-anchor="middle"%3ENo Image%3C/text%3E%3C/svg%3E';
            };
            image.appendChild(img);
            
            // Product title
            const title = document.createElement('h3');
            title.className = 'ps-product-title';
            title.textContent = product.title || 'Untitled Product';
            
            // Product meta (brand / category)
            const meta = document.createElement('div');
            meta.className = 'ps-product-meta';
            if (product.brand && product.brand.trim() !== '') {
                const brand = document.createElement('span');
                brand.className = 'ps-product-brand';
                brand.textContent = product.brand.trim();
                meta.appendChild(brand);
            }
            if (product.category && product.category.trim() !== '') {
                const category = document.createElement('span');
                category.className = 'ps-product-category';
                category.textContent = product.category.trim();
                meta.appendChild(category);
            }
            if (meta.children.length === 0) {
                meta.style.display = 'none';
            }
            
            // Product price
            const priceSection = document.createElement('div');
            priceSection.className = 'ps-product-price';
            
            const price = document.createElement('span');
            price.className = 'ps-product-price-current';
            price.textContent = product.price || 'Price not available';
            priceSection.appendChild(price);
            
            if (product.original_price && product.original_price.trim() !== '' && product.original_price !== product.price) {
                const original = document.createElement('span');
                original.className = 'ps-product-price-original';
                original.textContent = product.original_price.trim();
                priceSection.appendChild(original);
            }
            
            if (product.savings && product.savings.trim() !== '') {
                const savings = document.createElement('span');
                savings.className = 'ps-product-price-savings';
                let savingsText = product.savings.trim();
                if (!/save/i.test(savingsText)) {
                    savingsText = 'You Save ' + savingsText;
                }
                savings.textContent = savingsText;
                priceSection.appendChild(savings);
            }
            
            // Product description (if available)
            if (product.description && product.description.trim() !== '') {
                const description = document.createElement('div');
                description.className = 'ps-product-description';
                description.textContent = product.description;
                card.appendChild(description);
            }
            
            // Compare checkbox
            const compareWrapper = document.createElement('div');
            compareWrapper.className = 'ps-product-compare-wrapper';
            const compareCheckbox = document.createElement('input');
            compareCheckbox.type = 'checkbox';
            compareCheckbox.className = 'ps-product-compare-checkbox';
            compareCheckbox.id = 'ps-compare-' + (product.link || Math.random().toString(36).substr(2, 9));
            compareCheckbox.setAttribute('data-product-id', product.link || Math.random().toString(36).substr(2, 9));
            compareCheckbox.setAttribute('data-product-data', JSON.stringify(product));
            const compareLabel = document.createElement('label');
            compareLabel.htmlFor = compareCheckbox.id;
            compareLabel.className = 'ps-product-compare-label';
            compareLabel.textContent = 'Compare';
            compareWrapper.appendChild(compareCheckbox);
            compareWrapper.appendChild(compareLabel);
            
            // View Product button
            const button = document.createElement('a');
            button.className = 'ps-product-button';
            button.href = product.link || '#';
            button.target = '_blank';
            button.rel = 'noopener noreferrer';
            button.textContent = 'View Product';
            
            // Assemble card
            card.appendChild(image);
            card.appendChild(title);
            if (meta.style.display !== 'none') {
                card.appendChild(meta);
            }
            card.appendChild(priceSection);
            if (product.description && product.description.trim() !== '') {
                // Description already added above
            }
            card.appendChild(compareWrapper);
            card.appendChild(button);
            
            return card;
        }
        
        /**
         * Show error message
         */
        function showError(errorElement, loadingElement, errorMessage) {
            if (loadingElement) {
                loadingElement.style.display = 'none';
            }
            if (errorElement) {
                if (errorMessage) {
                    errorElement.innerHTML = '<p>' + escapeHtml(errorMessage) + '</p>';
                }
                errorElement.style.display = 'block';
            }
        }
        
        /**
         * Compare functionality
         */
        function initializeCompare() {
            // Create floating compare button
            createFloatingCompareButton();
            
            // Load saved compare items and update UI
            updateCompareUI();
            
            // Listen for compare checkbox changes
            document.addEventListener('change', function(e) {
                if (e.target.classList.contains('ps-product-compare-checkbox')) {
                    handleCompareChange(e.target);
                }
            });
        }
        
        /**
         * Get compare items from localStorage
         */
        function getCompareItems() {
            try {
                const stored = localStorage.getItem('ps_compare_items');
                return stored ? JSON.parse(stored) : [];
            } catch (e) {
                return [];
            }
        }
        
        /**
         * Save compare items to localStorage
         */
        function saveCompareItems(items) {
            try {
                localStorage.setItem('ps_compare_items', JSON.stringify(items));
            } catch (e) {
                console.error('Failed to save compare items:', e);
            }
        }
        
        /**
         * Handle compare checkbox change
         */
        function handleCompareChange(checkbox) {
            const productData = JSON.parse(checkbox.getAttribute('data-product-data') || '{}');
            const productId = checkbox.getAttribute('data-product-id');
            const items = getCompareItems();
            
            if (checkbox.checked) {
                // Add to compare (max 4 products)
                if (items.length >= 4) {
                    alert('You can compare up to 4 products at a time. Please remove one product first.');
                    checkbox.checked = false;
                    return;
                }
                
                // Check if already exists
                const exists = items.findIndex(item => item.link === productData.link);
                if (exists === -1) {
                    items.push(productData);
                    saveCompareItems(items);
                }
            } else {
                // Remove from compare
                const index = items.findIndex(item => item.link === productData.link);
                if (index !== -1) {
                    items.splice(index, 1);
                    saveCompareItems(items);
                }
            }
            
            updateCompareUI();
        }
        
        /**
         * Update compare UI (checkboxes and bottom bar)
         */
        function updateCompareUI() {
            const items = getCompareItems();
            const compareBar = document.getElementById('ps-compare-bar');
            const slotsContainer = compareBar ? compareBar.querySelector('.ps-compare-slots') : null;
            
            // Show/hide bottom bar
            if (compareBar) {
                if (items.length === 0) {
                    compareBar.style.display = 'none';
                } else {
                    compareBar.style.display = 'flex';
                }
            }
            
            // Update product slots
            if (slotsContainer) {
                const slots = slotsContainer.querySelectorAll('.ps-compare-slot');
                slots.forEach(function(slot, index) {
                    const product = items[index];
                    
                    // Clear slot
                    slot.innerHTML = '';
                    
                    if (product) {
                        // Create thumbnail container
                        const thumbnail = document.createElement('div');
                        thumbnail.className = 'ps-compare-thumbnail';
                        
                        // Product image
                        if (product.image) {
                            const img = document.createElement('img');
                            img.src = product.image;
                            img.alt = product.title || '';
                            img.className = 'ps-compare-thumbnail-img';
                            thumbnail.appendChild(img);
                        } else {
                            // Placeholder
                            const placeholder = document.createElement('div');
                            placeholder.className = 'ps-compare-thumbnail-placeholder';
                            thumbnail.appendChild(placeholder);
                        }
                        
                        // Remove button (X)
                        const removeBtn = document.createElement('button');
                        removeBtn.className = 'ps-compare-thumbnail-remove';
                        removeBtn.innerHTML = '&times;';
                        removeBtn.setAttribute('aria-label', 'Remove product');
                        removeBtn.addEventListener('click', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            // Remove this product
                            const updatedItems = items.filter(function(item) {
                                return item.link !== product.link;
                            });
                            saveCompareItems(updatedItems);
                            updateCompareUI();
                            
                            // Uncheck checkbox
                            document.querySelectorAll('.ps-product-compare-checkbox').forEach(function(checkbox) {
                                const productData = JSON.parse(checkbox.getAttribute('data-product-data') || '{}');
                                if (productData.link === product.link) {
                                    checkbox.checked = false;
                                }
                            });
                        });
                        thumbnail.appendChild(removeBtn);
                        
                        slot.appendChild(thumbnail);
                        slot.classList.add('ps-compare-slot-filled');
                    } else {
                        // Empty slot
                        slot.classList.remove('ps-compare-slot-filled');
                    }
                });
            }
            
            // Update checkboxes state
            document.querySelectorAll('.ps-product-compare-checkbox').forEach(function(checkbox) {
                const productData = JSON.parse(checkbox.getAttribute('data-product-data') || '{}');
                const exists = items.findIndex(item => item.link === productData.link);
                checkbox.checked = exists !== -1;
            });
        }
        
        /**
         * Create bottom comparison bar
         */
        function createFloatingCompareButton() {
            // Check if already exists
            if (document.getElementById('ps-compare-bar')) {
                return;
            }
            
            const bar = document.createElement('div');
            bar.id = 'ps-compare-bar';
            bar.className = 'ps-compare-bar';
            bar.style.display = 'none';
            
            // Product slots container
            const slotsContainer = document.createElement('div');
            slotsContainer.className = 'ps-compare-slots';
            
            // Create 4 product slots
            for (let i = 0; i < 4; i++) {
                const slot = document.createElement('div');
                slot.className = 'ps-compare-slot';
                slot.dataset.slotIndex = i;
                slotsContainer.appendChild(slot);
            }
            
            // Actions container
            const actionsContainer = document.createElement('div');
            actionsContainer.className = 'ps-compare-actions';
            
            // Compare button
            const compareBtn = document.createElement('button');
            compareBtn.className = 'ps-compare-bar-btn';
            compareBtn.textContent = 'Compare';
            compareBtn.addEventListener('click', openCompareModal);
            
            // Remove All link
            const removeAllLink = document.createElement('a');
            removeAllLink.href = '#';
            removeAllLink.className = 'ps-compare-remove-all';
            removeAllLink.textContent = 'Remove All';
            removeAllLink.addEventListener('click', function(e) {
                e.preventDefault();
                clearAllCompareItems();
            });
            
            actionsContainer.appendChild(compareBtn);
            actionsContainer.appendChild(removeAllLink);
            
            bar.appendChild(slotsContainer);
            bar.appendChild(actionsContainer);
            
            document.body.appendChild(bar);
        }
        
        /**
         * Clear all compare items
         */
        function clearAllCompareItems() {
            saveCompareItems([]);
            updateCompareUI();
        }
        
        /**
         * Open compare modal
         */
        function openCompareModal() {
            const items = getCompareItems();
            
            if (items.length === 0) {
                alert('Please select products to compare. You can select up to 4 products.');
                return;
            }
            
            // Create or update modal
            let modal = document.getElementById('ps-compare-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'ps-compare-modal';
                modal.className = 'ps-compare-modal';
                document.body.appendChild(modal);
            }
            
            // Build comparison table
            let html = '<div class="ps-compare-modal-content">';
            html += '<div class="ps-compare-modal-header">';
            html += '<h2>Compare Products (' + items.length + ')</h2>';
            html += '<button class="ps-compare-close" id="ps-compare-close">&times;</button>';
            html += '</div>';
            html += '<div class="ps-compare-table-wrapper">';
            html += '<table class="ps-compare-table">';
            
            // Header row with product images and titles
            html += '<thead><tr>';
            html += '<th class="ps-compare-label-col">Product</th>';
            items.forEach(function(product) {
                html += '<th class="ps-compare-product-col">';
                html += '<button class="ps-compare-remove" data-product-link="' + escapeHtml(product.link || '') + '">&times;</button>';
                if (product.image) {
                    html += '<img src="' + escapeHtml(product.image) + '" alt="' + escapeHtml(product.title || '') + '" class="ps-compare-product-image">';
                }
                html += '<h3>' + escapeHtml(product.title || 'Untitled') + '</h3>';
                html += '</th>';
            });
            html += '</tr></thead>';
            
            // Comparison rows
            html += '<tbody>';
            
            // Price
            html += '<tr><td class="ps-compare-label">Price</td>';
            items.forEach(function(product) {
                html += '<td>' + escapeHtml(product.price || 'N/A') + '</td>';
            });
            html += '</tr>';
            
            // Original Price
            if (items.some(p => p.original_price)) {
                html += '<tr><td class="ps-compare-label">Original Price</td>';
                items.forEach(function(product) {
                    html += '<td>' + escapeHtml(product.original_price || 'N/A') + '</td>';
                });
                html += '</tr>';
            }
            
            // Brand
            if (items.some(p => p.brand)) {
                html += '<tr><td class="ps-compare-label">Brand</td>';
                items.forEach(function(product) {
                    html += '<td>' + escapeHtml(product.brand || 'N/A') + '</td>';
                });
                html += '</tr>';
            }
            
            // Category
            if (items.some(p => p.category)) {
                html += '<tr><td class="ps-compare-label">Category</td>';
                items.forEach(function(product) {
                    html += '<td>' + escapeHtml(product.category || 'N/A') + '</td>';
                });
                html += '</tr>';
            }
            
            // Size
            if (items.some(p => p.size)) {
                html += '<tr><td class="ps-compare-label">Size</td>';
                items.forEach(function(product) {
                    html += '<td>' + escapeHtml(product.size || 'N/A') + '</td>';
                });
                html += '</tr>';
            }
            
            // Curve
            if (items.some(p => p.curveCode || (p.title && /P\d{2}|W\d{2}/i.test(p.title)))) {
                html += '<tr><td class="ps-compare-label">Curve</td>';
                items.forEach(function(product) {
                    const curve = product.curveCode || (product.title ? product.title.match(/P\d{2}|W\d{2}/i)?.[0] : '') || 'N/A';
                    html += '<td>' + escapeHtml(curve) + '</td>';
                });
                html += '</tr>';
            }
            
            // Flex
            if (items.some(p => p.flexValue || (p.title && /\d+\s*[Ff]lex/i.test(p.title)))) {
                html += '<tr><td class="ps-compare-label">Flex</td>';
                items.forEach(function(product) {
                    const flex = product.flexValue || product.flexKey || (product.title ? product.title.match(/\d+\s*[Ff]lex/i)?.[0] : '') || 'N/A';
                    html += '<td>' + escapeHtml(flex) + '</td>';
                });
                html += '</tr>';
            }
            
            // Division
            if (items.some(p => p.division)) {
                html += '<tr><td class="ps-compare-label">Division</td>';
                items.forEach(function(product) {
                    html += '<td>' + escapeHtml(product.division || 'N/A') + '</td>';
                });
                html += '</tr>';
            }
            
            // Pattern
            if (items.some(p => p.pattern)) {
                html += '<tr><td class="ps-compare-label">Pattern</td>';
                items.forEach(function(product) {
                    html += '<td>' + escapeHtml(product.pattern || 'N/A') + '</td>';
                });
                html += '</tr>';
            }
            
            // Hand (Left/Right)
            if (items.some(p => p.hand)) {
                html += '<tr><td class="ps-compare-label">Hand</td>';
                items.forEach(function(product) {
                    html += '<td>' + escapeHtml(product.hand || 'N/A') + '</td>';
                });
                html += '</tr>';
            }
            
            // Description
            if (items.some(p => p.description)) {
                html += '<tr><td class="ps-compare-label">Description</td>';
                items.forEach(function(product) {
                    html += '<td>' + escapeHtml((product.description || '').substring(0, 100)) + (product.description && product.description.length > 100 ? '...' : '') + '</td>';
                });
                html += '</tr>';
            }
            
            // View Product link
            html += '<tr><td class="ps-compare-label">Action</td>';
            items.forEach(function(product) {
                html += '<td><a href="' + escapeHtml(product.link || '#') + '" target="_blank" class="ps-compare-view-btn">View Product</a></td>';
            });
            html += '</tr>';
            
            html += '</tbody></table>';
            html += '</div>';
            html += '<div class="ps-compare-modal-footer">';
            html += '<button class="ps-compare-clear-all" id="ps-compare-clear-all">Clear All</button>';
            html += '</div>';
            html += '</div>';
            
            modal.innerHTML = html;
            modal.style.display = 'flex';
            
            // Close button
            document.getElementById('ps-compare-close').addEventListener('click', closeCompareModal);
            
            // Remove product buttons
            document.querySelectorAll('.ps-compare-remove').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    const link = btn.getAttribute('data-product-link');
                    const items = getCompareItems();
                    const index = items.findIndex(item => item.link === link);
                    if (index !== -1) {
                        items.splice(index, 1);
                        saveCompareItems(items);
                        updateCompareUI();
                        if (items.length === 0) {
                            closeCompareModal();
                        } else {
                            openCompareModal(); // Refresh modal
                        }
                    }
                });
            });
            
            // Clear all button
            document.getElementById('ps-compare-clear-all').addEventListener('click', function() {
                if (confirm('Remove all products from comparison?')) {
                    saveCompareItems([]);
                    updateCompareUI();
                    closeCompareModal();
                }
            });
            
            // Close on backdrop click
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeCompareModal();
                }
            });
        }
        
        /**
         * Close compare modal
         */
        function closeCompareModal() {
            const modal = document.getElementById('ps-compare-modal');
            if (modal) {
                modal.style.display = 'none';
            }
        }
        
        /**
         * Escape HTML
         */
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        /**
         * Escape HTML
         */
        function escapeHtml(text) {
            var map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text ? text.replace(/[&<>"']/g, function(m) { return map[m]; }) : '';
        }
    });
    
    // Expose functions globally for global search bar
    window.psApplyFilters = function(instanceId) {
        const grid = document.getElementById(instanceId + '-grid');
        if (grid && typeof applyFilters === 'function') {
            applyFilters(instanceId, grid);
        }
    };
    
    window.psUpdateClearButton = function(instanceId) {
        if (typeof updateClearButton === 'function') {
            updateClearButton(instanceId);
        }
    };
})();

