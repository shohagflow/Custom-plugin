<?php
/**
 * Shortcode Generator Admin Page
 */

if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
$shortcode = '';
$error_message = '';

if (isset($_POST['ps_generate_shortcode']) && check_admin_referer('ps_shortcode_generator')) {
    $url = isset($_POST['ps_url']) ? esc_url_raw($_POST['ps_url']) : '';
    
    if (empty($url)) {
        $error_message = __('Please enter a valid URL.', 'product-scraping');
    } else {
        $shortcode = '[product_scraping url="' . esc_attr($url) . '"]';
    }
}
?>

<div class="wrap">
    <h1><?php esc_html_e('Shortcode Generator', 'product-scraping'); ?></h1>
    
    <div class="ps-admin-container">
        <div class="ps-admin-main">
            <div class="ps-admin-card">
                <h2><?php esc_html_e('Generate Shortcode', 'product-scraping'); ?></h2>
                <p class="description"><?php esc_html_e('Enter a URL to generate a shortcode for displaying products.', 'product-scraping'); ?></p>
                
                <?php if ($error_message): ?>
                    <div class="notice notice-error">
                        <p><?php echo esc_html($error_message); ?></p>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="" class="ps-shortcode-form">
                    <?php wp_nonce_field('ps_shortcode_generator'); ?>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ps_url"><?php esc_html_e('Product URL', 'product-scraping'); ?></label>
                            </th>
                            <td>
                                <input type="url" 
                                       id="ps_url" 
                                       name="ps_url" 
                                       class="regular-text" 
                                       value="" 
                                       placeholder="https://example.com/products"
                                       required>
                                <p class="description"><?php esc_html_e('Enter the URL of the page containing products to scrape.', 'product-scraping'); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <input type="submit" 
                               name="ps_generate_shortcode" 
                               class="button button-primary" 
                               value="<?php esc_attr_e('Generate Shortcode', 'product-scraping'); ?>">
                    </p>
                </form>
                
                <?php if ($shortcode): ?>
                    <div class="ps-shortcode-result">
                        <h3><?php esc_html_e('Generated Shortcode', 'product-scraping'); ?></h3>
                        <div class="ps-shortcode-box">
                            <code id="ps-shortcode-text"><?php echo esc_html($shortcode); ?></code>
                            <button type="button" class="button button-secondary ps-copy-shortcode" data-clipboard-target="#ps-shortcode-text">
                                <?php esc_html_e('Copy', 'product-scraping'); ?>
                            </button>
                        </div>
                        <p class="description"><?php esc_html_e('Copy this shortcode and paste it into any page or post to display the products.', 'product-scraping'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.ps-admin-container {
    max-width: 1400px;
}

.ps-admin-main {
    display: grid;
    gap: 20px;
}

.ps-admin-card {
    background: #fff;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    padding: 20px;
    border-radius: 4px;
}

.ps-shortcode-form {
    margin-top: 20px;
}

.ps-shortcode-result {
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #ddd;
}

.ps-shortcode-box {
    display: flex;
    align-items: center;
    gap: 10px;
    background: #f5f5f5;
    padding: 15px;
    border-radius: 4px;
    margin: 10px 0;
}

.ps-shortcode-box code {
    flex: 1;
    font-size: 14px;
    padding: 0;
    background: transparent;
    color: #2271b1;
    word-break: break-all;
}

.ps-copy-shortcode {
    flex-shrink: 0;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Copy shortcode to clipboard
    $('.ps-copy-shortcode').on('click', function() {
        var $button = $(this);
        var $target = $($(this).data('clipboard-target'));
        var text = $target.text();
        
        // Create temporary textarea
        var $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(text).select();
        document.execCommand('copy');
        $temp.remove();
        
        // Update button text
        var originalText = $button.text();
        $button.text('<?php esc_js_e('Copied!', 'product-scraping'); ?>');
        setTimeout(function() {
            $button.text(originalText);
        }, 2000);
    });
});
</script>

