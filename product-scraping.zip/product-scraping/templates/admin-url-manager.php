<?php
/**
 * Admin URL Manager Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap ps-admin-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="ps-admin-container">
        <div class="ps-admin-main">
            <div class="ps-settings-section">
                <h2><?php esc_html_e('Add New URL', 'product-scraping'); ?></h2>
                <p class="description">
                    <?php esc_html_e('Save website URLs for easy access. You can use these URLs in shortcodes.', 'product-scraping'); ?>
                </p>
                
                <form method="post" action="">
                    <?php wp_nonce_field('ps_url_action'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="url_name"><?php esc_html_e('Name (Optional)', 'product-scraping'); ?></label>
                            </th>
                            <td>
                                <input 
                                    type="text" 
                                    id="url_name" 
                                    name="name" 
                                    class="regular-text" 
                                    placeholder="<?php esc_attr_e('Enter your shortcode name', 'product-scraping'); ?>"
                                />
                                <p class="description">
                                    <?php esc_html_e('Enter a short, memorable label for this URL.', 'product-scraping'); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="url"><?php esc_html_e('Website URL', 'product-scraping'); ?></label>
                            </th>
                            <td>
                                <input 
                                    type="url" 
                                    id="url" 
                                    name="url" 
                                    class="regular-text" 
                                    placeholder="https://example.com/products"
                                    required
                                />
                                <p class="description">
                                    <?php esc_html_e('Enter the full URL of the website you want to scrape', 'product-scraping'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                    
                    <?php submit_button(__('Add URL', 'product-scraping'), 'primary', 'ps_add_url'); ?>
                </form>
            </div>
            
            <div class="ps-settings-section" id="ps-saved-urls-section">
                <h2><?php esc_html_e('Saved URLs', 'product-scraping'); ?></h2>
                
                <?php if (empty($saved_urls)) : ?>
                    <p class="ps-no-urls"><?php esc_html_e('No URLs saved yet. Add a URL above to get started.', 'product-scraping'); ?></p>
                <?php endif; ?>
                
                <div id="ps-saved-urls-wrapper" style="<?php echo empty($saved_urls) ? 'display:none;' : ''; ?>">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th style="width: 30%;"><?php esc_html_e('Name', 'product-scraping'); ?></th>
                                <th style="width: 50%;"><?php esc_html_e('Shortcode', 'product-scraping'); ?></th>
                                <th style="width: 20%;"><?php esc_html_e('Actions', 'product-scraping'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($saved_urls)) : ?>
                                <?php foreach ($saved_urls as $index => $url_data) : ?>
                                    <tr>
                                        <td><strong><?php echo esc_html($url_data['name']); ?></strong></td>
                                        <td>
                                            <code style="font-size: 12px;">[product_scraping url="<?php echo esc_attr($url_data['url']); ?>"]</code>
                                        </td>
                                        <td>
                                            <a href="<?php echo esc_url(admin_url('admin.php?page=product-scraping-test&test_url=' . urlencode($url_data['url']))); ?>" class="button button-small">
                                                <?php esc_html_e('Test', 'product-scraping'); ?>
                                            </a>
                                            <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=product-scraping-urls&delete=' . $index), 'ps_delete_url')); ?>" 
                                               class="button button-small button-link-delete" 
                                               onclick="return confirm('<?php esc_attr_e('Are you sure you want to delete this URL?', 'product-scraping'); ?>');">
                                                <?php esc_html_e('Delete', 'product-scraping'); ?>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="ps-settings-section" id="ps-url-groups-section">
                <h2><?php esc_html_e('URL Groups (Multiple URLs → One Shortcode)', 'product-scraping'); ?></h2>
                <p class="description">
                    <?php esc_html_e('Create a group of URLs to show products from multiple websites under a single filter and shortcode.', 'product-scraping'); ?>
                </p>

                <form method="post" action="">
                    <?php wp_nonce_field('ps_group_action'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="group_name"><?php esc_html_e('Group Name', 'product-scraping'); ?></label>
                            </th>
                            <td>
                                <input
                                    type="text"
                                    id="group_name"
                                    name="group_name"
                                    class="regular-text"
                                    placeholder="<?php esc_attr_e('e.g. All Hockey Sticks', 'product-scraping'); ?>"
                                />
                                <p class="description">
                                    <?php esc_html_e('A label to help you remember what this group is for.', 'product-scraping'); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="group_urls"><?php esc_html_e('Website URLs (one per line)', 'product-scraping'); ?></label>
                            </th>
                            <td>
                                <textarea
                                    id="group_urls"
                                    name="group_urls"
                                    class="large-text code"
                                    rows="5"
                                    placeholder="https://example.com/products&#10;https://othersite.com/listing">
                                </textarea>
                                <p class="description">
                                    <?php esc_html_e('Paste 2–6 URLs (or more) – one per line. Products from all of these URLs will be combined under one filter when you use the generated shortcode.', 'product-scraping'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>

                    <?php submit_button(__('Save URL Group', 'product-scraping'), 'secondary', 'ps_add_group'); ?>
                </form>

                <hr />

                <h3><?php esc_html_e('Saved URL Groups', 'product-scraping'); ?></h3>

                <?php if (empty($saved_groups)) : ?>
                    <p class="ps-no-urls"><?php esc_html_e('No URL groups yet. Add a group above to generate a combined shortcode.', 'product-scraping'); ?></p>
                <?php else : ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th style="width: 25%;"><?php esc_html_e('Group Name', 'product-scraping'); ?></th>
                                <th style="width: 35%;"><?php esc_html_e('Shortcode', 'product-scraping'); ?></th>
                                <th style="width: 25%;"><?php esc_html_e('URLs in Group', 'product-scraping'); ?></th>
                                <th style="width: 15%;"><?php esc_html_e('Actions', 'product-scraping'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($saved_groups as $group) : ?>
                                <tr>
                                    <td><strong><?php echo esc_html(isset($group['name']) ? $group['name'] : $group['id']); ?></strong></td>
                                    <td>
                                        <?php if (!empty($group['id'])) : ?>
                                            <code style="font-size: 12px;">[product_scraping_group id="<?php echo esc_attr($group['id']); ?>"]</code>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                            if (!empty($group['urls']) && is_array($group['urls'])) {
                                                echo '<ul style="margin:0; padding-left:18px;">';
                                                foreach ($group['urls'] as $u) {
                                                    echo '<li>' . esc_html($u) . '</li>';
                                                }
                                                echo '</ul>';
                                            } else {
                                                esc_html_e('No URLs', 'product-scraping');
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($group['id'])) : ?>
                                            <button type="button" 
                                                    class="button button-small ps-test-group" 
                                                    data-group-id="<?php echo esc_attr($group['id']); ?>"
                                                    data-group-name="<?php echo esc_attr(isset($group['name']) ? $group['name'] : $group['id']); ?>">
                                                <?php esc_html_e('Test', 'product-scraping'); ?>
                                            </button>
                                            <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=product-scraping-urls&delete_group=' . $group['id']), 'ps_delete_group')); ?>"
                                               class="button button-small button-link-delete"
                                               onclick="return confirm('<?php esc_attr_e('Are you sure you want to delete this URL group?', 'product-scraping'); ?>');">
                                                <?php esc_html_e('Delete', 'product-scraping'); ?>
                                            </a>
                                            <div class="ps-test-results" id="ps-test-<?php echo esc_attr($group['id']); ?>" style="display: none; margin-top: 8px; padding: 10px; background: #f0f0f1; border-left: 4px solid #2271b1; border-radius: 4px;">
                                                <strong><?php esc_html_e('Test Results:', 'product-scraping'); ?></strong>
                                                <div class="ps-test-content"></div>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <p class="description" style="margin-top: 10px;">
                        <?php
                        echo wp_kses_post(
                            sprintf(
                                /* translators: %1$s and %2$s are shortcode examples. */
                                __('Use %1$s to show all products from this group with filters. Use %2$s to show only a few featured products from this group (no filters). Replace YOUR_GROUP_ID with the ID shown in the table above.', 'product-scraping'),
                                '<code>[product_scraping_group id="YOUR_GROUP_ID"]</code>',
                                '<code>[product_scraping_featured id="YOUR_GROUP_ID" limit="5" columns="5"]</code>'
                            )
                        );
                        ?>
                    </p>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="ps-admin-sidebar">
            <div class="ps-info-box">
                <h3><?php esc_html_e('How to Use', 'product-scraping'); ?></h3>
                <ol>
                    <li><?php esc_html_e('Add website URLs above', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Copy the shortcode for any URL', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Paste shortcode in any page/post', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Products will display automatically', 'product-scraping'); ?></li>
                </ol>
            </div>
            
            <div class="ps-info-box">
                <h3><?php esc_html_e('Quick Links', 'product-scraping'); ?></h3>
                <ul>
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=product-scraping')); ?>"><?php esc_html_e('Settings', 'product-scraping'); ?></a></li>
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=product-scraping-test')); ?>"><?php esc_html_e('Test Scraping', 'product-scraping'); ?></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

