<?php
/**
 * Admin Test Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap ps-admin-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="ps-admin-container">
        <div class="ps-admin-main">
            <?php
            // Show warning if server might not be running
            ?>
            <div class="notice notice-info" style="margin: 20px 0;">
                <p><strong><?php esc_html_e('Quick Reminder:', 'product-scraping'); ?></strong> <?php esc_html_e('Use this page to preview any site before publishing. Testing here won’t affect your frontend.', 'product-scraping'); ?></p>
                <p><?php esc_html_e('Paste a URL below, click "Test Scraping", and review the results. Save it if you want to reuse the dataset later.', 'product-scraping'); ?></p>
            </div>
            
            <div class="ps-test-section">
                <h2><?php esc_html_e('Test Product Scraping', 'product-scraping'); ?></h2>
                <p class="description">
                    <?php esc_html_e('Enter any website URL to test the scraping functionality. Everything runs in WordPress—no external server needed.', 'product-scraping'); ?>
                </p>
                
                <div class="ps-test-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="test_url"><?php esc_html_e('Website URL', 'product-scraping'); ?></label>
                            </th>
                            <td>
                                <input 
                                    type="url" 
                                    id="test_url" 
                                    class="regular-text" 
                                    placeholder="https://example.com/products"
                                    value="<?php echo isset($_GET['test_url']) ? esc_attr(urldecode($_GET['test_url'])) : ''; ?>"
                                />
                                <p class="description">
                                    <?php esc_html_e('Enter the URL of the website you want to scrape.', 'product-scraping'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="button" id="ps-test-scrape" class="button button-primary">
                            <?php esc_html_e('Test Scraping', 'product-scraping'); ?>
                        </button>
                        <span class="spinner" id="ps-test-spinner"></span>
                    </p>
                </div>
                
                <div id="ps-test-results" style="display: none;">
                    <h3><?php esc_html_e('Results', 'product-scraping'); ?></h3>
                    <div id="ps-test-output"></div>
                </div>
            </div>
            
            <div class="ps-test-section">
                <h2><?php esc_html_e('System Check', 'product-scraping'); ?></h2>
                <p>
                    <button type="button" id="ps-test-health" class="button">
                        <?php esc_html_e('Test WordPress AJAX', 'product-scraping'); ?>
                    </button>
                </p>
                <p class="description">
                    <?php esc_html_e('Verify that WordPress AJAX is working correctly.', 'product-scraping'); ?>
                </p>
                <div id="ps-health-results" style="display: none;">
                    <div id="ps-health-output"></div>
                </div>
            </div>
        </div>
        
        <div class="ps-admin-sidebar">
            <div class="ps-info-box">
                <h3><?php esc_html_e('How It Works', 'product-scraping'); ?></h3>
                <p>
                    <?php esc_html_e('Shortcode → AJAX → PHP scraper. Everything happens inside WordPress using the built-in HTTP API and DOM parsing.', 'product-scraping'); ?>
                </p>
                <ul>
                    <li><?php esc_html_e('✅ Pure PHP/AJAX workflow', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('✅ No external services required', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('✅ Follows WordPress security best practices', 'product-scraping'); ?></li>
                </ul>
            </div>
            
            <div class="ps-info-box">
                <h3><?php esc_html_e('Tips', 'product-scraping'); ?></h3>
                <ul>
                    <li><?php esc_html_e('If you see "Failed to fetch", run System Check above to verify AJAX', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Test with a known working URL first', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Check browser console for errors', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Some websites may block scrapers', 'product-scraping'); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

