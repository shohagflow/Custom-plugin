<?php
/**
 * Admin Saved Products Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap ps-admin-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="ps-admin-container">
        <div class="ps-admin-main">
            <?php if (empty($saved_products)) : ?>
                <div class="ps-settings-section">
                    <p><?php esc_html_e('No saved products yet.', 'product-scraping'); ?></p>
                    <p><?php esc_html_e('Go to', 'product-scraping'); ?> <a href="<?php echo esc_url(admin_url('admin.php?page=product-scraping-test')); ?>"><?php esc_html_e('Test Scraping', 'product-scraping'); ?></a> <?php esc_html_e('to scrape and save products.', 'product-scraping'); ?></p>
                </div>
            <?php else : ?>
                <div class="ps-settings-section">
                    <h2><?php esc_html_e('Saved Products Summary', 'product-scraping'); ?></h2>
                    <p class="description"><?php esc_html_e('Quick overview of all saved scrapes, including shortcode and product count.', 'product-scraping'); ?></p>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th style="width:30%;"><?php esc_html_e('Name', 'product-scraping'); ?></th>
                                <th style="width:50%;"><?php esc_html_e('Shortcode', 'product-scraping'); ?></th>
                                <th style="width:20%;"><?php esc_html_e('Products', 'product-scraping'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($saved_products as $saved) : ?>
                                <tr>
                                    <td><strong><?php echo esc_html($saved['name']); ?></strong></td>
                                    <td>
                                        <code style="font-size:12px;">[product_scraping url="<?php echo esc_attr($saved['url']); ?>"]</code>
                                    </td>
                                    <td><?php echo esc_html($saved['count']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php foreach ($saved_products as $index => $saved) : ?>
                    <div class="ps-settings-section">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                            <div>
                                <h2 style="margin: 0;">
                                    <?php echo esc_html($saved['name']); ?>
                                    <small style="font-weight: normal; color: #666;">
                                        (<?php echo esc_html($saved['count']); ?> <?php esc_html_e('products', 'product-scraping'); ?>)
                                    </small>
                                </h2>
                                <p style="margin: 5px 0 0 0;">
                                    <code style="font-size: 12px;"><?php echo esc_html($saved['url']); ?></code><br>
                                    <small style="color: #666;">
                                        <?php esc_html_e('Saved:', 'product-scraping'); ?> <?php echo esc_html($saved['saved_at']); ?>
                                    </small>
                                </p>
                            </div>
                            <div>
                                <button type="button" class="button ps-rename-btn" data-id="<?php echo esc_attr($saved['id']); ?>" data-name="<?php echo esc_attr($saved['name']); ?>">
                                    <?php esc_html_e('Rename', 'product-scraping'); ?>
                                </button>
                                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=product-scraping-saved&delete=' . $saved['id']), 'ps_delete_saved')); ?>" 
                                   class="button button-link-delete" 
                                   onclick="return confirm('<?php esc_attr_e('Are you sure you want to delete these saved products?', 'product-scraping'); ?>');">
                                    <?php esc_html_e('Delete', 'product-scraping'); ?>
                                </a>
                            </div>
                        </div>
                        
                        <div style="margin-top: 15px;">
                            <strong><?php esc_html_e('Shortcode:', 'product-scraping'); ?></strong><br>
                            <code style="display: block; padding: 10px; background: #f5f5f5; margin: 10px 0;">
                                [product_scraping url="<?php echo esc_attr($saved['url']); ?>"]
                            </code>
                        </div>
                        
                        <div style="margin-top: 15px;">
                            <strong><?php esc_html_e('Preview Products:', 'product-scraping'); ?></strong>
                            <div class="ps-saved-products-preview" id="ps-preview-<?php echo esc_attr($saved['id']); ?>" style="margin-top: 10px;">
                                <!-- Products will be loaded here -->
                            </div>
                            <button type="button" class="button ps-load-preview" data-id="<?php echo esc_attr($saved['id']); ?>" style="margin-top: 10px;">
                                <?php esc_html_e('Load Preview', 'product-scraping'); ?>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="ps-admin-sidebar">
            <div class="ps-info-box">
                <h3><?php esc_html_e('Quick Links', 'product-scraping'); ?></h3>
                <ul>
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=product-scraping')); ?>"><?php esc_html_e('Settings', 'product-scraping'); ?></a></li>
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=product-scraping-urls')); ?>"><?php esc_html_e('URL Manager', 'product-scraping'); ?></a></li>
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=product-scraping-test')); ?>"><?php esc_html_e('Test Scraping', 'product-scraping'); ?></a></li>
                </ul>
            </div>
            
            <div class="ps-info-box">
                <h3><?php esc_html_e('How to Use Saved Products', 'product-scraping'); ?></h3>
                <ol>
                    <li><?php esc_html_e('Copy the shortcode from any saved product', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Paste it in any page or post', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Products will be scraped fresh from the URL', 'product-scraping'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>

<!-- Rename Modal -->
<div id="ps-rename-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 100000;">
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #fff; padding: 20px; border-radius: 4px; min-width: 400px;">
        <h3><?php esc_html_e('Rename Saved Products', 'product-scraping'); ?></h3>
        <form method="post" id="ps-rename-form">
            <?php wp_nonce_field('ps_rename_saved'); ?>
            <input type="hidden" name="ps_rename_saved" value="1">
            <input type="hidden" name="id" id="ps-rename-id" value="">
            <p>
                <label for="ps-rename-name"><?php esc_html_e('Name:', 'product-scraping'); ?></label><br>
                <input type="text" id="ps-rename-name" name="name" class="regular-text" required>
            </p>
            <p>
                <button type="submit" class="button button-primary"><?php esc_html_e('Save', 'product-scraping'); ?></button>
                <button type="button" class="button ps-cancel-rename"><?php esc_html_e('Cancel', 'product-scraping'); ?></button>
            </p>
        </form>
    </div>
</div>

