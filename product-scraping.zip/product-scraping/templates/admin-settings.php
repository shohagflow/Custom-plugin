<?php
/**
 * Admin Settings Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap ps-admin-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="ps-admin-container">
        <div class="ps-admin-main">
            
            <div class="ps-settings-section">
                <h2><?php esc_html_e('Quick Start Checklist', 'product-scraping'); ?></h2>
                <ol>
                    <li><?php esc_html_e('Go to Product Scraping → URL Manager and add the site URL you want to display.', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Copy the shortcode that appears next to your saved URL.', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Paste the shortcode into any page/post and publish.', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Use Product Scraping → Test Scraping to preview any URL before going live.', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Optionally save test results to reuse them from the Saved Products page.', 'product-scraping'); ?></li>
                </ol>
            </div>
            
            <div class="ps-settings-section">
                <h2><?php esc_html_e('Shortcode Reference', 'product-scraping'); ?></h2>
                <p><?php esc_html_e('Basic format (replace the URL with your own target page):', 'product-scraping'); ?></p>
                <code style="display:block;padding:10px;background:#f5f5f5;margin:10px 0;">[product_scraping url="https://example.com/products"]</code>
                <p><?php esc_html_e('You can place multiple shortcodes on a single page—each will load independently.', 'product-scraping'); ?></p>
            </div>
            
            <div class="ps-settings-section">
                <h2><?php esc_html_e('Workflow at a Glance', 'product-scraping'); ?></h2>
                <p><?php esc_html_e('Shortcode → WordPress AJAX → PHP scraper (DOMDocument) → Rendered product grid. No external services or Python servers are used.', 'product-scraping'); ?></p>
                <ul>
                    <li><?php esc_html_e('Uses the WordPress HTTP API to fetch the remote page.', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Parses HTML with DOMDocument/XPath to extract product cards.', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('All logic runs inside your WordPress install (PHP + AJAX).', 'product-scraping'); ?></li>
                </ul>
            </div>
            
        </div>
        
        <div class="ps-admin-sidebar">
            <div class="ps-info-box">
                <h3><?php esc_html_e('Quick Links', 'product-scraping'); ?></h3>
                <ul>
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=product-scraping-urls')); ?>"><?php esc_html_e('URL Manager', 'product-scraping'); ?></a> - <?php esc_html_e('Save and manage URLs', 'product-scraping'); ?></li>
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=product-scraping-test')); ?>"><?php esc_html_e('Test Scraping', 'product-scraping'); ?></a> - <?php esc_html_e('Test before using', 'product-scraping'); ?></li>
                </ul>
            </div>
            
            <div class="ps-info-box">
                <h3><?php esc_html_e('Documentation', 'product-scraping'); ?></h3>
                <p><?php esc_html_e('All guides live inside the plugin folder:', 'product-scraping'); ?></p>
                <ul>
                    <li><?php esc_html_e('README.md - Full documentation', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('INSTALLATION.md - Setup guide', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('USAGE.md - Usage examples', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('COMPLETE_INSTALLATION_GUIDE.md - Detailed walkthrough', 'product-scraping'); ?></li>
                </ul>
            </div>
            
            <div class="ps-info-box">
                <h3><?php esc_html_e('Need Help?', 'product-scraping'); ?></h3>
                <p><?php esc_html_e('If a URL fails to load, follow this checklist:', 'product-scraping'); ?></p>
                <ol>
                    <li><?php esc_html_e('Run the System Check on the Test Scraping page to ensure AJAX works.', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Open the browser console (F12 → Console/Network) to see detailed errors.', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Verify the target page is publicly accessible and not behind login/JS rendering.', 'product-scraping'); ?></li>
                    <li><?php esc_html_e('Try another URL to confirm whether the issue is site-specific.', 'product-scraping'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>

