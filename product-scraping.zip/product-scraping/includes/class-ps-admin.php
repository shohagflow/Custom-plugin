<?php
/**
 * Admin functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class PS_Admin {
    
    /**
     * Option name for settings
     */
    private $option_name = 'ps_settings';
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_menu', array($this, 'maybe_hide_saved_products_menu'), 999);
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Product Scraping', 'product-scraping'),
            __('Product Scraping', 'product-scraping'),
            'manage_options',
            'product-scraping',
            array($this, 'render_settings_page'),
            'dashicons-download',
            30
        );
        
        add_submenu_page(
            'product-scraping',
            __('Settings', 'product-scraping'),
            __('Settings', 'product-scraping'),
            'manage_options',
            'product-scraping',
            array($this, 'render_settings_page')
        );
        
        add_submenu_page(
            'product-scraping',
            __('URL Manager', 'product-scraping'),
            __('URL Manager', 'product-scraping'),
            'manage_options',
            'product-scraping-urls',
            array($this, 'render_url_manager_page')
        );
        
        add_submenu_page(
            'product-scraping',
            __('Saved Products', 'product-scraping'),
            __('Saved Products', 'product-scraping'),
            'manage_options',
            'product-scraping-saved',
            array($this, 'render_saved_products_page')
        );
        
        $settings = $this->get_settings();
        if (!empty($settings['enable_test_menu'])) {
            add_submenu_page(
                'product-scraping',
                __('Test Scraping', 'product-scraping'),
                __('Test Scraping', 'product-scraping'),
                'manage_options',
                'product-scraping-test',
                array($this, 'render_test_page')
            );
        }
    }
    
    /**
     * Hide Saved Products submenu from the menu list while keeping the page accessible.
     */
    public function hide_saved_products_menu() {
        remove_submenu_page('product-scraping', 'product-scraping-saved');
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('ps_settings_group', $this->option_name, array($this, 'sanitize_settings'));
    }
    
    /**
     * Sanitize settings
     */
    public function sanitize_settings($input) {
        $sanitized = $this->get_settings();
        
        if (isset($input['api_base_url'])) {
            $url = esc_url_raw(trim($input['api_base_url']));
            $sanitized['api_base_url'] = $url;
        }
        
        $sanitized['enable_test_menu'] = isset($input['enable_test_menu']) ? 1 : 0;
        
        return $sanitized;
    }
    
    /**
     * Get settings
     */
    public function get_settings() {
        $defaults = array(
            'api_base_url' => '',
            'enable_test_menu' => 1,
        );
        
        $settings = get_option($this->option_name, array());
        return wp_parse_args($settings, $defaults);
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'product-scraping') === false) {
            return;
        }
        
        wp_enqueue_style(
            'ps-admin-style',
            PS_PLUGIN_URL . 'includes/ps-admin.css',
            array(),
            PS_VERSION
        );
        
        wp_enqueue_script(
            'ps-admin-script',
            PS_PLUGIN_URL . 'includes/ps-admin.js',
            array('jquery'),
            PS_VERSION,
            true
        );
        
        // Pass AJAX URL and nonce to JavaScript
        wp_localize_script(
            'ps-admin-script',
            'psAdminData',
            array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ps_scrape_nonce'),
                'savedProductsUrl' => admin_url('admin.php?page=product-scraping-saved'),
            )
        );
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $settings = $this->get_settings();
        
        include PS_PLUGIN_DIR . 'templates/admin-settings.php';
    }
    
    /**
     * Render test page
     */
    public function render_test_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // No settings needed
        $settings = array();
        
        include PS_PLUGIN_DIR . 'templates/admin-test.php';
    }
    
    /**
     * Render URL Manager page
     */
    public function render_url_manager_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Handle single URL actions
        if (isset($_POST['ps_add_url']) && check_admin_referer('ps_url_action')) {
            $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
            $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
            
            if (!empty($url)) {
                $urls = get_option('ps_saved_urls', array());
                $urls[] = array(
                    'url' => $url,
                    'name' => $name ? $name : $url,
                    'created' => current_time('mysql'),
                );
                update_option('ps_saved_urls', $urls);
                
                $shortcode = '[product_scraping url="' . esc_attr($url) . '"]';
                echo '<div class="notice notice-success is-dismissible">';
                echo '<p>' . esc_html__('URL added successfully! Use this shortcode:', 'product-scraping') . '</p>';
                echo '<p><code style="font-size:13px;">' . esc_html($shortcode) . '</code></p>';
                echo '</div>';
            }
        }
        
        if (isset($_GET['delete']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'ps_delete_url')) {
            $index = intval($_GET['delete']);
            $urls = get_option('ps_saved_urls', array());
            if (isset($urls[$index])) {
                unset($urls[$index]);
                $urls = array_values($urls); // Re-index array
                update_option('ps_saved_urls', $urls);
                echo '<div class="notice notice-success"><p>' . esc_html__('URL deleted successfully!', 'product-scraping') . '</p></div>';
            }
        }
        
        $saved_urls = get_option('ps_saved_urls', array());
        if (!is_array($saved_urls) || empty($saved_urls)) {
            $saved_urls = array();
        }
        if (!is_array($saved_urls)) {
            $saved_urls = array();
        }

        // Handle URL GROUP actions (multiple URLs under one shortcode)
        $saved_groups = get_option('ps_url_groups', array());
        if (!is_array($saved_groups)) {
            $saved_groups = array();
        }

        // Add new group
        if (isset($_POST['ps_add_group']) && check_admin_referer('ps_group_action')) {
            $group_name = isset($_POST['group_name']) ? sanitize_text_field($_POST['group_name']) : '';
            $group_urls_raw = isset($_POST['group_urls']) ? trim(wp_unslash($_POST['group_urls'])) : '';

            $urls = array();
            if (!empty($group_urls_raw)) {
                $lines = preg_split('/\r\n|\r|\n/', $group_urls_raw);
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line)) {
                        $urls[] = esc_url_raw($line);
                    }
                }
            }

            if (!empty($urls)) {
                $group_id = uniqid('ps_group_');
                $saved_groups[] = array(
                    'id'      => $group_id,
                    'name'    => $group_name ? $group_name : $group_id,
                    'urls'    => $urls,
                    'created' => current_time('mysql'),
                );
                update_option('ps_url_groups', $saved_groups);

                $shortcode = '[product_scraping_group id="' . esc_attr($group_id) . '"]';
                echo '<div class="notice notice-success is-dismissible">';
                echo '<p>' . esc_html__('URL group saved successfully! Use this shortcode:', 'product-scraping') . '</p>';
                echo '<p><code style="font-size:13px;">' . esc_html($shortcode) . '</code></p>';
                echo '</div>';
            } else {
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p>' . esc_html__('No valid URLs were provided for the group.', 'product-scraping') . '</p>';
                echo '</div>';
            }
        }

        // Delete group
        if (isset($_GET['delete_group']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'ps_delete_group')) {
            $group_id = sanitize_text_field(wp_unslash($_GET['delete_group']));
            $new_groups = array();
            foreach ($saved_groups as $group) {
                if (!isset($group['id']) || $group['id'] !== $group_id) {
                    $new_groups[] = $group;
                }
            }
            $saved_groups = $new_groups;
            update_option('ps_url_groups', $saved_groups);
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('URL group deleted successfully!', 'product-scraping') . '</p></div>';
        }
        
        include PS_PLUGIN_DIR . 'templates/admin-url-manager.php';
    }
    
    /**
     * Render Saved Products page
     */
    public function render_saved_products_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $saved_products = ps_get_saved_products_index();
        
        // Handle delete
        if (isset($_GET['delete']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'ps_delete_saved')) {
            $id = sanitize_text_field($_GET['delete']);
            $saved_products = array_filter($saved_products, function($item) use ($id) {
                return isset($item['id']) && $item['id'] !== $id;
            });
            $saved_products = array_values($saved_products);
            ps_save_products_index($saved_products);
            ps_delete_saved_products_data($id);
            
            echo '<div class="notice notice-success"><p>' . esc_html__('Saved products deleted successfully!', 'product-scraping') . '</p></div>';
        }
        
        // Handle rename
        if (isset($_POST['ps_rename_saved']) && check_admin_referer('ps_rename_saved')) {
            $id = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : '';
            $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
            
            if (!empty($id) && !empty($name)) {
                foreach ($saved_products as &$item) {
                    if (isset($item['id']) && $item['id'] === $id) {
                        $item['name'] = $name;
                        break;
                    }
                }
                ps_save_products_index($saved_products);
                echo '<div class="notice notice-success"><p>' . esc_html__('Name updated successfully!', 'product-scraping') . '</p></div>';
            }
        }
        
        // Refresh data after potential modifications
        $saved_products = ps_get_saved_products_index();
        
        include PS_PLUGIN_DIR . 'templates/admin-saved-products.php';
    }
    
    /**
     * Get API base URL (for use in frontend)
     */
    public static function get_api_base_url() {
        $admin = new self();
        $settings = $admin->get_settings();
        return $settings['api_base_url'];
    }
    
    /**
     * Hide Saved Products submenu from sidebar (page still accessible via direct link).
     */
    public function maybe_hide_saved_products_menu() {
        remove_submenu_page('product-scraping', 'product-scraping-saved');
    }
    
}

