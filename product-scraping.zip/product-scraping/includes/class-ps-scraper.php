<?php
/**
 * PHP-based Web Scraper
 * No Python server needed - works entirely in WordPress
 */

if (!defined('ABSPATH')) {
    exit;
}

class PS_Scraper {
    
    /**
     * Scrape products from a URL
     */
    public static function scrape_products($url) {
        $products = array();
        
        // Validate URL
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return array(
                'status' => 'error',
                'message' => 'Invalid URL provided',
                'products' => array()
            );
        }
        
        // Fetch the page using WordPress HTTP API
        // Note: We don't specify Accept-Encoding to avoid Brotli (br) issues
        // WordPress will automatically handle gzip/deflate decompression
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'headers' => array(
                'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language' => 'en-US,en;q=0.9',
                'Connection' => 'keep-alive',
                'Upgrade-Insecure-Requests' => '1',
            ),
            'sslverify' => false, // Allow self-signed certificates
            'decompress' => true, // Let WordPress handle decompression automatically
            'redirection' => 5, // Follow redirects
        ));
        
        // Check for errors
        if (is_wp_error($response)) {
            return array(
                'status' => 'error',
                'message' => $response->get_error_message(),
                'products' => array()
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            return array(
                'status' => 'error',
                'message' => 'HTTP ' . $response_code . ': Failed to fetch page',
                'products' => array()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            return array(
                'status' => 'error',
                'message' => 'Empty response from website',
                'products' => array()
            );
        }
        
        // Parse HTML using DOMDocument
        libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        @$dom->loadHTML(mb_convert_encoding($body, 'HTML-ENTITIES', 'UTF-8'));
        $xpath = new DOMXPath($dom);
        
        // Get base URL for making relative URLs absolute
        $parsed_url = parse_url($url);
        $base_url = $parsed_url['scheme'] . '://' . $parsed_url['host'];
        
        // Find product containers
        $product_elements = self::find_product_elements($xpath);
        
        // If no products found, try alternative methods
        if (empty($product_elements)) {
            $product_elements = self::find_products_alternative($xpath, $url);
        }
        
        // Extract product data
        foreach ($product_elements as $element) {
            if (count($products) >= 50) { // Limit to 50 products
                break;
            }
            
            $product = self::extract_product_data($element, $xpath, $base_url, $url);
            
            // Only include products that have all required fields: title, price, and image
            if (!empty($product['title']) && 
                !empty($product['price']) && 
                !empty($product['image']) &&
                $product['price'] !== 'Price not available') {
                $products[] = $product;
            }
        }
        
        // Remove duplicates server-side before sending to frontend
        $products = self::remove_duplicate_products($products);
        
        return array(
            'status' => 'ok',
            'products' => $products,
            'count' => count($products)
        );
    }
    
    /**
     * Find product container elements
     */
    private static function find_product_elements($xpath) {
        $selectors = array(
            '//div[contains(@class, "product-item")]',
            '//div[contains(@class, "product-tile")]',
            '//div[contains(@class, "product-card")]',
            '//div[contains(@class, "product")]',
            '//article[contains(@class, "product")]',
            '//li[contains(@class, "product")]',
            '//div[@data-product-id]',
            '//div[@data-product]',
        );
        
        $elements = array();
        foreach ($selectors as $selector) {
            $nodes = $xpath->query($selector);
            if ($nodes && $nodes->length > 0) {
                foreach ($nodes as $node) {
                    $elements[] = $node;
                }
                if (count($elements) > 0) {
                    break; // Found products, stop searching
                }
            }
        }
        
        return $elements;
    }
    
    /**
     * Alternative method to find products
     */
    private static function find_products_alternative($xpath, $url) {
        $elements = array();
        
        // Look for links that might be products
        $links = $xpath->query('//a[contains(@href, "/product/") or contains(@href, "/p/") or contains(@href, "/item/") or contains(@href, "/products/")]');
        
        if ($links && $links->length > 0) {
            foreach ($links as $link) {
                // Get parent container
                $parent = $link->parentNode;
                if ($parent && $parent->nodeName !== 'body') {
                    $elements[] = $parent;
                }
            }
        }
        
        return array_slice($elements, 0, 30); // Limit
    }
    
    /**
     * Extract product data from element
     */
    private static function extract_product_data($element, $xpath, $base_url, $fallback_url) {
        $product = array(
            'title' => '',
            'price' => '',
            'original_price' => '',
            'savings' => '',
            'brand' => '',
            'category' => '',
            'image' => '',
            'description' => '',
            'link' => $fallback_url,
            'sourceUrl' => $fallback_url // Track which URL this product came from
        );
        
        // Extract title - prioritize better selectors
        $title_selectors = array(
            './/*[contains(@class, "product-name")]',
            './/*[contains(@class, "product-title")]',
            './/*[contains(@class, "product") and contains(@class, "name")]',
            './/*[contains(@class, "product") and contains(@class, "title")]',
            './/h2[contains(@class, "product")]',
            './/h3[contains(@class, "product")]',
            './/h2',
            './/h3',
            './/h4',
            './/*[@itemprop="name"]',
            './/*[@data-product-name]',
            './/a[contains(@class, "product")]',
        );
        
        foreach ($title_selectors as $selector) {
            $nodes = $xpath->query($selector, $element);
            if ($nodes && $nodes->length > 0) {
                foreach ($nodes as $node) {
                    // Get text content and clean it
                    $title_text = self::clean_title_text($node);
                    
                    if (!empty($title_text) && strlen($title_text) > 3 && strlen($title_text) < 200) {
                        // Check if it looks like a valid title (not CSS/JS)
                        if (!self::is_css_or_js_code($title_text)) {
                            $product['title'] = $title_text;
                            break 2; // Break out of both loops
                        }
                    }
                }
            }
        }
        
        // If no title found, try getting text from links
        if (empty($product['title'])) {
            $link_nodes = $xpath->query('.//a[@href]', $element);
            if ($link_nodes && $link_nodes->length > 0) {
                foreach ($link_nodes as $link) {
                    $title_text = self::clean_title_text($link);
                    if (!empty($title_text) && strlen($title_text) > 3 && strlen($title_text) < 200) {
                        if (!self::is_css_or_js_code($title_text)) {
                            $product['title'] = $title_text;
                            break;
                        }
                    }
                }
            }
        }
        
        // Last resort: get text from element but filter out CSS/JS
        if (empty($product['title'])) {
            $text = trim($element->textContent);
            // Remove style and script content
            $text = preg_replace('/<style[^>]*>.*?<\/style>/is', '', $text);
            $text = preg_replace('/<script[^>]*>.*?<\/script>/is', '', $text);
            // Remove CSS-like patterns
            $text = preg_replace('/\.[a-z0-9_-]+\s*\{[^}]*\}/i', '', $text);
            $text = preg_replace('/#[a-z0-9_-]+\s*\{[^}]*\}/i', '', $text);
            $text = trim($text);
            
            if (!empty($text) && !self::is_css_or_js_code($text)) {
                // Get first meaningful line
                $lines = explode("\n", $text);
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (strlen($line) > 3 && strlen($line) < 200 && !self::is_css_or_js_code($line)) {
                        $product['title'] = $line;
                        break;
                    }
                }
            }
        }
        
        // Extract primary price (final price)
        $price_found = false;
        $price_queries = array(
            './/*[@data-price-type="finalPrice"]',
            './/*[contains(@class, "price-wrapper") and @data-price-amount]',
            './/*[contains(@class, "price-box")]//*[contains(@class, "price")]',
        );
        
        foreach ($price_queries as $query) {
            $nodes = $xpath->query($query, $element);
            if ($nodes && $nodes->length > 0) {
                foreach ($nodes as $node) {
                    // Skip old price / save price containers
                    if (self::is_descendant_of_class($node, array('old-price', 'save-price'))) {
                        continue;
                    }
                    $price_text = trim($node->textContent);
                    if (!empty($price_text)) {
                        $product['price'] = self::clean_price_text($price_text);
                        if (!empty($product['price'])) {
                            $price_found = true;
                            break 2;
                        }
                    }
                }
            }
        }
        
        // Fallback price selectors
        if (!$price_found) {
            $price_selectors = array(
                './/*[contains(@class, "price")]',
                './/*[contains(@class, "product-price")]',
                './/*[contains(@class, "cost")]',
                './/*[contains(@class, "amount")]',
                './/*[@itemprop="price"]',
            );
            
            foreach ($price_selectors as $selector) {
                $nodes = $xpath->query($selector, $element);
                if ($nodes && $nodes->length > 0) {
                    foreach ($nodes as $node) {
                        if (self::is_descendant_of_class($node, array('old-price', 'save-price'))) {
                            continue;
                        }
                        $price_text = trim($node->textContent);
                        if (!empty($price_text)) {
                            $product['price'] = self::clean_price_text($price_text);
                            if (!empty($product['price'])) {
                                $price_found = true;
                                break 2;
                            }
                        }
                    }
                }
            }
        }
        
        // If no price found, try regex on element text
        if (empty($product['price'])) {
            $text = $element->textContent;
            if (preg_match('/[\$£€¥]\s*[\d,]+\.?\d*/', $text, $matches)) {
                $product['price'] = $matches[0];
            } else {
                $product['price'] = 'Price not available';
            }
        }
        
        // Extract original price (strikethrough)
        $original_price_node = $xpath->query('.//*[contains(@class, "old-price")]//span[contains(@class, "price")]', $element);
        if ($original_price_node && $original_price_node->length > 0) {
            $original_price_text = trim($original_price_node->item(0)->textContent);
            if (!empty($original_price_text)) {
                $product['original_price'] = self::clean_price_text($original_price_text);
            }
        }
        
        // Extract savings (percentage or amount)
        $savings_node = $xpath->query('.//*[contains(@class, "save-price")]//span[contains(@class, "price")]', $element);
        if ($savings_node && $savings_node->length > 0) {
            $savings_text = trim($savings_node->item(0)->textContent);
            if (!empty($savings_text)) {
                $product['savings'] = preg_replace('/\s+/', ' ', $savings_text);
            }
        } else {
            // Try to detect "You Save" text
            $save_text_node = $xpath->query('.//*[contains(@class, "save-price")]', $element);
            if ($save_text_node && $save_text_node->length > 0) {
                $save_text = trim($save_text_node->item(0)->textContent);
                if (!empty($save_text)) {
                    if (preg_match('/\d+%/', $save_text, $matches)) {
                        $product['savings'] = $matches[0];
                    } else {
                        $product['savings'] = self::clean_price_text($save_text);
                    }
                }
            }
        }
        
        // Extract brand
        $brand_nodes = $xpath->query('.//*[contains(@class, "brand-name")]', $element);
        if ($brand_nodes && $brand_nodes->length > 0) {
            $brand_text = trim($brand_nodes->item(0)->textContent);
            $product['brand'] = preg_replace('/^\s*by\s+/i', '', $brand_text);
        }
        
        // Extract category (best effort)
        $category_selectors = array(
            './/*[contains(@class, "product-category")]',
            './/*[contains(@class, "category-name")]',
            './/*[contains(@class, "product-type")]',
            './/*[contains(@class, "item-category")]',
            './/*[@data-category]',
            './/*[@data-item-category]',
        );
        foreach ($category_selectors as $selector) {
            $nodes = $xpath->query($selector, $element);
            if ($nodes && $nodes->length > 0) {
                $cat_text = trim($nodes->item(0)->textContent);
                if (empty($cat_text) && $nodes->item(0)->hasAttribute('data-category')) {
                    $cat_text = $nodes->item(0)->getAttribute('data-category');
                }
                if (empty($cat_text) && $nodes->item(0)->hasAttribute('data-item-category')) {
                    $cat_text = $nodes->item(0)->getAttribute('data-item-category');
                }
                if (!empty($cat_text)) {
                    $product['category'] = preg_replace('/\s+/', ' ', $cat_text);
                    break;
                }
            }
        }
        
        // Extract image - try multiple methods with broader search
        $image_url = '';
        
        // Method 1: Look for img tags (search more broadly)
        $img_nodes = $xpath->query('.//img', $element);
        
        // If no images found, try parent element
        if ((!$img_nodes || $img_nodes->length === 0) && $element->parentNode) {
            $parent_xpath = new DOMXPath($element->ownerDocument);
            $img_nodes = $parent_xpath->query('.//img', $element->parentNode);
        }
        
        if ($img_nodes && $img_nodes->length > 0) {
            // Try all img tags, prioritize larger images
            foreach ($img_nodes as $img) {
                $candidate_url = '';
                
                // Try data-lazy-src (some lazy loaders use this)
                $candidate_url = $img->getAttribute('data-lazy-src');
                
                // Try data-src (common lazy loading)
                if (empty($candidate_url)) {
                    $candidate_url = $img->getAttribute('data-src');
                }
                
                // Try data-original
                if (empty($candidate_url)) {
                    $candidate_url = $img->getAttribute('data-original');
                }
                
                // Try data-lazy (another lazy loading variant)
                if (empty($candidate_url)) {
                    $candidate_url = $img->getAttribute('data-lazy');
                }
                
                // Try data-srcset (parse first URL)
                if (empty($candidate_url)) {
                    $srcset = $img->getAttribute('data-srcset');
                    if (!empty($srcset)) {
                        $candidate_url = self::parse_srcset($srcset);
                    }
                }
                
                // Try srcset (parse first URL)
                if (empty($candidate_url)) {
                    $srcset = $img->getAttribute('srcset');
                    if (!empty($srcset)) {
                        $candidate_url = self::parse_srcset($srcset);
                    }
                }
                
                // Fall back to src
                if (empty($candidate_url)) {
                    $candidate_url = $img->getAttribute('src');
                }
                
                // Validate URL
                if (!empty($candidate_url)) {
                    // Skip data URIs and obvious placeholders
                    if (strpos($candidate_url, 'data:image') === 0) {
                        continue;
                    }
                    
                    // Skip obvious placeholder patterns (but be less strict)
                    $lower_url = strtolower($candidate_url);
                    if (strpos($lower_url, 'placeholder') !== false && 
                        (strpos($lower_url, '1x1') !== false || strpos($lower_url, 'blank') !== false)) {
                        continue;
                    }
                    
                    // Make absolute URL
                    $candidate_url = self::make_absolute_url($candidate_url, $base_url);
                    
                    // If URL looks valid, use it (be more lenient)
                    if (strpos($candidate_url, 'http') === 0 || 
                        strpos($candidate_url, '//') === 0 ||
                        (strpos($candidate_url, '/') === 0 && strlen($candidate_url) > 5)) {
                        $image_url = $candidate_url;
                        break; // Found valid image
                    }
                }
            }
        }
        
        // Method 1b: Look for picture elements (HTML5 picture tag)
        if (empty($image_url)) {
            $picture_nodes = $xpath->query('.//picture//img', $element);
            if ($picture_nodes && $picture_nodes->length > 0) {
                foreach ($picture_nodes as $img) {
                    $candidate_url = $img->getAttribute('src');
                    if (empty($candidate_url)) {
                        $candidate_url = $img->getAttribute('data-src');
                    }
                    if (!empty($candidate_url) && strpos($candidate_url, 'data:image') !== 0) {
                        $image_url = self::make_absolute_url($candidate_url, $base_url);
                        break;
                    }
                }
            }
        }
        
        // Method 2: Look for background images in style attributes
        if (empty($image_url)) {
            $style_nodes = $xpath->query('.//*[@style]', $element);
            if ($style_nodes && $style_nodes->length > 0) {
                foreach ($style_nodes as $style_node) {
                    $style = $style_node->getAttribute('style');
                    if (preg_match('/background-image:\s*url\(["\']?([^"\']+)["\']?\)/i', $style, $matches)) {
                        $image_url = trim($matches[1]);
                        if (!empty($image_url)) {
                            $image_url = self::make_absolute_url($image_url, $base_url);
                            break;
                        }
                    }
                }
            }
        }
        
        // Method 3: Look for data attributes with image URLs (broader search)
        if (empty($image_url)) {
            $data_selectors = array(
                './/*[@data-image]',
                './/*[@data-img]',
                './/*[@data-product-image]',
                './/*[@data-thumb]',
                './/*[@data-thumbnail]',
                './/*[@data-src]',
            );
            
            foreach ($data_selectors as $selector) {
                $data_nodes = $xpath->query($selector, $element);
                if ($data_nodes && $data_nodes->length > 0) {
                    foreach ($data_nodes as $data_node) {
                        $candidate_url = $data_node->getAttribute('data-image');
                        if (empty($candidate_url)) {
                            $candidate_url = $data_node->getAttribute('data-img');
                        }
                        if (empty($candidate_url)) {
                            $candidate_url = $data_node->getAttribute('data-product-image');
                        }
                        if (empty($candidate_url)) {
                            $candidate_url = $data_node->getAttribute('data-thumb');
                        }
                        if (empty($candidate_url)) {
                            $candidate_url = $data_node->getAttribute('data-thumbnail');
                        }
                        if (empty($candidate_url)) {
                            $candidate_url = $data_node->getAttribute('data-src');
                        }
                        
                        if (!empty($candidate_url) && strpos($candidate_url, 'data:image') !== 0) {
                            // Check if it looks like an image URL
                            $lower_url = strtolower($candidate_url);
                            if (preg_match('/\.(jpg|jpeg|png|gif|webp|svg)(\?|$)/i', $candidate_url) || 
                                strpos($candidate_url, '/image') !== false ||
                                strpos($candidate_url, '/img') !== false) {
                                $image_url = self::make_absolute_url($candidate_url, $base_url);
                                break 2; // Break out of both loops
                            }
                        }
                    }
                }
            }
        }
        
        // Method 4: Look in product image containers
        if (empty($image_url)) {
            $image_container_selectors = array(
                './/*[contains(@class, "product-image")]//img',
                './/*[contains(@class, "product-img")]//img',
                './/*[contains(@class, "product-thumb")]//img',
                './/*[contains(@class, "product-thumbnail")]//img',
                './/*[contains(@class, "thumb")]//img',
                './/*[contains(@class, "thumbnail")]//img',
            );
            
            foreach ($image_container_selectors as $selector) {
                $container_imgs = $xpath->query($selector, $element);
                if ($container_imgs && $container_imgs->length > 0) {
                    foreach ($container_imgs as $img) {
                        $candidate_url = $img->getAttribute('data-src');
                        if (empty($candidate_url)) {
                            $candidate_url = $img->getAttribute('src');
                        }
                        if (!empty($candidate_url) && strpos($candidate_url, 'data:image') !== 0) {
                            $image_url = self::make_absolute_url($candidate_url, $base_url);
                            break 2;
                        }
                    }
                }
            }
        }
        
        if (!empty($image_url)) {
            $product['image'] = $image_url;
        }
        
        // Extract description
        $desc_selectors = array(
            './/*[contains(@class, "product-description")]',
            './/*[contains(@class, "description")]',
            './/*[contains(@class, "product-desc")]',
            './/*[contains(@class, "excerpt")]',
            './/*[@itemprop="description"]',
        );
        
        foreach ($desc_selectors as $selector) {
            $nodes = $xpath->query($selector, $element);
            if ($nodes && $nodes->length > 0) {
                $desc_text = trim($nodes->item(0)->textContent);
                if (!empty($desc_text)) {
                    $product['description'] = substr($desc_text, 0, 200);
                    break;
                }
            }
        }
        
        // Extract link
        $link_nodes = $xpath->query('.//a[@href]', $element);
        if ($link_nodes && $link_nodes->length > 0) {
            $href = $link_nodes->item(0)->getAttribute('href');
            if (!empty($href)) {
                $product['link'] = self::make_absolute_url($href, $base_url);
            }
        } elseif ($element->nodeName === 'a' && $element->hasAttribute('href')) {
            $href = $element->getAttribute('href');
            if (!empty($href)) {
                $product['link'] = self::make_absolute_url($href, $base_url);
            }
        }
        
        return $product;
    }
    
    /**
     * Clean title text - remove unwanted content
     */
    private static function clean_title_text($node) {
        if (!$node) {
            return '';
        }
        
        // Get text content directly
        $text = trim($node->textContent);
        
        // Remove script and style content using regex (more reliable)
        $text = preg_replace('/<script[^>]*>.*?<\/script>/is', '', $text);
        $text = preg_replace('/<style[^>]*>.*?<\/style>/is', '', $text);
        
        // Remove HTML tags
        $text = strip_tags($text);
        
        // Remove extra whitespace
        $text = preg_replace('/\s+/', ' ', $text);
        
        return trim($text);
    }
    
    /**
     * Check if node is inside element with specific class names
     */
    private static function is_descendant_of_class($node, $class_names = array()) {
        if (!$node || empty($class_names)) {
            return false;
        }
        
        $class_names = array_map('strtolower', $class_names);
        $current = $node;
        while ($current instanceof DOMNode) {
            if ($current->attributes && $current->attributes->getNamedItem('class')) {
                $class_attr = strtolower($current->attributes->getNamedItem('class')->nodeValue);
                foreach ($class_names as $class_name) {
                    if (false !== strpos($class_attr, $class_name)) {
                        return true;
                    }
                }
            }
            $current = $current->parentNode;
        }
        
        return false;
    }
    
    /**
     * Check if text looks like CSS or JavaScript code
     */
    private static function is_css_or_js_code($text) {
        // Check for CSS patterns
        if (preg_match('/^[.#][a-z0-9_-]+\s*\{/i', $text)) {
            return true;
        }
        
        // Check for CSS properties
        if (preg_match('/:\s*[^;]+;\s*$/', $text)) {
            return true;
        }
        
        // Check for JavaScript patterns
        if (preg_match('/function\s*\(|var\s+\w+\s*=|\.\w+\s*\(/', $text)) {
            return true;
        }
        
        // Check for common CSS/JS keywords
        $keywords = array('width', 'height', 'px', 'margin', 'padding', 'color', 'background', 'display', 'position');
        $lower_text = strtolower($text);
        foreach ($keywords as $keyword) {
            if (preg_match('/\b' . preg_quote($keyword, '/') . '\s*[:=]/', $lower_text)) {
                return true;
            }
        }
        
        // Check if it's mostly special characters or numbers
        if (preg_match('/^[^a-zA-Z]*$/', $text) || strlen($text) < 5) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Clean price text - remove unwanted labels
     */
    private static function clean_price_text($price_text) {
        if (empty($price_text)) {
            return $price_text;
        }
        
        // Remove common unwanted text patterns
        $patterns = array(
            '/\bOriginal Price\b/i',
            '/\bYou Save\s+\d+%\b/i',
            '/\bSave\s+\d+%\b/i',
            '/\bWas\b/i',
            '/\bNow\b/i',
            '/\bRegular Price\b/i',
            '/\bSale Price\b/i',
            '/\bCompare at\b/i',
        );
        
        foreach ($patterns as $pattern) {
            $price_text = preg_replace($pattern, '', $price_text);
        }
        
        // Clean up multiple spaces and trim
        $price_text = preg_replace('/\s+/', ' ', $price_text);
        $price_text = trim($price_text);
        
        // If we have multiple prices, try to get the first/main one
        // Look for price patterns and take the first one
        if (preg_match_all('/[\$£€¥]\s*[\d,]+\.?\d*/', $price_text, $matches)) {
            if (count($matches[0]) > 0) {
                // Return the first price found
                return $matches[0][0];
            }
        }
        
        return $price_text;
    }
    
    /**
     * Parse srcset attribute and return first URL
     */
    private static function parse_srcset($srcset) {
        if (empty($srcset)) {
            return '';
        }
        
        // Split by comma
        $sources = explode(',', $srcset);
        
        foreach ($sources as $source) {
            $source = trim($source);
            // Extract URL (before space or descriptor)
            if (preg_match('/^([^\s]+)/', $source, $matches)) {
                $url = trim($matches[1]);
                if (!empty($url) && filter_var($url, FILTER_VALIDATE_URL)) {
                    return $url;
                }
            }
        }
        
        return '';
    }
    
    /**
     * Make relative URL absolute
     */
    private static function make_absolute_url($url, $base_url) {
        if (empty($url)) {
            return '';
        }
        
        // Already absolute
        if (preg_match('/^https?:\/\//', $url)) {
            return $url;
        }
        
        // Protocol-relative
        if (strpos($url, '//') === 0) {
            $parsed = parse_url($base_url);
            return $parsed['scheme'] . ':' . $url;
        }
        
        // Absolute path
        if (strpos($url, '/') === 0) {
            return $base_url . $url;
        }
        
        // Relative path
        return rtrim($base_url, '/') . '/' . ltrim($url, '/');
    }
    
    /**
     * Remove duplicate products server-side
     * Uses multiple strategies to identify duplicates
     */
    private static function remove_duplicate_products($products) {
        if (empty($products) || !is_array($products)) {
            return $products;
        }
        
        $seen = array();
        $unique_products = array();
        
        foreach ($products as $product) {
            $keys = array();
            $is_duplicate = false;
            
            // Strategy 1: Normalize and use product link/URL
            if (!empty($product['link'])) {
                $normalized_url = strtolower(trim($product['link']));
                $normalized_url = rtrim($normalized_url, '/');
                $normalized_url = strtok($normalized_url, '?'); // Remove query params
                $normalized_url = strtok($normalized_url, '#'); // Remove hash
                
                // Extract product slug from URL
                $url_parts = explode('/', $normalized_url);
                $last_part = end($url_parts);
                if ($last_part) {
                    $product_slug = preg_replace('/\.html?$/i', '', $last_part);
                    $product_slug = preg_replace('/[^a-z0-9-]/i', '', $product_slug);
                    if (!empty($product_slug)) {
                        $keys[] = 'url:' . $product_slug;
                    }
                }
                $keys[] = 'fullurl:' . $normalized_url;
            }
            
            // Strategy 2: Use title + price combination (normalized)
            if (!empty($product['title']) && !empty($product['price'])) {
                $normalized_title = strtolower(trim($product['title']));
                $normalized_title = preg_replace('/[^a-z0-9]/i', '', $normalized_title);
                $normalized_title = substr($normalized_title, 0, 50);
                
                $normalized_price = strtolower(trim($product['price']));
                $normalized_price = preg_replace('/[^0-9.]/i', '', $normalized_price);
                
                if (!empty($normalized_title) && !empty($normalized_price)) {
                    $keys[] = 'titleprice:' . $normalized_title . '|' . $normalized_price;
                }
            }
            
            // Strategy 3: Use title only (normalized)
            if (!empty($product['title'])) {
                $normalized_title = strtolower(trim($product['title']));
                $normalized_title = preg_replace('/[^a-z0-9]/i', '', $normalized_title);
                $normalized_title = substr($normalized_title, 0, 50);
                if (!empty($normalized_title)) {
                    $keys[] = 'title:' . $normalized_title;
                }
            }
            
            // Check if any key matches a previously seen product
            foreach ($keys as $key) {
                if (isset($seen[$key])) {
                    $is_duplicate = true;
                    break;
                }
            }
            
            // If not duplicate, add all keys to seen array and add product
            if (!$is_duplicate && !empty($keys)) {
                foreach ($keys as $key) {
                    $seen[$key] = true;
                }
                $unique_products[] = $product;
            } elseif (empty($keys)) {
                // Fallback: If no keys could be generated, use a generic key
                $fallback_key = 'fallback:' . (!empty($product['title']) ? substr(md5($product['title']), 0, 10) : 'unknown') . '|' . (!empty($product['price']) ? $product['price'] : '0');
                if (!isset($seen[$fallback_key])) {
                    $seen[$fallback_key] = true;
                    $unique_products[] = $product;
                }
            }
        }
        
        return $unique_products;
    }
}

