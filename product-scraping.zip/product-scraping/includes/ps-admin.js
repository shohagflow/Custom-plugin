/**
 * Admin JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Test Scraping
        $('#ps-test-scrape').on('click', function() {
            var $button = $(this);
            var $spinner = $('#ps-test-spinner');
            var $results = $('#ps-test-results');
            var $output = $('#ps-test-output');
            var testUrl = $('#test_url').val();
            var ajaxUrl = psAdminData.ajaxUrl;
            var nonce = psAdminData.nonce;
            
            if (!testUrl) {
                alert('Please enter a URL to test');
                return;
            }
            
            // Validate URL
            try {
                new URL(testUrl);
            } catch (e) {
                alert('Please enter a valid URL');
                return;
            }
            
            // Disable button and show spinner
            $button.prop('disabled', true);
            $spinner.addClass('is-active');
            $results.show();
            $output.html('<p>Scraping products from <code>' + escapeHtml(testUrl) + '</code>...</p>');
            
            // Fetch products via WordPress AJAX
            fetch(ajaxUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=ps_scrape_products&url=' + encodeURIComponent(testUrl) + '&nonce=' + encodeURIComponent(nonce)
            })
                .then(function(response) {
                    if (!response.ok) {
                        throw new Error('HTTP ' + response.status + ': ' + response.statusText);
                    }
                    return response.json();
                })
                .then(function(data) {
                    console.log('Response data:', data);
                    $spinner.removeClass('is-active');
                    $button.prop('disabled', false);
                    
                    if (data.success && data.data && data.data.status === 'ok' && data.data.products && data.data.products.length > 0) {
                        displayProducts(data.data.products, $output, testUrl);
                    } else {
                        var errorMsg = data.data && data.data.message ? data.data.message : 'No products found. The website may not have products or the structure is different.';
                        $output.html('<div class="ps-error-message">' + escapeHtml(errorMsg) + '</div>');
                    }
                })
                .catch(function(error) {
                    console.error('Error:', error);
                    $spinner.removeClass('is-active');
                    $button.prop('disabled', false);
                    
                    var errorMsg = '<div class="ps-error-message">';
                    errorMsg += '<strong>Error:</strong> ' + escapeHtml(error.message) + '<br><br>';
                    errorMsg += '<strong>Possible issues:</strong><ul>';
                    errorMsg += '<li>Website may be blocking requests</li>';
                    errorMsg += '<li>Website may require JavaScript to load content</li>';
                    errorMsg += '<li>Check browser console (F12) for more details</li>';
                    errorMsg += '<li>Try a different website URL</li>';
                    errorMsg += '</ul>';
                    errorMsg += '</div>';
                    $output.html(errorMsg);
                });
        });
        
        // Health Check (now tests WordPress AJAX)
        $('#ps-test-health').on('click', function() {
            var $button = $(this);
            var $results = $('#ps-health-results');
            var $output = $('#ps-health-output');
            var ajaxUrl = psAdminData.ajaxUrl;
            var nonce = psAdminData.nonce;
            
            $button.prop('disabled', true);
            $results.show();
            $output.html('<p>Testing WordPress AJAX system...</p>');
            
            // Test with a simple request
            fetch(ajaxUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=ps_scrape_products&url=https://example.com&nonce=' + encodeURIComponent(nonce)
            })
                .then(function(response) {
                    return response.json();
                })
                .then(function(data) {
                    $button.prop('disabled', false);
                    $output.html('<div class="ps-success-message"><strong>✓ WordPress AJAX is working!</strong><br>The plugin is ready to scrape websites.</div>');
                })
                .catch(function(error) {
                    $button.prop('disabled', false);
                    var errorMsg = '<div class="ps-error-message">';
                    errorMsg += '<strong>Error:</strong> ' + escapeHtml(error.message) + '<br><br>';
                    errorMsg += '<strong>Possible Issues:</strong><ul>';
                    errorMsg += '<li>WordPress AJAX may not be configured correctly</li>';
                    errorMsg += '<li>Check browser console (F12) for more details</li>';
                    errorMsg += '</ul>';
                    errorMsg += '</div>';
                    $output.html(errorMsg);
                });
        });
        
        // Store current products for saving
        var currentProducts = null;
        var currentUrl = null;
        
        /**
         * Display products in preview
         */
        function displayProducts(products, $container, url) {
            var html = '<div style="margin-bottom: 15px;">';
            html += '<strong>Found ' + products.length + ' product(s)</strong>';
            html += '<button type="button" id="ps-save-products" class="button button-primary" style="margin-left: 15px;">';
            html += 'Save Products';
            html += '</button>';
            html += '<span id="ps-save-status" style="margin-left: 10px; color: #46b450; display: none;">✓ Saved!</span>';
            html += '</div>';
            html += '<div class="ps-product-preview">';
            
            // Filter products - only show those with title, price, and image
            var validProducts = products.filter(function(product) {
                return product.title && 
                       product.title.trim() !== '' &&
                       product.price && 
                       product.price.trim() !== '' &&
                       product.price !== 'Price not available' &&
                       product.image && 
                       product.image.trim() !== '';
            });
            
            if (validProducts.length === 0 && products.length > 0) {
                html += '<div class="ps-error-message">';
                html += '<strong>No complete products found.</strong><br>';
                html += 'Some products are missing required information (image, price, or title) and were filtered out.';
                html += '<br><br>Total products scraped: ' + products.length;
                html += '<br>Valid products: ' + validProducts.length;
                html += '</div>';
                html += '</div>';
                $container.html(html);
                $('#ps-save-products').prop('disabled', true).text('No products to save');
                return;
            } else {
                currentProducts = validProducts;
                currentUrl = url;
                
                html += '<p style="color: #666; font-size: 12px; margin-top: 10px;">';
                html += 'Showing ' + validProducts.length + ' complete product(s)';
                if (products.length > validProducts.length) {
                    html += ' (filtered out ' + (products.length - validProducts.length) + ' incomplete product(s))';
                }
                html += '</p>';
                
                validProducts.forEach(function(product) {
                    html += '<div class="ps-product-preview-card">';
                    
                    if (product.image) {
                        html += '<img src="' + escapeHtml(product.image) + '" alt="' + escapeHtml(product.title || '') + '" onerror="this.src=\'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'200\' height=\'150\'%3E%3Crect fill=\'%23ddd\' width=\'200\' height=\'150\'/%3E%3Ctext fill=\'%23999\' font-family=\'sans-serif\' font-size=\'14\' dy=\'10.5\' font-weight=\'bold\' x=\'50%25\' y=\'50%25\' text-anchor=\'middle\'%3ENo Image%3C/text%3E%3C/svg%3E\'">';
                    } else {
                        html += '<div style="width:100%;height:150px;background:#ddd;display:flex;align-items:center;justify-content:center;color:#999;">No Image</div>';
                    }
                    
                    html += '<h4>' + escapeHtml(product.title || 'Untitled') + '</h4>';
                    
                    if ((product.brand && product.brand.trim() !== '') || (product.category && product.category.trim() !== '')) {
                        html += '<div class="ps-preview-meta">';
                        if (product.brand && product.brand.trim() !== '') {
                            html += '<span class="brand">' + escapeHtml(product.brand.trim()) + '</span>';
                        }
                        if (product.category && product.category.trim() !== '') {
                            html += '<span class="category">' + escapeHtml(product.category.trim()) + '</span>';
                        }
                        html += '</div>';
                    }
                    
                    html += '<div class="price">';
                    html += '<span class="current-price">' + escapeHtml(product.price || 'Price not available') + '</span>';
                    if (product.original_price && product.original_price.trim() !== '' && product.original_price !== product.price) {
                        html += '<span class="original-price">' + escapeHtml(product.original_price.trim()) + '</span>';
                    }
                    if (product.savings && product.savings.trim() !== '') {
                        var savingsText = product.savings.trim();
                        if (!/save/i.test(savingsText)) {
                            savingsText = 'You Save ' + savingsText;
                        }
                        html += '<span class="savings">' + escapeHtml(savingsText) + '</span>';
                    }
                    html += '</div>';
                    
                    if (product.description && product.description.trim() !== '') {
                        html += '<p style="font-size:12px;color:#666;margin:5px 0;">' + escapeHtml(product.description) + '</p>';
                    }
                    
                    if (product.link) {
                        html += '<a href="' + escapeHtml(product.link) + '" target="_blank" style="font-size:12px;color:#2271b1;">View Product →</a>';
                    }
                    
                    html += '</div>';
                });
            }
            
            html += '</div>';
            $container.html(html);
            
            // Add save button handler
            $('#ps-save-products').on('click', function() {
                if (!currentProducts || currentProducts.length === 0) {
                    alert('No products to save');
                    return;
                }
                
            var $button = $(this);
            var $status = $('#ps-save-status');
            
            var totalCount = currentProducts.length;
            var chunkSize = Math.ceil(totalCount / 4);
            chunkSize = Math.max(10, Math.min(50, chunkSize));
            var chunks = [];
            for (var i = 0; i < currentProducts.length; i += chunkSize) {
                chunks.push(currentProducts.slice(i, i + chunkSize));
            }
            
            var sessionId = 'ps_' + Date.now();
            var processed = 0;
            
            function sendChunk(index) {
                if (index >= chunks.length) {
                    return;
                }
                
                var chunk = chunks[index];
                var body = 'action=ps_save_products_chunk' +
                           '&url=' + encodeURIComponent(currentUrl || '') +
                           '&products=' + encodeURIComponent(JSON.stringify(chunk)) +
                           '&nonce=' + encodeURIComponent(nonce) +
                           '&sessionId=' + encodeURIComponent(sessionId) +
                           '&chunkIndex=' + index +
                           '&totalChunks=' + chunks.length +
                           '&totalProducts=' + totalCount;
                
                fetch(ajaxUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: body
                })
                    .then(function(response) {
                        return response.json();
                    })
                    .then(function(data) {
                        if (data.success) {
                            var serverProcessed = data.data && data.data.processed ? parseInt(data.data.processed, 10) : null;
                            var serverTotal = data.data && data.data.total ? parseInt(data.data.total, 10) : totalCount;
                            if (serverTotal > 0) {
                                totalCount = serverTotal;
                            }
                            processed = serverProcessed !== null ? serverProcessed : Math.min(totalCount, processed + chunk.length);
                            
                            var percent = totalCount === 0 ? 100 : Math.round((processed / totalCount) * 100);
                            $status.text('Saving... ' + percent + '%').fadeIn();
                            
                            if (data.data && data.data.completed) {
                                var countdown = 5;
                                $status.text('✓ Saved! Redirecting in ' + countdown + 's...').fadeIn();
                                var countdownInterval = setInterval(function() {
                                    countdown--;
                                    if (countdown <= 0) {
                                        clearInterval(countdownInterval);
                                        window.location.href = psAdminData.savedProductsUrl;
                                    } else {
                                        $status.text('✓ Saved! Redirecting in ' + countdown + 's...');
                                    }
                                }, 1000);
                            } else {
                                sendChunk(index + 1);
                            }
                        } else {
                            throw new Error(data.data && data.data.message ? data.data.message : 'Unknown error');
                        }
                    })
                    .catch(function(error) {
                        alert('Error: ' + error.message);
                        $button.prop('disabled', false).text('Save Products');
                    });
            }
            
            $button.prop('disabled', true).text('Saving...');
            sendChunk(0);
            });
        }
        
        /**
         * Escape HTML
         */
        function escapeHtml(text) {
            var map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text ? text.replace(/[&<>"']/g, function(m) { return map[m]; }) : '';
        }
        
        // Rename button handler
        $('.ps-rename-btn').on('click', function() {
            var id = $(this).data('id');
            var name = $(this).data('name');
            $('#ps-rename-id').val(id);
            $('#ps-rename-name').val(name);
            $('#ps-rename-modal').fadeIn();
        });
        
        // Cancel rename
        $('.ps-cancel-rename').on('click', function() {
            $('#ps-rename-modal').fadeOut();
        });
        
        // Load preview
        $('.ps-load-preview').on('click', function() {
            var $button = $(this);
            var id = $button.data('id');
            var $preview = $('#ps-preview-' + id);
            
            if ($preview.hasClass('loaded')) {
                $preview.toggle();
                return;
            }
            
            $button.prop('disabled', true).text('Loading...');
            
            // Get saved products from server
            fetch(ajaxUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=ps_get_saved_products&id=' + encodeURIComponent(id) + '&nonce=' + encodeURIComponent(nonce)
            })
                .then(function(response) {
                    return response.json();
                })
                .then(function(data) {
                    $button.prop('disabled', false).text('Hide Preview');
                    
                    if (data.success && data.data && data.data.products) {
                        displayProducts(data.data.products, $preview, data.data.url);
                        $preview.addClass('loaded').show();
                    } else {
                        $preview.html('<p>Error loading products.</p>');
                    }
                })
                .catch(function(error) {
                    $button.prop('disabled', false).text('Load Preview');
                    $preview.html('<p>Error: ' + escapeHtml(error.message) + '</p>');
                });
        });

        // Test URL Group - Show product counts per URL
        $(document).on('click', '.ps-test-group', function() {
            var $button = $(this);
            var groupId = $button.data('group-id');
            var groupName = $button.data('group-name');
            var $results = $('#ps-test-' + groupId);
            var $content = $results.find('.ps-test-content');
            var ajaxUrl = psAdminData.ajaxUrl;
            var nonce = psAdminData.nonce;
            
            if (!groupId) {
                alert('Group ID not found');
                return;
            }
            
            // Disable button and show loading
            $button.prop('disabled', true).text('Testing...');
            $results.show();
            $content.html('<p><span class="spinner is-active" style="float: none; margin: 0 5px 0 0;"></span>Testing URLs...</p>');
            
            // Fetch product counts via AJAX
            fetch(ajaxUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=ps_test_url_group&group_id=' + encodeURIComponent(groupId) + '&nonce=' + encodeURIComponent(nonce)
            })
                .then(function(response) {
                    if (!response.ok) {
                        throw new Error('HTTP ' + response.status + ': ' + response.statusText);
                    }
                    return response.json();
                })
                .then(function(data) {
                    $button.prop('disabled', false).text('Test');
                    
                    if (data.success && data.data) {
                        var html = '<p><strong>Group:</strong> ' + escapeHtml(data.data.group_name || groupId) + '</p>';
                        html += '<p><strong>Total Products:</strong> <strong style="color: #2271b1;">' + (data.data.total_products || 0) + '</strong></p>';
                        html += '<table class="widefat" style="margin-top: 10px;">';
                        html += '<thead><tr><th style="width: 60%;">URL</th><th style="width: 20%;">Status</th><th style="width: 20%;">Products</th></tr></thead>';
                        html += '<tbody>';
                        
                        if (data.data.urls && Array.isArray(data.data.urls)) {
                            data.data.urls.forEach(function(urlData) {
                                var statusClass = urlData.status === 'ok' ? 'color: #00a32a;' : 'color: #d63638;';
                                var statusText = urlData.status === 'ok' ? '✓ Success' : '✗ Error';
                                var count = urlData.count || 0;
                                var urlDisplay = urlData.url.length > 60 ? urlData.url.substring(0, 60) + '...' : urlData.url;
                                
                                html += '<tr>';
                                html += '<td><code style="font-size: 11px;">' + escapeHtml(urlDisplay) + '</code></td>';
                                html += '<td style="' + statusClass + '">' + statusText + '</td>';
                                html += '<td><strong>' + count + '</strong></td>';
                                html += '</tr>';
                                
                                if (urlData.message) {
                                    html += '<tr><td colspan="3" style="color: #d63638; font-size: 11px; padding-left: 20px;">' + escapeHtml(urlData.message) + '</td></tr>';
                                }
                            });
                        }
                        
                        html += '</tbody></table>';
                        $content.html(html);
                    } else {
                        var errorMsg = data.data && data.data.message ? data.data.message : 'Failed to test URL group';
                        $content.html('<p style="color: #d63638;">Error: ' + escapeHtml(errorMsg) + '</p>');
                    }
                })
                .catch(function(error) {
                    $button.prop('disabled', false).text('Test');
                    $content.html('<p style="color: #d63638;">Error: ' + escapeHtml(error.message) + '</p>');
                });
        });
    });
    
})(jQuery);

