# Product Scraping WordPress Plugin

A WordPress plugin that displays real-time product data from any external website. **Everything happens inside WordPress—no Python server or external service required.**

## Features

- Shortcode `[product_scraping url="ANY_URL"]`
- Works with any public product/category URL
- Scrapes via WordPress AJAX + PHP DOM parsing
- Responsive grid with title, brand, price, savings, description, button
- URL Manager, Saved Products, and Test Scraping admin tools
- Loading/error states and system health checks

## Installation

1. Upload `product-scraping` to `/wp-content/plugins/`.
2. Activate the plugin in WordPress → Plugins.
3. Done. No additional setup.

## Usage

```
[product_scraping url="https://example.com/products"]
```

Place the shortcode on any page/post. The plugin injects a container, fetches data via AJAX, and renders a card grid automatically.

## How It Works

1. The shortcode registers the target URL and outputs the frontend container.
2. JavaScript posts the external URL to the `ps_scrape_products` WordPress AJAX action.
3. `PS_Scraper` (PHP) fetches the remote page with `wp_remote_get`, parses it with DOMDocument/XPath, and extracts up to 50 products.
4. JSON is returned and rendered instantly—no external dependencies.

## File Structure

```
product-scraping/
├── product-scraping.php
├── includes/
│   ├── class-ps-frontend.php
│   ├── class-ps-admin.php
│   ├── class-ps-scraper.php
│   ├── ps-scripts.js
│   ├── ps-admin.js
│   └── ps-style.css
├── templates/
│   ├── admin-settings.php
│   ├── admin-test.php
│   ├── admin-url-manager.php
│   └── admin-saved-products.php
└── docs (.md files)
```

## Requirements

- WordPress 5.0+
- PHP 7.4+
- DOMDocument/libxml (bundled with PHP)
- Outbound HTTP access from your hosting provider

## Troubleshooting

1. **Check WordPress AJAX** – Product Scraping → Test Scraping → System Check.
2. **Enable WP_DEBUG_LOG** – inspect `wp-content/debug.log` for PHP notices/errors.
3. **Browser Console** – F12 → Console/Network for failed fetches.
4. **Website Restrictions** – Some sites block automated scraping or require JavaScript-rendered content (not supported).
5. **Hosting Limits** – Ensure outbound HTTP requests are allowed by your host/firewall.

## Support

- WordPress debug log
- Browser console/network tab
- Confirm target URL is publicly reachable
- Ensure hosting allows outbound HTTP/HTTPS requests

## License

GPL v2 or later
