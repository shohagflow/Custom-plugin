<?php
/**
 * Plugin Name: Product Scraping
 * Plugin URI: https://example.com/product-scraping
 * Description: Display real-time product data from any external website using shortcode [product_scraping]. No external servers needed - works entirely in WordPress!
 * Version: 1.0.1
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: product-scraping
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('PS_VERSION', '1.0.1');
define('PS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PS_PLUGIN_FILE', __FILE__);

/**
 * Saved products helpers
 */
function ps_get_saved_products_index() {
    $index = get_option('ps_saved_products_index', null);
    
    // Migrate legacy storage if needed
    if (is_null($index)) {
        $legacy = get_option('ps_saved_products', array());
        $index = array();
        
        if (!empty($legacy) && is_array($legacy)) {
            foreach ($legacy as $entry) {
                $entry_id = isset($entry['id']) ? sanitize_text_field($entry['id']) : uniqid('ps_');
                $meta = array(
                    'id' => $entry_id,
                    'url' => isset($entry['url']) ? esc_url_raw($entry['url']) : '',
                    'name' => isset($entry['name']) ? sanitize_text_field($entry['name']) : '',
                    'count' => isset($entry['count']) ? intval($entry['count']) : 0,
                    'saved_at' => isset($entry['saved_at']) ? sanitize_text_field($entry['saved_at']) : current_time('mysql'),
                );
                
                $index[] = $meta;
                $products = isset($entry['products']) && is_array($entry['products']) ? $entry['products'] : array();
                update_option('ps_saved_products_items_' . $entry_id, $products, false);
            }
            delete_option('ps_saved_products');
        }
        
        add_option('ps_saved_products_index', $index, '', 'no');
    }
    
    if (!is_array($index)) {
        $index = array();
        update_option('ps_saved_products_index', $index, false);
    }
    
    return $index;
}

function ps_save_products_index($index) {
    update_option('ps_saved_products_index', array_values($index), false);
}

function ps_save_products_data($id, $products) {
    update_option('ps_saved_products_items_' . $id, $products, false);
}

function ps_get_saved_products_data($id) {
    $data = get_option('ps_saved_products_items_' . $id, array());
    return is_array($data) ? $data : array();
}

function ps_delete_saved_products_data($id) {
    delete_option('ps_saved_products_items_' . $id);
}

/**
 * Main plugin class
 */
class Product_Scraping {
    
    /**
     * Instance of this class
     */
    private static $instance = null;
    
    /**
     * Get instance of this class
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init();
    }
    
    /**
     * Initialize plugin
     */
    private function init() {
        // Include required files
        $this->includes();
        
        // Initialize hooks
        $this->init_hooks();
    }
    
    /**
     * Include required files
     */
    private function includes() {
        require_once PS_PLUGIN_DIR . 'includes/class-ps-scraper.php';
        require_once PS_PLUGIN_DIR . 'includes/class-ps-frontend.php';
        
        // Load admin only in admin area
        if (is_admin()) {
            require_once PS_PLUGIN_DIR . 'includes/class-ps-admin.php';
        }
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Register shortcode
        add_shortcode('product_scraping', array($this, 'render_shortcode'));
        add_shortcode('product_scraping_group', array($this, 'render_group_shortcode'));
        add_shortcode('product_scraping_featured', array($this, 'render_featured_shortcode'));
        add_shortcode('product_scraping_search', array($this, 'render_search_shortcode'));
        
        // Register AJAX endpoints
        add_action('wp_ajax_ps_scrape_products', array($this, 'ajax_scrape_products'));
        add_action('wp_ajax_nopriv_ps_scrape_products', array($this, 'ajax_scrape_products'));
        add_action('wp_ajax_ps_save_products', array($this, 'ajax_save_products'));
        add_action('wp_ajax_ps_save_products_chunk', array($this, 'ajax_save_products_chunk'));
        add_action('wp_ajax_ps_get_saved_products', array($this, 'ajax_get_saved_products'));
        add_action('wp_ajax_ps_test_url_group', array($this, 'ajax_test_url_group'));
        add_action('wp_ajax_ps_search_all_products', array($this, 'ajax_search_all_products'));
        add_action('wp_ajax_nopriv_ps_search_all_products', array($this, 'ajax_search_all_products'));
        
        // Initialize admin
        if (is_admin()) {
            new PS_Admin();
        }
    }
    
    /**
     * AJAX handler for scraping products
     */
    public function ajax_scrape_products() {
        // Verify nonce
        check_ajax_referer('ps_scrape_nonce', 'nonce');
        
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        
        if (empty($url)) {
            wp_send_json_error(array('message' => 'URL is required'));
            return;
        }
        
        // Scrape products
        $result = PS_Scraper::scrape_products($url);
        
        if ($result['status'] === 'ok') {
            wp_send_json_success($result);
        } else {
            wp_send_json_error(array('message' => $result['message']));
        }
    }
    
    /**
     * AJAX handler for saving products
     */
    public function ajax_save_products() {
        // Verify nonce
        check_ajax_referer('ps_scrape_nonce', 'nonce');
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
            return;
        }
        
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        $products_json = isset($_POST['products']) ? stripslashes($_POST['products']) : '';
        
        if (empty($products_json)) {
            wp_send_json_error(array('message' => 'No products to save'));
            return;
        }
        
        $products = json_decode($products_json, true);
        
        if (!is_array($products) || empty($products)) {
            wp_send_json_error(array('message' => 'Invalid products data'));
            return;
        }
        
        $saved_products = ps_get_saved_products_index();
        
        // Create entry metadata
        $entry = array(
            'id' => uniqid('ps_'),
            'url' => $url,
            'name' => $url,
            'count' => count($products),
            'saved_at' => current_time('mysql'),
        );
        
        // Prepend for convenience (newest first)
        array_unshift($saved_products, $entry);
        
        // Persist metadata + product data separately
        ps_save_products_index($saved_products);
        ps_save_products_data($entry['id'], $products);
        
        wp_send_json_success(array(
            'message' => 'Products saved successfully!',
            'id' => $entry['id'],
            'count' => count($products)
        ));
    }

    /**
     * AJAX handler for chunked saving
     */
    public function ajax_save_products_chunk() {
        check_ajax_referer('ps_scrape_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
            return;
        }
        
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        if (empty($url)) {
            wp_send_json_error(array('message' => 'URL is required'));
            return;
        }
        
        $session_id = isset($_POST['sessionId']) ? sanitize_text_field($_POST['sessionId']) : uniqid('ps_');
        
        $chunk_index = isset($_POST['chunkIndex']) ? intval($_POST['chunkIndex']) : 0;
        $total_chunks = isset($_POST['totalChunks']) ? max(1, intval($_POST['totalChunks'])) : 1;
        $is_final_chunk = ($chunk_index >= $total_chunks - 1);
        $total_products = isset($_POST['totalProducts']) ? intval($_POST['totalProducts']) : 0;
        
        $products_json = isset($_POST['products']) ? stripslashes($_POST['products']) : '';
        if (empty($products_json)) {
            wp_send_json_error(array('message' => 'Chunk data missing'));
            return;
        }
        
        $products_chunk = json_decode($products_json, true);
        if (!is_array($products_chunk)) {
            wp_send_json_error(array('message' => 'Invalid chunk data'));
            return;
        }
        
        $pending_option = 'ps_saved_products_pending_' . $session_id;
        
        if ($chunk_index === 0) {
            $pending_meta = array(
                'id' => $session_id,
                'url' => $url,
                'name' => $url,
                'saved_at' => current_time('mysql'),
                'expected_total' => $total_products > 0 ? $total_products : count($products_chunk),
            );
            update_option($pending_option, $pending_meta, false);
            update_option('ps_saved_products_items_' . $session_id, array(), false);
        } else {
            $pending_meta = get_option($pending_option, false);
            if (!$pending_meta) {
                wp_send_json_error(array('message' => 'Save session expired. Please try again.'));
                return;
            }
        }
        
        $existing = get_option('ps_saved_products_items_' . $session_id, array());
        if (!is_array($existing)) {
            $existing = array();
        }
        
        $existing = array_merge($existing, $products_chunk);
        update_option('ps_saved_products_items_' . $session_id, $existing, false);
        $current_count = count($existing);
        
        if ($total_products > 0) {
            $pending_meta['expected_total'] = $total_products;
            update_option($pending_option, $pending_meta, false);
        }
        
        if ($is_final_chunk) {
            $pending_meta = get_option($pending_option, array(
                'id' => $session_id,
                'url' => $url,
                'name' => $url,
                'saved_at' => current_time('mysql'),
                'expected_total' => $current_count,
            ));
            delete_option($pending_option);
            
            $entry = array(
                'id' => $session_id,
                'url' => $pending_meta['url'],
                'name' => $pending_meta['name'],
                'count' => $current_count,
                'saved_at' => $pending_meta['saved_at'],
            );
            
            $saved_products = ps_get_saved_products_index();
            array_unshift($saved_products, $entry);
            ps_save_products_index($saved_products);
            
            wp_send_json_success(array(
                'message' => 'Products saved successfully!',
                'id' => $session_id,
                'count' => $entry['count'],
                'processed' => $current_count,
                'total' => $pending_meta['expected_total'],
                'completed' => true,
            ));
        } else {
            wp_send_json_success(array(
                'message' => 'Chunk saved',
                'id' => $session_id,
                'processed' => $current_count,
                'total' => !empty($pending_meta['expected_total']) ? intval($pending_meta['expected_total']) : $current_count,
                'chunkIndex' => $chunk_index,
                'totalChunks' => $total_chunks,
                'completed' => false,
            ));
        }
    }
    
    /**
     * AJAX handler for getting saved products
     */
    public function ajax_get_saved_products() {
        // Verify nonce
        check_ajax_referer('ps_scrape_nonce', 'nonce');
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
            return;
        }
        
        $id = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : '';
        
        if (empty($id)) {
            wp_send_json_error(array('message' => 'ID is required'));
            return;
        }
        
        $saved_products = ps_get_saved_products_index();
        
        foreach ($saved_products as $saved) {
            if (isset($saved['id']) && $saved['id'] === $id) {
                wp_send_json_success(array(
                    'products' => ps_get_saved_products_data($id),
                    'url' => $saved['url'],
                    'name' => $saved['name']
                ));
                return;
            }
        }
        
        wp_send_json_error(array('message' => 'Saved products not found'));
    }
    
    /**
     * Render shortcode
     */
    public function render_shortcode($atts) {
        // Parse shortcode attributes
        $atts = shortcode_atts(array(
            'url' => '',
        ), $atts, 'product_scraping');
        
        $frontend = new PS_Frontend();
        return $frontend->render_products($atts['url']);
    }

    /**
     * Render group shortcode: merge products from multiple URLs under one filter
     */
    public function render_group_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => '',
        ), $atts, 'product_scraping_group');

        $group_id = sanitize_text_field($atts['id']);
        if (empty($group_id)) {
            return '';
        }

        $groups = get_option('ps_url_groups', array());
        if (!is_array($groups) || empty($groups)) {
            return '';
        }

        $urls = array();
        foreach ($groups as $group) {
            if (isset($group['id']) && $group['id'] === $group_id && !empty($group['urls']) && is_array($group['urls'])) {
                foreach ($group['urls'] as $url) {
                    $clean = esc_url_raw($url);
                    if (!empty($clean)) {
                        $urls[] = $clean;
                    }
                }
                break;
            }
        }

        if (empty($urls)) {
            return '';
        }

        $frontend = new PS_Frontend();
        return $frontend->render_products_group($urls);
    }

    /**
     * Render featured shortcode: limited products from a group, no filters
     *
     * Usage: [product_scraping_featured id="ps_group_xxx" limit="4"]
     */
    public function render_featured_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id'    => '',
            'limit' => 4,
            'columns' => 4,
        ), $atts, 'product_scraping_featured');

        $group_id = sanitize_text_field($atts['id']);
        $limit    = max(1, intval($atts['limit']));
        $columns  = max(1, intval($atts['columns']));

        if (empty($group_id)) {
            return '';
        }

        $groups = get_option('ps_url_groups', array());
        if (!is_array($groups) || empty($groups)) {
            return '';
        }

        $urls = array();
        foreach ($groups as $group) {
            if (isset($group['id']) && $group['id'] === $group_id && !empty($group['urls']) && is_array($group['urls'])) {
                foreach ($group['urls'] as $url) {
                    $clean = esc_url_raw($url);
                    if (!empty($clean)) {
                        $urls[] = $clean;
                    }
                }
                break;
            }
        }

        if (empty($urls)) {
            return '';
        }

        $frontend = new PS_Frontend();
        return $frontend->render_products_group_featured($urls, $limit, $columns);
    }

    /**
     * Render search bar shortcode: standalone search bar for header
     *
     * Usage: [product_scraping_search]
     */
    public function render_search_shortcode($atts) {
        $frontend = new PS_Frontend();
        return $frontend->render_search_bar();
    }

    /**
     * AJAX handler to test URL group and return product counts per URL
     */
    public function ajax_test_url_group() {
        check_ajax_referer('ps_scrape_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
            return;
        }
        
        $group_id = isset($_POST['group_id']) ? sanitize_text_field($_POST['group_id']) : '';
        if (empty($group_id)) {
            wp_send_json_error(array('message' => 'Group ID is required'));
            return;
        }
        
        $groups = get_option('ps_url_groups', array());
        if (!is_array($groups) || empty($groups)) {
            wp_send_json_error(array('message' => 'No URL groups found'));
            return;
        }
        
        $urls = array();
        $group_name = '';
        foreach ($groups as $group) {
            if (isset($group['id']) && $group['id'] === $group_id && !empty($group['urls']) && is_array($group['urls'])) {
                $group_name = isset($group['name']) ? $group['name'] : $group_id;
                foreach ($group['urls'] as $url) {
                    $clean = esc_url_raw($url);
                    if (!empty($clean)) {
                        $urls[] = $clean;
                    }
                }
                break;
            }
        }
        
        if (empty($urls)) {
            wp_send_json_error(array('message' => 'URL group not found or has no URLs'));
            return;
        }
        
        // Test each URL and get product counts
        $results = array();
        $total_products = 0;
        
        foreach ($urls as $url) {
            $scrape_result = PS_Scraper::scrape_products($url);
            $count = 0;
            $status = 'error';
            $message = '';
            
            if ($scrape_result && isset($scrape_result['status']) && $scrape_result['status'] === 'ok') {
                $count = isset($scrape_result['count']) ? intval($scrape_result['count']) : (isset($scrape_result['products']) && is_array($scrape_result['products']) ? count($scrape_result['products']) : 0);
                $status = 'ok';
                $total_products += $count;
            } else {
                $message = isset($scrape_result['message']) ? $scrape_result['message'] : 'Failed to scrape products';
            }
            
            $results[] = array(
                'url' => $url,
                'count' => $count,
                'status' => $status,
                'message' => $message
            );
        }
        
            wp_send_json_success(array(
                'group_name' => $group_name,
                'group_id' => $group_id,
                'total_products' => $total_products,
                'urls' => $results
            ));
    }

    /**
     * AJAX handler to search products from all URL groups
     * Works on any page, even if products aren't loaded
     */
    public function ajax_search_all_products() {
        check_ajax_referer('ps_scrape_nonce', 'nonce');
        
        $search_query = isset($_POST['search_query']) ? sanitize_text_field($_POST['search_query']) : '';
        
        if (empty($search_query)) {
            wp_send_json_success(array('products' => array()));
            return;
        }
        
        $search_query_lower = strtolower($search_query);
        $all_products = array();
        
        // Get all URL groups
        $groups = get_option('ps_url_groups', array());
        
        if (!is_array($groups) || empty($groups)) {
            wp_send_json_success(array('products' => array()));
            return;
        }
        
        // Collect all URLs from all groups
        $all_urls = array();
        foreach ($groups as $group) {
            if (!empty($group['urls']) && is_array($group['urls'])) {
                foreach ($group['urls'] as $url) {
                    $clean = esc_url_raw($url);
                    if (!empty($clean) && !in_array($clean, $all_urls)) {
                        $all_urls[] = $clean;
                    }
                }
            }
        }
        
        // Fetch products from each URL (limit to first 3 URLs for performance)
        $urls_to_search = array_slice($all_urls, 0, 3);
        $products_found = 0;
        $max_products = 20; // Limit total products for search
        
        foreach ($urls_to_search as $url) {
            if ($products_found >= $max_products) {
                break;
            }
            
            $scrape_result = PS_Scraper::scrape_products($url);
            
            if ($scrape_result && isset($scrape_result['status']) && $scrape_result['status'] === 'ok') {
                $products = isset($scrape_result['products']) ? $scrape_result['products'] : array();
                
                foreach ($products as $product) {
                    if ($products_found >= $max_products) {
                        break 2;
                    }
                    
                    // Search in product data
                    $search_text = (
                        (isset($product['title']) ? $product['title'] : '') . ' ' .
                        (isset($product['brand']) ? $product['brand'] : '') . ' ' .
                        (isset($product['category']) ? $product['category'] : '') . ' ' .
                        (isset($product['description']) ? $product['description'] : '')
                    );
                    
                    if (stripos($search_text, $search_query_lower) !== false) {
                        $all_products[] = $product;
                        $products_found++;
                    }
                }
            }
        }
        
        wp_send_json_success(array('products' => $all_products));
    }
}

/**
 * Initialize the plugin
 */
function product_scraping_init() {
    return Product_Scraping::get_instance();
}

// Start the plugin
product_scraping_init();

